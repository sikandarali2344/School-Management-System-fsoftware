<?php
require_once "config.php";

if (!isset($_GET['class_id']) || empty($_GET['class_id'])) {
    exit;
}

$class_id = intval($_GET['class_id']);

/*
students table structure (as you shared):
id
user_id
class
parent_name
parent_contact
status
email
phone
address
created_at
class_id
*/

// Fetch students of selected class
$stmt = $pdo->prepare("
    SELECT s.id, u.name
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.class_id = ?
    ORDER BY u.name ASC
");
$stmt->execute([$class_id]);
$students = $stmt->fetchAll();
?>

<label>Select Student</label>
<select name="student_id" required>
    <option value="">-- Select Student --</option>

    <?php if(count($students) > 0): ?>
        <?php foreach($students as $st): ?>
            <option value="<?= $st['id'] ?>">
                <?= htmlspecialchars($st['name']) ?>
            </option>
        <?php endforeach; ?>
    <?php else: ?>
        <option value="">No students found</option>
    <?php endif; ?>

</select>
