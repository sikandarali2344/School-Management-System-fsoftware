<?php
require_once 'config.php';

class NotificationController {
    private $conn;
    
    public function __construct() {
        $this->conn = new mysqli('localhost', 'root', '', 'edumanage');
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // Send new notification
    public function sendNotification($data) {
        $title = $this->conn->real_escape_string($data['title']);
        $message = $this->conn->real_escape_string($data['message']);
        $type = $this->conn->real_escape_string($data['type']);
        $target = $this->conn->real_escape_string($data['target']);
        $sender_id = (int)$data['sender_id'];
        $sender_role = $this->conn->real_escape_string($data['sender_role'] ?? 'admin');
        $attachment = isset($data['attachment']) ? $this->conn->real_escape_string($data['attachment']) : null;

        $sql = "INSERT INTO school_notifications (title, message, notification_type, target_audience, attachment_path, sender_id, sender_role) 
                VALUES ('$title', '$message', '$type', '$target', '$attachment', $sender_id, '$sender_role')";

        if ($this->conn->query($sql)) {
            $notification_id = $this->conn->insert_id;

            if ($target === 'specific' && isset($data['recipients'])) {
                $this->addRecipients($notification_id, $data['recipients']);
            }

            $this->createUserNotifications($notification_id, $target, $data['recipients'] ?? []);
            return ['success' => true, 'id' => $notification_id];
        }

        return ['success' => false, 'error' => $this->conn->error];
    }

    private function addRecipients($notification_id, $recipients) {
        foreach ($recipients as $recipient) {
            $user_id = (int)$recipient['id'];
            $user_role = $this->conn->real_escape_string($recipient['role']);
            $sql = "INSERT INTO notification_recipients (notification_id, user_id, user_role) 
                    VALUES ($notification_id, $user_id, '$user_role')";
            $this->conn->query($sql);
        }
    }

    private function createUserNotifications($notification_id, $target, $recipients) {
        switch ($target) {
            case 'all':
                $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                        SELECT id, $notification_id FROM users WHERE is_active = 1";
                break;
            case 'students':
                $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                        SELECT id, $notification_id FROM users WHERE role = 'student' AND is_active = 1";
                break;
            case 'teachers':
                $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                        SELECT id, $notification_id FROM users WHERE role = 'teacher' AND is_active = 1";
                break;
            case 'specific':
                if (!empty($recipients)) {
                    $user_ids = array_column($recipients, 'id');
                    $ids_str = implode(',', $user_ids);
                    $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                            SELECT id, $notification_id FROM users WHERE id IN ($ids_str)";
                } else return;
                break;
            default: return;
        }
        $this->conn->query($sql);
    }

    public function getUserNotifications($user_id, $user_role, $limit = 20) {
        $user_id = (int)$user_id;
        $limit = (int)$limit;

        $sql = "SELECT DISTINCT n.*, un.is_read, un.read_at 
                FROM school_notifications n
                LEFT JOIN user_notifications un ON n.id = un.notification_id AND un.user_id = $user_id
                LEFT JOIN notification_recipients nr ON n.id = nr.notification_id
                WHERE n.is_active = 1 
                AND (
                    n.target_audience = 'all' 
                    OR (n.target_audience = 'students' AND '$user_role' = 'student')
                    OR (n.target_audience = 'teachers' AND '$user_role' = 'teacher')
                    OR (n.target_audience = 'specific' AND nr.user_id = $user_id)
                    OR ('$user_role' = 'admin')
                )
                ORDER BY n.created_at DESC 
                LIMIT $limit";

        $result = $this->conn->query($sql);
        $notifications = [];
        while ($row = $result->fetch_assoc()) $notifications[] = $row;
        return $notifications;
    }

    public function markAsRead($user_id, $notification_id) {
        $user_id = (int)$user_id;
        $notification_id = (int)$notification_id;
        $sql = "UPDATE user_notifications 
                SET is_read = TRUE, read_at = NOW() 
                WHERE user_id = $user_id AND notification_id = $notification_id";
        return $this->conn->query($sql);
    }

    public function getUnreadCount($user_id) {
        $user_id = (int)$user_id;
        $sql = "SELECT COUNT(*) as count 
                FROM user_notifications 
                WHERE user_id = $user_id AND is_read = FALSE";
        $result = $this->conn->query($sql);
        return $result->fetch_assoc()['count'];
    }

    public function getAllUsers($exclude_admin = false) {
        $sql = "SELECT id, name, email, role FROM users WHERE is_active = 1";
        if ($exclude_admin) $sql .= " AND role != 'admin'";
        $result = $this->conn->query($sql);
        $users = [];
        while ($row = $result->fetch_assoc()) $users[] = $row;
        return $users;
    }

    public function downloadAttachment($notification_id) {
        $notification_id = (int)$notification_id;
        $sql = "SELECT attachment_path FROM school_notifications WHERE id = $notification_id";
        $result = $this->conn->query($sql);
        return $result->fetch_assoc()['attachment_path'] ?? null;
    }

    public function __destruct() {
        $this->conn->close();
    }
}
?>
