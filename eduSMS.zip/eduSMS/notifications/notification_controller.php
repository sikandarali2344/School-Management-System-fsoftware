<?php
// notifications/notification_controller.php

class NotificationController {
    private $conn;
    
    public function __construct() {
        // Create connection directly
        $this->conn = new mysqli('localhost', 'root', '', 'edumanage');
        
        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }
    
    // Send new notification - FIXED VERSION
    public function sendNotification($data) {
        // Debug: Print received data
        error_log("Sending notification with data: " . print_r($data, true));
        
        // Validate required fields
        if (empty($data['title']) || empty($data['message'])) {
            return ['success' => false, 'error' => 'Title and message are required'];
        }
        
        // Escape inputs
        $title = $this->conn->real_escape_string($data['title']);
        $message = $this->conn->real_escape_string($data['message']);
        $type = $this->conn->real_escape_string($data['type'] ?? 'announcement');
        $target = $this->conn->real_escape_string($data['target'] ?? 'all');
        $sender_id = (int)$data['sender_id'];
        $sender_role = $this->conn->real_escape_string($data['sender_role'] ?? 'admin');
        $attachment = isset($data['attachment']) ? $this->conn->real_escape_string($data['attachment']) : null;
        
        // Get sender name
        $sender_name = 'System';
        $user_sql = "SELECT name FROM users WHERE id = $sender_id";
        $user_result = $this->conn->query($user_sql);
        if ($user_result && $user_result->num_rows > 0) {
            $sender_name = $user_result->fetch_assoc()['name'];
        }
        
        // Insert into notifications table
        $sql = "INSERT INTO school_notifications 
                (title, message, notification_type, target_audience, attachment_path, sender_id, sender_name, sender_role) 
                VALUES ('$title', '$message', '$type', '$target', '$attachment', $sender_id, '$sender_name', '$sender_role')";
        
        error_log("SQL Query: " . $sql);
        
        if ($this->conn->query($sql)) {
            $notification_id = $this->conn->insert_id;
            error_log("Notification inserted with ID: " . $notification_id);
            
            // Handle specific recipients
            if ($target === 'specific' && isset($data['recipients']) && !empty($data['recipients'])) {
                error_log("Adding recipients: " . print_r($data['recipients'], true));
                $this->addRecipients($notification_id, $data['recipients']);
            }
            
            // Create user notification records
            error_log("Creating user notifications for target: " . $target);
            $this->createUserNotifications($notification_id, $target, $data['recipients'] ?? []);
            
            return ['success' => true, 'id' => $notification_id];
        }
        
        $error = $this->conn->error;
        error_log("Database error: " . $error);
        return ['success' => false, 'error' => 'Database error: ' . $error];
    }
    
    // Add specific recipients - FIXED
    private function addRecipients($notification_id, $recipients) {
        foreach ($recipients as $recipient) {
            $user_id = (int)$recipient['id'];
            
            // Get user role
            $role_sql = "SELECT role FROM users WHERE id = $user_id";
            $role_result = $this->conn->query($role_sql);
            $user_role = 'student';
            if ($role_result && $role_result->num_rows > 0) {
                $user_role = $role_result->fetch_assoc()['role'];
            }
            
            $sql = "INSERT INTO notification_recipients (notification_id, user_id, user_role) 
                    VALUES ($notification_id, $user_id, '$user_role')";
            $this->conn->query($sql);
        }
    }
    
    // Create user notification records - FIXED
    private function createUserNotifications($notification_id, $target, $recipients) {
        $sql = "";
        
        switch ($target) {
            case 'all':
                $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                        SELECT id, $notification_id FROM users WHERE is_active = 1";
                break;
                
            case 'students':
                $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                        SELECT id, $notification_id FROM users WHERE role = 'student' AND is_active = 1";
                break;
                
            case 'teachers':
                $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                        SELECT id, $notification_id FROM users WHERE role = 'teacher' AND is_active = 1";
                break;
                
            case 'specific':
                if (!empty($recipients)) {
                    $user_ids = array_column($recipients, 'id');
                    if (!empty($user_ids)) {
                        $ids_str = implode(',', $user_ids);
                        $sql = "INSERT INTO user_notifications (user_id, notification_id) 
                                SELECT id, $notification_id FROM users WHERE id IN ($ids_str) AND is_active = 1";
                    }
                }
                break;
        }
        
        if (!empty($sql)) {
            error_log("User notification SQL: " . $sql);
            $result = $this->conn->query($sql);
            if (!$result) {
                error_log("Error creating user notifications: " . $this->conn->error);
            }
        }
    }
    
    // Get notifications for a user - FIXED
    public function getUserNotifications($user_id, $user_role, $limit = 20) {
        $user_id = (int)$user_id;
        $limit = (int)$limit;
        
        $sql = "SELECT DISTINCT 
                    n.*, 
                    COALESCE(un.is_read, 0) as is_read, 
                    un.read_at 
                FROM school_notifications n
                LEFT JOIN user_notifications un ON n.id = un.notification_id AND un.user_id = $user_id
                LEFT JOIN notification_recipients nr ON n.id = nr.notification_id AND nr.user_id = $user_id
                WHERE n.is_active = 1 
                AND (
                    n.target_audience = 'all' 
                    OR (n.target_audience = 'students' AND '$user_role' = 'student')
                    OR (n.target_audience = 'teachers' AND '$user_role' = 'teacher')
                    OR (n.target_audience = 'specific' AND nr.user_id = $user_id)
                    OR ('$user_role' = 'admin')
                )
                ORDER BY n.created_at DESC 
                LIMIT $limit";
        
        error_log("Get notifications SQL: " . $sql);
        $result = $this->conn->query($sql);
        $notifications = [];
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $notifications[] = $row;
            }
        } else {
            error_log("Error getting notifications: " . $this->conn->error);
        }
        
        return $notifications;
    }
    
    // Mark notification as read - FIXED
    public function markAsRead($user_id, $notification_id) {
        $user_id = (int)$user_id;
        $notification_id = (int)$notification_id;
        
        // Check if record exists
        $check_sql = "SELECT id FROM user_notifications 
                      WHERE user_id = $user_id AND notification_id = $notification_id";
        $result = $this->conn->query($check_sql);
        
        if ($result->num_rows > 0) {
            // Update existing record
            $sql = "UPDATE user_notifications 
                    SET is_read = TRUE, read_at = NOW() 
                    WHERE user_id = $user_id AND notification_id = $notification_id";
        } else {
            // Insert new record
            $sql = "INSERT INTO user_notifications (user_id, notification_id, is_read, read_at) 
                    VALUES ($user_id, $notification_id, TRUE, NOW())";
        }
        
        $success = $this->conn->query($sql);
        if (!$success) {
            error_log("Error marking as read: " . $this->conn->error);
        }
        
        return $success;
    }
    
    // Get unread count - FIXED
    public function getUnreadCount($user_id) {
        $user_id = (int)$user_id;
        
        $sql = "SELECT COUNT(*) as count 
                FROM user_notifications 
                WHERE user_id = $user_id AND is_read = FALSE";
        
        $result = $this->conn->query($sql);
        if ($result) {
            $row = $result->fetch_assoc();
            return $row['count'] ?? 0;
        }
        
        return 0;
    }
    
    // Get all users for dropdown
    public function getAllUsers($exclude_admin = false) {
        $sql = "SELECT id, name, email, role FROM users WHERE is_active = 1";
        
        if ($exclude_admin) {
            $sql .= " AND role != 'admin'";
        }
        
        $sql .= " ORDER BY name ASC";
        
        $result = $this->conn->query($sql);
        $users = [];
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
        
        return $users;
    }
    
    // Download attachment
    public function downloadAttachment($notification_id) {
        $notification_id = (int)$notification_id;
        
        $sql = "SELECT attachment_path FROM school_notifications WHERE id = $notification_id";
        $result = $this->conn->query($sql);
        
        if ($result && $row = $result->fetch_assoc()) {
            return $row['attachment_path'];
        }
        
        return null;
    }
    
    // Create notification tables if they don't exist
    private function createTables() {
        $tables = [
            "CREATE TABLE IF NOT EXISTS school_notifications (
                id INT PRIMARY KEY AUTO_INCREMENT,
                title VARCHAR(255) NOT NULL,
                message TEXT NOT NULL,
                notification_type VARCHAR(50) DEFAULT 'announcement',
                target_audience VARCHAR(50) NOT NULL,
                attachment_path VARCHAR(500),
                sender_id INT NOT NULL,
                sender_name VARCHAR(100) NOT NULL,
                sender_role VARCHAR(50) NOT NULL,
                is_active BOOLEAN DEFAULT TRUE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )",
            
            "CREATE TABLE IF NOT EXISTS user_notifications (
                id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT NOT NULL,
                notification_id INT NOT NULL,
                is_read BOOLEAN DEFAULT FALSE,
                read_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY unique_user_notification (user_id, notification_id)
            )",
            
            "CREATE TABLE IF NOT EXISTS notification_recipients (
                id INT PRIMARY KEY AUTO_INCREMENT,
                notification_id INT NOT NULL,
                user_id INT NOT NULL,
                user_role VARCHAR(50) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )"
        ];
        
        foreach ($tables as $table_sql) {
            $this->conn->query($table_sql);
        }
    }
    
    public function __destruct() {
        $this->conn->close();
    }
}
?>