<?php
// notifications/notification_router.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/notification_controller.php';

$controller = new NotificationController();

// Current user
$current_user = [
    'id'       => $_SESSION['user_id'] ?? null,
    'username' => $_SESSION['username'] ?? null,
    'role'     => $_SESSION['role'] ?? null,
    'name'     => $_SESSION['name'] ?? 'User'
];

if (!$current_user['id']) {
    echo "<div class='alert alert-danger'>Please login first</div>";
    exit;
}

$action = $_GET['action'] ?? 'view';

// Handle POST requests first
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'send') {
    header('Content-Type: application/json');
    
    if ($current_user['role'] !== 'admin') {
        echo json_encode(['success' => false, 'error' => 'Access denied. Admin only.']);
        exit;
    }

    // Handle file upload
    $attachment_path = null;
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = __DIR__ . '/../uploads/notifications/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = time() . '_' . preg_replace('/[^a-zA-Z0-9\._-]/', '_', $_FILES['attachment']['name']);
        $target_file = $upload_dir . $file_name;
        
        $allowed_types = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
        $file_ext = strtolower(pathinfo($_FILES['attachment']['name'], PATHINFO_EXTENSION));
        
        if (in_array($file_ext, $allowed_types)) {
            if (move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file)) {
                $attachment_path = $target_file;
            }
        }
    }

    // Prepare notification data
    $data = [
        'title' => $_POST['title'] ?? '',
        'message' => $_POST['message'] ?? '',
        'type' => $_POST['type'] ?? 'announcement',
        'target' => $_POST['target'] ?? 'all',
        'sender_id' => $current_user['id'],
        'sender_role' => $current_user['role'],
        'attachment' => $attachment_path
    ];

    // Handle specific recipients
    if ($_POST['target'] === 'specific' && isset($_POST['users'])) {
        $recipients = is_array($_POST['users']) ? $_POST['users'] : $_POST['users'];
        $data['recipients'] = [];
        
        foreach ($recipients as $user_id) {
            $data['recipients'][] = ['id' => (int)$user_id];
        }
    }

    // Send notification
    $result = $controller->sendNotification($data);
    
    echo json_encode($result);
    exit;
}

// Handle GET requests
switch ($action) {

    /* =========================
       VIEW NOTIFICATIONS
    ==========================*/
    case 'view':
        ?>
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Notifications - School System</title>
            
            <!-- Bootstrap 5 CSS -->
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            
            <!-- Font Awesome -->
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            
            <style>
            body {
                background: #f8f9fa;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                padding: 20px;
            }
            
            .notification-container {
                max-width: 1000px;
                margin: 0 auto;
                background: white;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                overflow: hidden;
            }
            
            .notification-header {
                background: linear-gradient(135deg, #0d6efd 0%, #0b5ed7 100%);
                color: white;
                padding: 30px;
                text-align: center;
            }
            
            .notification-tabs {
                display: flex;
                background: #f8f9fa;
                border-bottom: 2px solid #dee2e6;
            }
            
            .notification-tab {
                padding: 15px 30px;
                cursor: pointer;
                font-weight: 600;
                color: #6c757d;
                transition: all 0.3s;
                border-bottom: 3px solid transparent;
                flex: 1;
                text-align: center;
            }
            
            .notification-tab:hover {
                background: #e9ecef;
                color: #495057;
            }
            
            .notification-tab.active {
                color: #0d6efd;
                border-bottom-color: #0d6efd;
                background: white;
            }
            
            .tab-content {
                padding: 30px;
                display: none;
            }
            
            .tab-content.active {
                display: block;
                animation: fadeIn 0.5s ease;
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .notification-card {
                border-radius: 10px;
                border: 1px solid #dee2e6;
                margin-bottom: 20px;
                transition: all 0.3s;
            }
            
            .notification-card:hover {
                box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                transform: translateY(-2px);
            }
            
            .notification-card.unread {
                border-left: 4px solid #0d6efd;
                background: #f8fbff;
            }
            
            .badge-type {
                position: absolute;
                top: 15px;
                right: 15px;
                padding: 5px 10px;
                border-radius: 20px;
                font-size: 0.8rem;
                font-weight: 600;
            }
            
            .user-selector {
                max-height: 300px;
                overflow-y: auto;
                border: 1px solid #dee2e6;
                border-radius: 8px;
                padding: 15px;
            }
            
            .user-option {
                padding: 10px;
                margin-bottom: 5px;
                border-radius: 5px;
                cursor: pointer;
                transition: all 0.3s;
            }
            
            .user-option:hover {
                background: #f8f9fa;
            }
            
            .user-option.selected {
                background: rgba(13, 110, 253, 0.1);
                border: 1px solid #0d6efd;
            }
            
            .loader {
                border: 4px solid #f3f3f3;
                border-top: 4px solid #0d6efd;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
                margin: 30px auto;
            }
            
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            </style>
        </head>
        <body>
            <div class="notification-container">
                <!-- Header -->
                <div class="notification-header">
                    <h1><i class="fas fa-bell"></i> School Notification System</h1>
                    <p>Stay updated with important announcements and notifications</p>
                    <div class="mt-3">
                        <span class="badge bg-light text-dark">
                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($current_user['name']); ?>
                            (<?php echo ucfirst($current_user['role']); ?>)
                        </span>
                        <span class="badge bg-warning ms-2" id="unreadBadge">
                            <i class="fas fa-envelope"></i> 
                            <span id="unreadCount"><?php echo $controller->getUnreadCount($current_user['id']); ?></span> unread
                        </span>
                    </div>
                </div>
                
                <!-- Tabs -->
                <div class="notification-tabs">
                    <div class="notification-tab active" onclick="switchTab('view')">
                        <i class="fas fa-list"></i> View Notifications
                    </div>
                    <?php if ($current_user['role'] === 'admin'): ?>
                    <div class="notification-tab" onclick="switchTab('send')">
                        <i class="fas fa-paper-plane"></i> Send Notification
                    </div>
                    <?php endif; ?>
                    <div class="notification-tab" onclick="switchTab('settings')">
                        <i class="fas fa-cog"></i> Settings
                    </div>
                </div>
                
                <!-- View Notifications Tab -->
                <div id="view-tab" class="tab-content active">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2 class="mb-0">
                            <i class="fas fa-bell text-primary"></i> Recent Notifications
                        </h2>
                        <button class="btn btn-outline-primary" onclick="loadNotifications()">
                            <i class="fas fa-sync-alt"></i> Refresh
                        </button>
                    </div>
                    
                    <div id="notifications-list">
                        <?php
                        $notifications = $controller->getUserNotifications($current_user['id'], $current_user['role']);
                        
                        if (empty($notifications)) {
                            echo '<div class="text-center py-5">
                                    <i class="fas fa-bell-slash fa-3x text-muted mb-3"></i>
                                    <h4 class="text-muted">No notifications found</h4>
                                    <p class="text-muted">You\'re all caught up!</p>
                                  </div>';
                        } else {
                            foreach ($notifications as $n) {
                                $is_unread = !$n['is_read'];
                                $badge_class = '';
                                $badge_text = ucfirst($n['notification_type'] ?? 'announcement');
                                
                                switch($n['notification_type'] ?? 'announcement') {
                                    case 'holiday': $badge_class = 'bg-success'; break;
                                    case 'exam': $badge_class = 'bg-danger'; break;
                                    case 'event': $badge_class = 'bg-info'; break;
                                    default: $badge_class = 'bg-primary';
                                }
                                ?>
                                <div class="card notification-card <?php echo $is_unread ? 'unread' : ''; ?>" 
                                     data-id="<?php echo $n['id']; ?>">
                                    <div class="card-body position-relative">
                                        <span class="badge badge-type <?php echo $badge_class; ?>">
                                            <?php echo $badge_text; ?>
                                        </span>
                                        <h5 class="card-title"><?php echo htmlspecialchars($n['title']); ?></h5>
                                        <p class="card-text"><?php echo nl2br(htmlspecialchars($n['message'])); ?></p>
                                        
                                        <div class="d-flex justify-content-between align-items-center text-muted">
                                            <div>
                                                <small>
                                                    <i class="fas fa-user text-primary"></i>
                                                    <?php echo htmlspecialchars($n['sender_name'] ?? 'System'); ?>
                                                    &nbsp;•&nbsp;
                                                    <i class="fas fa-clock text-primary"></i>
                                                    <?php echo date('M d, Y h:i A', strtotime($n['created_at'])); ?>
                                                </small>
                                            </div>
                                            <div>
                                                <?php if ($is_unread): ?>
                                                    <button class="btn btn-sm btn-success mark-read-btn">
                                                        <i class="fas fa-check"></i> Mark as Read
                                                    </button>
                                                <?php else: ?>
                                                    <span class="text-success">
                                                        <i class="fas fa-check-circle"></i> Read
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <?php if (!empty($n['attachment_path'])): ?>
                                            <div class="mt-3">
                                                <a href="<?php echo $n['attachment_path']; ?>" 
                                                   target="_blank" 
                                                   class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-paperclip"></i> View Attachment
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </div>
                </div>
                
                <!-- Send Notification Tab (Admin Only) -->
                <?php if ($current_user['role'] === 'admin'): ?>
                <div id="send-tab" class="tab-content">
                    <h2 class="mb-4">
                        <i class="fas fa-paper-plane text-success"></i> Send New Notification
                    </h2>
                    
                    <form id="sendNotificationForm" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Title *</label>
                            <input type="text" name="title" class="form-control" required 
                                   placeholder="Enter notification title">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Message *</label>
                            <textarea name="message" class="form-control" rows="5" required 
                                      placeholder="Enter notification message"></textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Type</label>
                                <select name="type" class="form-select">
                                    <option value="announcement">📢 Announcement</option>
                                    <option value="holiday">🎉 Holiday</option>
                                    <option value="exam">📝 Exam</option>
                                    <option value="event">🎪 Event</option>
                                </select>
                            </div>

                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Send To *</label>
                                <select name="target" id="targetSelect" class="form-select" required>
                                    <option value="all">👥 All Users</option>
                                    <option value="students">🎓 Students</option>
                                    <option value="teachers">👨‍🏫 Teachers</option>
                                    <option value="specific">📍 Specific Users</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-3" id="specificUsers" style="display:none;">
                            <label class="form-label fw-bold">Select Users</label>
                            <div class="user-selector">
                                <?php
                                $users = $controller->getAllUsers();
                                if (empty($users)) {
                                    echo '<div class="alert alert-warning">No users found in the system.</div>';
                                } else {
                                    foreach ($users as $u) {
                                        echo '<div class="form-check user-option">';
                                        echo '<input class="form-check-input" type="checkbox" name="users[]" value="'.$u['id'].'" id="user_'.$u['id'].'">';
                                        echo '<label class="form-check-label" for="user_'.$u['id'].'">';
                                        echo htmlspecialchars($u['name']).' ('.$u['role'].')';
                                        echo '</label></div>';
                                    }
                                }
                                ?>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold">Attachment (Optional)</label>
                            <input type="file" name="attachment" class="form-control" 
                                   accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
                            <small class="text-muted">Max file size: 5MB. Allowed: JPG, PNG, PDF, DOC, DOCX</small>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg w-100">
                            <i class="fas fa-paper-plane"></i> SEND NOTIFICATION
                        </button>
                        
                        <div id="formMessage" class="mt-3"></div>
                    </form>
                </div>
                <?php endif; ?>
                
                <!-- Settings Tab -->
                <div id="settings-tab" class="tab-content">
                    <h2 class="mb-4">
                        <i class="fas fa-cog text-warning"></i> Notification Settings
                    </h2>
                    
                    <div class="card mb-3">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="fas fa-envelope text-primary"></i> Email Notifications
                            </h5>
                            <p class="card-text">Receive notifications via email</p>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" id="email-notifications" checked>
                                <label class="form-check-label" for="email-notifications">
                                    Enable Email Notifications
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="fas fa-bell text-success"></i> Push Notifications
                            </h5>
                            <p class="card-text">Receive browser notifications</p>
                            <button class="btn btn-primary" id="enable-push">
                                <i class="fas fa-bell"></i> Enable Push Notifications
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <script>
            // Tab switching function
            function switchTab(tabName) {
                // Hide all tabs
                document.querySelectorAll('.tab-content').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Show selected tab
                document.getElementById(tabName + '-tab').classList.add('active');
                
                // Update active tab indicator
                document.querySelectorAll('.notification-tab').forEach(tab => {
                    tab.classList.remove('active');
                });
                
                // Find and activate the clicked tab
                const tabs = document.querySelectorAll('.notification-tab');
                if (tabName === 'view') tabs[0].classList.add('active');
                if (tabName === 'send') tabs[1].classList.add('active');
                if (tabName === 'settings') tabs[tabs.length-1].classList.add('active');
            }
            
            // Target audience change
            const targetSelect = document.getElementById('targetSelect');
            if (targetSelect) {
                targetSelect.addEventListener('change', function() {
                    const specificUsers = document.getElementById('specificUsers');
                    specificUsers.style.display = this.value === 'specific' ? 'block' : 'none';
                    
                    // Uncheck all checkboxes when not in specific mode
                    if (this.value !== 'specific') {
                        document.querySelectorAll('.user-option input[type="checkbox"]').forEach(cb => {
                            cb.checked = false;
                            cb.closest('.user-option').classList.remove('selected');
                        });
                    }
                });
                
                // Initialize user selector
                document.querySelectorAll('.user-option').forEach(option => {
                    option.addEventListener('click', function(e) {
                        if (e.target.type !== 'checkbox') {
                            const checkbox = this.querySelector('input[type="checkbox"]');
                            checkbox.checked = !checkbox.checked;
                        }
                        
                        this.classList.toggle('selected', this.querySelector('input').checked);
                    });
                });
            }
            
            // Mark as read functionality
            document.addEventListener('click', function(e) {
                if (e.target.closest('.mark-read-btn')) {
                    const card = e.target.closest('.notification-card');
                    const notificationId = card.dataset.id;
                    markAsRead(notificationId, card);
                }
            });
            
            // Mark notification as read
            function markAsRead(notificationId, cardElement) {
                fetch('?action=mark_read&id=' + notificationId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Update UI
                            cardElement.classList.remove('unread');
                            const button = cardElement.querySelector('.mark-read-btn');
                            button.outerHTML = '<span class="text-success"><i class="fas fa-check-circle"></i> Read</span>';
                            
                            // Update unread count
                            updateUnreadCount();
                        }
                    });
            }
            
            // Update unread count
            function updateUnreadCount() {
                fetch('?action=unread_count')
                    .then(response => response.text())
                    .then(count => {
                        document.getElementById('unreadCount').textContent = count;
                        const badge = document.getElementById('unreadBadge');
                        
                        if (parseInt(count) > 0) {
                            badge.classList.remove('bg-light', 'text-dark');
                            badge.classList.add('bg-warning');
                        } else {
                            badge.classList.remove('bg-warning');
                            badge.classList.add('bg-light', 'text-dark');
                        }
                    });
            }
            
            // Form submission
            const sendNotificationForm = document.getElementById('sendNotificationForm');
            if (sendNotificationForm) {
                sendNotificationForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    
                    const form = this;
                    const submitBtn = form.querySelector('button[type="submit"]');
                    const originalText = submitBtn.innerHTML;
                    const formMessage = document.getElementById('formMessage');
                    
                    // Disable button and show loading
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
                    formMessage.innerHTML = '';
                    
                    const formData = new FormData(form);
                    
                    // Debug: Show form data
                    console.log('Form Data:');
                    for (let pair of formData.entries()) {
                        console.log(pair[0] + ': ' + pair[1]);
                    }
                    
                    // Send request
                    fetch('?action=send', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        console.log('Response:', data);
                        if (data.success) {
                            // Show success message
                            formMessage.innerHTML = '<div class="alert alert-success alert-dismissible fade show">' +
                                '<i class="fas fa-check-circle"></i> ✅ Notification sent successfully!' +
                                '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                                '</div>';
                            
                            // Reset form
                            form.reset();
                            document.getElementById('specificUsers').style.display = 'none';
                            if (targetSelect) targetSelect.value = 'all';
                            
                            // Uncheck all user selections
                            document.querySelectorAll('.user-option').forEach(option => {
                                option.classList.remove('selected');
                                const checkbox = option.querySelector('input[type="checkbox"]');
                                if (checkbox) checkbox.checked = false;
                            });
                            
                            // Switch to view tab after 2 seconds
                            setTimeout(() => {
                                switchTab('view');
                                location.reload(); // Reload to show new notification
                            }, 2000);
                        } else {
                            formMessage.innerHTML = '<div class="alert alert-danger alert-dismissible fade show">' +
                                '<i class="fas fa-exclamation-triangle"></i> ❌ Error: ' + (data.error || 'Failed to send notification') +
                                '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                                '</div>';
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        formMessage.innerHTML = '<div class="alert alert-danger alert-dismissible fade show">' +
                            '<i class="fas fa-exclamation-triangle"></i> ❌ Network error occurred. Please try again.' +
                            '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                            '</div>';
                    })
                    .finally(() => {
                        // Re-enable button
                        submitBtn.disabled = false;
                        submitBtn.innerHTML = originalText;
                    });
                });
            }
            
            // Push notifications
            document.getElementById('enable-push')?.addEventListener('click', function() {
                if (!('Notification' in window)) {
                    alert('This browser does not support notifications');
                    return;
                }
                
                if (Notification.permission === 'granted') {
                    alert('Push notifications are already enabled!');
                } else if (Notification.permission === 'denied') {
                    alert('Notifications are blocked. Please enable them in your browser settings.');
                } else {
                    Notification.requestPermission().then(permission => {
                        if (permission === 'granted') {
                            alert('✅ Push notifications enabled!');
                        }
                    });
                }
            });
            
            // Load notifications function
            function loadNotifications() {
                location.reload();
            }
            
            // Update unread count every 30 seconds
            setInterval(updateUnreadCount, 30000);
            </script>
        </body>
        </html>
        <?php
        break;


    /* =========================
       MARK AS READ
    ==========================*/
    case 'mark_read':
        if (isset($_GET['id'])) {
            header('Content-Type: application/json');
            $success = $controller->markAsRead($current_user['id'], $_GET['id']);
            echo json_encode(['success' => $success]);
        }
        break;


    /* =========================
       UNREAD COUNT
    ==========================*/
    case 'unread_count':
        echo $controller->getUnreadCount($current_user['id']);
        break;


    default:
        header('Location: ?action=view');
}
?>