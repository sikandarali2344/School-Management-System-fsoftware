<!-- includes/sidebar.php -->
<nav class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-graduation-cap"></i> School System</h3>
    </div>
    
    <div class="user-info">
        <div class="user-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div class="user-details">
            <h5><?php echo htmlspecialchars($current_user['name']); ?></h5>
            <small><?php echo ucfirst($current_user['role']); ?></small>
        </div>
    </div>
    
    <ul class="nav-menu">
        <li class="nav-item">
            <a href="index.php?page=dashboard" class="nav-link <?php echo ($page == 'dashboard') ? 'active' : ''; ?>">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="index.php?page=students" class="nav-link <?php echo ($page == 'students') ? 'active' : ''; ?>">
                <i class="fas fa-users"></i>
                <span>Students</span>
            </a>
        </li>
        
        <li class="nav-item">
            <a href="index.php?page=teachers" class="nav-link <?php echo ($page == 'teachers') ? 'active' : ''; ?>">
                <i class="fas fa-chalkboard-teacher"></i>
                <span>Teachers</span>
            </a>
        </li>
        
        <!-- NOTIFICATIONS MENU ITEM -->
        <li class="nav-item">
            <a href="notifications/notification_router.php?action=view" 
               class="nav-link <?php echo ($page == 'notifications') ? 'active' : ''; ?>">
                <i class="fas fa-bell"></i>
                <span>Notifications</span>
                <?php
                // Get unread count
                require_once __DIR__ . '/../notifications/notification_controller.php';
                $controller = new NotificationController();
                $unread = $controller->getUnreadCount($current_user['id']);
                if ($unread > 0): ?>
                    <span class="badge bg-danger ms-auto"><?php echo $unread; ?></span>
                <?php endif; ?>
            </a>
        </li>
        
        <!-- SEND NOTIFICATION LINK (ADMIN ONLY) -->
        <?php if ($current_user['role'] === 'admin'): ?>
        <li class="nav-item">
            <a href="notifications/notification_router.php?action=send" 
               class="nav-link <?php echo ($page == 'send_notification') ? 'active' : ''; ?>">
                <i class="fas fa-paper-plane"></i>
                <span>Send Notification</span>
            </a>
        </li>
        <?php endif; ?>
        
        <li class="nav-item">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </li>
    </ul>
</nav>

<style>
.sidebar {
    background: #343a40;
    color: white;
    width: 250px;
    min-height: 100vh;
    padding: 0;
}

.sidebar-header {
    padding: 20px;
    background: #212529;
    text-align: center;
}

.user-info {
    padding: 20px;
    display: flex;
    align-items: center;
    border-bottom: 1px solid #495057;
}

.user-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #495057;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 10px;
}

.nav-menu {
    list-style: none;
    padding: 0;
    margin: 0;
}

.nav-item {
    border-bottom: 1px solid #495057;
}

.nav-link {
    color: #adb5bd;
    padding: 15px 20px;
    display: flex;
    align-items: center;
    text-decoration: none;
    transition: all 0.3s;
}

.nav-link:hover {
    background: #495057;
    color: white;
}

.nav-link.active {
    background: #0d6efd;
    color: white;
}

.nav-link i {
    margin-right: 10px;
    width: 20px;
    text-align: center;
}
</style>