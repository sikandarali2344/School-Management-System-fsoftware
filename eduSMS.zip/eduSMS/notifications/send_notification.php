<?php
// notifications/send_notification.php

session_start();

// Check if POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
    exit;
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Please login first']);
    exit;
}

// Check if user is admin
if (($_SESSION['role'] ?? '') !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Access denied. Admin only.']);
    exit;
}

// Include controller
require_once __DIR__ . '/notification_controller.php';

$controller = new NotificationController();

// Handle file upload
$attachment_path = null;
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = __DIR__ . '/../uploads/notifications/';
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_name = time() . '_' . basename($_FILES['attachment']['name']);
    $target_file = $upload_dir . $file_name;
    
    $allowed_types = ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'];
    $file_ext = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    if (in_array($file_ext, $allowed_types) && $_FILES['attachment']['size'] <= 5 * 1024 * 1024) {
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $target_file)) {
            $attachment_path = $target_file;
        }
    }
}

// Prepare notification data
$data = [
    'title' => $_POST['title'] ?? '',
    'message' => $_POST['message'] ?? '',
    'type' => $_POST['type'] ?? 'announcement',
    'target' => $_POST['target'] ?? 'all',
    'sender_id' => $_SESSION['user_id'],
    'sender_role' => $_SESSION['role'] ?? 'admin',
    'attachment' => $attachment_path
];

// Handle specific recipients
if (($_POST['target'] ?? '') === 'specific' && isset($_POST['users'])) {
    $users = is_array($_POST['users']) ? $_POST['users'] : [];
    $data['recipients'] = [];
    
    foreach ($users as $user_id) {
        $data['recipients'][] = [
            'id' => (int)$user_id,
            'role' => 'student' // Default role
        ];
    }
}

// Send notification
$result = $controller->sendNotification($data);

header('Content-Type: application/json');
if ($result['success']) {
    echo json_encode(['success' => true, 'id' => $result['id']]);
} else {
    echo json_encode(['success' => false, 'error' => $result['error'] ?? 'Failed to send notification']);
}
?>