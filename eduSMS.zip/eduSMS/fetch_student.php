<?php
require_once "config.php";

if(!isset($_GET['class_id'])) {
    die("Class ID required");
}

$class_id = (int)$_GET['class_id'];

// Fetch students for this class
$stmt = $pdo->prepare("
    SELECT s.id, u.name 
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.class_id = ?
    ORDER BY u.name
");
$stmt->execute([$class_id]);
$students = $stmt->fetchAll();

if($students){
    echo '<label>Select Student</label>';
    echo '<select name="student_id" required>';
    echo '<option value="">-- Select Student --</option>';
    foreach($students as $s){
        echo '<option value="'.$s['id'].'">'.htmlspecialchars($s['name']).'</option>';
    }
    echo '</select>';
} else {
    echo '<p>No students found in this class.</p>';
}
?>
