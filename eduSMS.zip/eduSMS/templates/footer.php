<?php
// templates/footer.php
?>
            </div> <!-- End main content -->
        </div> <!-- End row -->
    </div> <!-- End container-fluid -->
    
    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Auto update unread count every 30 seconds
    setInterval(function() {
        if (typeof updateUnreadCount === 'function') {
            updateUnreadCount();
        }
    }, 30000);
    
    // Initialize Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    </script>
</body>
</html>