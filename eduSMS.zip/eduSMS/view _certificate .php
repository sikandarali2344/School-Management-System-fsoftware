<?php
require_once "config.php";
session_start();

// 🔒 login check
if (!isset($_SESSION['user_id'])) {
    die("Access denied");
}

// 🔎 certificate id required
if (!isset($_GET['id'])) {
    die("Invalid request");
}

$cert_id = (int) $_GET['id'];

// 🔎 student id
$stmt = $pdo->prepare("SELECT id FROM students WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch();

if (!$student) {
    die("Student not found");
}

// 🔎 certificate verify (security)
$cstmt = $pdo->prepare("
    SELECT file_path 
    FROM certificates 
    WHERE id = ? AND student_id = ?
");
$cstmt->execute([$cert_id, $student['id']]);
$cert = $cstmt->fetch();

if (!$cert) {
    die("Certificate not found");
}

// 🔗 redirect to real PDF (browser handles it)
$file = $cert['file_path'];
$encoded = implode('/', array_map('rawurlencode', explode('/', $file)));

header("Location: $encoded");
exit;
