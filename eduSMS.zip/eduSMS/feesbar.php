<?php
$page = $_GET['page'] ?? '';
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Sidebar Fees Menu</title>

<!-- FONT AWESOME -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
/* ===== SIDEBAR BASE ===== */
.sidebar {
    width:260px;
    background:#0b2540;
    min-height:100vh;
    padding-top:10px;
    font-family:Arial;
}

.menu-item {
    list-style:none;
    color:#fff;
}

/* ===== MAIN LINK ===== */
.menu-link {
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:14px 18px;
}

.menu-text {
    display:flex;
    align-items:center;
    gap:10px;
    color:#fff;
    text-decoration:none;
    font-size:15px;
    flex:1;
}

.menu-text:hover {
    color:#4fc3f7;
}

/* ===== ARROW ===== */
.menu-arrow {
    cursor:pointer;
    transition:0.3s;
}

.menu-item.open .menu-arrow i {
    transform:rotate(90deg);
}

/* ===== SUB MENU ===== */
.submenu {
    display:none;
    background:#102f52;
}

.menu-item.open .submenu {
    display:block;
}

.submenu li a {
    display:block;
    padding:11px 48px;
    font-size:14px;
    color:#cfd8dc;
    text-decoration:none;
}

.submenu li a:hover {
    background:#163d66;
    color:#fff;
}

/* ===== ACTIVE ===== */
.submenu a.active {
    background:#1e88e5;
    color:#fff;
}
</style>
</head>

<body>

<div class="sidebar">

    <!-- FEES MENU -->
    <li class="menu-item has-sub <?= in_array($page,['fees','fees_bar'])?'open':'' ?>">

        <div class="menu-link">

            <!-- TEXT CLICK -->
            <a href="?page=fees" class="menu-text">
                <i class="fas fa-wallet"></i>
                <span>Fees</span>
            </a>

            <!-- ARROW CLICK -->
            <span class="menu-arrow">
                <i class="fas fa-chevron-right"></i>
            </span>

        </div>

        <!-- SUB MENU -->
        <ul class="submenu">
            <li>
                <a href="?page=fees&tab=structure"
                   class="<?= ($_GET['tab']??'')=='structure'?'active':'' ?>">
                    Fee Structure
                </a>
            </li>
            <li>
                <a href="?page=fees&tab=payments"
                   class="<?= ($_GET['tab']??'')=='payments'?'active':'' ?>">
                    Fee Payments
                </a>
            </li>
            <li>
                <a href="?page=fees&tab=settings"
                   class="<?= ($_GET['tab']??'')=='settings'?'active':'' ?>">
                    Payment Settings
                </a>
            </li>
        </ul>

    </li>

</div>

<!-- ===== JS ===== -->
<script>
document.querySelectorAll('.menu-arrow').forEach(arrow => {
    arrow.addEventListener('click', function (e) {
        e.stopPropagation();
        this.closest('.menu-item').classList.toggle('open');
    });
});
</script>

</body>
</html>
