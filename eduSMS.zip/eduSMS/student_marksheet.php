<?php
require_once 'config.php';


if (!isset($current_user) || $current_user['role'] != 'student') {
    die("Access Denied");
}

/* SCHOOL */
$settings = $pdo->query("SELECT school_name FROM settings LIMIT 1")->fetch();
$school_name = strtoupper($settings['school_name'] ?? 'SCHOOL NAME');

/* STUDENT */
$stmt = $pdo->prepare("
    SELECT s.id, u.name student_name, c.class_name,
           s.parent_name, s.parent_contact
    FROM students s
    JOIN users u ON s.user_id = u.id
    JOIN classes c ON s.class_id = c.id
    WHERE s.user_id = ?
");
$stmt->execute([$current_user['id']]);
$student = $stmt->fetch();

$student_id = $student['id'];

/* ACADEMIC YEAR */
$y = date('Y');
$academic_year = (date('m') >= 4) ? "$y-".($y+1) : ($y-1)."-".$y;

/* GRADES */
$gq = $pdo->prepare("
    SELECT g.*, c.course_name
    FROM grades g
    JOIN courses c ON g.course_id = c.id
    WHERE g.student_id = ? AND g.academic_year = ?
");
$gq->execute([$student_id, $academic_year]);
$grades = $gq->fetchAll();

/* CALC */
$total = $obt = 0;
$result = "PASS";
foreach ($grades as $g) {
    $total += $g['total_marks'];
    $obt += $g['marks_obtained'];
    if ($g['grade'] == 'F') $result = "FAIL";
}
$percent = $total > 0 ? ($obt / $total) * 100 : 0;
?>

<!DOCTYPE html>
<html>
<head>
<title>Student Marksheet</title>
<style>
body{
    background:#eee;
    font-family: "Times New Roman", serif;
}
.sheet{
    width:900px;
    margin:20px auto;
    background:#fff;
    border:3px solid #000;
    padding:20px;
}
.school{
    text-align:center;
    font-size:26px;
    font-weight:bold;
    letter-spacing:1px;
}
.subtitle{
    text-align:center;
    font-size:16px;
    margin-bottom:15px;
    text-decoration:underline;
}
.info{
    width:100%;
    margin-bottom:15px;
}
.info td{
    padding:4px;
    font-size:15px;
}
table.marks{
    width:100%;
    border-collapse:collapse;
    font-size:15px;
}
.marks th, .marks td{
    border:2px solid #000;
    padding:6px;
    text-align:center;
}
.marks th{
    background:#f2f2f2;
    font-weight:bold;
}
.sign{
    margin-top:40px;
}
.sign td{
    text-align:center;
    font-size:14px;
}
.download{
    float:right;
    background:#000;
    color:#fff;
    padding:8px 14px;
    text-decoration:none;
    margin-bottom:10px;
}
</style>
</head>

<body>

<a class="download" href="?download=1">Download PDF</a>

<div class="sheet">

<div class="school"><?php echo $school_name; ?></div>
<div class="subtitle">STATEMENT OF MARKS</div>

<table class="info">
<tr>
    <td><b>Student Name:</b> <?php echo $student['student_name']; ?></td>
    <td><b>Class:</b> <?php echo $student['class_name']; ?></td>
</tr>
<tr>
    <td><b>Parent Name:</b> <?php echo $student['parent_name']; ?></td>
    <td><b>Contact:</b> <?php echo $student['parent_contact']; ?></td>
</tr>
<tr>
    <td><b>Academic Year:</b> <?php echo $academic_year; ?></td>
    <td><b>Result:</b> <?php echo $result; ?></td>
</tr>
</table>

<table class="marks">
<tr>
    <th>Subject</th>
    <th>Total Marks</th>
    <th>Marks Obtained</th>
    <th>Grade</th>
</tr>

<?php foreach($grades as $g): ?>
<tr>
    <td style="text-align:left"><?php echo $g['course_name']; ?></td>
    <td><?php echo $g['total_marks']; ?></td>
    <td><?php echo $g['marks_obtained']; ?></td>
    <td><?php echo $g['grade']; ?></td>
</tr>
<?php endforeach; ?>

<tr>
    <th>Total</th>
    <th><?php echo $total; ?></th>
    <th><?php echo $obt; ?></th>
    <th><?php echo $result; ?></th>
</tr>
</table>

<p style="margin-top:10px;"><b>Percentage:</b> <?php echo number_format($percent,2); ?>%</p>

<table class="sign" width="100%">
<tr>
    <td>_<br>Class Teacher</td>
    <td>_<br>Principal</td>
    <td>_<br>Parents</td>
</tr>
</table>

</div>
</body>
</html>