<?php
require "config.php";

$student_id = $_GET['student_id'];

// Get student info (JOIN users table)
$stmt = $pdo->prepare("
    SELECT s.id, s.class, u.name
    FROM students s
    JOIN users u ON s.user_id = u.id
    WHERE s.id = ?
");
$stmt->execute([$student_id]);
$s = $stmt->fetch();

$type = $_GET['type'];
$school = strtoupper($_GET['school']);
$date = date("d F Y");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Certificate</title>
    <style>
        body { margin:0; }
        .cert {
            width:100%;
            height:100vh;
            border:10px solid #2c3e50;
            padding:60px;
            text-align:center;
            font-family:'Georgia';
        }
        h1 { font-size:48px; }
        h2 { margin-top:30px; }
        .name { font-size:36px; font-weight:bold; margin:20px 0; }
        .footer { margin-top:80px; display:flex; justify-content:space-between; }
    </style>
</head>
<body onload="window.print()">
<div class="cert">
    <h1><?= $school ?></h1>
    <h2><?= $type ?> Certificate</h2>

    <p>This is to certify that</p>
    <div class="name"><?= $s['name'] ?></div>

    <p>
        has successfully received the <b><?= $type ?></b> certificate
        for Class <b><?= $s['class'] ?></b>.
    </p>

    <p>Date: <?= $date ?></p>

    <div class="footer">
        <div>_________________<br>Principal</div>
        <div>_________________<br>Class Teacher</div>
    </div>
</div>
</body>
</html>
