<!DOCTYPE html>
<!-- saved from url=(0055)http://localhost/phpmyadmin/index.php?route=/server/sql -->
<html lang="en" dir="ltr"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="referrer" content="no-referrer">
  <meta name="robots" content="noindex,nofollow,notranslate">
  <meta name="google" content="notranslate">
  
  <link rel="icon" href="http://localhost/phpmyadmin/favicon.ico" type="image/x-icon">
  <link rel="shortcut icon" href="http://localhost/phpmyadmin/favicon.ico" type="image/x-icon">
  <link rel="stylesheet" type="text/css" href="./edumanage_files/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="./edumanage_files/codemirror.css">
  <link rel="stylesheet" type="text/css" href="./edumanage_files/show-hint.css">
  <link rel="stylesheet" type="text/css" href="./edumanage_files/lint.css">
  <link rel="stylesheet" type="text/css" href="./edumanage_files/theme.css">
  <title>localhost / 127.0.0.1 | phpMyAdmin 5.2.1</title>
    <script data-cfasync="false" type="text/javascript" src="./edumanage_files/jquery.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/jquery-migrate.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/sprintf.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/ajax.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/keyhandler.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/jquery-ui.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/name-conflict-fixes.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/bootstrap.bundle.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/js.cookie.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/jquery.validate.min.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/jquery-ui-timepicker-addon.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/jquery.debounce-1.0.6.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/menu_resizer.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/cross_framing_protection.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/messages.php"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/config.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/doclinks.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/functions.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/navigation.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/indexes.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/common.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/page_settings.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/home.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/codemirror.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/sql.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/runmode.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/show-hint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/sql-hint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/lint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/sql-lint.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/tracekit.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/error_report.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/drag_drop_import.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/shortcuts_handler.js.download"></script>
  <script data-cfasync="false" type="text/javascript" src="./edumanage_files/console.js.download"></script>

<script data-cfasync="false" type="text/javascript">
// <![CDATA[
CommonParams.setAll({common_query:"",opendb_url:"index.php?route=/database/structure",lang:"en",server:"1",table:"",db:"",token:"62336b6e4b527e4b4e77644a7c392a5b",text_dir:"ltr",LimitChars:"50",pftext:"",confirm:true,LoginCookieValidity:"1440",session_gc_maxlifetime:"1440",logged_in:true,is_https:false,rootPath:"/phpmyadmin/",arg_separator:"&",version:"5.2.1",auth_type:"config",user:"root"});
var firstDayOfCalendar = '0';
var themeImagePath = '.\/themes\/pmahomme\/img\/';
var mysqlDocTemplate = '.\/url.php\u003Furl\u003Dhttps\u00253A\u00252F\u00252Fdev.mysql.com\u00252Fdoc\u00252Frefman\u00252F8.0\u00252Fen\u00252F\u002525s.html';
var maxInputVars = 1000;

if ($.datepicker) {
  $.datepicker.regional[''].closeText = 'Done';
  $.datepicker.regional[''].prevText = 'Prev';
  $.datepicker.regional[''].nextText = 'Next';
  $.datepicker.regional[''].currentText = 'Today';
  $.datepicker.regional[''].monthNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];
  $.datepicker.regional[''].monthNamesShort = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec',
  ];
  $.datepicker.regional[''].dayNames = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];
  $.datepicker.regional[''].dayNamesShort = [
    'Sun',
    'Mon',
    'Tue',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
  ];
  $.datepicker.regional[''].dayNamesMin = [
    'Su',
    'Mo',
    'Tu',
    'We',
    'Th',
    'Fr',
    'Sa',
  ];
  $.datepicker.regional[''].weekHeader = 'Wk';
  $.datepicker.regional[''].showMonthAfterYear = false;
  $.datepicker.regional[''].yearSuffix = '';
  $.extend($.datepicker._defaults, $.datepicker.regional['']);
}

if ($.timepicker) {
  $.timepicker.regional[''].timeText = 'Time';
  $.timepicker.regional[''].hourText = 'Hour';
  $.timepicker.regional[''].minuteText = 'Minute';
  $.timepicker.regional[''].secondText = 'Second';
  $.extend($.timepicker._defaults, $.timepicker.regional['']);
}

function extendingValidatorMessages () {
  $.extend($.validator.messages, {
    required: 'This\u0020field\u0020is\u0020required',
    remote: 'Please\u0020fix\u0020this\u0020field',
    email: 'Please\u0020enter\u0020a\u0020valid\u0020email\u0020address',
    url: 'Please\u0020enter\u0020a\u0020valid\u0020URL',
    date: 'Please\u0020enter\u0020a\u0020valid\u0020date',
    dateISO: 'Please\u0020enter\u0020a\u0020valid\u0020date\u0020\u0028\u0020ISO\u0020\u0029',
    number: 'Please\u0020enter\u0020a\u0020valid\u0020number',
    creditcard: 'Please\u0020enter\u0020a\u0020valid\u0020credit\u0020card\u0020number',
    digits: 'Please\u0020enter\u0020only\u0020digits',
    equalTo: 'Please\u0020enter\u0020the\u0020same\u0020value\u0020again',
    maxlength: $.validator.format('Please\u0020enter\u0020no\u0020more\u0020than\u0020\u007B0\u007D\u0020characters'),
    minlength: $.validator.format('Please\u0020enter\u0020at\u0020least\u0020\u007B0\u007D\u0020characters'),
    rangelength: $.validator.format('Please\u0020enter\u0020a\u0020value\u0020between\u0020\u007B0\u007D\u0020and\u0020\u007B1\u007D\u0020characters\u0020long'),
    range: $.validator.format('Please\u0020enter\u0020a\u0020value\u0020between\u0020\u007B0\u007D\u0020and\u0020\u007B1\u007D'),
    max: $.validator.format('Please\u0020enter\u0020a\u0020value\u0020less\u0020than\u0020or\u0020equal\u0020to\u0020\u007B0\u007D'),
    min: $.validator.format('Please\u0020enter\u0020a\u0020value\u0020greater\u0020than\u0020or\u0020equal\u0020to\u0020\u007B0\u007D'),
    validationFunctionForDateTime: $.validator.format('Please\u0020enter\u0020a\u0020valid\u0020date\u0020or\u0020time'),
    validationFunctionForHex: $.validator.format('Please\u0020enter\u0020a\u0020valid\u0020HEX\u0020input'),
    validationFunctionForMd5: $.validator.format('This\u0020column\u0020can\u0020not\u0020contain\u0020a\u002032\u0020chars\u0020value'),
    validationFunctionForAesDesEncrypt: $.validator.format('These\u0020functions\u0020are\u0020meant\u0020to\u0020return\u0020a\u0020binary\u0020result\u003B\u0020to\u0020avoid\u0020inconsistent\u0020results\u0020you\u0020should\u0020store\u0020it\u0020in\u0020a\u0020BINARY,\u0020VARBINARY,\u0020or\u0020BLOB\u0020column.')
  });
}

ConsoleEnterExecutes=false

AJAX.scriptHandler
  .add('vendor/jquery/jquery.min.js', 0)
  .add('vendor/jquery/jquery-migrate.min.js', 0)
  .add('vendor/sprintf.js', 1)
  .add('ajax.js', 0)
  .add('keyhandler.js', 1)
  .add('vendor/jquery/jquery-ui.min.js', 0)
  .add('name-conflict-fixes.js', 1)
  .add('vendor/bootstrap/bootstrap.bundle.min.js', 1)
  .add('vendor/js.cookie.js', 1)
  .add('vendor/jquery/jquery.validate.min.js', 0)
  .add('vendor/jquery/jquery-ui-timepicker-addon.js', 0)
  .add('vendor/jquery/jquery.debounce-1.0.6.js', 0)
  .add('menu_resizer.js', 1)
  .add('cross_framing_protection.js', 0)
  .add('messages.php', 0)
  .add('config.js', 1)
  .add('doclinks.js', 1)
  .add('functions.js', 1)
  .add('navigation.js', 1)
  .add('indexes.js', 1)
  .add('common.js', 1)
  .add('page_settings.js', 1)
  .add('home.js', 1)
  .add('vendor/codemirror/lib/codemirror.js', 0)
  .add('vendor/codemirror/mode/sql/sql.js', 0)
  .add('vendor/codemirror/addon/runmode/runmode.js', 0)
  .add('vendor/codemirror/addon/hint/show-hint.js', 0)
  .add('vendor/codemirror/addon/hint/sql-hint.js', 0)
  .add('vendor/codemirror/addon/lint/lint.js', 0)
  .add('codemirror/addon/lint/sql-lint.js', 0)
  .add('vendor/tracekit.js', 1)
  .add('error_report.js', 1)
  .add('drag_drop_import.js', 1)
  .add('shortcuts_handler.js', 1)
  .add('console.js', 1)
;
$(function() {
        AJAX.fireOnload('vendor/sprintf.js');
        AJAX.fireOnload('keyhandler.js');
        AJAX.fireOnload('name-conflict-fixes.js');
      AJAX.fireOnload('vendor/bootstrap/bootstrap.bundle.min.js');
      AJAX.fireOnload('vendor/js.cookie.js');
            AJAX.fireOnload('menu_resizer.js');
          AJAX.fireOnload('config.js');
      AJAX.fireOnload('doclinks.js');
      AJAX.fireOnload('functions.js');
      AJAX.fireOnload('navigation.js');
      AJAX.fireOnload('indexes.js');
      AJAX.fireOnload('common.js');
      AJAX.fireOnload('page_settings.js');
      AJAX.fireOnload('home.js');
                    AJAX.fireOnload('vendor/tracekit.js');
      AJAX.fireOnload('error_report.js');
      AJAX.fireOnload('drag_drop_import.js');
      AJAX.fireOnload('shortcuts_handler.js');
      AJAX.fireOnload('console.js');
  });
// ]]>
</script>

  <noscript><style>html{display:block}</style></noscript>
<style type="text/css">button.btn[data-v-5f0b9ba1]{display:inline-block;font-weight:300;line-height:1.25;text-align:center;white-space:nowrap;vertical-align:middle;user-select:none;border:1px solid transparent;cursor:pointer;letter-spacing:1px;transition:all .15s ease}button.btn.btn-sm[data-v-5f0b9ba1]{padding:.4rem .8rem;font-size:.8rem;border-radius:.2rem}button.btn.btn-primary[data-v-5f0b9ba1]{color:#fff;background-color:#45C8F1;border-color:#45C8F1}button.btn.btn-outline-primary[data-v-5f0b9ba1]{color:#45C8F1;background-color:transparent;border-color:#45C8F1}button.btn.btn-danger[data-v-5f0b9ba1]{color:#fff;background-color:#FF4949;border-color:#FF4949}.text-muted[data-v-5f0b9ba1]{color:#8492A6}.text-center[data-v-5f0b9ba1]{text-align:center}.drop-down-enter[data-v-5f0b9ba1],.drop-down-leave-to[data-v-5f0b9ba1]{transform:translateX(0) translateY(-20px);transition-timing-function:cubic-bezier(0.74, 0.04, 0.26, 1.05);opacity:0}.drop-down-enter-active[data-v-5f0b9ba1],.drop-down-leave-active[data-v-5f0b9ba1]{transition:all .15s}.move-left-enter[data-v-5f0b9ba1],.move-left-leave-to[data-v-5f0b9ba1]{transform:translateY(0) translateX(-80px);transition-timing-function:cubic-bezier(0.74, 0.04, 0.26, 1.05);opacity:0}.move-left-enter-active[data-v-5f0b9ba1],.move-left-leave-active[data-v-5f0b9ba1]{transition:all .15s}.no-tr[data-v-5f0b9ba1]{transition:none !important}.no-tr *[data-v-5f0b9ba1]{transition:none !important}.overlay[data-v-5f0b9ba1]{position:fixed;background:rgba(220,220,220,0.8);display:flex;align-items:center;justify-content:center;top:0;left:0;right:0;bottom:0;transition:all 0.2s ease;opacity:0;visibility:hidden}.overlay .modal[data-v-5f0b9ba1]{transition:all 0.2s ease;opacity:0;transform:scale(0.6);overflow:hidden}.overlay.show[data-v-5f0b9ba1]{opacity:1;visibility:visible}.overlay.show .modal[data-v-5f0b9ba1]{opacity:1;transform:scale(1)}.panel[data-v-5f0b9ba1]{padding:6px 10px;display:flex;width:100%;box-sizing:border-box;align-items:center;border-radius:4px;position:relative;border:1px solid #eaf7ff;background:#f7fcff;outline:none;transition:all 0.07s ease-in-out}.btn[data-v-5f0b9ba1]{cursor:pointer;box-sizing:border-box}.light-btn[data-v-5f0b9ba1]{padding:6px 10px;display:flex;width:100%;box-sizing:border-box;align-items:center;border-radius:4px;position:relative;border:1px solid #eaf7ff;background:#f7fcff;outline:none;cursor:pointer;transition:all 0.07s ease-in-out}.light-btn[data-v-5f0b9ba1]:hover{background:#e0f4ff;border-color:#8acfff}.shake[data-v-5f0b9ba1]{animation:shake-data-v-5f0b9ba1 0.82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;transform:translate3d(0, 0, 0)}@keyframes shake-data-v-5f0b9ba1{10%,90%{transform:translate3d(-1px, 0, 0)}20%,80%{transform:translate3d(2px, 0, 0)}30%,50%,70%{transform:translate3d(-4px, 0, 0)}40%,60%{transform:translate3d(4px, 0, 0)}}.pulse[data-v-5f0b9ba1]{animation:pulse-data-v-5f0b9ba1 2s ease infinite}@keyframes pulse-data-v-5f0b9ba1{0%{opacity:.7}50%{opacity:.4}100%{opacity:.7}}.flash-once[data-v-5f0b9ba1]{animation:flash-once 3.5s ease 1}@keyframes fade-up-data-v-5f0b9ba1{0%{transform:translate3d(0, 10px, 0);opacity:0}100%{transform:translate3d(0, 0, 0);opacity:1}}.fade-in[data-v-5f0b9ba1]{animation:fade-in-data-v-5f0b9ba1 .3s ease-in-out}@keyframes fade-in-data-v-5f0b9ba1{0%{opacity:0}100%{opacity:1}}.spin[data-v-5f0b9ba1]{animation-name:spin-data-v-5f0b9ba1;animation-duration:2000ms;animation-iteration-count:infinite;animation-timing-function:linear}@keyframes spin-data-v-5f0b9ba1{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}.bounceIn[data-v-5f0b9ba1]{animation-name:bounceIn-data-v-5f0b9ba1;transform-origin:center bottom;animation-duration:1s;animation-fill-mode:both;animation-iteration-count:1}@keyframes bounceIn-data-v-5f0b9ba1{0%,20%,40%,60%,80%,100%{-webkit-transition-timing-function:cubic-bezier(0.215, 0.61, 0.355, 1);transition-timing-function:cubic-bezier(0.215, 0.61, 0.355, 1)}0%{opacity:1;-webkit-transform:scale3d(0.8, 0.8, 0.8);transform:scale3d(0.8, 0.8, 0.8)}20%{-webkit-transform:scale3d(1.1, 1.1, 1.1);transform:scale3d(1.1, 1.1, 1.1)}40%{-webkit-transform:scale3d(0.9, 0.9, 0.9);transform:scale3d(0.9, 0.9, 0.9)}60%{opacity:1;-webkit-transform:scale3d(1.03, 1.03, 1.03);transform:scale3d(1.03, 1.03, 1.03)}80%{-webkit-transform:scale3d(0.97, 0.97, 0.97);transform:scale3d(0.97, 0.97, 0.97)}100%{opacity:1;-webkit-transform:scale3d(1, 1, 1);transform:scale3d(1, 1, 1)}}@keyframes dots-data-v-5f0b9ba1{0%,20%{color:rgba(0,0,0,0);text-shadow:0.25em 0 0 rgba(0,0,0,0),0.5em 0 0 rgba(0,0,0,0)}40%{color:#8492A6;text-shadow:0.25em 0 0 rgba(0,0,0,0),0.5em 0 0 rgba(0,0,0,0)}60%{text-shadow:0.25em 0 0 #8492A6,0.5em 0 0 rgba(0,0,0,0)}80%,100%{text-shadow:.25em 0 0 #8492A6, .5em 0 0 #8492A6}}@keyframes recording-data-v-5f0b9ba1{0%{box-shadow:0px 0px 5px 0px rgba(173,0,0,0.3)}65%{box-shadow:0px 0px 5px 5px rgba(173,0,0,0.3)}90%{box-shadow:0px 0px 5px 5px rgba(173,0,0,0)}}body[data-v-5f0b9ba1]{margin:0;font-size:100%;color:#3C4858}a[data-v-5f0b9ba1]{text-decoration:none;color:#45C8F1}h1[data-v-5f0b9ba1],h2[data-v-5f0b9ba1],h3[data-v-5f0b9ba1],h4[data-v-5f0b9ba1]{margin-top:0}svg[data-v-5f0b9ba1]{outline:none}.container_selected_area[data-v-5f0b9ba1]{display:none;visibility:hidden;padding:0;position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647}.container_selected_area.active[data-v-5f0b9ba1]{visibility:visible;display:block}.container_selected_area .label[data-v-5f0b9ba1]{font-family:"Didact Gothic Regular",sans-serif;font-size:22px;text-align:center;padding-top:15px}.container_selected_area .area[data-v-5f0b9ba1]{display:none;position:fixed;z-index:2147483647;border:1px solid #1e83ff;background:rgba(30,131,255,0.1);box-sizing:border-box}.container_selected_area .area.active[data-v-5f0b9ba1]{display:block;top:0;left:0}.hide[data-v-5f0b9ba1]{display:none}
</style><style type="text/css">button.btn[data-v-2b23e28f]{display:inline-block;font-weight:300;line-height:1.25;text-align:center;white-space:nowrap;vertical-align:middle;user-select:none;border:1px solid rgba(0,0,0,0);cursor:pointer;letter-spacing:1px;transition:all .15s ease}button.btn.btn-sm[data-v-2b23e28f]{padding:.4rem .8rem;font-size:.8rem;border-radius:.2rem}button.btn.btn-primary[data-v-2b23e28f]{color:#fff;background-color:#45c8f1;border-color:#45c8f1}button.btn.btn-outline-primary[data-v-2b23e28f]{color:#45c8f1;background-color:rgba(0,0,0,0);border-color:#45c8f1}button.btn.btn-danger[data-v-2b23e28f]{color:#fff;background-color:#ff4949;border-color:#ff4949}.text-muted[data-v-2b23e28f]{color:#8492a6}.text-center[data-v-2b23e28f]{text-align:center}.drop-down-enter[data-v-2b23e28f],.drop-down-leave-to[data-v-2b23e28f]{transform:translateX(0) translateY(-20px);transition-timing-function:cubic-bezier(0.74, 0.04, 0.26, 1.05);opacity:0}.drop-down-enter-active[data-v-2b23e28f],.drop-down-leave-active[data-v-2b23e28f]{transition:all .15s}.move-left-enter[data-v-2b23e28f],.move-left-leave-to[data-v-2b23e28f]{transform:translateY(0) translateX(-80px);transition-timing-function:cubic-bezier(0.74, 0.04, 0.26, 1.05);opacity:0}.move-left-enter-active[data-v-2b23e28f],.move-left-leave-active[data-v-2b23e28f]{transition:all .15s}.no-tr[data-v-2b23e28f]{transition:none !important}.no-tr *[data-v-2b23e28f]{transition:none !important}.overlay[data-v-2b23e28f]{position:fixed;background:rgba(220,220,220,.8);display:flex;align-items:center;justify-content:center;top:0;left:0;right:0;bottom:0;transition:all .2s ease;opacity:0;visibility:hidden}.overlay .modal[data-v-2b23e28f]{transition:all .2s ease;opacity:0;transform:scale(0.6);overflow:hidden}.overlay.show[data-v-2b23e28f]{opacity:1;visibility:visible}.overlay.show .modal[data-v-2b23e28f]{opacity:1;transform:scale(1)}.panel[data-v-2b23e28f]{padding:6px 10px;display:flex;width:100%;box-sizing:border-box;align-items:center;border-radius:6px;position:relative;border:1px solid #eaf7ff;background:#f7fcff;outline:none;transition:all .07s ease-in-out}.btn[data-v-2b23e28f]{cursor:pointer;box-sizing:border-box}.light-btn[data-v-2b23e28f]{padding:10px 12px;display:flex;width:100%;box-sizing:border-box;align-items:center;border-radius:6px;position:relative;border:1px solid #eaf7ff;background:#f7fcff;outline:none;cursor:pointer;transition:all .07s ease-in-out}.light-btn[data-v-2b23e28f]:hover{background:#e0f4ff;border-color:#8acfff}.primary-btn[data-v-2b23e28f]{background:#239bf5;color:#fff;border-radius:6px;height:46px;display:flex;align-items:center;justify-content:center;transition:.2s ease;font-size:12px;font-family:"Poppins",sans-serif}.primary-btn[data-v-2b23e28f]:hover{background:rgb(64.2695652174,168.3043478261,246.3304347826);color:#fff;text-decoration:none}.button[data-v-2b23e28f]{transition:.2s ease;cursor:pointer;user-select:none;outline:none;box-sizing:border-box;display:flex;align-items:center;justify-content:center}.button.disabled[data-v-2b23e28f]{pointer-events:none;opacity:.3}.default-color-picker[data-v-2b23e28f]{display:grid !important}.default-color-picker input[data-v-2b23e28f]{width:100%;height:100%;grid-area:1/1;opacity:0;pointer-events:none}.default-color-picker .color[data-v-2b23e28f]{grid-area:1/1}.shake[data-v-2b23e28f]{animation:shake-2b23e28f .82s cubic-bezier(0.36, 0.07, 0.19, 0.97) both;transform:translate3d(0, 0, 0)}@keyframes shake-2b23e28f{10%,90%{transform:translate3d(-1px, 0, 0)}20%,80%{transform:translate3d(2px, 0, 0)}30%,50%,70%{transform:translate3d(-4px, 0, 0)}40%,60%{transform:translate3d(4px, 0, 0)}}.pulse[data-v-2b23e28f]{animation:pulse-2b23e28f 2s ease infinite}@keyframes pulse-2b23e28f{0%{opacity:.7}50%{opacity:.4}100%{opacity:.7}}.flash-once[data-v-2b23e28f]{animation:flash-once 3.5s ease 1}@keyframes fade-up-2b23e28f{0%{transform:translate3d(0, 10px, 0);opacity:0}100%{transform:translate3d(0, 0, 0);opacity:1}}.fade-in[data-v-2b23e28f]{animation:fade-in-2b23e28f .3s ease-in-out}@keyframes fade-in-2b23e28f{0%{opacity:0}100%{opacity:1}}.spin[data-v-2b23e28f]{animation-name:spin-2b23e28f;animation-duration:2000ms;animation-iteration-count:infinite;animation-timing-function:linear}@keyframes spin-2b23e28f{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}.bounceIn[data-v-2b23e28f]{animation-name:bounceIn-2b23e28f;transform-origin:center bottom;animation-duration:1s;animation-fill-mode:both;animation-iteration-count:1}@keyframes bounceIn-2b23e28f{0%,20%,40%,60%,80%,100%{-webkit-transition-timing-function:cubic-bezier(0.215, 0.61, 0.355, 1);transition-timing-function:cubic-bezier(0.215, 0.61, 0.355, 1)}0%{opacity:1;-webkit-transform:scale3d(0.8, 0.8, 0.8);transform:scale3d(0.8, 0.8, 0.8)}20%{-webkit-transform:scale3d(1.1, 1.1, 1.1);transform:scale3d(1.1, 1.1, 1.1)}40%{-webkit-transform:scale3d(0.9, 0.9, 0.9);transform:scale3d(0.9, 0.9, 0.9)}60%{opacity:1;-webkit-transform:scale3d(1.03, 1.03, 1.03);transform:scale3d(1.03, 1.03, 1.03)}80%{-webkit-transform:scale3d(0.97, 0.97, 0.97);transform:scale3d(0.97, 0.97, 0.97)}100%{opacity:1;-webkit-transform:scale3d(1, 1, 1);transform:scale3d(1, 1, 1)}}@keyframes dots-2b23e28f{0%,20%{color:rgba(0,0,0,0);text-shadow:.25em 0 0 rgba(0,0,0,0),.5em 0 0 rgba(0,0,0,0)}40%{color:#8492a6;text-shadow:.25em 0 0 rgba(0,0,0,0),.5em 0 0 rgba(0,0,0,0)}60%{text-shadow:.25em 0 0 #8492a6,.5em 0 0 rgba(0,0,0,0)}80%,100%{text-shadow:.25em 0 0 #8492a6,.5em 0 0 #8492a6}}@keyframes recording-2b23e28f{0%{box-shadow:0px 0px 5px 0px rgba(173,0,0,.3)}65%{box-shadow:0px 0px 5px 5px rgba(173,0,0,.3)}90%{box-shadow:0px 0px 5px 5px rgba(173,0,0,0)}}@font-face{font-family:"Poppins";font-style:normal;font-weight:400;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAJqMAA0AAAACADAAAJo1AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAbp2YcyiYGYACCPgqGsDyFvDQLikAAATYCJAOUfAQgBYNcB7QSWwHAcYMxrt4PdN42Ktrpok3YG4xxtc3gtlHv4hvAkU3FOGYq4DyQOvhl51T2//+ftlTG0LTq0lCE4SZOf0sGVQKFNhTKqMiU2Y0khBPpMBie0LpNmUbzLuGNo3y+2OvZaqt5zjH2ofrRt9ZsJA+KlUZ0+4Jj+tf6v+W3P93KzV32Ig1B0zFlZKQQSDDoKcKKiECYYspPd9peIHuOVh+UB21xXZH+4Y6n935nx769PxMOt8Pl0yMamnMHnulE9emfK+25lCCSRqAfNuMNWVlisKz2f72MdPtWlgG2S7YhS5BDSqnxOTw/t957fxujRtToMWDASEcrjA4boxGrqJLjEBE5WkoYMBVGCoioWDgUqUOMIkssojZA6vZ/bRmr0LLKEloonVnNvMu4NXKX5HKXPdo0TdN0U9gyBQUHiD74uHAs9D3HxqfPz1Bf9SnixrVx7WGnaUISj++59BR72I59x30YGLLZYIqkQE8mY5J/gHt/593/dwXW5oCjSBaPaREv4E2p7x/f5ZoM+7IO02CeYZpbMelhdpl5D5O7YF5EH9J9IdZhvwvmPfidtJgWs2UnFEXR6YxXik6jaDQajaLRaBRFURRFnWt+n3wVcWu5XPZwB2cj4jASBkk4GfeX+sp2/8/PtY140iYnaoh5bnh33w3z2fv/VQidDPTPH7Gfs9zXbgEGmgWSx4EtO60cF5dgYJEE+G3lkVp8LS/Tfez9rULoMxKJsBoj8QiDRzLx//u56uyxRrjUfY/CRKO2YmgkGWKnNDMbUvxbKujE2fvEwuWCQw2Lnv+/37R7+dX73rcwroutr331gJjQoXWqMPkb6OxgxiNKvMoUKuofq0Kk+mOHLGj4eX5uf8dIpcICFJQemRvbzhoWb2xjY6MX9GjBgNEGiArK11kBXwGzMDASAfsHRtT/4GTaAkF3vY8LASYg25VZEQOLa9nYdpPAj5g+IKxJhRLnpgDIb0PzCrUuWTcYD2ZfAH2SDcntt7dmJ5l97/7lm8nV/BNu3Z2QJxxOLjPU5GoCXd1fRfVFmCYUDiERshWHRC4K14TDIS3Wu/zZy4euSrU4lOUhTTK7KXuTf7TmSmmuCIXUOG8BCS7mm90BPZCWtagDa/5NV7Z/pA0CJ3E5sk6p3uDAOufSufN7WBp2YAY2SAfCQ9xwkdvEoAuIvUOIUQbPjEYCaUbaFAjHIpJg4WHNRnEph0WEZWNySLHzw03n0k3pOuTOZbW128qVoer3plR7fa+s/xznzhFeCSABFhA3NFdI/0b5S07PMQISMzRTmTFB4wgDchmaUEOXAUZmMDi0jcPNZ1lwHAfF/9fUsuWQ0lLnnMtrXXQKTrny690UXADDTxEzw12lDdrw3sXklPDx8cEZDGaWoqQLOVcOqXVTuqtcdufOvSvbx34t7735s/hZLEskthN/qIbEEH/D5CQWukkySXANUQLb8W7wgN5lwTDKPABPMJRZ7UINA8wwDiTlkAPZIKhpPMMujA5vH+j9//ZL7btn83veS3+K/BOWFQ5Y2MoKWZXM7iZ5OzM5mQWxJUQF7BwQOkBV4cnKKqHryy9Vev8k/XQvgAuwnVASa/xrrKdz1wKsuLwuSsqqOtLspJf8gC6E0rEQN7vzrd6Vszg9ZvYdIYR5IUyNMUaoQlVVYUww867jq4vs2q2o+TX9eii/YUymCslgiyBFBFRsKVP3cNtjzLQkmn6m3eMHIA5E9OBkKSY/+6n/19u0fZ35emunygFn4kJFhnAAkxC1tvBhhceoRRAREZspijc/BSAAhAC8HiEiU4ahojqHWMcRNpRUqUN7xfm4YrlksNV+jQBnG9UcfLtvA5qTY4EMgMr7h8BCuF8p+FIg+MOpEO5vAMAQDn8CzwAVlKPTQbtaAkAx7KoA4ZG1gLePo48A0uIgIjgSfxIGjoSAkJuzQL/5Y86EId8e94d2Tre21q1nNT+O+raH1eJgK5STe9XVkiVc73Xe69M2sddw1Vf2A4UbUVaQuR32C9zQlUiEi6ChzGdPf2b0aB4N9eQokCZKwIPg17CjOPyUjdt3vee2+0UuX990626lJb/M3EyUxBu3YGMGfNF7/XV6fbfdbV5cW481XAPVypRcsgLZUiWdFfxZc+JFC3XZ2dN22gQ4bK8dAg77sHlzPcnsMU/4CTyBzM7Rsx+DznFHQwnU9VkNVOWsVSn+KuXEYUhatFcg79ky0F/BeG+OgXY/P8x5ZSny4rqtituXHXXOaNcuy2e/fDzvok7G6B8YSov+dXq0F6BMxK0O86J3VvCaMcdbGCVKuVeBvEHx3RumuhU1cnHXNkZRajVE17tKjNcoJZSMExW+7XX11HsZjluUHpYIs6nA5PHIW1CdsbHzf3iItgRtZWiFx+Tw5R8BdkVemduK6NiiRrOXTEljxZLIgMuxe1O4q5/r3K7n8151qO5zALMpDn2I+IuipmhT5GtKAPivF4BEtIZMGYAbQJPE/9Z4x4prX3LhNVvG6ixtKSu3kkvCEXEIW2uh+aYaqa9P9dS+tLg9q6m6Krsbq7wySymxxOKKbKxKxXIlCuXJGRueNZMMoqeWUuTEE8IIGGhIEW1GxNiGtXbWyy+xTTcug4bT6A3RW4onEkQ4uNFMqYUQN7xoHY0phsgtk9oFjYK4waw5YsSP/3tHtX6VCPFOu5L2k9ZuimwSUJQ3L8le51bpm+wC+oSvEniHoYeTx79K5J2GzpXSTTYMbt4UFs2zvicNlRrH6q4mHAe8cc8szbNI3++ydi49ZhuXnH+zfsMrzBf3lXuW814d+qgeR2tFQsWIDx6yosQKqwi2nUC5d/0k3Rjf0NqCRWOYQt5SRBqQZxh33YW3N3oYyJSxGaRWXoh5djOKBJVqp1SvbHCtF4m5I80NeeQ1aYmm9tpjVDe36qhQWZsmPUbFxO/GUhRZkS7xmEy5R8kVEzf+EZW+Z0OjAc7XNdW5RYgHxb1DrDB+vRlEye9gZIapWQjIEcgZ6hTghvab1Fla3gK4aFeRb4nvvsJKacXEFCrKP9aHczbah09jWGhepYzvR8q81+x1888KGj+pijkzHCyxYS6d/fXz0yPH7YT969nStp2uS6m5lTdZin308uJ9AlqDmukGpyVTFxCax7bcdHvs9Ak4vI/CgH/yblKjiU6PPgObGDNnxR6FJXBwusYtuW4rVISFrUyVOvUaNBnUm61uv9/+WBYVIohBAiRTo00Hw2ZbWHLmxp0nLz58bbXdDrvs5mePvQ454rwLAkWJFiPWVf+IlyBRijTpMuQrcNtd99Sq1+CBx55q8Uabdr2+GTHujyVr1vGFIRzCIwISQIJIGImTIkOOAkVKlFGooNGghU6bLj36NjFhwZINlsDNwy8gONMAILdcw/8sYECaJFPMfXthfH5Vo2uNfp+kvT3lE9Oqf/RTKLGz4B6v4cpzaG8ZrsggrIfNGjG0bjScHzFXDHtZMcVxO4ii7Wfr9HAaOnc57hvldDPSNLk0U3JlzPO+4CV9e8NeQgW38iFM2CcyeRGR6u82zbg6wZsOgqQcY0Y1GYeObiMIZZPEcURofUY5oijUySpzR4ewzLCQ0IDun2gT6q+9jDJgaP/JmmMnBcMJh8VUCeR2VJQMip1DSx5hToBCk0GsA4aVhHrCG4gnY7miQXOQqgKtP19gj103KYP6MxQlXafrG23CDRcoIRgqlo0LeEDbanvUi664KlqJjzCgz8gBYNy+4MzLiItQsSjeqHaRg9rvtLFsqcFC4KP6Czn9SBRYahGZVlnZgBhbyEolzVe4sirnhMBQfKO6qSdCEL1RdxN8oSVw4Nrbl4E50bcnc9c3MvNtGXK7bSyI3pjNWoL6eph/+qp4ljuu1L44dbu2+jSlvMO7L3U8H3JevNH2C2LqEqe2Y5baHT9qd9nbTorhsTX0ZyD4UOMFADI00TEYHviKD9YmSHXWqeKhljOVrJ+YYABAWv4VAtBPIJj3dX8PDI78KTZcNUh6fe1YfIVwBBzAwb7S9/vTXBMN9a0PdddWS801VhsndoXllF5yCcXWdtfiYy250/ashPIz8fnwRsog+eL503ShTLECn5MSokMzZ9REenhQM2oKSSfKbxHAcFitjRotWYodDv0yY8yAL5zu1em1F9cfa/DPVytTokC2VEniRZNDDS22pFtKhI/IjkSCmWHQQUMhRxIJERFCDLe3ZgGvnzdlRJ9PerRjmuuZJnVQyXexSp7MT5YmRaI4kYKfHBfRPQkPOc0/VXY0IfRlxce93dGyby2aRBb3fCqd8PV6XqBPpXmbmwyVhHQDzK0n1rPqdraVD94wQTWDaiXzGk+2LAerBHZcbuOZ5LhvkJ+kZBkbd1q+gxEAO/u62tAz8EqyOjkK96+pdoQXrO4gfBac0JxE3fwLsVIKMbMpZPjUvhrjtz5NpiG5+dKfoJMW3Jkt8VufA20zRdsfzjXIztO8nJE6e4Neb+zTx12OTUo0HRyyw/C6817oXUD5yYkn9/M1jC79ejZsA8ovNbbigPWqXy885b7AqIUnAiJ+AgQJEUYiQpQYcRIkB0JzzHnVd/EICYuISiooD4n/zX3qFZlCZYrkQyMcSURZFDRsxKgx4ya6dEmOAGC9QJvFjjrzx1b9pzeSxVmiTA0kSpRRP9x3xle2V163HgW9igY/wLdr5HCH2NM/I/FHDDGWnkSMJBlylFFyMfDeNT4ChImSIE2WAiWAPwi43vETIkKcFDJ5ilQODwdegqvXDz0VcBYu+/ALf04H+cO50Iw3uwSrZR90jQh+g354s7Pg649w+n7qMvhU/gNXBgYXJK+X+3njeS7/XvQHr0j2Af28SLhdLl8Bp85P1+YHMHAhbtQmkweDgETwBTIRLAYQwAcMRA5/8BRusPu+we4KUZJDjVAYpY1CUqLwm7xD4I9XytZu6l5uT/bed9kKQirhhnlDenE1KpMnWbSLjtrB2WY6lIgiFQj8MSalw7CkO0wYBhGzSiO2Z2rHA4KMrNycIYMpxEFjk1LSxbPC3T+878Nuv3hfcvGfQaXVhRVEbcySuVQTflBaGEQUmhcrQpwRbJ8guwX6whXrXJbtktkumuiC4cqe1e9BJX31aa+oiVNqOqmcEwihgDzfcDzm+c+UY/sfgOv/54f0iGz8VcxWTCkGFJ2KLUBtPUXekk+Vj8hL8qx8o1w6gHBOqhahigjNXr2Z7B3uw+7ndX78IBGWKblZstD6CBMZB/w4lRpzzg/9RdkD/sBU3BwY/XZgen831Y876O464d4ouqLqhWV3Af8qT1PY09JEgpFEQixsqskVPNVkC5pqZBCu0KkmBxFCKDDdv9INETcp6/Y2SCl1UBDNeaTkAubrYVMNFu6qTRBsyB7M71GOH9MOegFJdJbESAeVNvY65LbtcuvSnJS4oNTOl5Aqn4J5JM1ZzozVzylOjlUkgONj9XCYQ6SnGXFwsncVPjLnRFvuTqGCSlWqVmEA0OY3UHxqpizk1cLNvUCCk/qmjJLLfWADhMU4O8BoSF1xeFMsqj0LKaaiGz6V/5peoMC/TTeQ51+m43JEr0++E+/+Sz9zp/kknoPH5Ig/X56cx6htPVgEG8RxJZcZLbJdxIjUcwqnJEx1Z1bBxmhxfRzEQxOmDjvqP5W+lx9JlVmvOh6F9sVEhbglV6lydX7UqYBM0K8ryHCKKEIlyVOE438zfpZRHFpX4ZecMy7Jqk4Naliz2l2jnYLm9YUYNR6EfFBemGK1XniJh95d+RgazxFm1g8LYBEsgzV4Xqt2HTp9qN/MJKfdmjFtCQpAQSgExYiT8NArXG8LEUIiSLTila6iL9Sd1AeuO+kvWIHCkAQNGdlXgDaRWK2KSXE1e8Mj5syDn73jIUTID0WgKAObmLHmwIWrOP963UcWlQ+RkGStcaLpher/UTNmHcowZo7Jhi17jvbzd1y4EhVqtOgxaMS8X/5YsGi9QohStdKqWZd61qdbkRkI6ufT8WCPAhU0uvRYcOLMg7edDohw3Q1pcpSp0qXbFwOGDJsw57flYgPjQapVr2O9u707SCgUUblEAO5TRqVKjQZNWuNuWd/fzoqdg44JlixVpkIsH332Tb9R02atFI9kSq5cqWXUtvZ1r0d9Q9QsUF5KMymylNBZ2mavE0457aLLrggUKUU2tjt9/LLVmjzx1HNfjZk05W9xSLaru2lHn3OtGwEtoJwyVx/Uw7vtcdLNYfv0Zu+890mf8cpXpeYDcq42qjUozYtF5nemeNCwvle9Ro8802vpPJnb3C01bIHiBXw665wLHteoxm19ERTOE0CdCwc9qMFqFYb2fBEDTX5vB464r74YVz0Y7Pt2At0h91wRtOnQxWADAQPPPxQodleNhyWUk+yy7Xl1I6a2sGDFkVtwVKhqrcrVeIoyAXKzJNBo0EJnwpIrh2TLkeuOSg0aNZkowLU6clyG2/PUGDKzmTU4LNcocU+5arXb1l0TgyHtgo93Fc8HtsxjVPYBai6xu8voDqkq+SEjE7OPgtWuQaNx3eOax/b1KunT9gfvkaP9qH1PfXt/m3wjgaVP6Ofgh/lR+CD+gZ/cn3FfBV9xX9TfFn6U/LC+C3f/tTh5J/G5+0Q+Cg3GEeo8d7ZE06ddmTihlMkROQdbNeyWN17hJlM9HYcSaaIEtBaEvVYT6cw3FoyUeXKbLEgK0SZPvTzhpk6VnbgLhuNKI6OUbVHvJKCDhkLutG4kURbiw20kGoS1SLJMqFjEX/94ccUfefK+nPlZFv5qs99dc5OTEpJ5UgjQsebvxnpNvZEWYBog+B358araLesCsmqnLNshi7bLtG0/k4GsBakOR4kC2VIliRct1JCSbikRPiI7EswMI7epdi97UUmWymhrsUsiwo03nn0PYTn3Ktdilgt1OJ8wzrHKKFsZZiO9rKWdldSzOKWWl8SpE7o+GOEwdAAaIVvMH+sNtUCedEnihBtRVpAREyAR0FBmRvRoZsw+Nqkw3XI7uoTY0rXNbAgwtQlvjIIhRvpFP22u1uKXzMIw9odBvSdCb8gPmmJTGyEtZ81aS8kNVW3FplZ6t+iIOmpWVc1UpVAJiugpd7RSXIUvH1JCJk4ohUHsW47EMmSD/C9gSt4XPh2P1KBamf2rCarYIbnVUOyrdu9ChxYRLsJSUQ8g0AHg40VTmGkYvhgMpy+YoR8CnKTFc8X21kOqdxrNJOLUAr87qjZOe2Nr3FiRZcu1aT4S2VIkiK2aF6dZlTeley0Vey22Ogv87f+Rmvud+5Wby01XTcqsiY5p41VjNhwg6+ML/WOTrZnX/Vvdo8iMMORB9haPz2DMnJuavoToLm4a4Es/fXzjqz8z5ZM/coz3xaRe4F3doyd16jJgve86V33oHQbV/7HzjfxuvkiyDjq3E/E23hTzXitCq1+hR0tHrxfP2B5Nz0X4GX+e0uwnmvsxLo9oojEeFP0a0Bce9ovfFC1n1swY0ERBJooIAVgC82DCgE96tON6pkmdSnex5MmUIlGcSMaoUCRHghAenLoXRFl3PBIs3alA7LJLSfWuocbVvF3FmAqXae+7ATYlLjSA/MgpRmUKiYyuQen9tMbPpeZStqguGOewVbudUlXZkzbieC2VR+nAkY2KDXTRJFu360PPkVcfJLmydWvoAISyxhn/hfeN+8FxDv2xntPopkCSueHrchaSCJ/VXMc3W0SXrBIRuEaC/9XJ//iUOK4SGzHSKGqJ9ijdKLKeiAj/O5qS0+eDTlzNGlRiKzB1C1hwrEw6N8dxZXZEGTVMTqFRlaFUusKNDFFhgBJF95pIt3NdzEnLmDiNornWMb7PhAajfDujIKgPohDxUEc8MiEuZna9/gzGVxSN0mFIgxIRBbGIntSiSL/NKJxRKKPgnHoEEIXv1a7+hNdY2jJGS5qrww03XCPVOOFYoIR/JBt2YYhROhHr8hYzh2x6MiXDpK3vOQ+N9MOTSiM69QuDyKSQjFYacROwbT6y1RxbFLG5zQz2P3TWQphqfyJ8evB8m2Y8tPpiFYmV+O4U0uroo6HgrE9BBdFO22Jrtz+cK1lRoljTXIg6alBRsXLToIQCspAt4wJLy7JUA7UkN6J0iqSY5Nty6/hOynVUu5rEokXoLUyMoAXITNQz+Gr1qWenDI0ef3qTWhxshXKkSz6b+z+bsDHdVQPKjj86Nvy2xq+is6VsYc0vyOazH5W5k8Zmp2yiMi6GsTU9Z27WJi3Dg+omA/ju7eGKLmzrakJSWb11GpuZptzJ5yZ0x7UM/voafryRAcB2epjCKYZZKogxmqWdRPNEGp5LU5u09LxK/8Lqb5+ZEeNeOKiUCYm0dZePOoGhdWGmT20RX+zXBYCFhwoJn4CDq3nfJRECXPPLhD692jzTgIMlW7K4R7Dv528vX86YjNBRSBOCCCyBOSO+6Mb1WK27Cp4qBlrpp+Km/6bPd9989cVnn3z0wXu93unxv25dOnVo91abN15rxfVKi5deeO6Zp5o98dgjTR5q9ECDenXuq1WjWpVKFTjKlbnnrjvYSpUoxlKk0G0F8uXJleOWbFkyM2N+kU9YdrDiwDLO8DTxxMla3vTQ4hQDoAwxBtPGT+oMrRZNqrHlSZUg0mUnHbTjAx8dzehRI0cUAayBX2BCn15tnmnAwZIt+YMiR6Kq9RwDAAAAAAAAAACAMVquPvF0s/bXYac3ZcAH7V5oVKlEjhTxwl0UYL9tXFkzoYOKjARDiQMr5o0p+VS0OmUKZUoSK1hJRsjHURvGjBoxbMigigFl/Ur6FPW6So9ueTlZGWkpSQlxMVERYSFBAX4+3vLcyCTuVprodFR/8GXGDfAFNFVtPhiJs2WKLH1VsnuSMv+X3NAiIWRsuGBKnx5cTSqxZEoU6SJ/fjzZMkGnRBwBrIA5Qz5o06wWW45ksQIpEOsN8SZYL3xCrN61UR9og9Zrnd7XWq3Raq3SSq1QjpZrmd7Tu3pH2VqqJVqsLC3SQr2tBZqveZqrOXpLszVLM4MMoE2dNUXnTLDZU0itE/EJ4uxjSRn6DASsSUiKRVQzMZz6pSAucHUnclfu5gg84/dq7eIZf2acRXuxwIzQUUhDySu3E2lUnjce3Llx5TLRns6aRNSoo9H+RAVqzvd0s1VK8AD02l0BgNuWHZ5Gm3MA8NdRr980OnBpXU4gGZ0E1P84uZcFR3uul34hkAYAgA7a0THKDH+Rj0wtCJNtYTjRMZPcHScNAGHufPfXgIUgQgc5NtjjGu/AwQERMWTRjzIqqZy+dW9JLy8+N2rO6Qd4AyJEG12U2OKIO3wIHgcHkECub67BIP///sMDFqr9LKwviiz+DsCi4KEPABbNF+bPVHZRbqEoe9X1a6YmyiUgGTJIYTACiHGwEUfs8Nov0AwlgMdNmEP8S5x2nV1JXr77ZzZabxFpMshkyZFH/bIErTr/gwizCVOg6Lokz/regM7+Ev75YsmfQPPdEnZ6B3Q9/zqR8I3+f2ZkPwnsgwgavsKzuskpwfpYelVT6P+1zCl0QEVpGfMX2gnurkfuKmGiKToQZb/0UtXiTSaE4l3c3n9ePIfBHU2WGSzE1ErQIu7DGCytkZcMw5LLeQL8MYEqoaCLOzpZX0FOAI2HCj5uwr/RGPIYv5oxf5W3EhVYSNMZolQTLCBF1WCdMkwhqAICM2ZYGUqYNAmW4BZwZlGC9RHit4Ah21QC9AVJn4bB16GIj2CHoecEHxKCUdrHCkSp1qFRYFAZs7mMTCvjImQwqSYUqUXMAawQXNWD2L1qwi2KIsgdcAlkOfDPsQguMzmBKhJsmoKEBQzueijlfNQWkNrI+DUQdAoQ5/UNroNOhXLYGDv+b1ylxNXd8m5xffXJux+nq4++9Qf93qCT3X/BuDN2W01i6ffaJadn0+GC2SR25SZCfzM99BmiQAwsbNfYrozvYlc1w4afevs5ueE804q9zAyuTGdtRgLTKlamxe45jAswsV07NpVxYaX+zIzIkmZIOjI1ZOtzpTFGUc9NyKdbPDTqHaLzWEaD9oYX59N0yTIbuM2hi8Fxfj1iCzUGQGUTYxPpu1RbDX/uHQvyGHFRNPuSlNcGi2jNninN+N50zNqYkREY01rtTIsmSWE6f8doM7yImZlOmGhrmJkN0ojryEUx/MnGFHwOVZdrmqwZq+RtLdt6FM196NWWyuuW6jLU27bT20hPoitRZp2Ygj2f0slF6Cj+CZRq/0jkgksO+KStizBx2RIfemyWc3xHY1/oqb2nPtMdxNOPxeqXgF7HuRdA/9D/+Ld1lsSUi4SzPjlJDO0oEY6HjnVzxKLvkXXeXs1w+OQX+dHVPAoL4Gg/ErswdiG1fFG4nZfGPI+NHfYll830bio7Lo2tZZiH0zx8p6vDld67O+7l8FidSlZAZmymlds5rp2xy448nKbXnzU3OTdRIWNyEbkx5d0nN+4g3z25aymRwu1xjT4wgrEjSAr3qtdUfR9dh04/4jKWbSzDXCv3knMrTDHD+/YN5saWntpMM/m8cEfv1fI2CO/FPfJW793utEs2H13RLIAcGIlNkoW+42fCF2PfyrN7Ub4TT7nhasId71nwqCz53uMTP1d+6XjgidfUL/in8Dv+5piTWyFTcAbegPfgjeU7sfzUWc6NZemp5UyYO155/Nzyw8BT2odA+Y4TOaMbyLStibAbYA30xNhuKMd2J3QT9SZoLyElJINwBB9X8DEG5QXtVTNCDfFYBNhpgAciD7AK8CV+c8gCcBYEwC6APQSwaRTgwwAfaoBZ4LBvBqi9ADe0O7GXYn+3V87OPVv5dubRDgzsCIYG4LC5zFTY6btxc1i7j0Ri6iS9jlzi2Bj+qzzw1D6qHQXOls2OzT3P3vg2dRy2JZHnn/VLqj7H8vz200f3za8ffveXfPLZJb7GE/CpfTD2Tv77T55ceR1+4v2aOaYSfRTOQnfjqq0etJpU/aWy6hpbdaW6u1BZA7oDoomHtRch81B6VuKm7xbNyHfDpu/iBvx5A+J3DPwzA39t4PeaJrBDz1PYri9+F3Bd0/D9V9H3El1L6LS2sRato13bk9NSriJ303vX0ZNdWWZAATwBhQBlYOwm8NRmgX4S5eIOQfPEbcRVZOw6/uNeViHZj+gi3jPL4sUbDrlYsMP5nGNu1tw08sbj+7rW535yZh8xSfqDwfA2p2smtW1MEvGG5IDmjRj+z1e/OkpdzkWSKHMKA2gOSc7/mQDIEP0BFiAqjBBM0CvHTIR7OpUhsODJgUFUYTJ+F4bCTDK+fBbmthsq392GBb4UjMY7BpJYH0cN3j0pSUH2n0kDqkBARWKo516GGGB0YYRiVCbHPYYunOVCjINf4uh7lHoZyyBlqRFsvm79yVbH6sDBx/ZgkdkUqrA8MQqDk0z/wi0eMJGNJDehp9992cusCVTQLoJ9OhIHhBB+CcHgY/vGMgq4T4cgDpQMTRBgKC+5tC/s2R50Dvs2EFHXek2y9et52AAOUEFdgrUnK3e8yhw/npAzyG0hodlU7UI5+VtQBxKw8VI5SR8G+UryTYzzNjJgviFl01Px4Wv05vZPz7XkYmwuoQyj4qz8Il62DNNyClnKFMsoY/CU3A1I6D9jmQkzXd2mSPtTaZ5wA51oUD3DYMpL6VHK7uvJwFrPyBSOWlH5fhJ76qJ4lFyqHbGejkVQdG+O3z+/UnPrKjmEm+q8RUVB50JfHgUuV/tufTbX0KCCv0w2KDuMwt4iTOUlzAcx3en6h4UtzO3Ysmg6XEwJ35jCpmFYizBRLBuR+KGAlX//p5g61GoAG2B4bzeiOGsinWPbtoDQH4LAnQo/gMTRp1BJE6t7/dzNNYSq4FOr2f4mTV/6BWK70/zew37o2PTmTWfj2i0IbivZ4JauhKWh7jJJQX21h6DzO9WBvwgd+mVKT+dpF5vY828nEbgj+7GB8mrXxnpauPrQUSDclW+nl0oWKVlqxD54zLrTsdk8pGHdIGbq+HFP1EvGeixezBvE7jJIWAPVegB1ehSNlo3uDiJIU52pxShtP8tTx5HWXjHG+ackQr2WdjSR5NJQnmDQRUdRgZXHFY2cbtjNEbvsY06Gj6X+CHi7S2DzFnqQCGJOweaRv6k2QCY2lwY/sNUlOZYzT3AeSwekPghT5ZhtbS0fMplvZwflZT7NWXU/pmBupC4Gx6atl7bXR5kThJnwmJSKhuYGAUwq3RNnEeYlTOSSLmZYbTOsC+XvbYRoJzDjj6yCyMAerncBU/CwWfN80FHaGiaDROnS7dHTMQfAkSVVO9SRtjzVwk251rzYFXNNnYmuegayPyacVbm5hE7/AQjLdz9FQMptnmwnKNKGK9HFup6yCaaAtpvwcQdN8fbsItvdVQGkRo+UJmlmMKzX8Y8ufJ4NidTmpE0WxYSOZP4bRSZlCR1+IMMxURzkXCSdvx5KIwQaGUkwv5q+/RiUr0AdZnkWMZBoyacTRytutctM+3y1BkLDzNC+TSr4FFQzYKIPzGrMsBKPBvCn8oGCq+E5NXyHkYHA4O4qmHO9nKC57AO796livfprGIheKyTTxN1LkAfTtQFMwHEGrGaBw1c5p3MnasCxhMmRwegwi54EFlAdrzpvMYpZZrxc8RquGwapBmvNE4aeB1sGDB7OqeA+QMcBlr5XBf6TrBp1cA/0V0MBOmIYJhsFV+foLB2AmoYN5qWgvpjli+SXp43Lj/gcwjIsqTCuhgGbcRCfDNNRGtaqWZH73obHONweeLIUKntYdTLw+1+YvREI1SEoo3OSmF0wPVh4UyQWjsfuXtj86pTyxtO/4EIWlq/U58d0F7xzcak2O6r11nWlTubIsuzsn90VRerCOdPm3bHDZ7SlOPq4myNCXh/uw7PqTsjcHpjE0YPmJ/Bg3X0MUs5uaMTYmGyX1Myhue8T+Q/kwZRROdlo7tlFLdufHpcu9s6S9x7TPNc7yo/VH/rn6Ac1iQ0dffNTjOJ10/wUBMxhlunET4fx08dRHvR/i1jIFtQ459F88Y3L+a3D9blwPO5r8/tyc3kuyU79bzFmnbp6gkJ84cerUYaywceOJ4m3cz0knIJczBFCJOZ4W+wBUaHi/uHoq3y1Hn1966MrmHhx6CaPRIA4GgMKIcY6o3VNfsWXQ04bB3WznaR3AS12roCmZy9DtTMWPY3jKO4O/Qr6G30OZ/nzOVQrMirpsANayQ894NhpBCBwNhGEWMeHDET6oNJICzv6yfT+0miN1Wql33BEzIGEw489AJ1sd9Av2cBSJZG+yaozx5pi79p0VZtt3Ol0paZ00yYvBcYpy1NZ7oYzHLyVlaqODYijx6KE7UY5noV6OuYUedxQVl0o+jNTh+R+9fg82O0lo16VMjDIRXVZgfygmljFu1iNv4pQkGvb92sY5ffqOXocYjgabBkOhLvu11TKP0ZvuvCNKDGgvHz/JBYQlmceOaP9m8ZEbfbseLJuP1CHUTp8knLq1VxDqH190P2HrvKAO4zSVSChQyldnbBTDKfArPK9qkdzsQfcntUjrKoA4V1tVHlOMEG8qCsuL/WA+1LTkCfB03momonmTZ7W0ZeVohSnH2zpsgGDgCsrqoIOugB+HStQs6v31QTKTJBhrzl5YGX1/2kfOntiTo0LpIOrA6wFM7t3+fONDKxmw2455aMQyw2u3u7KChAGlOALoFRcy9ZdOeVnAYkncIQp70KmNf3LozQcoaCcPMF1MuJHasR905jAhpm9buCYWjppQKHPYxITdAYalZV/fvrPqWensNu90f6p+T1krHM41zUgG3RefeIpYgzxqhMcq0UfRhSgmXGVGrToBgbvauEORXsZwu4ITbowQix0aovrC7FOZsKAj4an8XHTQckbrQYclPulmI1KsGiInVUtGnt8tlFRVCx5OjvxqsIQ6+QCpsbYcDi4s7V3FpQR2gCTStjUD9mdQJLxwUUqR1YTLmiucThax6tUFmtUamLaoZEarUY/wQROby8r7tby7d+ykvslOh4ac6Ors494KycS1X1C34zAQz/nrEUQpe8iBHwk1RY3fQ6DqJl58iD/gCPd1IrPQZ1J6S5qne3WKSN+QBQbRUf7p61GpHdxIIcdgrj7hiM6C86qlGTsDKb/p434fXl8vgWsuce2BQGr2FodKwIjI6CYdJ2qU8wBTjkacWmB4OHRpSZykKkQllvvNHoRBXl8yxyZoL3KV/nNtNnxtrUXK7bkCsjiAOzUUAQ8rfGvSAKAYibYHa4dZ7pYmKBZrhgRha3aDgPmhLz2NcrYoLnDq5XnLEL9WhcydRZtaaV9lXAsO8KVQmXZ9jVcjgvAlFfYs1+XsFUVwwIrawIz7aUGyS5EHcDMIfmgINsP1WL3MKCV1PK0HrmuFbtj79h73BB/tWcrme9WeeIBaFZZzkePBG0kL+cdHvOTXGOnz5FabLWZ7VzFz2XTUDiIpaWzdZwa/UsbWlgcqmwVgykZwQ2+8cGjVB3E0EVzqZKCMSkCAYqq1bo5P2MUwk55XShTJ+KvIKUynDiEB1Kd8/hKFphaGIUC4a5yoKWPTLhaQv9k0xubLETogxKb4RzF9Ka/he6FH8LrZiZMIkoB1DWYxwPPRZkpvEBEfE0nONDFWFSrqWWWGshuVxJWDlRE4g6lFMLeGGKb19D04IhMg5z6ajfA6BFiAwSiXgiMLlforEDit7tCu7FPkDyF2jnouE+POjtk5K+R/4aMtth8HhopmMhMW8Ooz2bONNy8JQT6dEFNVucYMbrXoSVBJMpeUOaxY1MGh1iNIbPvXNRT/2RWhflC0ZZarWok5iiO9JHD2Eo2S2//EJcQmbMHrXBJ4br3dz0MXPzKnEC6X6iFIs4SpLUaczRH5ZVu8kTOWg1Wx6lkFJKtaAfU2MaTpZ9b23Nj76BNf0N6P9rYbtmq2lxI3txPHkUy8tJNYyqOYb88au1wzW2fqH1UeJp3qMJGJWat8srxrLwV6tWShvapE2iCobiDUM653nYNiHFPFTQyHxQzue5m3A38f4FmfK70gimcm+fgsO2bjNM/ex59kJSVABDtfrg0TPswIUabXQDhxFlDVcVpU2xu29SS2sJ63pxESuGwWLmLl18l9GDjb/pU+Un9uixCD2OPd4UGRO7gaOoi+CKqaCNXNsxJrp8OxpjPRXwoGpEFDxF0jskCuisqGpZct1XrRekpnbM82wDC/7sb+ZY5xOnAhjS8pMPYuiJnVRy3A4nNe6OOYsO5lF9ZM3/8WB00OkpMa1Z+mHpfIPehrvuOmvaManJ89FLuAi7q2nnZwaJv4DFZZSNwTY0/xUgkxH3ShDf1xdVE0bFIGdv4dPTUZ4OWi53jP5W9TgjMAQcwjeWMuCf99rDUfJafMBSKpMsk9x11rR23UVha7jT3IoO78NooBONC667nud2K55jmuKk9gCXzB9i19PWXKDp1a3hxzpOn5BnNgOGUV8Wbhjky9JInOQ8vlRSQRZRKRA9FcerTNapC5h9v4jLFUQ3Utiibh2B65qtTR+L5+OOggBQaWD8ojLVN1S3F27LIcSEnxJ7vuw7ePQiawz9gw5ooykjuHqKgcPjN7AWgAOqUz2Uc32RZ9ltSkQ5qzzFBfQGKY7/QLLNLZ4eFi1vcZQKX170eCbSoz7Xm2bI9ypw8b4fM0ra9aO1uEob+B+2UH53a1j/r5flxZaOFXWk0b9U6jFtZdJNOJLI4NSCGoexnUR+1qDGeJYhPK7RDaDxvt0FxIN05Ni5Kibz4yEoqLaOO2TH8/87WXtG+Ln0qj9AXYEKHmHDVtwfHCR/9FsRhL4IofV9Vo7b/+BC+NgSZrv9MSoRdqVlkb1X3uR3ojLVTNBENMR8OrK6ISlrRr5AYPLujUE0EQjSrnOgbz/g1GFa1vZapE0x8lHtMokbobiywBt0Nz6ZYRNtFSYpsmqyllUDusJbJHBm6dmh0bCNCLdKtRLTKlKUipDOJHt+kRD3Yk3DeYRYDe3tknuJ9zZuBiQYCMzs2GfGcMxwJ3aXCgYsGs1/UcsdgmpfpVIc2/KZjum3K1uXyDolwnJoJii7BYAibmtYxXKyt4roaUvI2omfQYxdP6Tg87Bs8KrfSBznpHcXyxC9IV5nPYus1qH+vYGP/Ezq7+1CCd7SKgNlU7amCNsitVQ+fPOFrm1ssTVjlF724D4/dyrsKeNpSoaEuiruRBGSbv/BxCWwOSVsg27smok7d5mCPvqz8vdgZCMNWTcQfWZeUJ59UUIdxmpfWXdrw2XkIK9wFFchhoNbCdB+UhySwSCdByI3TdhKcTm/aWXQ7j3c7yHm39pB0Fjq0mvzD0D1Tc3SymP6IObe84VTKhZzxtj6K5fHODJq3dLUho8RqQZT9nGDCXj978JBKTz9fwH1PXXXmJRxOIPk4lWuNS4a0Yd3i8BVn42AWB1kv6p+k7LtZmKczJm1Q0HvK75LvVWhA8EejtfZAavpmVu4Hh0/4ULnb+0f97dUFuB2wLaT40AyHKYoe7p4hTtJimuqUlAvZ0OvAh/rppKB/CKWgkpOHBT9yRKnNr76D3SVGanCUkaUSt0OgdzRH08pxa/2EsE6QaMXKJuUAEIshUaRIe/VwvNiTmNgDGRgiDyc/sCSYNC6CgCiSM2jHAPJVHRbN2BlBgE+MLxrgxsNigm8WHG6AjniKdR2oYCAhOi3h8eyeeVVwnXnqvByD7vLVyXkJzpFEHtTyEH/XR8i42JFvudc49JNbT5vQvmcBG0tAjU/zla4SmnGmm3Da3vJZcg1v+y5NsKiYEX+NWxwAGB1MocAZsC9ZhUZYrxPLCljne8rClcxpIEj4b9i71O/RsjlJzCXYNqlecWqKsM6YN0C+fROmYgsp55uS3r0goVpwTD0zTj2BGde1UXpxBgGevqQ1yzaOoeViLOCIzWJ/AqIVDCbylRrDdd43LHiEZRyecwbqvK+cw9gPOb6e1K64TJgZrefyWCFgx6LUQj64XQMUNxnL3i3vjbyqE3V2LZ7S0D6TE/GVsWXiTP8/lNtsoh3PVZYZoeg53RaxcCogL4fVDaXe7GtayF0mvr6/4XJkABe59IsTrzILMG1cHg+pBSZuC+FY69G/7vARJlcWHNfupnW0i5A/prZ/ue8pxN39fKqfFRStbTapQu3lU/+TJfLZRs7aErKqNeLwP7O1b5jX4oZMCwZ1WGNgnsmRhCYgWnBhESlP+pFqZE340brnoqR40BKiz91GSmVD2NP4UbQpnXXe41Y/Sz5ykyAWCY/k1iOdD2Rq9N39oKFcc1ZTxBzWGTzcmp6Jz1PEGbOaW6XLq3QdR8jB53TOXDxa4e0B+yx7agqxP8xex8pcG5bhKXLutoazbSbpLy7DPlMIwnXb64IfhfVA8PLiCAkYFFI3MFcNO8pRsmpAR/Yon5ZSY7KNk8V1f7jYvU2vqpiXDWBhBQWQ6HNawPwEKDo5K4O3lDi/NVMNEDEuz1qyTnYraYrsWTAbs5tKxuuzng+46ucIXcdBzH7CrA5qrLNbXjV1QSQxBlxL3BOUc5U22j68QlIz465MtR4ub1KHeTp6IcA4mJS499xHDzCiE4QSNG0czNyzbbQX6xxdTABY7QoDfGaGHzqUoLGUaouE4o8YEWwSQYwFgJesjbwh6Gpub0G0WI/FaYgSKQZ5Dutu8uwi5Wt+5NdAIBaWu+JngVfPnAe+pEwJS9VuSM0X9OtsypZncPSwCzuPINFhEdi5VYCrsmwJkaOtoC9hejf4GZLabqGwyOnDZwbXshWW6Jwz/nYiNPL8JdXTZGaNQqAD+cQa8zA0RIOcYi6tWiUbCRjRt73ywstUJtEcvQnDQK+a55f96Sr2Qbas0XkqElkYhf0eji+KWzmkeAWGt6D3I/RikLkc3Zt41/DLyoIDMn/d9uMoFa2Bmj6PAjemicKbfPeRyDEeRDjFo/eOZJuxDK6wubz1cCdkk8cXWgqwVkdPSQBbcsMEZtY2WyUz91KhnGUY7frCxTCv1vyK08F7rdVl9LDHZpYdu/c3I22Mx3NCRPIdnNRSdNamj8t5v5aF7QPBvo9Ft1HkzsE0ZwvqTJ9RkArdPMtgHTtVYE/WtXZX0qb9bMChrR3NvRRsqB8NHdk7Bd/slrCuHQ2NJ/yGsClehJDqqHzh16uQ8sT7OgB2ZG+F029jzFavtbR7exte4E5E5q5r5zq9+6r2CiQVUC21klk8jiYkWH3w0kKktooWyW3RNEcDWcLpQzoZS0m8n+eOlIj64ob2FDqlKTb6qPa4dRuusVDPeSe6LyhqunZoNOvvZsU+GCH3MaaMb8sScJmJiAjTIRhTgrP22Q0B++pZR+mPF5US6zDBGwltwJRJ06oC2p3/Vsb+9mA1AXL9hIrG4KHi/30zHWU2HmJ2ceHUT0gres/DcnGr7J4fd3yTnu3cPh9YVXdrRZWx5oQYqRwOzsNTZjkHsOO3X74eC9U/X5kYmPly6I82w1sIz+AVSD07xX5IQ/1K8/54x8n31nxsePewFo3dEdfWh0K2CHJ9zXfwUdNa1xesI+qvLvCe68aSCPgqZqPJPQA9wZBLh/TT2jXrnMUfenDsVf3xu1FkLq/FsK6AbdzbHyk4H7S44JHQtPa6W8Wos/HPrR3hVZRBwC8ORcSe4S2bX4V/k/XaDLqw3tTq1X+PCWZ957kA9EJiNz796iMT442NzOv+f4OzuWrah7qYhYrJ71ATzwWIy/uJbya7fodMfXO7ha0+8r81nRoQvePLd4OoM3kITa4yXJHjuNqSQN2LV3RhATTk24XHX1FAJiwly36Fvw5l/GqeTefgI4s/ewaJli0XCHSl6hylAf0mHECX2iR5Ik9cxjncF0qyo3Fo4nU12fDevvxajxj40AetYv2TvGyQDppBb+86Lo5AuQuG47gx4301LRzKVn5hJIBX+tU6VycS1aRw5czi9w/+BBknRs2SggLCbXnlSX6J+0AZMyHxofXJKMSgzXFjAOpU8Ro7rcOZd/TibMgjqrz6UHAQP5Z0Q9WfzWKOGeQVZ5yIGK6u3gZx3tRguaVI1O/+BMxBM3cu0hDABEqTXxGIh19oJYod8292S0yb/e2QcBk2peXkrBho5HfAJkj7G4z8JDjhN6D1OqQUKPwhoQxuPVN+wIKR257cfU37ktNr2BuyF80QHtPxdSzOHKfenxN+45UtrkJtlqH+7dyQyN20oYrEbu4l0tIKZDYHCn33LH06Vxq2idSQVkf01gbWvJND4oSeuaPsxDt6iy1VPbHb2/HBy0SVqRh/VV8Ye3d7kBQ0i8XV3nrKSZ4IsbG0s+pc3KQjiGOLXRx5K5Wfo9gbnww8ACn7Q3neJiacP1GuIzQ5ROrH9EICc+mgmkO0hFEfGd8FHgf+cob2apxwCZu1HBFH39aaikRUle6n4GelPdYph3ZQ+4gC81379EJuRgNYNv9O22fWzbc9ZYg6C/33LZjXnzAAg3re29P44QD1+LW+5U/YP+4u2vnEY+mP313vhWGr2iUbbh+S5q8+tVurap5OteOJ68U36p983ziGNtMr68RSkVoEK/Ijnu1R1Bc8Q371jNsH0nRrDOLEYY3Uqf9eTlz7ysx+N9wvm261ITBAyu0UDErf00OR2ln5DoEbWXAorVMFHP8fNwZ5zxBM2ufdzfwzv/LcU3GBdgITHfFsBYdaYR3XzKTXSjvrfpVOPyTQaWrw9zYX1Oug4xu3mzEc/aqHhj9Ke7mbeo4eEzJmqUUNkIsEgN3rfl9movQTCI3fwUiEVR7K5q3+onUzx1FN42Xn62NV2HOQcoRTHmFud+1RqH8lDu+wgy25iwbORH3Z6WPh1+tj29+PC/9fKiXOr9xfb3OB1vzpOv/n2Pj9W+lhCL55MKKfOlWDjA6GoVqgIPXsj30ZGTimE4+bXfjJanTaQZbpx93kQg+zTYY/jhVu2cdBoiMySBT7KUl+rvbSboP9xm/WXrbHhJtgGC2WV3KU7w5TCCgJi6vySCBHlG6c+gWcaM1ZWgo2WCKhnIF66JG/OO7ANbP1/3yMR8Kwv9YlFr78xi309+5h/EO4VC+gHUGO7QOl7gia0YJhqxMSOJuVoaHO/hojB7uVbLURuNJIIQYTB+ud3sFMONCXcJth8R6DPfoHYoCRep0e099Scu/5E716STerO/4/0C8w7AqzsaiX8VgurElG/HAXTVo+J8S4umwGpiodaL6HdIyO3QxLYNW+AeQZ/AaLVLGYyz/ySl1nv65cqCHgDtzCFLu7PcC7P+L40w3+FHpZRJdIGUmqD7RmMbGjjaBbFJhTxKz2gKCyN8M4aUrfAeX0um7+LzWTyk2JTKQQ98/7iJ5wjKIsKC5bib5rOHH6eMpAIGkX/HF1IvBsD8aycKkF4Fn/MKxLv+xTys+z+d2yiApebNaCCvDW0qSFdQu6p1Wpi5rCQN3prE92WIb7EAaNaJ+8aAEhtIRvGTPt7V1ta9OdakTdWWlvvdJ/GrcIaX3UhZHCcGXHWPVqI4JVhvbXSQShP5NuhIVgIagKg79PZ34eEIp2GVaPEkuaPD0eN+zwfSJZQeJeG44nPfOZ+RKahjHKS7uksDAziDvpoJ3YXkjT56NGGyvLf+J7yc7DC/PhkRcza/u5L2Ha+I/hCEVHd3VreVvc0BaRDvDkty6lY5YRcwmt4gohNyYwTskuFdeN9Y6N7axAe6NwCspDeSEdXPYSk2sd/gpOxphXwnzIds6zIphBS8Pt/gAYOUGvAbPNcXdRe020302ccyba19hufujvr34Ckv93iJ+p0+5cFZzg9iP1oQaQ+vOM5jT/cFekashb76kjA96ds1kb7uHjlA0GLLgBGpAoo3JnqAZAvNKjtsknXu02WzRuGJbM6dBIOuMfzrQAwGRGKJLdpjJQsWoghaUtpFHbskixBF/i8gVo4CCZykZEju8O+EY2XDvfcRblnYoWXSBhVHUc8DMbiAcC3TViSfLy6WhwtWWF8bGAMLLL0P4rBnSdH3ZhpNAg/i3XmtWfCHFeyAJrmtrx1pZ0pxpWdQ62tV5JmB6YmgBs3+cRkVkOu2CL6orRaU7as37+KspSC9ZalJRSuUJrNKOGOsxcrvOEEqJLDpKGt3oNeomxICaGnM03GRN+bZq9sBkYq1KxPGRon2MErepqsj9gMOo1q/OyumkOqs61szO7fHmgsUnXyBqWH5qJHi4N4eHsq+ETvYF6LwlmsTKw6Et9cmNwwn4l/Rqp5UzMSOUacPONQYJUW98yxY89PHnQNymsIciwutOl4VQ4hqI4pmKBlXBH4YcQaxzS53DGkI8ZrWt3JH6cliB67IzsRex8ksDFM4UhEIcToKGbpoz5pAlBg6a+V1/QS+irP1PUTWxrWyNLKXV4wMvwPh8JWPFN5j51l2rvNC6c/3WJ01XZWV+6ZnYij8vjjfQNa9kh3O2BUptVFw52gQa+k3yxQ6fJiIlAfkQw6EK2Xri2JoKQcYuTQ3AHbwU0TNrDWT9omcRNym5vxLlSWtXe3aliFfU4DVwAnR578KRsZTPrYgGEd41XRyIs6dhI/zFKlTnr76yaNNgZWGvxwbQpqNJ7jMDdHry5byCY2qzqvDWA4B92BYW+cLa8RYUT8WfyQcBISG12dtna+W7CweXzSUfHj0Bty9uODkTq+LYD7oh+0flwv3wiOwKxJNSmIGxQybfuT8zD1zBeGSUCPN7lUHe4taiNXgiUoZY4m6vyJyP7trOKru4vUVMOzxm8J8JRPevpPN02kLN8SV1MLXQKlInf6KoEtkcz+wTVSrTuko5fzXOmUzY6XnCfRkZ6tEEv6D2uSO0uhUJZdI5uxbZERzNavZUx32LVuw3mA0Z5vX34+KPIjJkY8MiMaLjkuuRvLLcDJcwP+YQwEKU2FKzoemi+vV56Fj1xQM+s+6N+Ts8MScVACompjM5+16O0aDPrjNKUM8paWMvhZDNGSTqRGCrOFmq6doECmPtPeSKsV7k9SoPJo1Z5TKIDGx5FXc51MFnhZHZoS0xKw9BhOAmvHslB4zCXOD2XaClQPDUwDgvCOExV7JS5J4f+XEPQr8N98XSGGg05st9Dr1dJexiMHuUM0gPfvFTXvagyfi2U0pft60VTP20r1NiM8YwB52KcRTmuaEFbZ7ci9XNQEUc6wiHObA70qu2+XWTOhBzkJy6NE7aV74UDcKhPgUykx29l/RnX1HRfOJTuD6waofe9pL7uGW7GtVoINwKT0KDHdnam5wcD3ng0vJhoGt07v2rDdTX1XX328CXqMrX3Tyb2WDjM++V1GLpOXtaRfnFpoD449MkwK4tgme/rTnlMskopGzN7sst0QCC1O21JaqEY2gNMear2uhiPl12DXvIPAgeWTiZ62g1o2mDKMgLVPabn2dI/oRtRt+1fgR5DvR67Nz6IOOLjIRlm7dPxEaZEcrGw4Aj4mcWzUBMfRqUOKSAJpSDSiFOQxiSDhDmi1Ues5XNIhzt6Lx880zyD3A5qZX+nCYqo9T6z1eiPKa3s8TLgv/IE0migKRPIkCYjTUDAbaDTC6bvwvzMPcXt2r+L6WdvU53vYfaIQDkDODAfxhVBELPGQH0WZw3dILPHrSSsIcTHXQuoIOQYSF466uo0Zrq3ljwupudB6JKP+FSIwTgfCpwBuccid2hpRhRJlsxIkWHgYp+ZIFPme67ZQcMH062/eW0mtElunfmBl4FcuV3H/2H79nc80vEPYbteULeZkx0t+OVsQpSLEW8sZlMQ6vbWrgVaGZrnSo25Q9JAxn2zy/tUxICCWs0j/kFGCga0bq6i7sCZYQE5A3rPPH4+j2bOUR8aP2BISdOjUNeJj83foUEvuHetz+zYuLu73slzblDC+qlmuuEc9bTg0SETk7iqGANDKp3XBNystyZE8aDBSpsXiPXRXF8wmRlOnVLfuS29Hjj0WKLSP1YB7oRGirU4FGQMpV5YmLGMwZvOEkQFCvcjGJHyzKNZCRyiPny0IEf5cQ6YsvNgA8XoEnCP6j/wH2iu1+rK4QlAj3twqZ43vC49kiDyZrDAkFA+D+FkArxiBA8dRLammW+r6mjmBbVJzbd22rWOaJAD7h5YiMMuFIRZW63bUqHui+RKY/l7O4UagYcxGoJw2raoRUbmWrXhqBaJDfSnC7uLitCbtP3f+wl0LzTo+Y67MD9rb//O8r+L6bO3KYP+l9QRRuiXPu+PCTkxB6B39Y16ftrLncQo3myw0eY5orFZSFUIJXIjyedlHn/QGR6he85Rz0j1q9xnTNDFN/t9XIMz9s7IKMVmU7kH6dEW2unFcKdMm1nwODcf5GMKhO2GDGkEAZMd8bd94wMot618Eyyg9w0eQB9hAXuevNKPm7M5EOGLTkWNrdfBI1nQnMVJcz4LwkKO34cXidmPa56AafTuLwIPScs+kvT6GNInEyveEfoISvZTpOwhCZ9MAjp7ArbpedVr2pZcrfRUvxsagdA6ZpHjxkugNjnjYdag4Wj1XpKFUEwbdWKgw6TztnbxBlUzsfxFwqHHGIFXtRzxDiJsOi0B6QE9hn6t8IdvPKfnm01q2aM0mgPq7P/xbJ0xL2mGabuFigrcQnL0QCPguJt5wovcb/1hCFUFzqLw9oUcBvsjgWJzbKQvmRzpiyGmcFIDr9ruTKy4RDz/HEH6I93laDaPojkW+1wyBvwKC9B6SouAB8EmL585qO7yGBgWHxzHxfLmNIkN37QUaaAbGqABdzm2ZADj0bzKHERt7XQywP2Ao+3In5XselmliRJo3HDgAQ9egsnIZyhrFBW2eqQPfZmg592NbGiVB/+CNXtw080u+kqEnQxwQiXqDFQ49bEtA4ihfzi0Gh9DrbNY9srWON72ro4FWLNGiI+mZCBQkazeaPZ2b5YILUfLoN9ERHqDHAdc48F9IBnACJfbAVkPxupxxFDcCvZB6qAcmhSmz6Uhqn8YORJ0tL1oSLo40ePheJm9etN7YQRYf4QO0HfvKKYYi1Yc6iujTq5iQYo0AxcHLPYHvaNUbbJbZ27+ebj+G5amS5Q7tMKf9m/eWNGmyDlkcH7OjlJU+giMP6TeuZn8EPiusAlLU25Kljeg7m0ruhoOSXvBofCXyO+NmIIKnVsnDOMaLY2emPfbKzksIZM2T8lVRl526Y+lMHp/uKaMS/YyZOtlSDhfhji5TBgK1huZihBv4jXNQntHs8CrTRpHq4LXAjc55nxICAVaAC6BqsqOTr2U1VOVEZO+mYBuuM8GDxI+3ZDCiTqBu6q6us+YUm/B+Yir4JK0yVOdRjddhN5xlyhZdiQHboxJkB4WtELGJBTHX5oIv3EMHHsY0OSROX4RTzzYUHaQpzx4E2pHr5Ct5a0NTN2TjRrqAg11gCV1gAZl2q03o/PrR+vrx+rnj9Uf4xBcIRWOh1VKVxelokgMo0gVCdwVs5qyZN6ShrqLFEOBL/D3W07h+7GfeXfOmGXf9PERb0YHLJnJs7SHPe+6uW3a8EuLF63dKFAMgMSNn8MmnkOq8N9TyH+L5ItLUp9otbdYaTufOFY/f3Q+dlONQuQlH5xU+J789xJKVzOuZRUUmpjYtai6rcFrNTit7pZyPft5IR7YrCPNKa8cr64OC5WLESyjNYWtrpTD2bTRnE1POZhWphUmKA1E40YTY2MST+X2DfZnZBvsfQLf8DU2ehtJ7s9lAPSvNMTS4SCrEdo7OJWqgxPaNAtQq0aDWrWaswFBLwSir59+JH308W/tnMeCj9DKI+KC8Nzj7kUPuaY2hh/5u2JdJTSyrYlFp20IQwk77P8v+sw6ypxuMyh1TKjVHBsMT+PLbajJaDjq6UJWZh2jTe3QKjVspAMO9kWmcNNsx8NDjnqglxrYbElsMqXEOipNcdfOirKtGEqnZRPpXF96nzZ/rnWGwrn5IY5oJLYgx2c2AfVArDNjT6qTJAtEZsRiQGxWPPa3QhGPAf6SigULDtSxph8ifkWIyGERr4GIT3MjTnIiPpcc8TBEFOGIXwdHnGgcATz4WJLUNHImR9Hg7LoYrWCzzPznmvRdclw2F6BCCLnkRwronrOjM6aLtgwWU5KJgHR7EsDpinrx/4OtQ5HrVuLiEiZjlowHzCH8KoGvvJl8GXVY+7i2XTS/74/hq6Gpba1W2uaF2qSAf95PC1IiL+O4/06SmHA0JI5Voo6EzrdTAyvy4Tmy6smTyO0bO+yz10V8CYIyM1bUxpQaVtqDz+1YI5JZk1u2hmXtTVRBvGB1vjrz28lTkcMrJsUkVKaALWaQdd2BdfOcrlzLsbYt6qqZ1FGoiB78WCTpg6FENNFd+I9raq4/GMqWwmlP0gLROr2VtiQX3N4L8wGzcVSnT55754QQoOt0TP1lgTPr6ZFjUlwsIcREtzl/6+NPIisHHzYRVZQzaEJtdMKubt5qYZ1+HHH6ljptFB1K1HJ6nA/A0ojCpjGR3Z5iv2+1qKHDSNchau8ROmQ3pyYWska6twjtr9TLrCZ3rhXZF7akJRhOCHMecm57D4NazLCRElWUZENWPp71zFmymmblV6yTTynvyU46QOqlT/5tqZDoHWafGQmmS+FQuhR8pYLe+4L6+j1jNKHVQkTqYZvr9DwLyzm9huUKV8RiE9IRtwxwfYtFiKHS4Jm3DREIPz6caocPc6fe2I6PQ7zxxqUuPN1/5NrlyE16YqbelKFvVV1QrKnv/86pevI0cvvmIPN4dUiKRwTQ+0d1eta5X1Z7BYnrn7iUczF2SX4VGJX4OPQe7wbNnGWH8xWUr/h9t0ZmqvO3lkQm2s/yj/97i6IPRqqzVZuLohNrlNMjzdeuhI+sJJpTCiGkQCcoQvXWXcg+a24ZzQ0PPhGXEe/zyNkI7yoGvPEwrMS72hs0dc1uaJ4zNeoOyAMZ5xPTTWNyPWpQKR7wD05TXHPs85bW0Xxkx1FWRqzok7Jxp9Qb8SaezqeZl6mPnzpqQlbof9UE3h7wPA6JVnSYsp9Mviin3tiGn9/albCAkwdrgss23586IutuNyUrQbCHTiAo9aone7tu5nhfuJmabvTlRlF/i2LytXV0bz6NaVWSX222BFRqUWMDI+9+0n0O4Qx/H0jVqBDc0IXCy+drmWgcYdFTPi398cvvr16Zlle0oyyWMEwf72JN8YSLgSKNow16xr2LC/iL8tr6O8KDMZ1Ch5vmcPzl/ZKcKxDtDVzY+8Zb1Gk9yNdAz9KbpyQXuWnFWsfA4KxPSpoUZ1kpzJk58AFmHsjFOvk4VkMBx6HGo/9LAsnqEAfwRVevn9e1eLnekkL5KrXglRNGC70mbBa7m0W1uHqVvQN3v/BuBQXh/hgExdj3ylRg6NCrfjzVq8WtMF6bGYG/7eT4tqPjV45OqRsidcLHd+hLHL8mbbdNrhRIP3aL9rjugrm6YFQeNM3sF139M3apA9HltYchvONlPMv+lfXyl+xFaR+wRA0imnrV39R0RFlIL4rehofhJ8lUy1RX3lJkIXvd6RaZD2z533Ksuje/1gwFlq+Iu7Qnqyp7/+2xyC3rSixTLzs86EyH3PtODkUOLltoE4Eh5dogsRjOsJczhrwOaIdjU7vQ25yQeYfsIr6W/gM/Bdoj+OAvPjKKbvTgSVi9x/1wcwNd76icHN6IScHPv6OVf7Rss/Gx4tz53s8tx6fZAHYPcvQz1/YoHeWIH6UlSCjEkd0iY9G+QYsA7CYByfuc3yin3fmz2DpiE83RHfk6LV747X+id2zWzY7bzH3F1L7aYP2a5E1HgtqifV/9lv73RmJuDEfbkuY/jtPZQJ2pzaeH/Ic7S8xTOW7fpPy//aTxxM0Kju4tznYtWAT8A049JN8pJj0EPlNwc7MYv6qlJrlTAQx0ViQOTHuWO/X6FsvkTjSIRnrou/qjMa3RtkUSpy6FjqwssUjU3BDHw+RBu8muaRbaOpp5u9qkFloVdi2wsq79/VvZqWbfbEqxmm/Bh09N2RSe/GAx4SjNwppWoqcM8OFbl8vzr4eNbTSxlmQNfOWGI+lDnNy03wB3pPNqnvkqDl5GiP8hLKMt971HOd1xHKaOa++ZPsdSN1rEI3nCY9ne3k/gt+5kbKmfvUM0ctBLu21vI8gDmq2P6mzZvEj1re/2crzM2K636RW86kk3O7riPw8ZhxfhqAS5jdBCeRLRAzcX8TqOnxN3GP/QoC0jHMmIRHesL1hqu+u2In2yJyvXnUlVQifQiIfeTXFKqxlbfp8UFYyjGQ6guIyDOxYUxQTazsVGAIocSufVMa0mkhl/YcwhGZDbJtg67pFAmdWN2ludEXdxOV/IEEyQbGx6+Jp7BC7jFpdzNcIG+MU1fmV9zrxZxZRgADHrgz/vxpJCBCjMeQ1qgHPa1qeysJ4hiDWM10tQAQeuteKcuv37B4qaJTsQOojVq1F4jbU0R+40ITeJzmmR3idaQwZN3DpvK6WBFtpyizWpi+fCG232wZ6CstQ6MQ5PjXhYAyQE2qWc9+kuT6tSCw1DkvqLAxlnnT86mKsF8J2lR+m61JXNKDRy1GiN0zjbrbcdKd+YsfnLi0/3nl5wWRCDKDhlNvWQHNibAbHVLYT+EsYXdGraOKq1E7SrV3NtgBsa0/N9XikRDC0imob3Vhci6uAdvbTPh8JhggZCzdSx46BdrtLPqHcwLpDG4rjAILIxjWkP3o5J0lrgILyCoy7vCr/BFJU2r0vjJSMEXuFujbBh9xJctRNZkgO8O0B13bSqmQskSoTKG250Ev1aIm1LclOYTBflftmb1QWa3dZlv+XbycK1w4J4dzJcYxPozoWdnJLmjBy5IlKf9JjHNbgYL42w7NbnuYmVgVe082MxGbSZgpbR37IUcJKEM/L99DpcVOjRbXNX2lmjMm+MuUZVsxdHiICl1By8gEyf3sGatMHyqhEwEs3WQhaZnQvsUYXzcJLvzElMGjXoRAnyIX3bmpwSgJWhqpQFG8fq6Pe3u0Z43MfEcm2QxGUiO4SmhxWwfM1ic6QjVbUflGxGt9aJI0efxYB6erOxYffTArnduBtlOnP0FASAeOAkSg1pnJhWoqDZUmkyemnwKA/j/HmxSFm7Uapjdn01wXFZ+RAyInBO0zNvU9gLeh9NnqFm4fu4QM9YXpg4SvVj/Z6W9h7sSdYKNxAjVDTWqS6cQHMvKxf9HmG7dJY3tDEmTl3j348wcyQ69UdIqknPFj34V1F5xuno9940RiCXn5V6D7TqPu1aaT+CfidLz7Zbj3IkPfI/revOrWv8XYBXkfup8WfTs8VXaYYu6NjBk6Vvddj088oANdSn/YGMdkhp1FxEsD6/iKQGC0ZPoLPnuf7r/laFIBE+7GqVMMt+PzVuub+zAVRXb+SPpgCJ2dRuo2paczeexHbo9xdQGdB2eSSNavuaFj8fNMqWDMjl2gPjB+JvuPB26jpxZ3X6d64+J+19rh1OiFmIsgo7pGEcHgGEWRgKcZzpvvwJEXjzspDS8AvGc9Lrd6JeE8pUTqc/etbExKT2BTUwZrx284mJEcL6vKrqqJteRXBEW89k6q0D6Hvju66wgCcNvVt92X6Bl2E3Fqdx48fiUMLEvkxvDoJ6FrcgovnIZa7frvsZGpstQY/XxAO+pRlBbJ41LBTjeOhX77uP+iDBUTZWHc8lCVwZgus+z+tOIEb+I1zCnt8aLeEtO2L0VDrLGdjYgPkj6ODp3KeGTE0ldTw6EDnenu00dxtGo8JZ1BHkNpBTr+E7TJobGuUX/ISWcMSFmFDOmnfWQ1PAyt1Jv7qwRlEuZXr2lE0vehPo9MIJ4sOZorksprdX4G0EAy2h/oNtCtlNiqtKH84J8TRVbM7oquypJ43wJ6Muqyuz5VjuwScHjXaS5N4hIh//IcMn1Scu68TN28Su9wPpYvd5BE3dQlrPvlgFp3Mmn7xah5rGbeeSZNwZ7L70Yk40F49MSe23+LKFNAwFu7puCwgyUDDgci0777vXeiFeHkOQYdcUnBDBfD4piLmCz8LDVCRIYNNm5bAkkcnEpxr71bkYGBQAB3g3h25Nzb+wLj0CJ/JmqMA0NE+TfHCf3ZFPYoiE6fKbW2Gl/FPPLGdNj354vkDayEOsht24eKcIj7uMbCNwdFi0RLH29WmvRseFVe8ZZC1yJmz+Qdgntvs4E2c5/5Aoyoljvg/TZZo4Gn+yO6lpDUPvN+mtGyRo3Iyfe77TOjAUaVW+05kQLYBGG2WZ47YWTZQkWeCjF9BG6amWczBvwBVuJi/xMTMH2yvj371104T9ttfboc/EMc15RlKV2pgAiK7cYaTJXZMmRMPdaIOt3EHxABNCTf1FXC3j5ggL6NNDxkgsuCa8YGw6/719rylFvy/4XruvzsEHVPu27EivSNZJZNCdcy1gTqtTcuPMlNT38De6mo3HozWo2NKsvzE6wmpx3VlzQUHMXb7204FYboG8Ed6j8grjfO07WqcrvTnTSlISzkOtMH8CcYQ+pbe07qJ7LqRYCPtW9sbU0a+zdMGVq/AmI6+gJjt3SY+54tktsb1Y9PNx6Cl0qnQjS0xkcvIWwOcba3zncsXYW3GJaGgRsTK3KVwXvEI87V+PShpECBxDoxpSN5J0DA89EiC2xAaDxOVQO+O4esU7b444EGMv41AMDgU9bertSXmsEe2GW0SeYKsrEb+IbmsP0Jf3gIwEi0yD6RsEbgY2py5P/4rJVIrRQFEmkCZNRoqAHLGVitXt52RHCj6rR2u7m+uqra3ChAjQ5GgNdQt5Cp4ly8/vbUC9rNrAg+P7Nb950o8ftH2KkK5c9D4pxdGYin2KHOPZIgCAOWpNtOcJMdu0UNEjkcBgdWA8PevOJmtw/uxEFAxjCmPr7T0LfEDX5sPt6ZEEmbYc3yycI1Pgby8hLzKMKBk3XXErvKrQGuq81swTT54OqkCEEW72VzBN1iPUiRIgUYsa7yJ9qeniPG+7yXrD9lmKgVLGnb5Oum6NcCJiUH/cQ+oT58qdNiskaHMDZc2fWX8bzg7E1aM6vTBtkiuJofHc1uF8TyhPbYpoYSrr9pI4iY4Mw3xBZ/iWrksUCpTqC4MLPduVUckderSp05f5oQLXjeOyXLIUL8V7iKNH0V2WrzvZunsQX+zdJnLK8nlSlZRRAJBV9I/l//uas+ckwgQV9CnUjuXzILESkoebYeofWWi81D1w+fZZzjSqPJO2NOVh4mtnyqggbxkaAhwxJZ4imhupyjQwmGIE43oQdliRjEz7EzDsgGIZ6SixSzBo927lPNqBoYCR8uTl2hSE9c3mTRjRW49fB/6ovU+K1gA1UFSHEAtxgIugnCyvZ84hTiLsk6qI69LP2O5uI91gkzO5A65fhfdMKGDlKQkS7zuBamk+/nwkNgWX0YxEnuv48D5NGo00yYYfy4/6QVmOJMvyhit2R+ycNjpqGjT1LWuhVKvcfKW0OfgRBVEHshUMtMfaepd6bmPgPsLPOHqhS8l8VKKeh6dGqWcET54xwbcd+r2WVvi2XbqHlmU9aU43APhtcfKm/tEyn93CK51Z63NR0hD2Bw4lmPihEAid24G6k98H2jjq75UPzjjP/JsRKIzQe4FZ9krD6iqw6rJTxH5bVlx5HsAJxJuL0eH2xPqgaXNav+7GdK0/L/hVJO7cQWpWrAgjdplZ7KPmUoucLnaxZVhSnbxt1AcOmDRQ5pqMUoICYh3w8ewMxsTPTxupRtIK2yDab11AZVf62ktvt57OAcv0GeMkl9XMQl4P1hr7ElNYHktagbmFsxLzjW8vPmAHoYoXShfQ4Ol0jLYlVSZLm/5+F0DPwo2ZhQqc/OPfWuXlUcoTqKMBQuoRxyt63fGkqdxP0naTLa2yhBCnnRyQ1/bXDgaZdbcpJ4aWGwGHYoSN34hnD8fjcdZyEV8FWhXtKHpBo8ZzK9U6Ri1gu2FafpmkUlVJTBsisDYV2vr1LOSS3Sg45oj6+s70SNSWUUEB1qfEvXb4As+xGzfmT40I7vL4ThVZGwqq2afhn5d22WwJlakqG7HII6iTO2sKKqczfp5Muy9yG1OHvjMIX02HMm1PT3QnCOX08Lgj2T+8qLntcFXDZ36B+tadK0o4flwVyTr6LdNXxx5S67zZZKsPHpGizgIrWDpRtd5ezSJyzJnm3sA1W2OGBfFSIl1lXDc7qS5EjSG13sPMi+X2zZnSeuut7sjYoaRwE+DWz7l/wZcRdJmzUvVRGjvI1AHBDJiCUmS0HX8QyEQqSGb7C8JlAPDS1duNsPvmeb3AbFLJstJoCaqz/8e3dkW8pAVmeAsVc3BCmtRux7HNAjejvr2QcgEBI51u4feulczC+J4uw3o3XfypqdYHY39LvRSrz5R5a2p9TDSt21TPvNVMIoHt1FYbvuAimkYn9OVCkSlGWdXQsytgwJ4IPKWbdU8lR/k/FDRuY1Zdbh1AhxPALOGAgB+UgHuu8W0UgzatlTNFNTr2JKQeQ/EKUHkyg9eOjTW2demkBRvOE8o9ZltagXo7KXIalSlQCdqrEbzmE8tmotNN4xk94W/8Ad1grRy34+dj+RyHwzKONAwR7DEaoTB+j1fAXWt0DZCASTW7QVUZvxkW4AoUyVYTUnauUDq0YePI3trSjRL0U6wLhdvWlwBukae2/NlaZKoW+4PpbAVi41IrIbb0Fpw8wq15JLZrqHtx+0wpwM0OPFZs/L/erhZc8dcdqKTRSC1hX5PT5jYuuyNzhjcu5K4XbEsbAmICEGNRL7kzxfQHU9OiWb+UjTvoyw5j33Y7hK30ew3uyGoQJYBz2sNHdPAiPbj9+JIJkGxDCCjKh1lvd+3ehZkOKFymPQTQ0+/9Rl+rkyAl0zlw+HnBn4OG0WtMZjWE6xXmETvtWysQNQLntHuHSmLrFFlZCohJEX2ihjhT3qm05fBLI9YAn4YyBBc/f4QKh3ZVaNZ7lqTXkOC4sIK6i/wJMQA4cYTrIUYZJVm41nwbnhFVIheh2rtnJDqd12MhKMtFcdZtSWZAY8p22DIJWvFYx9lpqQ5QReQZyMUTyzx9kVKSuzDVfAiOFtb+xRU1wKefchFT/pkMZvS8HQoO7y9CqA4A/hPPoZpcfTNSKytwoNdG0VIv4cpyiY+A6y9rQz+c7+lv5SSORARvKCgxYs+WqgWAS0n35/4KyfeMbdXz3aN6OAbjmG/4UIIUTu7UaMH8jfA3fLWrCZm9VVAYEhU8gYhMuwhr8rbuBDGWuiK/YuTy/EwMDhzaFiezvQclzd8Ej+HirsZDG+V0j5wlBC6RPUk4IMbDOVe9IaoN+YGJ/tqZCNrY2sWtBBMRzr6eFG5RqdO7FJ2iXrTD5Qos8KMwHrLm7x+/DHSGvP0RMTcGxHIxDvKYHVV4LsnHAzPeppM4EhN8wahMi4Zmr+I59pVKvtIMBTRdAdAKBqceJCqQxM68Emv+FjgPk7uaqVLcKbGITWBtqp//mnahGlBlzChXRRAoxDKQH07tzS8dvCw/E4b8JhYMIeHBnsQMFZWehH9+kLJud4gl8BDndoc5PPyplMWJf4jsFYBbFlbyB0qaPtK7cCZd0X/HDNhVhnO7CAoLQ5THgu1cJhkAOqZ7SxH+uXmJWAnhII/FUYWnOKKwqB4NZ16PknukABshJ31GqSqSIo3Pcq5S8ZQQ6NOoA2ab0fdTc1wqGh7tTs/IodPPwz1vUxnRE2MIIsrJ7rAdR07+j7K9FI6wjEWFtn09Cz3433hhS9B8yeYie+wZO9nY0kYswQp968ue45OFHWIch1snWZ3Wt7xD+dVMoluHO33L34ukqMVV//QA9gpxrqFj3QYCi1sdpdz1oIPV+j40+N944UvQfL/Ntf2MmcRAK/U5C6EY6zV3tV5UeH7qZroUUtRBToS0Sy6UHwkWXBM6KseKzjy5yInZteI80sAhigdIWPly7nJQ0/v0vYilSd1CFPSHKdflK6PFhTNXInhTu1ZoAnltiCLByz5STynCz527/Upby7r9DKkkSQDu/29dLDtQOtIQHdah47Q2HnNNl97doXLozVaxDof5LnGuINZhe947zLnG7ivquNwdcBjaYfvNW7teE+zyIYiJQU0dW886owVxQzK/XI5lnBGzplWj6mhdPavV3FENyTDt9DixLtDe08ZUodjiaOBJ39GnzWnZA6EcvmtJ2BiseLaEM3rsTkc3uYRc7ugVeCI/qhfQ9ANwG873aJHot8GkvpCs4bZsWDRjxUvUNR06tgniC4GYFPxjHbRreV/AX/n5fFucyMzX0Dk+oTovy3ot2pa/Wr0brqAbpljRgXS2Er47YG0KW2GU8ynRZvNqsaV8X26/NEPpe+AAnOzJ9z3qI4lgOMhiJsX/X109D9B2/SCglcmjgTnQVxZ71G+H9b98If9ooCuT4ZTF/oJoKlZ3OCFTPaYpf96ytENWoQe+Uw/tLZrH9YO/OxcmHwOi7yFVqZ53JoxBoS03uf3kCsIaAGtKH6hrW7LZ9lBdnkl76g/1XkCWhzY+8hAxeova+jwTM8SHSgBg+sh8q4cIwdLhK8pMgmGK/xbW8cSm/n8LOYeaqeRacdcfg4liwL+9rbn+urn1m64kN6rf36dCOnjSzhHXroo8+aIa2+9qRbbEuv3nyFc6f/EG7B7kzlSoDj7vyDmjt1xOWqVKinq4zsbKHoeIDFX3Wpej4nMEw75CCI9vWZCX6CnUSeNo2ycOLtUBPhIGh557Ro1K8Bpb5Yhfgu/6UuEhVhTpj1cywPrL51V5irbUEEwIOw/ICKjJo/Oo2wLTrEbxF+qk/tvRoc6MmwklkAs486C0Y9k/8PT50NTWVsvSpoVaZsk/gc7lI3w0LCWC4UUXYWRvdSGljT++Gwz6YmA+wMkO3+z63UtwVVOokjvsD74EoT3wpuF95wZvi5iPAGtHGJOdwmQ5qf/Bc5oRaTyXyG1z7hqgLatvyyNUh9i7c/Prh0YpTsm5qFq5s/aVX7e/w7CmKpJlOTYmBpYRa0YuKynovUo1/zNJ0SIorg/C/F04+OwUGD3vHuFRKkVdcntGKRTP9TtsKwH7GKfsGzI3ibogc0l+iK0Md2liXt9zOPlaueoTkyKDPXlqvPLLbalKL7hEV8wbXApErCwdvK64XmPMmhHXg+qC4UqFMWtqrzLFdVPUkvzNntZ3D9Te+XAGxK0m8tc7YHSKqmgC3AKGbbavaPE9ZetO3TYsjgImN+dSJbrHazQsnP3HUIwBjN+yJSw9yM6O9hrVEuHPir4dIoquuLcrldqh67T1ZZc+wH9HqYcvqTbg+fCIblVJJu8VeCdunskP651g/cKfl8d6nA4+5g4sIxKwtGjgUFFd9fhH6DmJDOdcbAYlIrXHsCCW77tG+ZLllCtLZIldLMWHjF2/vaac9fso4S7Qj1LRHkrAjsNZx3tPFkCOnm05duG5k3oNtWlTDaJik8Vj9jhpg30VOiE1M/YqnBqlTjcdGRKpAVWWRJHgwpjGBbsHLkixnbLk7bV5/R7k/QgUknmGIOmG7Bgf3rY2UGBOowDOfanROUNue4WKybBwArzKLvuJaTaOpwFcPcYjfpg/4OxZQItiT5wXav0q8Ywx6nMM3BNn/vQ7iYf0bxY/XtLn9sxgVIkUWiDoaR1arVm3pwGv3UEpU+8kMkR2Hy7cO0mQksu5LcPzQ/G4b5pVbZWkiilpzWZ5dNHUbKCnkReBQMUyzH2esJgq8vlr7ftzpZCcj6jaFXV1KEtEc5ljlcW5s7uzznv7ogQzC3lPvzSNYpBSlgoxx+3hC7MTYo2lcuk9tsN6R5mV2Cp6vctz6Urf8MAp3al0ZUPvNOtAiPNR/4YH5rc6EuloosYkrt62RvUJCXaCanSuSBwxryC5sOcLzujOS4XwPC6OGJ3JOUdNwwYIQF2gvq8CK19JCAyyk2jTbzu9GGudJzi0tf8u5x1RkXf66IUzmRkt2U4l27ERm8fIolPblCWu0svwALTvXZMtm/3eBxMepfLhzCAcivTtHRDi7PFC46/0/8OkJ3lYm37NcSvxwlxpcDDsgRnn4poIjUOpZCjR6V/O2FKXgGzpFXgMlu9f8YChS5Nsza7I2M/8gigQmYGbxGMWDciazbagYx4ZvVo5yber5TuL0OaD7vcLoUw22sVT1EL3IYpAhUjdHt6E0KYaEMP0fD8eBU/Iq+kkfbCro1BtmQjGFx6jUmpo0eocLOJlSBYp0N2jer7IbiCRtHGJPnxfYH5sYUuSDdHs+PKJ51LGn0N/XpgDQZGCVv8goUPctVK+xgj5NRofaDJ5XvkcnWJObMsqEUv3Qxcs27tG6GRvI+ZPf2vZauehXPneaROr1vnHOVgbkQ73bmzNGlHtmFyl1MjPWaZMctBtraT+FiC91Dd1CMLujZH7M6IQ8XNiVpSEbMnbKwnevCsQLm2k8+epT+3bHP46yA9VGe9H287+JLtVBwhemnbFnyZ0Dhr0vL7I+v3plR4e4eBX8Y8ZIIgnIaorvIx+d4Q6Np/TPLXKZG9TK9hOM4JhVlLRpXUbyMxYXwX4pb2GrP78e0Xr2C/ktGlNslIlGQwa99BCyGdLbMvSukp3Qwd07P2DN41bu0CHoHqQwcGOB+64HEdcftlWU8mvMCFJU/L5KtSb3RTgAbGJugD+bsdMJg7vKUsE2eNO8PXrVotPZLQO7cOiuxWM7ek20g0s/pogmUWYyRKdm17LN7tVTOGXxgJMKGjlqVPw6OJQnOuljv/gvklIBEFMiCi2wIR1+zlZsV4f6FF2/1audmfXR7O4Et4MscPB2K5yi7HzdnBxjPrg+H5Diszwi1YAgoR8Ob4h8Ia2cXutrNTFwvCubIWLmcR5mG1PcISkyoPi17fpXzrJ+IXdfO/QbRg3QZ65HZf2oynIFwvlFTiwIaglW1xh9Fm0StfBqdtcqJ19SpvufN34GtbjtCF+GtMZfXxXw92Im25AGeSYnIx+tJY4J1nlMwKthP278/E59o5E5nnlMqy1Ml8F5tjVgtnyyoeU+AiUIbs30r5jCNqU09YvKQ3kIqfAgMYfvyTKKzs+i/b6ga4OPjBO5Epj/V/B9nm4zc/Wafa9jKByw9Bu6NdRMk5pASyM1zapecxyvQP6GM+IfVGn3mkzSBnP+73ZFkx/jSkMksjX0uYK90NWYyCmtF7oM4eJSK1qtVogKWFkrljQj5ucKRvUg3LYAxrVsSOEKXegt6zidH6k0ZrbmMUS+Y63qzjzA4uGFYr4cV2iovRFgYFxREBpMtuYo2BCVFnNv8dVlqB7lfyEfjzsQ67gjiwR8T7rEIp+3uxMLomMDtLYFNW0ZWsF4gkEeZOC/wh2x0NglrvFYmKA8vkKHucM877xAx2GNX82OSRpNc9xB6+1+vUIfRfZnhboBtvjjfB4fA2WSTlTuzPKtUAsTfmg/E69wjcmKmbJFFWzb7qm2bDiz6YZiWcYoSS2mV67xIwEaRM80fMi1qWjyljXYKMglrVVsGVlk2FlXyH6PRRVZkOJuy7hsik/1v5gEc4D7ntoSAmMdMRWmNjSTdBsg8Fo6PtWgB+CMpIkarsJDgV8fwHDY+2xPthsyU9qXaVDMHdhw/Se8M68br6gg3FUPIije5VMuSp14bNG0vOROcCcSSyecxNeypBJjXeAPu0UrqhDDhJVQepGaSYD4fTuOsqtTU61whcEyLOOclTHyolhhQVXXOLBgslqREf8zO6QL5LNYjtvCS/6Twwv4Li0nJhaPBayurrhYT8w0iVx7ng5ToMR9stqFiRrT7+vEuVhv3HUzr8HW3IZoAuO6UVdORNvP5oD/5wGcLqitApyxY3VBb1lmU1zXAYnjvT1n1cBAUGUp6dRbv5EdT6Qg1Cs2SxNqntjVQFvmGvX8TSInzwWReFjSkg0udMsU7W+Ko+aUqbeEKIlUG8pkiIy+9VFhCIgYSQS2hu8Gc76CnhyYbVEHshQN9u+90X0mCGSseWWSZhVP/aTiKIFmfqjQNATSKJXpARjy80TdWzv4F6LXVqYHkWQeQjsZZbaDxRDccfpjdGK4+Dm2wMQr+DUmhLteOlBjlCPzOsmtuRA/Z+Z/3kdpNQBr2kPXT5gRJHW93s2kMhaVgNE8T0SXfFaN2nke09zuZxvAO2k7hu+yHn2YUe5XGTQjGih3fu3UZh4R93JxmQT+FPWvZERm5fNODwy/jFlCFjt2ZGnKrbgfDEjraeldh9bpS42BQyk+PZ7eDCHiAPNLgnh3g3JWtlXh36nPUO+7swhQC6sO9Ay8JanB3DQJhB7UVIvh03gldeRb9ANoTPdZ5zt+Pj5I6ZjLYmxf//s70xdOLu1ElrmIdcf1crx3Q2G2p21Ayq4YduGOpEr1xeXzm0dLonl4tEaE58qFWOQ2qVzsq+pCvnt/ZdYmD766SfEUEsU28o7ID+AMuPFADrW7JFzBeiKjo3ty5UWByKNotZLfICBw5WyfEwKSVopkDE/iT7tNHcisr+LixzJIOChE59VpqVZNT9/qCIdqf70hJHdDTNhrV01hy6rxJd4CL39QCO8r1EfhViFeRXW/t0y1j52zkEk99ep6uXdRaZ5091ZaYljIdFWqvcjPhfiDSj4Ls6JGWeCzy4Bzl76ZKe7KcVqudC3LTb2yntwlLriPYyJsIqXLsyjFPLOjRoVzhcZAnTctksitzI9paJkYHLLez7LgAppIeLe8IFZtbAgAWACImwdDcQsNKAMi5B1wNOdbJn7Q8LUP5dtb1JZy/XnG4A9LswivWHF0huLXxfTt4QMjJdfdMy0EPHzxm84qA/dvczq51mMMWFsvXeZ4xqBl4npBFcGks4DF1zoS4O9Zbhl7j5wLBrM3jKOYsJeOrk5bIQ7FKlLg94F9stkWYTsz4xhxhcnp8ztCfNrbDAjixOqI1+A5xx6lBoM9nSpuJfUZ9hyoBPAlMs8dc2bEmWcpAf5tqile+RaSArkqL3b0nxydYADjTN86O8XqvXEDZ2y0STJhFhChq5QjvwRGh3TvagHpJFRZj8nZXj/SE15PUpho45/VqNzNQxlzhX6TAgcMG5FMkN/1JBao6rZDWFHhCA5a6wRoGrkGlgU98eg2geRoBfivoEW9iDKpBJEMKqrpvg5PlygsyzBD01fQPZHKw8buDLqpsxtgK0h0P8Yz1nTy57ll8EM9aRrRf3kUCPH5fVDg2UADS31s843ux3GZG6D5ZvS3vcGcvIG+XKp2aIT5HBG3pYaAXpi/ZWP1LdK+2RoTN2A7jzsgwRphLCNAo4cDAZ5e5PIF9fG55LAL7iIiSW/onZOemvc4TeinMMYODPKoy5EniYKEJDb8/WdggPcmg+nqApJeiYjjnsaN118pCcO8xz1Oc1Gl7L3AYGn/lUJhmJMRdnCJxiZvrWySDu9sEBnOC3Z1I8Puju4RwWWek7mkzlYHetaOpwxL6bO3hPceiuyhLZ7QMrVjE9BoDJcBWbN7EesaDMqg5cP4IW2vSKV9TCddtRj735zIg94x1iIFxlaoDXSdF8or7D/UGTjg2fPV6qQYJ+lCpgRRemGq6KXjlPkGVg8ElUbLbbdOKFnDOi2f0sCMIJB8/EDlMrAa9rpJ1GQJ3IykyEmz0w0/BGMyIuzv9GSThS33NoK0muvOm0pqx7MsL8Unf+IWew1B1283faNry29tpPvJh17q2S0t85z7MBr+86FUkc9FMhZz6j+/J92b18hiHE5i6/EVr6DWCP3sJIOHBnxNuD+oTbuYN8pOBz27qNcx72pAO2BV7m3/JC2zweS0p24WQBxBIWdfcj/7KoNAlvK0XYtH0ubsVpRsTQyxA1E5tV73+TqMaoCEgWORfrKFrpjpvm0xxysYYfdu8FgVTHZfFwZ44lV9Jg2SCAh45WgZE+7jvujWWykTE1QuTIL1EceMjX8pxN2sSBn5p0RQn2Ygp233iww2xvXn3eAe6w/xU3PHve3kmH3beyTqfAyzg23i9Zzh+anIJIoWX74X4G1xR/jKNr+N0EVBOGndqqz9OHt/34pqz/QgG+Y4CptF2otjFuxgLY34oIqHE4Nx2HRGHyYpE7/77ldJJWssdHgYsoix1IQqms5hlsB3VWzgnI4BnZPJlrh2MZIqQGVjZWA6+obmuxzFlax3PDg4+HyfejFtQPfqA0MreaiI/4GkvfFwjZlR1z88W7oWuUWPJ/n49P/f09oiY2sj4YkmN1GRr4A9sn3mxY8qqW6R4ucA9Rp5hQ2Q6QcuBYsSJV6ctVTp04ap+SkpwiWb2f0gyGUi5/UWCo856wSRtdMnh8K471hhTqkiHAfo2QmU4le+59aTw+9JfdgBCPrkb/EPwHn+ToX8Hme3bHL2YKhQaJ9p75xT0cNTrs5mEIlvfTO1W+f5LT64dX4DAqTl3wXED2/bu2MpydSZo5cAj9bpjxaqhgsVlYOzxj/favP3EUJ1pevZ03ocfL9sKiy+7NItgmZtEyJfKyAHgsxIUACGl/+ntgsweeMdpjOCbLrsvMFf8BF3w2Gp6DvoJtiICojS6dblQhxseJY2kuytzxSkbonmZjBM1RQQvoECGBtUYpGrKDFi5OMfFrka+x+YGIxK2y3MPOSz+3WZ3p2BK33mWVS+vFp8K1TDMPxofgk5qimjwxh8ho93R+LxrIdDXPnRJnoYziebg8MqbPoG2CMpfsWBvR7bPeXqsvu6hvJ1uJwYIk2eEYPyzMB0oEzeIz7jIHR7ebKNaVdz/fvFBNMnEf+w+AD3fVanR8M0cQW50ra4h1VJTlY/askuQFerDJciw33XfG11f8bo/DzX6id5YPtxXKotb9u9LluDN1EBNs74ysv2ywApvTN+Mlav1ldEgrcVs1vIIPKFtkl3DN+44BUCqHfPUSSwU5kEvN7CdXxRCBp5Ynxfn/Zw9bE2vSIeaG8U9WJ2hQSTALDhLtezh9/JbwLnxRYyc9ZBOdPjrwXa5lqfuqTHmkky6bApx+d5Oss1gH4tqda66xUQxedP2myPv/IGAZWTbZL3MBD+m5SQqVEdvhT1m2ynkI9em1m+0nYEa+3uKUO+4ybXHqdDw+V2eoXWxwrQOjTxbBO1pZMFeYfh3Zx7qA795oSNmvlY5sFjM/ljTVO/H4r5tCM3AMxQRZLlXDR3FDlifj6Fz1yNsxbPjnyNuKtVTMlrAM94XLW+Zg8TkloFn8cfXQaJ+uhdoHMQlqGThMI6eppjyrMjc4fPGJ5v480fG0nHlaULjkIOBn9/v9rhXg2o8hPK/eM7zl4YPxAYDqFfdP+k02XqdqGCYmjjnOjNv5FYifyuo3mSktPCGs0ZUmD42dmACA740+ZF98sH7KKY6n9Ni6cEvMi1zOvFNTzp+rdvtM/ewCacixYv/qXL2VAXkxWMWw4AQymCP/+zENRzkfzu/OL0CuWLi0GMHo51oSjZhBnrPMWTsfBT+Etw8T2UTvUw/Gsl1cJMQqjNaBqrk2E+H1/Xgg8KUpUwF/r3FcHcAFfwOV74L9J3N/DUn2j67RJ0EWOoCdtwDn9e+outz2VCXV5wFtoVt8ejAETLBTfVn79/t0/8ix2ac01rYATxvJ3+RAzvuP+FlD3EhV75mMlxbL7gmwqMA0msUq8sgLMSIgQ1xXvCL0SfbeIdbnHSGyTDyr1g/2SP2DjgMFOKHsDgcQQEC21V9QaWTy9Nr7x3YsNq9Om1CtQYgyRQgggMIXzUR/Ca46ZhXljw52vOnfTawmh0XaLH3NiMmyuH1S27v24s5DuchDbcL6MtuGmY8xUJeJIiW5bUDfBda/k0AidY08pQq3HaeqEfAD3+TrsJt2LfpG1XceFcmRN/Z2ilJ/Gg+JQcda4ZNxeh9Nmght/BJQoAF5HGgspfWRRSVf3pKRE8rj1gfaHnglw0kt/nc/yJbvD5VvmuZ82WxlQ1H8Fkf0IxQ2teqcRSGerU3CUGJcFQUu1hBlM5kw+jSZgqbVYKL+qU9Bt1r2CfgShRgCwhBTsNW4acg/yozUoZHSr9yXOM7gbhlCZVxa5iAlX0evC/JiV7gfYiXgIQzHCeqibVRT0aLfclRsO1byAAABcedle03Z0e80hMoYj0yUR5mCmBa4VX7lB8jYaKuNN9B9xlBwRW8PzvfPz7kpMmpCqcDUBcgwtsz+TR7dVUh8jaCv7MOvyazrb9lOpohNZOHPWIgchWjAcGmAtWyOIgxlssx/s2w/iCwgIX7cVdu6EdwSqIdVtQ8GJJLkLJJQENGhra31xaeDSoOnTjsLSC67Oj6Ldaf60Hr9T1ZhcTid5x2gnT8zpldSd6Amk9qTSA+uLtVPrpgOup+FfvJyFuSC2VVNL6cEsjSKirU798lpH51jTqM7OlrwIP/maDCGfDxvLIkxTR3wzgoORYCXWZHzdoXncK2fVPbjV3/gyh7665Tt4JhEK1kGcNBQ1YU82Vovd7ScwZOjZjFVV+Ykk1/ngRRDLV5FxOIwkWUEXMCOQ7V0uxa5P+dFtp/kwiCfjf8VHmeYUEduPrkZPrGBF+nKcH9hHzqewcDS2RWbdchwWV7mF1KqUDynd6ewUDMSM5blhmHgfip/3gERjhEhVUBrcsA16xT33BlFI8qO5RkByWrzwakKRmPQfCNu5y7fdPm3ioskb2ssIGpuhD6D/W29VrUMnqibulPiD6NnxeNcRnSpycGkepQzdHNztGOuqGS9zk4he/e7ZrA/XW27VrEQOYpnDrnV27DqZY9S1ojtjyefP79dx0YKwLpnzFxHMO4ZmMeU1xhVljcy3/qH3Qtbfpdj1vsjEgPtvEqRqHfEQD0Tt7csmcRkuzEaBKNYxc3znSxwWJP+yQZq0BhSJSMAeNJx7JZZ3Apc8G/rKxg3H0j7KLbAl0v7/ruwm/bZyC3i+cGfmiK0j9VDnbdeyIOravM3b8v0Q6yrQtw+kuBugazPg+9DTJNnXO894xhq7XWW6opH52yzpmDl7hyUtwFzXTUKfsdbRyzWTPAyQbs/1kZSP3XE5Q4+zrsOes/2zTxJo7pW+nMB7EUG/p3/uQ4zQpgCU7YoPPAs+cypjpqGi2XXC06fX4CVvgbkfE0lY81ofKCy/VHZp5og0umi2FBjSnO+ByF6bUCc0GbaVT4In53TrpOXPfh6T1hqYcJAXokEu1oX9d9r9DCVp3TEbFKo1JtvtO4J/MH0n1G6XnC0yIa6KArD6lc61wUFY+Zkq/UBehc6Yr34DhUNDJRNkpHDdYuJgXarZtM8lUy3+/p14rGrDHBG2qXPfQLPM/HIPYw4fhVVKh1cBWfwKlaAyGqWnPpQ+Fuw5PNVSoUBhow5DOtV6Yk8ZM6+8sUwR0avXFJDRttcY86q2IHSOfvVINgXc9p5875SwzvSCI5PR8MIYCeB6YlffQWhHXBswLb/X5YPCysMfa/+1SDH55gaGlyON7n29Xi3G0L1rkyxTy/NR5rgh3IvDCeSdsOdkYPd+fYJ5NUjOJcS3g6Z9hc+jG4IKx593hT/GJnAtvalBKCShW+TXQ5HFrgJ7kqwS5iKfRrwFL95e+PY8Kw4bAp5oSca2U6zdW6bw6BEJewn8iCNXEoZgJJAU03mcNEwDG3fR5WMLMRijOc/X2UOU7sQbLjksa0Gd2K7g1EwqZp/eFD/QJjO/spbZboFhwCe2iP7TsyRUk/tpn1gB1WsJqxEw63oVIUfRM9/+BNddV6zsdC4YvIDoPvt/OBILHKuv0Oy/2cUIv9nY87sb1bF9lzxc1atSbxLMAvcC+gmeG0MWH8UfrbnC0TU8NaBlo/84CAOjWJL+shXSiFDI/Ff+EC30X45e34N6EOh2Ql2Oze0ttpQlmQqbUWTZYUDvG8m7IW3s1qCXTtBkI72CXXGfJtXOsEvmZtOLXsB18TTVqdNrb0zxNhFCoY/z9AhtGBq25v2dF6O3UP3eM7asafrqyHRWG2rT3E97YPXcgUIr6SEZoTMM09G/DwRQ8Ok1RiNdzKgdBWIl+HUV9vQYwTbzBFfrbQT48fQzN1u7OOxmMXNiE2U2pzpicOauxqTR7s0pd7pSi5g22dwcRoVMHOH7BCzersg1ogCop0Soju/JGnr5V286X1eF8X4K2jn9/bEUZpQHcnbUPZ1kMroTQGTOQ74j8BXHG3uhVZgqHauvN8YmwibkoS6F8SQ0fGb293ypl/nUulSIgbLGxAfV19fKMjrIZMvPE1i96r2LUsNgssf4ywB9iRYzepwnGVMf+CMxsW/1qLFx7qmlyenwU8Ou9WELfkEPjR/IO07yeccpbcX3KejXVMuJNvO2eUeNTfL3FvFgVtGeBMAVuK9lTO2MnyfMxSDkIDbnEVUXii6hAh1EzD7artUvElkvL+NvxnxCd5Yn7w0xPdOM7/68fFRl4UAhuOszGBrN353k3vWh4c7DDViZF15zHL3cRYncYTAtDZt/ZgmLKJYf+BbTTohGtPfMlRobvX5aUyO9+DOzvxtvOM3YcHQobkZNcKPW6K67mhJINQJ0b82jGiY37mN+qxquNwu+zzIIbX0GRjQEexbC63OO3RMyUiI5ipXaUAY8UXQo0ptaQidi4Z0DNsIH4SwlOF/7TonTNbi9vjTznrZiiP8NsouNHkPhxZw1OG8Tx/1ZQyPz58gVdMHbAmU2qzbQYDMgrzS81KnLzgh30vKIEIBP9GiN+4sXlCYBJj/b+cGO+odKjwZ0CNjFKtNeueNuFwHS+jkhoBZeQjF5DjnJDpgIjNOfY9QdLd1CahZLwQ3FtiPkaIWLfivYj8Alm/9V0MVhVkIEPJprYTGnL5RCGWwBy09fgY98c4SCSbb7x68WzAyVAt9AWT3sGvlmoOWB/fiNbtVJvvbidwLcVgjH0jcble1cCT74+wACC8ntyS1rnkT+1NztFPm9hirVXeJ6lJw6iLjDDqAvRlvwTrscPov6eQgFbzevaDGs6u1hBP03LOAMkgqcUDmsAyTZQ+Q4B5a2hQVj21XjehFu1E27p1axmxKNCXTpMAlb+vmVzweE3VuiG4ua7gZCvdeKEj9e0u8dab4Ws7IRj2KqFjHnms+c7k22+djVVGEIkju5kocpLAKjUQ2OlKueeYcKmubohAu/TEQ+ukSJqv1d2c7k0G2nyPFqwkXZ71WiS6+OCT/5vN1xzM6IEXmusuZG+wsDwBk+AIAiyEJvZtgJ8fNHT6m3WQ4w1GUB9jwcXLmIUvKlrna8Z45PHrNdKbjoQYkwKaiEkCwagLeHcaPW4XbWQyKuMbF7ZtOREymU0NTpwADbUXcDDOE8768Sh4PPiWP4TDT9x+MwD255ktznjM152xB3lBo7DuzieEK+/WjtYMwXcsr3sPjFLbD4j2Fp5pwJ+vRNqtX4M0rs03XXNMQ30H3SbXdFxVImo4UG790akMXhunQEui+GB0yMILbwWabBgf4vfaI9FubHynlwB7YOeoQ++em0u+/KlZ1rnt43Zx/HTY1QFGsp1+kuL4Y7ZMbMgrdyC0x8/IYgUW7AnGjSxwXoHL26apJUGvKOLiauJXrNENOhGuYVGvzS8Dajf2ekYSp+nkmF4/aM5MFw34bUo43BjKvrROEwEtAq/KZZi2YSiW0KFdthTBfHExTU22Ojq2IjwJ4xrN0pbPNoestP3yiPlXm48jrcZWs3XywFp5wZfO6nbTV+apMQKDGcTYSxalOegdX8vWZFw+ckKjXqraN2WAZbCQat5RLQWV73eLhZVzZhnTO6ZnRoG1fxq1vv8ZokEhJziBTGCsGovv2LdQYip1stJFFMZWA8jqtbA1JQANg1nHEpnwENVvrn+J6jnNMqZ9LfwK7BcEY36LQzyDiuHwZ78TfiSr+q94qz87DVxVjWxH9tS2OyeNSkjltxbToE3TfpchMYlkG8/w9C6+75yo/hXqgb/D383kStqnn6pCe/vVPbDiQiuDWY7tHNuyY3HruJS+TWczJsKfA+2sLk/LXTyZPonHZWEEslUlMCZ0+Vc+MBHuHKIp69NR3j5+5KJ4Y8z30PvLeYWUpZ/ob1lSrvJeLq4eOtp4ZuaqmwRI88QUklkJyQ9I72VqYTm07x10EolLxK2WNnd52t3WG79BsECPJYgj1C4axcRWEuKq1euzOMDEAeFowmnFp7WzO7HGvQq7RmFJIvF82qndc0d27TvNrVtUBb4ffUAMAnzlT7640U6rz5ZY3tyeJIX0h7NCeYba5WLbQoeI4i1tBYDbY1zZjCve1WfzdxY52hf68moMXBdxjSlETKlKse3ueDOac2zmhn4COiQgNfxkZ3fXr9Pzd/77mwRPdDJdjao9RoU3LW1YIRmnsKkb5gn7vXM4FetOsGfLctLCzgUCU5I5bwkEAN+Q5HBPC+SxZ0qneH+BROWbi9noEVWFW84LfXaCBlFzBHNf4ViruGSDrycJ0suIPfk2LMIk7SRdsxIaOxV5K7ipSuGTesPszH6QD1xbq0oXbeSVfRy+/NACd0Be89UfZCW1hUYdeea3ak0a74QIsKmb2ZU7UbgGq5tHb1cRPC9HBx3swkNBpnqNFuArrr7zUsCltsSae7Hk1tRb48jyRq7hrK7I54hURQWrKI8l2iuzkoGDWCN7ffmusBlLlOnCsuQv8FEmIzDNqT0tNTtt8MVTEXTzmTCIdTuq+HedISfNOq329cgr+OTGelIGXU4AIZN0M7PQie9Ph6Ch5R6PelyKLCFq4iMWvIUpJHOZ0ytVdYabKmUNgU7xCfv4vV3GCStJk4NRn/iNSqeTwXokwDI0sPz3Oj2pOxogvCDffYvGFPdscfMKfLRE6xhlxYAOOwzZRoP96VL7+TW5VtlBIyIpCRVHZpXSacjzo5BiisyivOrpedVgH9CP/ZjhnpJObcodkCOli69QDSNLljZ0y4kedGQLgAPmcJYeOtvl2uZhQuPT5D/cCtS+WZ6od9E4XpwvCY8g232cNtbbP0FrXNh8AmgWQ7X/otVNkHymMx0tZdMQuWJLB/BGeHcC6y+rtyKv0SlO8PRKuuTFweKRzy1kt1JOXtaYYSu/joNqchrn6gthW5Nf+oJ0r84Gi+uy5zUFZUuQJDObJp6Q7V9iCvwMcXttdZ8+cq9TKdrluAU1mz4VTtXcg3/pPrO+psEN0uX7lSj0GDxgu1TyJC7NkbO3Rw56kG5du3bQnUek3XaieRpvD5Pzsbrfnz1EcUh2v+cOfKAEPl5vHa9xEe+MzSyo1qNWcVL7Rsnc2Xdqa41KzKi+GbUHjC559bmqy4aI7mWsaFFQOzBXLVgSHNqZwPH0CR3ktg91orHppNl4dO+25af2ROig8MZMrK++FHUUzRK7O2Fojn0DNCr/r1952fI/Zgoq58FTGMwLivjBMGx8OUF+g54fcJxw7d8EjNW/mVXyJvI3P4a1vSyLpwLRfNpqsi3/gPD73dloYAqGmFlZrI95E19nYVaXxdpFYwmaGJ/B4weuOTNsV6rLSSytyorxASuOibuH4iOoePZjIKY9MDP7j3vXeGtxq4dHAp9DtAKnofQd60HpiHZjFKYgu6Ln7+2zuLxT+uGGw2TwfI+O9IcmstrggmM8piq7R//gDtnHCqhtTmBQC98mMyuX2+fDYPzWRWxpW6mcDC9t0+mchrBs2WVQDrfZLRu+Y9SWcwapKgfvGclYril7F83iBl7QT44I9q+jJ9MIePZjDnJynDmoYOZQmfWFjGtZoAx5UvZczlCxSz+Gg6c2Em36hZbVANSLe+TGYjADHhp830ZUhpyJIbrWpUNUhtLMu1iYC04+tixoqFikk8nLG9OSsP5Cy8ehhWiuYyrS0CeOO+HWZ016Wb8dE0Vlt2JeijfZoxXw1WeHlbeS2cB/zhX7cwe+ohWJqji8qUUpp1fmDF4rKWhDLA1rD/5OJFPb44fbuLTi1a7O9ek+I4RnMEWXfG46A/tHj8IEnQ3P+oELB2hfz4LdlmNHC6vT5zKZUE22nS7qkGcU3RgvFsfmwgI6f+Ma8i6QwI75EAfOGmfI5MabSyAaaDe42IVqw0AdKF8jqusLPQJEfcK/M0zbJmPo1lG4QlYSDaBzaQCArzSDYItB6hyj8qeCvblbkhdQP+knmtBZqlU0wUBdv0cp5UFG2sYaCEST1b8iwkklMCBHW5Yk6ny+M0OLXLfdfuQYd3lUr8u9CaJI0Zz6/bNEDqewuIkB8MK2+oLAJSeT0zudj9K1huKlon+GMSLfnsTlfAAfy20WGRbOrW+qS7aPfmGIHVaPAVtIJQ0Bp9RrPN53mZHiMwJDGkF4SKHklgBBN/yXIsGaMpFwaDEoETEgm+ezpKUmjI4XAEHSgRpnng8XX0OFh2bsGtZmdorUS30dLD905s1S4u3rd3vt9NGmE0N9A3HcP+u0zIZ3g5LNCSn+XcfmeWAeiXh00P96R/AEBFAgA+qA1EAhXucOg4Z3HCuzcdUgPYoegBqPUifTmGRXVQ8d4lmmxzImkrMIFkoPxx0ya92PdkrlM50mYe0pf9QbMXoY71Jz2NhZz0NRqFZOC2orRJ8/vbNm4cSrXIBLE2lOz1dPGve0sb7TPad/TOV4/xF3L6eCWDTLLI5hY55JLnfHWx6qWf3WteviUoktJtje5Nu/CQRtaaivyiKLG0MNbrbOntqsbLkOr0bKde/QW1Rtxdte5BIgJwmNRASIKPpF8XDn0R/jmx17TZe6ehj9m4VS39lOGxNtrh0AqMLbNK44XTUNJMlbP7pF555FS9AWuZcF2Qr0xxPFgYgUOFYqGxttozZD3pM2wNM2wssM0IESkBGeWTHq+3Mtn2CCUihKufVqG8x/0PQIQOaJhU6ABgRvRDAMAj3v2Ztgd50QMABG4kHEqAKOD6CQAiFK9jyEDxbwBMqohe3i3AHf+aEu/IGx2JsZ+/cQXAHp6lZ8L1+LvWy8LTZ2ijf1HrHUEvKz8bNADr4L/FR3oztGuWS3m51K9eB2MMfl9R5QxJlcIssppTdhf0/onyen9GKb6vpmes7aihjvJTzD4KrZTUQEVvpg0XoMP29Y3HHdq7GCJasgPZ9K5KtIPRBGTH9rj835B5e7fXYXYoKgD83f9j8c7Ion1x+c87dJAz9o1YHFwC9/i9qnovo4QxFfiEmo7j0PU6Z1pwTkKJqaMv3aKjPb92Nt8ClgGnjVnEX0lV1nHhAPx3ACFd4nFAiyPF73/RCaLZvktEYevdbWOXf577swPAs2fk/9mnZ//5MtBApM/7VwcNRv4Se1kSI+aXlvXN5MBPDHAicD8efyhCi/+IGDYRAMCn37FmAAD4+jFeWZ9dbxHgw2kFAD7Qf7vM/+Fv59Zsh5fPmrt9XtegD39ShDtLI+worvUbbPt9S6w26kNYRy/i6EaspEE5FLvZY1uyaFlI7AAbvihHI1qjXWCoTl93Ub2o+bF2q4c36lIRTYGLdOoXb4IzfIguSkQxmBrzjl1oSDbi5UPJ6/hESm+28Zlqmlg+7hHXQSGZ4IQAK9GLnzPUUMhVPJaoxDm0Vi5ukrqNyn2ujzUUdqA4Ntd4W4OohPkJlIFlxJsQ7ydeDmsj7Nk2BlGQbMRdy/4JDd3KLUYiFz9dPUpoYontl0tRVJz5A3hG2m4DE7bMOsIzHBsduhy4n6dlVjGcR7p2JW27HM5h4UyNyoJiXWC4UuKl2fhILvnNJv/aHofDogN4kwN40a6HAfBc7DaW7qPXge0bNXnUUuwY04NRTcZQ3WZdb1p0Rzlziohbdi4jbdOYSidQWdEJFk1xf0X3FBazhq1U6qeFbgT2BUwRQUYcRyZVjhNqwa/jpB2FikFm93VB65/BhoQKC7oonMmWEwjRpapxXvMiHdJiqkJb/xG4uKoQvtlpcPTbAtqi7uh65Bo9pw+ScoQojyqjUKRIrp9UHZ+oVHIG3biBr64gBOyI/TQmeYl2lOK0XwNMYoqexWznClQR481lEAhcJilKquCKfk0kWUp6YOPEIKSVsIQXBGgmsJU4TU6icoNBv1ipQbl3rCGLPJpo9+aTCT8tbOOvi5EkeeP2asNEBrSIaWph/Etn66byxBNnubC+t4flD/FSF8ebu6volSn0MOFAOVz/kBPU1HfgvJa++kKQQFZNkIhXv1BOp6NpIDg+eqnuWyeHGetgwK8NxognW9KetTIQn/WA0jncIc9G822jV4pTwhhLQqFhK3k1B+LxGr98p9XeZ4K9PlSfPrlNfpGOuLAphstZlX6g24xO6DIxjHQy5ObxXZLOwBQEUEhZ6EWCCt6xAxd0n2ARUpQbV1u4WsEplqhFrgEctCLA8rVWxoP6k6glhVIOY+EwiXC6SjnqYfeZnmHI0cEO15mai1LcI7PwXJOyXF5e4PcJQGW5nrd6r0XE0FcBRSSThKQPkch3VI0kBu6rFewi0RpdlxtEzEBaib6B4R1bAArYSZlyLlgMMtbQkcAuogmdFMtVLV56L5Cjrq2C+9ScSzs6utXBNZw+H7/lMlGM7n00oRYDb3XhGbr6txflkFmYAHUB1kkvQRA4VVcbsaUpuL4FLyzNU2GDdBzEXic/vhSZC3yKhRLnZ72k1fjW9E3dHODhq56hwfb5mpreo4/ERjht/2X6g/GzwSLDkgJP0ggXxJpyLKex/Att1DPnbgC2keMuZrwyI1JrMPlWyIxHbZDaaxuX2qDLeEvbPo1PZCl+driG7PmYy6P/h8NhGSfWG74eCA6fH3UyCAk0DYQoIQDgKABgEACI/NWAY34AAEvvXgeRcIGixjqMhfA6HCX76/AEbFNCKzJRUloGQIChU9OyQWb6216SVtGjLD0Hqco9iqHnkuZ723qhCUT9npT1KC1T8pVNOjxJkzZtenoMGDAaU+OvwPGguVhQIJ3dC/ESh4GX/VVa4mDHJdi8uBWNGAyWMsW2txNlycreKtRC26aLyzaGw3aLNrnja+o047iea3lYKumRSTP6qO/LOf1eLsks03HZD82CdsjrqfPqMaQ9kQMfVlY4kE3lSIB8kAj5mRPpb6SVoCh14n0kSZEmg0yWHHkKFClRRqGih5iljuaHsPQYe4TV10xYhnbCGrMsZpgx9z7saMESkxVrvYTauTr4hk6cuXCVL1iPeO/YbTl6p+vk7vvsd8BBhxx2xFHHdBMrApxwEhNhz0Af9LzPuugSKeJvgwQLESpMuAiR6BMbF/3X9Zrf77okNyS7KcV/Uvkn18+UJdstOXLlYSJuVqgIS7ESpfyI5ytTjqNCpSrVatS6r86FcrtGDzV55LEnmj0V+9xxYVtoFq4VV1Hylm7x9bt0+1+Pd3q998FHn3z2xVfffNen34BBQ4aNGDVm3IRJU6bNmDXnR9afrr/d/s3LLVm2YtWadRt4OycgqJQVjzfveAr9dPvlu9DIN2x3uj0VhSZ+7MDfs+F0Nr8w+Pg8vo5ufOZuT5X44ZdX1ze3d/cPj08YTpAUzbCcnRccTpfolmSP12f02SQUjghKXEINklGU7CtM+du+Un95oDI4hFT5X9+6ifUbNm7ajOEESdEMy/GCKMmKqgHdMC3bcT0/CKM4SbO8KKu6abt+GKd5Wbf9OK/b/fF8vT/f35/jBVGSFVXTDdOyHdfzgzCKkzTLi7Kqm7brh3Gal3Xbj/O6n/fnr99//i4sLi2vrK6tb8wBhhlZrDa7w+lye7w+f9Rqd7q9+CzpD4bno3E6mc7mF9kiL8qqXq7Wm+1ufzieLq+ub27v7h8enzCcICmaYTk7LzicLtEtyR6vzx8IhsKRaCyeSKbSmWwu391T6C32lfrLA5XBoeGR0bHxdRPrN2zctBkGRyBRaAwWhycQSWQKlQbQxyXu38Fv63LTv9g0IX4pFD5UWVRd0EvfYwojnfrKR6g0zIgFsdDHy9Dr2LqpeexxbBqPX5ZhSU3GVPlGPe+bvlPf42TTsvoRhIU5IyOW9ngPexvb8nRwdhE9FUzGVF4fVFXU6NAuSl2qnLoCttbWo51Yzd+3YlSiFUcAJcCZJiVmjBbFEAwurRp99qizRqcZYUDUdM1YITG3by0viKoeh5n5dMnOPaJhXRnMat3BbLEDsNq8Ru/5xhRS4UPJfrFgWrquJbxYkHqqVWCz1WwVRooGgcB0VGi8VrkBFEitAY8eNGpwXS5q+HRYaHIKTGEu6lc3pXN7Au4JqCW0CmoJtYRtELv1YLvavr9+LC/LsbXTKo3ogrDR9wYVpB68/FzOvSg/6cGvRR54+Huz1D7o/e/bInxUbVoqfjBuv79s4nNXi640fAa0FOvG748+yb9Xqe20qaWC0zBAotqUe+PmAr6VUQpi18vKsv22HFbXJdvz6vf99++HDrCBbXtR9ZdU41W2H3TQH3ZfTvc6vT6ye3v7/m3oEZHeTDoK3/e/1s7S/9//La+/ji208gbQJ15jCA4z/W/ESaCj505tRlfFbbUcbLtFxtdjnGVUXgfYSzC4GjURzKGKoYAOBvbiWYtmh4wYkVBjw+A4UNR8QnS3rSmDJNLAZSvJZ+UhCJgVhIApoJapRXuVrNgpQ/ilaggBq4YpoLaiiKiAAEB5E3n2pFmTyxwlIkpg1TeZ/bsW3QMQsGoIASFg1dDmRw5D9Gydh9XyH4yqQ5vBHj7GmHwkSioOcItKf54z6aGSUKhiCFF4Dp8DSmBMUCBNreqh2cvR7JAzRiRVj9KcJ84mueC362H6ec41f4KHSYkoqJ0RvQJQ8nxLB2bscgGGl/rL19ga51vFQhFeXaW4NUeSJQ3ivdeSnkX6Gm6dHmFotreIGBJEFX+Z8xvS9Qek5AWdzgKaXXTTjuCOnHtIPAxFxVtKERaHvLW0VpFKtlhFNAW9s8vM4oYqDk0/7Tyg+1bJNyv6saomr/c6yPMCHyZVWzfa6DLTzl3Feou2vGcMTKzJhRBWE4bccFBss75F7jQkLlMQO7Ftmh5UTsrsp5XRg6QO0lTHFrtmgpRov6uJTPQagCMHuyOrnmVEtwE+EHUdBKbo8jwa0Seinbwc5uwTlnGv0ExVeyphd0uNP43oqUxpNfcFRL6KgmOLkIgYlj0iphSDAJnFs+uO8xrywIzTQ1ZydNHY0zAiRleH3rEL3Ye5UxT3Mlt5igG0AAhBc3YtGg5Qdn0zoEliNGNmCYxFC/J8o+S8r6tGjn2GC4EGmihID8XcOjmGP835bdHEsEIL7asBgROYoMJ5aUs0JpGJyBQ073iURB+0yoNWxI7dcvQG37iZ8uBsXCmTkZqHZg+JzzckAt6aMyh76FUdHOnAODAigeIHme9WNYltUHuZ2mQ4Gk8co1CE4Su1Cxw07nKkkgUnZgl+ZCIbulLvgl6AaULMEmpiymaNFDOxFj1pDpS1a8tGHom3uINkOuwZI5d6+45SIUZ6tENEDETqBQPj+Q86rwY48RARR25JTkKoZ8eZ0I0mZ9jhbJD7oHeLw9Hz9DHlPMAF2FAdUxJ12R18Ohp64qFGaIVrAB6FSMa6WIaEngym8QwMD8qLkI5thXFFMcYljyR5n3QrcLcZObVkGSMnmGduddlxrQVpP7Qm8ZnuIKCQOMmClVrdZPOL50E1IO4o4NUcZAdLuhGQ+G1w6xConuXHouY2kd/SDJQXPHiO1RsibnWMC650SB7AYr8sPbb7YNYE5iosfStGRBZ1JoiE0cpnwgk3thSUpY/HTtrY61LHvlV2XhkwUvI1m+ah0bDH7DgzIv1ipQNqf4J5/7D8fwvj9NfPdf6lezoZl/PLn5v+4FUjvrwyg+n4v74Xu7yh+UBb4PJyLPqPK0435dIZkxc27v+WtuPD4ymbnLIcLs7HRp2iNtRpqh1fHaWejGeNp0wb0ynTpcvfXR2XTxun+reg5s0k8cXkyATQlwbvP0JwpUkmuUSvbfqHRdEGu+6Znu25nu+FXpTSnW26Y9c907M91/O90ItSurNLd+y6Z/ZZ) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}@font-face{font-family:"Poppins";font-style:normal;font-weight:400;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAABWoAAwAAAAAMsgAABVWAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIIACskovF0LgmQAATYCJAOFRAQgBYNcB4ohG0MqVUaGjQOAOH53UZQHRgv+/5LAyRi/ObhWolrxUM8pbq7lDl3rRIaGgiAuOJCVt0Ps5weIZSHTXFnYxTJyOXIWsxjRm8VPdjMC+mm/iSg3cw9T5rF3h/Q/LWxyjIZGEpPne/b73z4zXzT9n7ESSNa8QhdfHSIvFBqJSqKZpCRakqU7P89v8w9YjRkgKhiElTziEYIgonDBRnsKKFurC/fnMtXpunQV6Y/SZQycc/ubVtFvikI/yMEvertSNMrBPqFgSWdKPvtBspupE/LWZcGtZwoWEC5rrkg8ofMMRdpay2TeJa8YHWGJhDoSwjwLC6QIFmRlhWn8a63cqaEmwFpae/wcl2wTaJtDl7VdeaZ2xOUQP0mfNwmmY8NGswVAXjy6/9NlttLOjIlkH0N3Kbq1i0pFn6YZf4+WRrMsZ9GAOsD1BVDWHmgV0gFXAXw9IrweuWigxjZ9m5SpY87SMtJe35YIYRTHMcIIp923/brZMZRqd9Ezy2y1rC2v8mVQNWKA8SQFwA4ECEDgnpMowRYsAZgRpoXRolls7HNLb2aBxySVnRGQdcdrFqMyjxVAdVURcHnaJMVYwVG3Dm6W54mLV/gyOA7A8QNLv6Vf5VpTmY4BPAEUpQ4CxyrOLwC9+pAFELjVEv7jJ21vjhewDyGxwU4hh5Gk4JEHRZ9JmZsF+VHRUh+ZJr4L+hISErJRPigfUdxbgPz7AwR77JrIJCYlkihTnJpN6/cKLWwX3wZ9JoN/Efr1ZxqGZpuqKLA0iXemlqfL6ifnJfnFgbo9tbNrtAC/3z7rBgKsYluxoe2+Vz9xyoHHYOsFYM8HrHWBOh8vxCSI24QQI6rBhDXpTjSwB8Pi1wrUyl8AtkntDB3K2NtYBQbrlkQoXy9Y1QtEOAiyfJ5mKX+PxurCJpjy0HECDX0HXtmaPpc42DHpBJ/NWvrGSUkZY9ss48EwMdNnWmKWABu08o62HJxsXGytNZ/xRNLKiSZgyniC5hXI61muypywJYr/3/peJqfbKq2+/DByomX03iStAO3mSS8t87tzmu0GvjdByNCT34UypDgZZLGWMJq1xqwi+jh78f0kuoISgnLK4j2S9Rmz893P0/wNs1qzlibtvVHuANOAgd4ZSkCxRv4/KUSt71kbHUQbY0DjbEkZTpEXDyqE1FxUdDNBSckevf6jOf9eSuUjZHGVSV/V5AwwEDhgWw7Mu5i2jQ4Qu2nWxTPmHwmfTYMco6lSnKccsToypoWO4GuRyB0gNLI+I5wYjlC0OpzhA3J82lr95C0QgJTNQM2235Hw65sGZJJFmDEU56hgQ5l4bWJZktJJmeZUBm9rUWCQiHOY8B2wcZovIxnwMECZInJN42n+HRqU170aIfQd5KAumv3mv9Oi5skZq+M8LyxvOO91aInVvGMK2cktUgoBLX0vwSCR/QFQCTi3vjVBnVChGSjHBoEMZFH8ZO1dKIBxQfOJvKYdi/w3BEMJAWyJB5QIE7hu0WJKpN++SR++ZjNmJ6xHoIakp8LTlOsyEv1FOWSiLWka7x8vgkJbJwhZFFvP8wL8n9aBYF6gBoTnQT2Td2QA1+0DCNM+tuFyt6+wefSy/2aGXt4KasTxeEATs+EPpj459Dmxax5SRieJoEFf03dAXQj1BJGQS1PnWUQMmg74XhgycOs7VmfUWrIcsAPGzLGU1PB5YfSei2q2Xb3mS2wr8VnSCopQG7/pe8wy5EDzaRmVZiw6j1hsktHzauaYXZTMQE2p0mAbUijnlhhNpPJRjEk8Ptxj0ZBDHix29lkTcfy1GwRZxxldLIqH9kN12nSCzcdZkZndkwq63NI4sIVEX7DhgzQSGKW3pXs5/uguW4+OlOnUO7mRRb2rlXRSdTqC+U0+C/EFz7gzRJiliTQ+55hXVvs7dMNtQ8hWY/9knD900Qt3gMw60QaKYt4EyFAzdukoAXgP6hB6pyQJsIUWXQcRxtA8rrTbjH1lWmloSVPHB2sdWnEayVj2m1SiuepO2vbpMO8Pqc6UlNyYfNaTZKYPd1s87eRW4ohiv81aqJU9sBlZM9c1Ac8aYEjuKWO4TnYzFXWuvpgou0JHPb4L06SHrv9+nb9UVjPWC+RObNZcKHcj6V56hZebKTdMQHaCNZPBXn7LOikb5f3qwX5h63pdMkRghd02M8lLSbcg0fVY+vPUbcpZKHL/vJDBBxk5AiVPNCxO3a2nkXOdNcHcj9/+b1Y8NMM48fMZ/cTPxLofxPXYPxV03V80I9HhbnbWgeB4CPL+Bl+Yxxk15imdYpyfkSXgSTo9fmVy+8Mi/4yEGLZAE5FabELWiuKM7KTEhJ6IIK7R/ojAl8aKYeBaWqa6UWuZp8tYn8juocKNTm4dnE5bbnquMbRENt3cMlkJFZP0pRVVjRWzjQ3OrpU8jpCkEWIhWAf8tZORtKL0217r696rfGhiSfo3BdpJ1N+DyoybGqmVjVcbMInQhOVMUObnTDBhQkkD52ojtWJTg7GsR4P6qmDpwHplUXd9fdGq9Qrjg8EHnY2z53RMnjO/cxJlEmwY9fdP8c/XAeLRB0eLQfvpciNHKGzhcCYoFJzxLRxh1ZSx9tVeotF8mwI0Z7FCW9ar0fZVVWn7ezVlTZsbqRWwYWAQDcIG4XuRbBCBIdFIo6ODqDGKhiDC2kX6Q+VlGuqrrqb8lspxaQvGmZiv5EwwYSJRpDGuzJfp7L+YEA6vCxgViAZfyBoSElAarmhUuG0nt+s7RUI8IxPHxJ0wVNDAyFDZlmXzOdwcUTY7cleO7ySum4KcKslJSSmsieOWTyizyasUCNMzUgSpCdQdf83lkvIpaRIOO0Fdm4TDl4HB0SbUdEwE6wYGdRq1PE+j1g2igUKe2ZwiEplTuObCAUhbMHhhoKqPsYFRCSdvlC2VbpBW9UqWSSB+4OUuG2Tzapd+S+mWUlguVcqO4/JQqewgDr+v5942yIBWjU0y84R4bUZPpZairdpRlykQtgqwjvxr6UykZLDZ+XFMlJnF1OZLNFHOM3nf02N4Uv3kMg9V+Y28lHRpSV15RUm9NF2W9KrcM39KZYV0DA9rU0G2Hb3fMq9Sg6dJE3+Ue0qnlJdLx/F47QUFWNs4bp50NJZtFuv4MSIplcErLbTO1UDr4DqTHhNDnNVizpE1zNU7Fmpe6NI54mJdgWlHbZZAaLaSK83frUuPbH0HbXg1hIbgUMz4MUZMk6iQqwS4Uq2KQxQk3aSNSYbhogk8fnuBEm+fyJVKJ3LxtoICUXsbT8qQFcTEIw6HjfKjmSxFNFOahjGQ/F0Ox74UsbOLfZavpyEKUsO1ogpaiiS0OJnLTo4/Qqa85bhek4QkZifQmDwUmYaakIUM0V4lMJeH+Ydx/9shDMolxDAFmsg0YJEpSL5cG5ucrY9PrZXkaBLktUaYfw0xwDJSNpOLp+xuXpHiLWTdxEvTL+mmXh5/GShkjzXU4nqbx4H6LYc2HYJ5Iidxq9hujq3IIIKExv+9vIa9PIfZtP89Zz0JPUWY+hV7QfNjbikXfr9728C9PQHohpHv/O8f/PDWlQ6qFRVdgzvwlrkLXy6ATRX45hkeMAuVhfEPphlnL5g8efb8zkn/HFce/3cS5Hx1rE8JEqSyiOjs/MQn5Z7StvISrDnjdJ2s9mZ9Ji9Bzwt30mieBKtJttRL9PzGLkkLN8uM67JjJXmRTLwGWUtrJf9Hyz0zikcH/fr0dB2VLRitD1v+hT2nrxx377LLw/uz/9jW7vIlUudJ0ieGs/kMtqCMXZC7FcqSztYdjnLu1uZ7KlkFXKsouzH1Wph2SFu9ujb4zN+qs8vCU6lsup/a35up0v67oNTOsFCboeOPKQV/ilY2JzbLtfKMYLEVsQ2unCCdG/Pz4EMc0OWY+XYVVOJYVMRxO0IRDeC/4phrMdtqPGWMtKa2ebP8Je8kpZj0NEYyiaHQgPeUaIOeFpfozVAhBbU+e2fO9eN4eDlrAxokCv02y5az/fww7kumUbIv/52/Gn0bCVEeG2wgUxAFMkcHZWSiQYQFc0xp2oJZG2mmSlqc5Q8Evk24++YtGkJ7br5tI7gmYCsiSaQ4rf1nbMnuNqzXUbeYYI1xKaYq36OI/g7uxdFTI1h0X3WAN7NAezPt46IN+rd5tf7eLNWg5DpqKqkPHMRxL/QdByQNaAhtSblEPGvzHnjCRh5fGi8P4MkDs1BQA5WPR3eBN3M7/i1Ifi6D8/0kKHLyppRzOuXhWiTW/lOo6WVj7sWHqS4dAqIa1yXPjZy7Z1cPJHYdrUD8NgwNkPx8d5sTq9Sk/J6ymsdmxGFJiaa0stBXPt6vQlkGnY2pGmSb2uWAu7JEJbNiCb/o1efZ6pEFp5keAmJTBX6sRtemY6L7oqNNEJhM9IjYHVhQDSYQC7pQ11zxXCzSlYblKlxK06DhVfhQMWyab6k7ialCa5/fRiRiXh7rxwCF1wcaajpUpLo6/BBp2XSds2GKYQBt0PuD1/z8PQU5rX4EUQgg85rg3/tL1fl9NbWK1fzvxxWlCyXyhdWBIbFEfkZDdVqO1Cj24tSGVG8aY85srY7PrLTg3uSkVNYkcYG4ux6TmqyFLUkka6E4R+BjLXIPPMxOIvGthQKpnbpGrrcWH0OOSFJkyOml2fb2Y6go4oJ7mwLJ3bMwWbE770cgmLKJZXYbaWkRrBo9OLQNPkLs1J9+zEjhf/VAHt8PX1hYualLiXcpZihwCF8/Q94lx7uUM5QQ0y/CMUyMp7olUpfExS6hJpKAuZXCGkrrPYShbedjYx7ExT2IiT3PEA57ew/7+o6wezLiC97zeZHuW+kPNE5urZR4ecFw2uWAL1H3WB+eALlBBme5PH15umB5Hnx4tLSx/VODtA/jJL2WXt8C3Nj/eNvdo6JSz9e93xytdA8qm+J+ala//ar48s5BnJ20yq1RnM2re/xjzJzjjm1wO6z0ofDhODROJVSVqnCV9IV5nEFTaDaOmyboFOPcjCwBV9IJcII1gE0IN898VfaW27OARd1jt9JjD7KZT40tLEU+aqqtC3rDM59h3F+/vmH/bm/ylW6LkG1rt9N5IkSmhJ1PlCH7SsUfGLQRlRBfz1LT4l4HzASVjzghdrGKfABaKexLo78r/RrX7VGfbOxXHwfkoPRNiZy/vqDvMxhU4XNRQfgnVc9UqKDne74XuyJyzFMp7bq/On1urthJV0oEdAMdiTmFarEo3dYL53DRRTlQ2qhd2RDn2H8jqJ4+rO6PrdLvCHIR1HNGDlpfQL0BDEFbUNd9Wbjm8t5zQgSr/e1sLB3dpoPTuu77yE3pZtJJHai3TQ6RekQ3IOs5rof0wLeqJI0kxNOH1avdV692Tt3vKgQhA3KfvypCy3kolFV+YY+UGRMK86x6NCoUvwlP8C5VJktlXAOCcwOdE2Ti3WdhzDMYS3Zd90URcbWiLTjKm399L/VKoiVFLy8sLD+2qSWAv24pJbilCsUPNileVouw0s7FlvY+HexaiTwUaX+rF+PUcuxsFhmufX8Xff/VTPrfDo6D6mgV+tzLrjM6aQsPy9Wv2vU6dNTbGdc01k3SedsjDqCWdTs7gNpcgxsjp+tI7xpIGxkm5eQmaecjiPzmGctbX8C4nFLt/FUIarWcXufnYjutVdPrzPzXbidWXY/xyRJ40eX18qu693Uz98Piql5bBuBicjsDt/f4KT7rr52iWZeJtJEPZCr/mq9HlW2MGkfVxiA38zy9TtxodHsS7hysj1QKf80Li9M35rQaPp+rXueZqMgZ0kaG8cnGZoqpdM/foebfn3oGR4COqNcwUAndgbk/l1b+2DViQYa799weTU87A5c31k3SzkfK6vzzpXYtyerhtUHuaoMY5Yfcw72N7SzU/j4I5x2A5zUEBLBGKBh3Va8ucUn/Y+sSrQC+rD1xFIDvXomXf/z/47S9jTkA2AQiAALw1n18+39TzZdRBwECrGa+ynvpODzdi7UCuTUeu/qFtiXQ65RuEiC37bUaHxPZCflYmGSRS++NWEoFCqs1xH0dVTh3XFtsCOBWa9GrZFtu0NeWSVU7svS0yqw9xGnPDd7xHIlDOBKecZLKO1O4+QTpqRyJkaHlMHRfUMqWe7y6l4D5D70FlKklHgoT6FQ2ELQLZEujPk7rNnlJPuD2lGWbcqFuEVe3LvqyZZej6RjSiUTA3McOvm0bxHvR2BCLmaJLOkQPEWpExKwfEKsdQY+G08APUhP0C6LfJgS9hT5Bf6FXgT5Dz2zlsZqEG8lc71/CciTZeqHbC+lJ4iZlX4u53L0DEUJdKgrUDMjyHgBvfk/RncmnmlF8dEAA8MpijmBmDQQgQhBrALeABiKALahiAQTLYgDP3NYWE8AZzspEMrDYAtJNWGwJQYoXW4E9KMPWaZIYdh5XgntatpZvZpIqjsqNKxjVauZWk9hsrQb8NjUxqhZHhk8iT5NmzWqNYhJDQa9aqwZljOLFYmCIt3cV8lkQUuKTSRPyAEZr8YOUSx7tinBM5WPb4dWNUs6zMLazIZQJd31l0MNGCtdZeEVmNker5DUBgM09MrJ8tdop26p8LK3QpFFcKlylfVytRqlkNFZczeEoRFgd7rzD8j/MKxAiCrAgmGgBBVWESDTR4jCxJEiUJFmqdBkwXHw4ERk5hQIqRTS0dOZ4CCfz/A3nWGMhFmExEjL88IsbHfgVW6jWAT0UBkcgUWgMtj/+Zo0nEElkCpVGZzD7pyQ/bA6XxxcIReLqNcSQyuQKpUqtMTI2MTUzt1DX0NTS1mlIU7p6+gaGRsYmpmbmFpZWuLWNrZ19hyBHJ+f+0JJL65USJEVD/91Xp0KlKmVqYrqx2Bwujy8QNplBLBH1OeGjUa65+IopRCx9cJD7VGR17z81SDMhjwt1GeMdQQzUFAk+zSg5jMxiUwepHb7eQEwtQ9BS4hC63qUqHUZFytpHIIjbCD3F9gGrkeZqx8WYhjYj9BS75GduTr5VNUTk9Sj1U8vVCNZgsL4bbGlmsRx6Nq0ythgMdb6eoJFQlCK4g5YUQ6E1MZ/Irf0cJT7dnTRMsv1945oMuYkR8g02dSgCZmbx8dVwpjfyTRGT5wpKK4GahkU9/9gwp1CYGKE4DcucTgn5OrjRpaC02ltPn3UeLSbCBXUYc0TJL/6Z0+QXiR0rvIVO1Mt48EzuWNp8vZLAz1jylh6a/87vlYZ9W+jtKe7Pka7eDQkDy+h11DhJkcZzRivafCHXAsJj0DeV0eOChY228Msa9hYeSxp2e/AXQ5VRo41f6fubXatOUzcZ8q0hyQoA) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:"Poppins";font-style:normal;font-weight:400;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAB7MAAwAAAAAP6AAAB54AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIFUCudM0jYLgzYAATYCJAOGaAQgBYNcB4QLG34ysyLYOAAgoXcUUbVZLPs/JHBDBr6G+hIpYlQoaayFQFiGbR8DjCviFJxE41HqT/OOXC0/Z9GQVQfAWhGOAF/O89SlbJ4fIclsS0SNUfbMPgE5dhgAVqioPNrYqNhUZCQIRaCBLIK83W+vy6VjrXTMAYfFIfS65yPR0ziMQaj0M56vY3h+bj1EaSMJC9jIVbCMv+2vgv0FSxg1alhIGl2gBxecx4xqvCi9NvP2XXsT27xJRGharfanif3dB1IbH7D/n1vvG1gi90J+0acoU3UyzKzznZ8Q8S/KSQdFE/HKrFSrbCW+EZMGJ/JOrWFOCzJcLDcqMIye7xUDVgJSUf//a37amcAiFDGyIExnC3pkybH+6s19gXl5eXMmRB9Ln2eT0vLklZIpALkqpMkyJiUkt25tgVyFkF8WZYV0VRkTScF3O1cffLfDNqsTWFV2rwUPIfjECpG7lz5AAVbIGyfmmutgE0hgB8wJNaQ30lgYP+3xQCMZjDoEDzyVUi580bg7SwwCfbU2wM1JQR5DDgSJxZ7llnqObrxHpgXHgAOb7RkL2/gXhVu/D4DXAHqoBwD7DAQKDGCTWIoEB7JEnap7PP3Aas/+DynGHuqZ3u8P+0ZRlopUoQZt6CZzX2tbJVpJTFb5OJJs6W/YeiSlKS9d/6ya+d/8fZ6YS2ftgn326bdP//3yrm98rcc+6yxV+PO3P/P9e2I8D/za2srbgL+A1V8AG18HMDYA+dea0d4dnI0DUjAxhECe4VuLDc7VmwqwYTiuFzfuViWi6aNC0Z4wRhGs1DQggom7F3EXA3Uj7WxnxPmMGXjAq72EYaM9d+AG6ziGD0E2Ej5mwCsAOBXGWG1AYIJtCLwQDEeD1BqU5mmQH15SfTnMYUKO6QE/4F8j1ltms2QsVoSSz4WUYkelXQ/7kGlFRAxAW5s6qQqGsbVQl+8GCZsOFLXw0ul+mnssHngMiMV+wiHwzdVDGrfpDWLDkN8ewxN6ZRvyKaQ6K04Nqc6B6o8yc2SW7XOOuk1FcKA/XlsYa6voyRGelb8acI8ZbnoE+I9bLYFYSdUlo6Miyo+OYJqnPAsyYlzDkHe2VlOgYQcrDqbWBQEPfr7lShm/dUdxu7Up8/IxDbSiNG8zdthTYufBq+u76tI1uHc3vs7tLencpdyDGVdkPq4cQvLkEMhSXsY0J+4dQu0yRz7TZW7mccfhw18fQHPvvAbszInsG2aKiyHGmqz3Yvm3u8vmFpjxaPQezfuYJlpv3PN2ELEgVO3vPWKl2Ow/IpRJqDdPE8JqY3cYGuq1ECiB1yW0RVSa66GOdCXTLnh+xxeZ2xOqquVBgJFiAV77CqaFeYl2Q3S3BeKrdnAR3ZBPYM8o7ibQuBGK9xO3wKqYDmUkxZX+YNiXA09cBmjYPgA3eC8JPjEQxkjfWNFnGY2x+ej0ZGhv9VXwYAX9XZ1h53rzljTYf774b0vaBdtfcXWQxtyLpkaMb6v1GUsdrpV5ajkXRww17Pu1Ak3yTzYCGLr8Iara73lF7Cb+vtFNzajk4iaA8ltEQiOf66wxQAem4oXOWNTna0SswZSLr69zS/jeLLVejEOPPrPCBwhciHFchPFxIsHeTycPj9TzLzASCiQQ3wskAX5KdXKVa1sfQ/sqkMZ64u7bhwtw/U8GOoEbFSSWFLQnxd1WqtNBLxi8rBazf8BSfI/jBekq6kcBa1EXlt6oSzrtaXe+aXn1zDSw+t2F0YBoSCOqvK6Ty82lpKxNRobfRmluFw/KDLgqURpESW0OWpuaXaHkb7VmE8MOcR+a/dhsTsOYCArwsIQcjWl06SjVvNzhISxlLRqvol7V9Uvp5h+XUC6iUmapwuGiAxeC1khAQZdBxgFmUTC3Z4yjPVCczdRKlpb1KicmRnbBwTOOKbXkmmPFA5OJDMkKWz+t9i6mbI/as3b5+7k73N1wNPu9xjdrpg+sMm01qiKDGA5cKAYnIcm+Qfh+uhwzPoM6yGjV7B60MOvA1XEKSqIe0eUd09HDQqAknanN3NpKivMX9BiYBbda9g9oXcV/PqUdinIHcm/0xF16f7v01DQjzirvp4PZFBDVvuQsuKo43h6x4onbhb8L/aorsWA7vreavOxZrXrFsTJEMSfmbtxnkGGNSLjUx4n7KqyizvGq3pG6UbpMYLQKzia0LJaGR1CpXzjijsrdmFQNi3l3ZYBXuX+Llw+XK27BoJFUN5uJGbP5AMzwbSAAsF0Rv6p1ZltdaUBWVzRXCpFiUgwe6Baj927ntwXVUyMpM/vud4ksUyM6kqSZVDs0S3iuldjWchysX2vbV4o/Pz8amoTijmvhaPWLd9VIgu1A/oldyDH0JWVzJzxjd0w6fMbXH0zOZ8+5usPgm5jaIvuHGYtiiiYCEnuoL1AdNtUB41RrTZ7Prwsb3D4W0uh3f+8i9Y0bosq9ebt7S1nLbRmg04XpC671CTyK/OjbeAPmgF2YeccypeMa1gKZ9E8jw7TT55F7FR2oTczlzcGotU+MVuoqoXw1TPk9a1bQ3tfBEjN7MCtjyfklpqmKJbbc34qhy8Q7eToWpjQGEGGJrZnakycxfRbZY43YyZIvHGjmrkwH3GX9ieY2bjaGtjSmpnJoafqeSCs7vP/AmRVQ5uYueAgyd/6U8/Ce98r/4CsiEQrURcQ8yxIrH6kYK037PryUXX1DSGoin9hSaDQjFAbj+CSei/XKrsvfazl9OA8ULAsnF+SYtWHLOyPlaySB9McWn9vqi5Rydc4BO8Wx7X4x481Yc106vl4c+4xeZM3i0C7U4fBplHqWdJI9w+dIizb5C8c3+c+W/s1fAWyvmjjcoH8R8PSKF/buAQYf8Vni2k1zcVt5+eRRTQvCvnyhGrvdSHxMpO0f+ipWFcWyWH3YgmF3OGGrEXByld91/lvL+Y5FK7ufR6crNdA/dFvx3trsWXx1L772EFa64hj34WLmJ78Qxmfiq3ku6j9tjemYFnMBbJS2VsycEIoo1+qL53Lh/wMrVnnuOnTikosR+44dGJUxlM41kdlU4FBuwQ31zIAn1EjHa7nrvNj5pOtpV0HbfVdql/aCfyuO6xX04YiLwnDUwrSZlLWD5ZDYebCxYV9c+xxqTqCguAXT+t+Kts5OICnYBGqxYfM2RfN3UMFKB0aj7MClv7cY2Vv0Qy834/a5ps7PZzGMEF78qaPzfxjAib6kF/C4RcYRSkaGno7qZohKB/HLxyWd4Sef+fFgBxou5nwzT7e+8KwV9AakNuq6Xfl63b7m+boXN6rX5w0wZBHB4mAKYvV0vT2+1g/UHmZV6nvRMD2KqRLoa0LOQUa60RRX6opXeUSMPS+FwwzZDJUwMmp5zZ/Ue5QfD3CEeFJv+D9QUK/XCQR6nUSaGKTyuSui9n1+07HVeHw4O7sGh2/O/u9whaDLSnT6BoZqRzMe1zw4mt9WwG9H0PVkBVRN4bgFCkO1buKro7lYrMyYV0TXFuQpxyMJn3PzU1AT4suuXhsrrvXqFw4u2bBhvtBSUHHpcguxnG1SS0D8N+OSz/BTzoA7SHnWnn01hWUl7sRwWU3u5vXl6cFQohsQoomCHn39Zh/FkI1yKK/v2/PtN+Z2gvaNKME85nxGjmiydegq1ZBVk2254nnMeUVo0TTb0NXwsNXAJLt9z3zvlvpWv7n/NuiaHk7hQilAO0gac88Y2T0cbbMPH2UD3HHhYwvms8e+nvDx+Qt22LPBMmayTCGWINnAah8zRZeIgfBHzw5yWoyHbjpawVfdi9u9i6RCnlImUZoGyGyx4ZYpgdLJtX6jd8P0Ro/GBv8qBKLJLaVBiZdINtJ4suIFgwRDVU6YSbGXUhTls6vjA7YKo0omgyCWyicMpMJpCHCyeDQJX8BT8QPFIG+L1PWw6ge/1r/VvjX2YkrTYJDU4X4QLs6nGksl2EouRKutFhpCbRWDi4vPGfkCrdal0WhNGpqGPNay5htwYGV9sXUO2OArZ4lKp7bUSqgV5Xy4tB7BbZ0UBt5wKFFn+nqFKhsvo8BWl0FmsCg1WpsavJ8/er4jvb1dcx/MXcg2cug0SzkZhrFUdAudxbWYbkAusZBf0kCF4Toq7IRiufv6kLtaoUyKufMYBrFIbJAwfj7hlEgFdvX6yixWC8SITAUOzYG4PKOmLWYt7CFzxGV0dkhVMa29bkHNt73N2O3lZmewtireZLq61GyQq4wILDNYIYXeqgGS2U8fPn1Q/+zBs4eg8n91VMffGbLAaciS+u474Tk+JewKtfnDA1za2I3jfWG2kSOXcnkyEcvCodm9JKHtrOj7sJ7W7UbrKp+WssRbLCLrWf+4SDTY4tCqeG1hjdydKf9CS8rMHsah5bNU4+sYHRsWL550pK7i7BTQsXnRIpc867ANXVGxTWdb5V/Y9tcfM5dIBCoqxk6nMgRUIsTIc5BpTgr4ax2xaF3Jh97Q+94S/YPp7ulucLXkV7SikEYzBYmygdH3ch+epCXzRDpPDHqtQMqm0bhZtPpB9lQ7k6UViTe93goKTyDbNiGeus6qXH/VlUoxrKgXC5tMRiD5V6SAK0VXqnJ9nZV1nk12ZGsQrO7bZbJtrKiwbdhlqOuP9s+qWriorX3R0lnN6Gawu/rvz6rPT8epJh2YpAJ3+pSEf18rX7OQKHA8vlQlUigaRKImg0E0rUGkCHZMSSodo5wkizcji1YaHJ7NdsfWYNCxbbPdE+6qyvWBQF8U4fg4SBQh+8hgd18UiYK9fbGWUNBqC5UhyAAChTKOEAvOTuDykCginiiqZzt4CNiteKnURhFAGtDbiwx8GCv4Y+AgpNf7P3uy1SJVhRjkAFJVUIiAvLjNdse24VQvbYBsLS1FNDcvpGkQi6YbTaKmerFSCQTdZLSR/z2sABNWNtZNnYVCor82Tq2172iWC7ltK2aBWWBax7x5OJqns0n91s0wrqc7tJDVWsHz7QoO7RxXPR6J/qqtpNEQNmSoMgzvRrUGZikVEJcHiVWzwIO4SiLXkuARyEQSoVJAyf9KmN4sGW5AsWAhk2ktI0i8TZ54nV+u4HCZchYtt+evxZIRRjQbFlFoxaEiCLzrUx4JI+GjSrCzL+q0F+t1bOeMIn1WaWMjU6lUNpJGax9Y0BfXFzIpz32beToBe1n0fF9wK3E30Q9ORD2rNbs1wc3wGhiEkNtI6a6hm4YGbiG3HcHdwzYPCwJq329fxSPxv38V2Fui6gVrNSbtMUifpdEegMDI5btU7vNuuLcEHOwcucJmp3aQFe2FA0+7qhe073H9k2z+N9n97XrQlGMaZQIPl0hu1WpBYam4uVGqgELcTX4H2hHsKefJFRG5uM14lUNCTEQKxUiQdh6f5DA+yEZUJw+cfFzBlSojUnGzyShua5Qr5OXcngDyAMmtr/ieIlDIX5rJDi6PFY0jyh+i5slSTaDdM8riva5jcjTucq/PXaHhaIt+9442dvh9mlxe3GKZTFWloIp1NdvxwFG6JaR2R+OrSZCC3T9Q57dDbA39k3e0psPr1UyVSlvNZnHLVIlOM0ksaFQ5ZTilJpcoLbHGqe0Ac6++H+mXq+R5DpcpBHOG0PPqQQRbjsGqE1X8hkahtnJxIMVq/9XJEalcTnN9T4g/CmrC6xxd/H4s63gdzkdlhGCxnW7QW+SQqdhCQB4gQzpdODbwNO1eE2BsaAQNfE0v/+uyYF8oFGI5TZ2b+wi9FgEtd549/5/dNzeet8QMGzAC7P6dJnsAyAPwPiqT+63qLFK50W7B369lBI1ou+y4ImmIuz4U4gvBQdy0yXVjQdml0nQ6cAzwOKFJKms1m6DW6RKNhmuAWsxmZWuLVEPUmnFURCSiIEYsiWzAkp4NxERE3wpOPCqXhkn0qsy+U4+EkHwkUF8JIFBV/ukLsdDvyHeENlbwISgCfcPRdzaKwJW2dlchgkaKwdUEXyETznIxJBQG9TAK/Vw07CqcSRfQCklSJJ+NhJFYLVL4O420NntstuS/HsUEdQyOJLfns8HBe+L8YYVitQFWSXViuUo+D5m3WAXIKDSiX+vAMwQBKisEC+00vd4iVxiLLTiQZuy86rmDKt9tvIBch+5CuTq+Nv8bdO1FOadfnH3ROePStEugou1i00X3l0O/HFnadmHaBXfPkC9HATRq1PZcV0X8D+MDew92HgRLlINVEVXiogRlrRKUrQmMsOQmIokeLKRTSVjagjxD/vh405BEN5ZGlVUMqKDKadhE95B40/h8Q16BliXRqSBsoicRybUERoAjIWQmAj7z2B3y3Sq7r3LAm1s/dtvW5kfDM0RcSdrSSEbt8eafRmYYuGLQTVFJmqGedRVcgJNeeEGzFqZvMScoajyWOBfdVZEwaUFFBTcnOOgOD0VexgmQ+aiqiAu7SiwWlxsGmQr4yItN+WZ+RketADnxU66A7vJSBMGqSGyxKUMk57MgsSzr/t0Tgu6ODLcMBoc5n7rmHnzE4uzrWtv1I4f38eLaS/vY7EOXTJ3J/DmRI0VFPZjCRQzGdAxY1TxXtC9me9458bmNyMbDLu+bvTGiuTuYwS739vwEQZx4LDIVsSch0xAQlS8mYIhyRwHP0WCJUSOc3Ux6Fyb9lDjzZSDLa5QxZBbRiPxF9RvyHfXWAZg9Iw4UZGyZ9dKf6atVahaP+lCrF0rFGhGRrOdLJBohEdCqHo0Z83jM6Me0waPRC35Uf2rhaDMGPDu60W7ZUlrKSPRAEMSqRevcg468uRrFQpdTsWiu1umYoyXd6bLt5mgcXIO3iFkmk2lbL4OjqtKNFJvGG5ArZdbqUBMH+/6saYSsSg2DTClGr8ISCCL0YC7kgjgf+7njiTAeY6ApmXwxgcgXMZmwIRL4QiZYMMndXY8o9naPQFzdQfv30gBnzy1kwX0IMI4jVIqDxaI4JcxiT6JTcBjZ8hobolBwClJYCODpLN7faiky/ELQDtdR75Zkd0xsTCtI/jc5+Z/kAlBzSlIiAWPtXrdG43FraTitDkPRlJToUhksAQ6rloLJXoTDHWWBtsn7b6o/qW/vv61SXeYu3deCzHXsGGqlNSlz/NjLqWldeYoJYjabKeHjcw/EaorAxEUQncVQsTETUr8bEFVOKICLuByoiAyxEseOS05Lw4zDEAvGp6elfhyX8adYCh4euVUrudUEilBoxL/SRefmi8YLWPZ8O9ZqQuRyQ7GFAOL0Veoq/YTkyKSw3T65tuE9+I4hpRAJ4iJ6PduT9Xta6u9Z5ClcIUibzWgugfJBppSgN2GpNCOWDHQa0WDCYaABt6J5TIEQT+AJ2SyugIAXCplgRa63u3i182O6PfcxkMPj3n1BikQtkejuBqIUkn5XuPGZ5xEx0l3dHQbFs+m1d/624sqotSp6sWU99kDMHISWGVFzR3RVA2FAF+GMPozjOVdbz/ra9wpgap98lH18lQFF1idb1vnmRXughsXLf1sGbkDh6u1GIasq/PG0Let451bZBy1zGDd4gwHvGUFngFtXbT/JarJS+2fWLVzW3r5w6azmf46Zjv3bDH5ZuWlVDzYt69ev2wD1ICbfuAks1HXjmqAQcub8mtyTPLGyJLQZP00eEPqykwfP0eXVi8UMTwDYEVNOg8KnXu8wAyYM9DELliEHkKWzrj5wO9sgCZcHSVWz4mYB9sLGhgapF0dWYYkE0bJdTcPG/CwYDaUKYTbktxVbq9xxRkdmJ5mQnoc+6NFlSNh4lFEwIXkcTkLmLF6Si5CA8FkK46ScptHmYQVG+o/e0ZoWr1tcwz1Vrg3dqOBJPYnaJc2TpLC4jDEwAAdkVfPgBgm/EXIK8LAunwSVIXGalj5yhtY8J5kBtWLf6YaMVDd4rXFkEdw5FZK4EMSaqjV7Xr+bwPj+WEi+pFmh1zbJJO1mo7R5ihSexEUmuiRwG4bsnPi51VlnbsdQnBMRrYlAdgqFJKcRTyYb8ES7UERw6YlkQI1XqGv/WKf+rP6DmTsyGH7zZbaH5VPMzKOgbxTKNa+yvexwY6YBBaNHeMOJTkS9lfkYqTCc+co+FJFCj+sAx/8sl0CBxucJCsk6m5C/EGq98xDZjfKplvpB+yf5p5djocbFufI5aptrgx3ZFixFtsoinLa5qlzZ/Eb5WEdQNO2XhRHTDAat4Wen2QLB9RRGb6ze7VBwwsmP41M2yJ5MnCpTaaaFS7UpJ0uHfI5IYU2jWBhRbn5gxlOcIhHZYcKRSAYmjulpcOjxpDoUTqPJJ8pLkIF6O1jfOc8EzTPMNUDgwepzeFw/gdCPw58jKh6npj5OT38yLc2TdJC6VJo/ch+m3z54eARN1ZtfG1wa966glkAODRSvUA9RA/LSleof1WD67aD7NyGw9wWGDQWAWceEBWcM/lYc/eG3eBCjLvTzScHaGzIZhfq2oVxGpZRYDvO2ZgBvoyuiyP5uBMNUlcJLlTm+zsraxm/asio9AmNBRnqekV8yGiqpnsXR1nZW5fgrL1cIYVOTOUP1H/9jXvp4+gfBv+MUTQY9SDv6nGHOh0Ce5WBRiRh8rvxMqRgQKypxViaFk8D9FerF6lMIqMvvwAHDAUtvWvKWPFZmnZYvDBDaDlS4PB2b3Z+c6F7tsqUpKcvFfrnlC7nx7eize858uTZVynLhG214nVi5nq+lLJf582gzf2KkSTkPOckX1IkHKcvFU7nlr9HGk0oGJlKGlFHJQIFxqJxbRAkZaLoCpKQsF9/JLT1yY//os34nJNe+lrJcrB9trBVPXKH0/5e7YBn5YZD5nukn49zEDFg0HRIfSVkudsotG0cbO5gNhEMBkDJwCABmEQFzULGVBE9QeGFk/XUdNNzBZGAmCcWXYvQwLy8Bz4Vxusj/33zzkJJ5CbAC5XxWws73djVb6qx1qqiyb4uQVJ1ZLgvoK2Nz4m5zF7vLGnaCGsh7Y7O7zVgmHvgWfgjPp1AX5wbOV2LAiI/9/CiGme/6J3iJqy0AI8uoRBsH3G0InSOBnmW9hje1jiFkaJ+6z7G7xEliQpoAGdqn7O7UtSHgXQLKeUEBALvA8yLMY3QytG/cVxvyE2i+LWUMGdqnxrtSFhaao72g2IWZueNYo7J7zjpeI9q0ZOvoFgMsypIrnzV/G63l/JcQO34E+PLN5QDwzRb636dHn04lxS86rpkMNSMEv1uqL3+UGfCuGnKlz7mv8xLiWflW7wm2oKEGJKvVOH2jsL/LsRkqZ1SqRzYrf+B2L6sz83PzsNyAzQ9obcCLQG75KFUjNSJ/Sis6Da+cbFmdhNNGCrdhkyBVDFNvCnQsV1PUxytQt8lqgHoM1O1J6sa4zVvqkaTbXmqvscUIBbWG82WMOG1yVMiIHBFDHCWU1FUVZsfL7naq7jBmXJPaKrhCRsYmxGe3mV2mA9WrG5HTH4USI/KNYDirrpsgCJVtUUg90tahi3nezoeNhbR6URxo6xtmAZoBidTRJMNUymgrqCQp44yU/GBwT0u1DxXkilBQ/KpH0nh13OfbtYSthG06fo3S65e7fPiwpI40pJyQlctwnacAnoN8Qk2H4VlnXLvZojQhsFRvDO9M6ppMdAshwwx3Snp6WedPbqvcbofuaajGG2B+nG9tY4YUOThjArCJ1+IHzqc9r3pbogy40NIOpUJRcjATAJBXaztxMDvOaMAiBY4sKoE/dGMzjAz4JLuUZqkIEgjkAPKCBMtx6XgwixgwvpeZIsO9MDQPomp3gkcE7HtpvMNMB+bnNElDz8C4qm1grBQ2aXCYPzmPJY6T0sdgmeaBz4sXQAzwtZVSsDgKKooDHgcMCCxzL5ZatBx4wy2yrRIkIrq/trXZadrWrsi1rYPXHXHG3HQSHNuBpzVsnjXqsRAUafepE/JIwzMSr55UEglHSGluQi0ZmE642bJGSHU7jkFgJJFPxFM3jAqPiIg6rswvgoKJjBZbJkCtmeNFeDHueYxUnKJTlkBLF4d0loz4ls5k8qwDg0Ga1BEpj1MfdVooIrRs0VBnnY9TtlToIR3hHYt9wqoQ8iT4TBhRza/OFHCGaSswwPN+zneQTf01kGaw/WXSf3LcPLx8/AKCQsKGG2GkUUYbI1WadBnGGme8CSbKlCUbClqOXHnyFSiEgYWDR0BEQkZBRUNXhIGJhY2Di4dPQEhETEJKRg6ioKQCU9PQ0tEzMDIxs7CyKWaHcHBycSvhyUCfZpjpsFX+Mssi823UaUcGeXNfh+Wee2Fh4rw46SfPbNLllZde2+YL553VzctnCb+LAs654KpLLrvib0E3XXNdj1JPLXXHLbeV+dcjc5ULqVClUrUtwmrVqFMvokGjSf4x2VRTTDNdkz5btWjWqs1/Hjvgri99lXgXP+r3tW/s951Ten3rtNn2OuKoQ0nw4UkSF912LwwPEN8VH3kmRCReEROXZPA1rZV8LR74/5ThpJVMHs8BAAAA) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}@font-face{font-family:"Poppins";font-style:normal;font-weight:500;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAJjgAA0AAAAB+RwAAJiHAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAbpywcyigGYACCPgqGoniFqgALikAAATYCJAOUfAQgBYNIB7QSW4G2cQN1w6TVqZzrzaqA7+5cHeUEcnMTxK83ozXXTs9DlYxtWcPgPAgF9DcCZf///2lLZQxNYT5pC6hTcX4zFI2DJQ8XPOnByNb66L2bITh97emN6Qh6CCtt34TcZQbR3psfJ4TMFVtGbjQRCmIg4sodE5n3MDuOqWM7p8niwcx2psnF3nv5U//Us3pUHsTNIt8CQYgyNKIM8e9CEDROkW7SfO0cV3sQD/rrzzLL09y8kH/AXOznN1m1weUSHK6ClwdYlaoVruL9tavxyp+WdNXmku+FPQTYrs2QwuoemlAsuf1g+vW20ve7Z2YJ7njhGCmSuQU5IEQ25ypnVuUGSgIBz/C0zX93YICIWIhYiIiMKWKDkayMnnNrXdsro+eKKSvntDGGnYvUba5KF/7NGf0Rq4bH5fxXoVCkLbSw4TU98+SSS+6Su5wkJ0lOtXZtr4504KUT8Kmx/Q3GTJCZsO0zmDM+k///ts/m8MeA72u//3d19575dx6pj5jEpjyhMQBQnsCY56NSX8fI6LCMBTyb/oFLct7f3UvlUDpyQBq1qiELxTDo9/P83P6yUakNfsneqBi5ZnOb29nGGlYwIjcqLB4gRpEm2F+wCmeAVaiYqD8iLWrzv0NmgaKrZyDyiCnE5Zl90dOKnhdBT+lgCIcTOJlaCNRd7+Mm1hykHY1Mo9MteijESIVEdn8xm5kP6lnYg5NUus4N5nJJ0Ccr5sG8M8/Mg3RsHsw7/V4PD9phdsG8h5gGfVmLaXgyce/Pu4ADnkCR1/lb+++9KZAxqSO3bOdLNum4cM6pQUQNhi5180UTcUeOZduXov36+Qfb93POfZn58WiH3izBYjxYNAiPWla1VDW1lTWy740xwfWup1LHhqGVhUSigu8wNfPs3XTno4FSaVQKhZ5CoVIoVAqVQqFRYwARDkXq7q7LsnY3IWRm7+cPYimIGBdhy5Jf6XEcWY3mbAcAxkz4llN6jB7ps//3tWXv0dH3W2hY18NF/HL5SOJIlsTZGGz60mRv0zGZkDEhBVFlot7AUKzADHEYKeZA6Pk3XdZ+EWzBOogNF6JDupR6O3Mh5i6zw+BBM4QskFiWgw2AHBHivAjWCDFiJAQezQxaMSPEpvxAYrUW6UAiPCOnHBBxY4KLqbrcORTdNeUV5ZUpFOV11TbldeVVV0aTZindldLWJxPLJnIAQs76Xk1fKfmR7wArROWsiBbS+l/Lmp2/zVYPcW8g61OEJNztqsNxwiFBuJnXf9jr+T2Xk906FUIuT6EUNkcHjpOE5JFYlNXA93Exvn3S7FIWEN+crd3HgAItbJJIE0xyCCxBC0F2hBeLeBhxpkHwBBIMj4Fi9v3KZvPS+cX+n2wVneFKocIKA8JtcCiBxGdnz5me2Wtmz895+vtSh6NwhloHboUDFIXEWCSF0AgpIFjeefCAngYBZR6AT3AoMQac8Gg5rDCo/H+qpS2w5B3lGEqXbkoeL0jqVPr1bordwQz/EgNgfVwuL+ydclqdQ8SfP384GARzo0KOnepOReeyU+nnqrJ97k3pruuuCzKy2cFPWDoBQcjW1aeTZqKbL0AOpVQY3BvjgTS+3zKlOzvSpNfHgwKwCyV3mq9Z+/S155LSUAAPj4OcsMDjjee/s7FB8ZLMlbn6/dydb71VTnF+ZnqFEF5DyBojjBBCaLXGmGDS6/haJ8MNHfrI+H/N7IE/DSTpghPFBvYyJbt7uGp2Wa4aoet6YpgEaZOR3+0P/h9T/+v7JG1jE98eGQwHBFHgIkPh/P/9Nfuh1XaOaPs1b1sVbhJAkGVLSEJ2sHGgSg9PHsrWbOYZoACcPDRPWImlAUEysvt9acJPrBWclfpE7/NBv+MOEpzxmcDSU2Kn0zolDz9qdQPRu7URCcgcFgU1kH9TsEqG0A+vqdDcARjjmWdHeoEABG92R/fRHA2QYPxEQaBw6Ln7EnXQRJecwoqKuEQ4RQFwcurOESP0Y6UyxQrkHPYOxnUnRO3Sny5/eFRnDxfOmz1j6lxT3PhR6/giVrk/X8i6Z7mX9WqcT+XLlSi0CvE5V2wFsmZalpA0GS/DGIsaLfJSSHVJwvhwoWGk2Fh5AYvZYzTfJDATcyFA89Hpn05/JhTmWRFgc/AcOivCx5qnXsfN/Wnw/LzVIjtvVOybf5jXEJ8GU6ZSxaspbl39uqxEReusQuphPdQJ+WuffHSisitb7nKsJHFkXWEVUAFilW95ylC6ZSuqSEBKb2MgtbcJkLJWn2HVDntONpRRYuPhDmSP6I0Xv0Dqmbup0koMxJlf9rK5u9OznDL+frfp0cIYXierbZRIRHNRob/RoXxgfWrMerAWjweYhygGaNA5CBKEZF+O3N0PhEwC+HcpWcxi4mZ6OCkj0whUuqlkuzWn01t3fazc3sypcatRPk6USSxDPTWnUoLsNmIez8g8lSNdLgWFhalNIR2ztKkT3iu6gKfva/WZ8vrF8K5bbjrbvDw7umlxjxelC+weBAkFukDpUS5CA/rtP1BIO9gQlL+Mi/+x070ci1PWxSrD0i1qkYpYCoVFSiJhxGrmI8xYBtKXnnzKm3QVKY/TkabUpCxFyU16biY5F3Mx8YnM6QTlWA5lT7zjmu2xj2VMwww9lKiHELlgEOIIQP94tg33Ldji2nzfq+b949nhjSY+0JpsHxdrcbFj/Al72qMWW+jYOC2G7jfMYosd40Oc2uTYIq05WgyxGuIQlb899yerBd+5UOG+1ZPuQ60AA7n/aynorvvS7686QB/ehN04WN9o+vbXJNuZ+upY3n9XCv3YfdzwgdnoaKLScC12Hwi/AC/91ObwQvn33aZv38qxVwoXfjR071rHB9cujizmo/T4s5jU2gmAGRHdy1LConPH7smfnvqR9j7WPesakFAMWh45+iChDGg1foQuR1FecYCP6dYMTRBh5hztW7iM9d8qs8hSXAxl/rnN3Cy1Aa1FyTTbjyJW4Wbjng2XDsDip+QcNwGlVlJp5j/dxJd0SGrMCttnU/VWnBrfa2Rbi19YhXPT9e2OKGVbpqx3ZW7FmBYKOwV8hdrmcgMMeltqJjMPrhQfQMWS2GMGY2VGPA2+ofUzqzKKFWWIm3Am7yjP+4HC0ZUPDIv7JlP4ns6+vzc4wdZNdTuKRu7vj+t7snPVzPBlN0LRqTDVmndr7oqnuv8T6AmwkvLvPNUvPjRxBVDzf7mYb/Eb7uIOSu0Alv5PnlMoaOgY9DEZMMFmg8OIZGVjt1eWHPkKFCpSokKtJs1adPir35ARU0SYwSyWRA2GEJA4RECxmS5D5ixY2Y5iZefAcHLxYPG8fPwCouLyBoxYbwoPn4CImJScloGRiYubR1RMXklZRVPHkEpj8InJKepZtGpNU6hqumU7HpsrEIklUplc4+Lm7uHl7eOns1idSFYMNw7PW6JUBhC/lKDmA8ahIJZasWMfr6Bi+uV7W70q9SKUXGGQ4hKaArtmPWL5EMhltlruCS1KDuDw3FvATTxTcJmPmF2cMv9sFpMP4rg3y+kBWfsBYkNUt+llW5yU+1q83cwsmuFgV7K6Ec2Gk6JdQFJ/LxsjE2hR8OEQsKWwqe1iNKwotiD9JmLhNCKoBDRgspbCkA8HKsERkw0HOiPGgBpZzVzDh+ibEDnIAJ3ElwQkTbm5jUDbu1W3WHy2hAzpEuz278kxu7F2W3gsakKBuDKhstACZmJkeI+HAhkDcjK0skK781TKc8gU4LpAYyTtJMwp+gR38BCRAKtsd1EpArpQxXfoBQLmISPBDYkCMRKlyMXOQRFqxgiqWa4aQqnJyXuuALOKq/AmowBgqE8TI4XJG9MiMjYFSm0OBw+gFg9kUWiqU+opaR0JS+cZfLFkyMwrxk8bLPW3Ujso4b3S67t4m1bds1Q3jFI5Xcuj49dBV89Gdq15+PeinutZraymuj0aHtWN8SG/TQn4vtC8aaHX70HBl5d+Sn5/knEp7HrjLbfpgW3+vn7dgQHGIJUbgAs66PqbGBhOAmogoiatSUsb8LSCKQFwL/+qAP0KBHu/D/jguKhNBeqJ1hj7Om21cWrotSrQUDkoeAbm+nq4SUpswhOWgBxJ1QmKhJLcSCsuAA/H8gfii+OFCT37Mzpna2xjfs6Nwwgt5KgGH1zQCDQCCa8vT0WQgpTIt1O25YuLUFtTcAhlWXGeMcjNSp+gJPbj5hAK+mTEBLBo/CzwSxY2AJ4amSBQIBZF+ojGhlZjmY9IaExuW9dXmgvxMEgYWAvgGYHK0qJ1I/7FeTTTfpITbldQvDGDeqTKYctd9ckWG5CeujBWD3jKyfUkWe3gCX14FQN8VJ762DrAGE+xO1MZeyksL+COdsOZyeJep0P37M0rJo3O6gTljNeD3CZdKEaKC/zsUOCBXrvOu8jW//HP81yd6wqtxUopVpOZkzzjFrQ0BUHzSb1mRn9XhvjMP/r0O5UuleS/rgFuskpd0UMviZmdoAce/NQYo/0qlzi1eaDGR4EDWrJ6xvd2HqNZETDKBy73e56ojUHUUyK3e3cPBit+rxRIXYLXWlDSdYkG2COfH+N74lixYceBExduPHjJkiNPYdB7Zj1/v4Obj19AUFROfvj75z7SqcsLL73x1Y9hcIsPxDW+9TmHO8KRjnJMB37VDqBxWappv5u/FHW2Bxp85d3gJkwD+bN2GX/+ru3zcZ/wSQc40EE+83m6I4erUO5CxmrfWuPP3fgoUEKkgZSzav2dBTsuvOThKVOlDvy5vH+ODSce/BQRqFCj+Xp5ZKiIvF65k+krIl5d4dnd0VQRliSrDBXB+NxpZXCJfq3SB368xufq7gL4zvzelEvBWb+ykPfJWd+LBlPgn35ZJu/dIb8VhWHw+tUoNlCsNPILtQkOgqAiyEIkVhAfKEPppIj4c6DcYD8/8+UHcnfyQHJSIicxO9Eb1lRvxk7a1wepGiq1ziY5HPf7rFWNkQmtE+rnI0HEOalxAAkskoYudThUDgYvMKRHtzpF0vgzBgprU3s0Se9lwdWffMRHfWyeMaxFVdDys78Po6u6fpf57iHOm+8M9Zl8GzSK9LDG3HtUx04SHAMaju7XqqOccqR/HOEnh/vc52zxWct8xmyfludTxjvMMIfq7xC9HexWB8lyoHQHqOqTYuETAHqp2Yl8jNLH1W8AXfx+/pB8Mpe+DoWEVkPTocFQJiiPzwYEgROB+cBooDuQHH8REBrbihFFeMjs1dUax419mM5pUz0GVtiFq9mIkAKC2pgKGJqMgm37bb6m4uYemYkNyrDfRiY3u6nc76Cda5bujeiK3AvXOyuw/et2rSRosDCR82KrYygmfpFB3CKSWP4GRyciKzkxHJ7W5zJReDG6brSDa+kkMueKkY7r+iKKUY717ZsQPDr72zNf4vs8h+KZEslCOCnoIvPSPvnyRZ/NnClqoVPB2YV1frnTX0mZl1YhKrhQqApUAYWC1Al1vNBJ5a/81GEWpA6hd3VaiLkmbk2iiUxLqlUjAbr8ODq/wmKdvt7V3INuNM6+t3CV+M9YkDFdYxyMCtsVvcuI183uUoRSuUu/qfxsUH+n8rIB/a3KlXimTx978cahwajF6i5eHSlWyeVHMsPwG/trVQ1K1HYRmfJQpjAKosqjCM/SmBWsDxbvj4TE7EDIlL+EndJeW4PlU8w6tyJ9gh7vg2KibVkcQhKKvjvBaFu6P19SakiizPBJ2mlHTaTbh0jzrw3BhkzYz+mjrZgZxcoBm6sxur6vFIOGc0EqYtwtr4+3NIrTD+ny/hj+N2/BktUgKMxrDCZLYNY3qdkJ2TFpMTQkBWEgWXLktVu0CsOwDIxLLnx7SrQv1R+HZdS4OctJQ1jIiLH9XiG1Au9gG7SmUiXErjE4QGi6c7ypJISCmAyw2DIys9hEYtpBpuWCsbBstiS5/KLy96ONIVPWkoFw8JSYYLNmxwAXkpK2xj1ScoY80nJKGlpEZs1bsJZClKjR2pE9JheDDqfi89LHhsI0aKKg0sNgaSsCyYbGCVtrBxUDu7iMDUdERlbX0rhoMX5/UlpptzU6TyyLxlD+a1EB6CQyLTpo9Bmy4SAiadCY6+iZefldhMUkpeQVVNVNQsBiMCFi5AyzD89GnnMFZVPpFClTt2mQfnsr3gKyuvUYNmKdG1iFRTr422bVtXT0RJVV9EPCSin3czHr5SMdo7LmZNG2lJbwtNEH9Zm7+eUUXD9uP6ntwC8kodhm7AGZi3Nap6Qki2DPlSKjw/rdSqoaukapXCfd5lmU6C6Kny+pEP0GPO9IN9vYJjZF6AIKPttBmh32ydNai1asOrjHOH2WAne3Ueyuxs7rglpH+3QXRjtT/M5F2kyXHgt2MEYmBMot+MpUqdesPa41rFOosRT37k7SGTNjyYaj/YpVq9XWKjLH/xT7tl46NqEzZSVTthwCpWou5cGRTuhqgX5KMR/nJpURFnO2DEh7latUp2He9kXrLyhaHDe8xPXOhpuUuUN1J3s3TvdS1PrAmIGI2+B6x6ixddONTZI6+7ro6/YHPiSw+SFlf2zffd90H0Yv7kXvHdqz3lPdg1F/Vte6uOPvLu7IJ+anYNqO+XFgWFZuJacs8VF1pKoUrTA5y144+rxR4aJoeSmBi3C3/nl10aPPaQOldTskYXg4aK3S0dpKwrggpw/YgMgGZ3zWzf6ebfT0rrKlrqJkYKlknJI96e3i5KIiIV7XleRxJndoUzhgGsOyLkysDVX+KNrzgv3OsdMfrDXHajNJldFUg2O7oIFuoyuVtZJsvRabit/jPbK8d7NxvmzYLtbNh7XbyYp5/8hiBM/d16SKAF+mVDyXJYpW0CcjJoBFs8DBWAznRDFPxhHenxUvzCu2zJMJHnCHa+6iLMzZzzFWbge3bd8o29bJ0tmzZHbMny1zZsO0WR5PnZvGySs6WwzbMrYAmQOhWX/fQYhqudLwXBRrRF5OQgjPycoEoWGMgTYT8WbA29OLt0bXYBZJ88zFBpjJVDaMzZDF048F2yxVm+Q5lhnZvDGzmTDG2DRkuh+EYKyccWt56tXgR4tN0+EX1UZogyIt00Q2CppGYvY0ullTWyI2vqSOQA7GqsC0ToUIRCgb4W+ggoofPun21H0t6lT4vzQp5cPB7JlSbB3+AQXIQRY4k4k1w9YApIERGiAJCRNn0cRi4ZD2AiGoHgxsprdRFe3WTLG/SzR52ylQ1eFbPzEIalxbZl1LWUU7Fplu4kryYhKyqk9W9sby/iOnP1odv+O3/FetwUwgCqaCcW+ULCNdM8PekIwGyez4R/1vY52JV4+1ugaJcR79+itecvEpnJmtpsqPYNvo1Fm5+BJf4DP8VK9Q9Oi7RPsaTX0BfM4+6aau9w7Uftvsfev7a+x92/VaVDWfGwre8ultJry2V5HtpSF4oU5ye95lePqU7VF5okJH5eMlPNQDy3WfFvfQgTZrjfpayIv2fvGLDqrtECpMNCQEOJIQBwC8gRAj/ujxyRtdHuvQpEaZIrnS3ZTsonhjBvVIifBxs1cOzNNKa8SK+Cg+H5YZ79dcNahXnWzVCka1KqxXWUAJBCpwAHmWHUtLV2J3ksLS8tuNH0oN3dyiJhAcgGrYjguq6UkrVdWaq7TixspKdx1U4USo/GwpW262CHIIlXVgAVbGBI1bnsGrjSA5IH+k51S6oRDXcU0pegoe49O6q8vNZonxUskEuAqurtikS3WKi7iAJDvPjBLm02/TleLLEWexf8YKRH2+eafLQy1qlOC7ugWSgY5pobMd58UO80JHY3uzfsxRjGqkGlHAIAbQhx51u4iMpWITjHqGyRMInPAO47uVcMjyNxJAD3vBcha2rIUtYXQZ63r5HMEXgQi0O1LBSEQYIQtuSmCg3wboD9AXoHfWPPDgjH1Z3J/gkTstF0XTOVsGBrQ5xgthh01WTlAPZc1CFJpjBySrvEnMEss0yahDuK8fWQlG+uEmqIWXfiQgxgpUSKH01QRYUB1J5460hkjTZlL1P0glAVNmXIViavB8k2g8lPAhAYu66NWhpNmew6HgFEsYiCJsAq3U6fZHkypZkqhVCG1QQIamNJoG6lCFMgimFIvD65JiAzUVViJ1CqfmVFrEmsRFWSP7VSUbJcMvaWZICc0mSTtNIku7PTWmf/T43Ts0qFKiQLY016/mfLoJK+Nd1SC2+Kvb5NKyi6qDxWB+mQgCYfC/N7VZZnIKRrxhFhtaznflhhzM8m8kTRogljwYMkpDbIkomAIrc7vUJppy1H8k3h2XE+rrX7UxyAVgTFYpO4YtFWFMo9tuo3rgAR1PPEHTrdsmn3xC/w7pr5/OIXczrn0JH23SgWtiCcoSCyQjxCLAZP3nOelJMQpyIlhWBipvlYCGqRhaJTIiwUfDgCT5WakJ72DfLiXAiQQzRkeCh4Hg62ik5EQ4JIS8KPcrL6XLF+tJSoiLiYoICwkK8PPx8nBz2Cwmg06jUsgkIgGPw2LQKCQCDoNCwCAgwL8/v358+/Lpw7s3r148e/Lowb07t25cu5Idb7jumquuuOySi3HhFoyFVFYAGmyxzHaUOq7smrjLahZoAKJgDNHGT3oHtefqUJ1KlKtUcRWvswrQIfl85uMiSwxRRBRO4uADRBjR54tuj7WoUiTT9c+KjFNR6xFCCCGEEEIIIYQQQgghhBBCCCGEEEIIydGy1NeeNvD211noio1JCTBwEGlBdlpilEEZIW4WCAVdZARYCCYSvIMQQ3755KWHmlQokI4nSaQ+CT7fRCMYM2rEsIIhgwbk9evTq0e33bIy0lKSEuJioiLCQoIC/Hy8eByWp90vXJwYHNAqIn32JTrB99C8lFkHlau2FIW0h5KDvOW1/iIOalgYhuaNSfCQYNL8zOQYg1J87AwU6NTJEQfLpvT7pttDjj02WcFSb9t8b0iHZq2/IHa3zVZbbLbJRhust85aa6y2ykorLLfMUkssVuBdiyy0wHz55plrjtlmmWmG6eDujsFPddXMVs4a5jVlKc/Z18jXiFdI/FpHhMCaKE5DXq6nUPJ3gwj9VAe7una0myGt95c3o+O6OVfRViSYMToSPMwNtDaHtbr/RZ9ePbp1pTjbOdVKKm1Um79SkbDlDmSvZr8z5wR9ZV/Xs41UTyLJkS9087vLjwZ2oOuVyQGOAmn/NeJWxJEz1GeuApwDALrT7YDvoeLv84FZhMAWIEWX8tzniwbgIvEeAiWFkkbJLoVFW8xltNhry9qxXJb7OrCOrtAVtk5fdZEeTnyc2J72xtxAyetCKDEUBiWDkl+Ki74MlsmyXNuWUyn3XYfWsYrOKeq5/98Br4rv8Orja8/CEcBrx+Ek4HXVvPCFcQvE+cIf2/tFb/L/ff3RCTRTYXcxY6Di8lJbWXjNx9SvjJs0H/93OXVGcqu7t1lnjcXwlBAoI1JB/s4E0ZqfEGceLoLUpOB5nRyv9fq95t32j7/3f/nr89ud9D7/HDNtU72Xfr2C7AmGA4Lit4vNpIQCseZ457BZvzM5Ji+SLkwjpuKt1U7KZufEfDLmK6pa/KHCxZ5qwkmy6upCXfjoYbTjfJFOIRdys6KsdojhuMQ8HFOZpddAP5LiBENGi65lIlIDRIcNemxEfy9MnOjr/JgOfflUwyFOO+Lk6dJhAS2yBNuUsUFQBAzlmDEOJco8McdaXyujYh4Qktdn5JtMSHsBIadMp6EU4SP4EbMyE0JslLADLohTrcopcMhnn31yzdciZDCrNlByEXOAkVBVPYWrV064RVEEvatcxchzkJ9zhCorSwJTBBgtBQ19hlOPlOQ165PcyHgNyNS7BuQIfJqgU0V+ZCF+/xyz78mrTa+s6Gpl6/O7Rt+MEdSqV7VSevOVSbFlV1pJWLsqjNkpt+sZ01ZJx4sY1VVnW6HDCAmQSclISVvnxE08lwva3qZPLthPdcokNZW9KS5MU2Hy47mJWWrAREBHStIyYxPZiQ26pkmOaOqkJduGtF+UxhiH6cA40uTqdUb9TdRI2KoWluw12u0Jx/2KLrcl1La9Y4MxJqgAY6kYqWjZ9WycC/rebkR+EpIBvNrY5gQcRksmZmzqF1M0C2OaRmFMfr42MU25BVME2mJKYrqmaCs2DvoE02MWTI6kkMElzBb4YFUfnCo5k0SZ5XVc0I3qMIAeFlSeIqtTp+dCfaRYd6qzA0ka4Db03jgnMwcFxzQqvGSZUfW9oJl1OstrpDsv1guN3NO3cqa9p9uop68a6jfwHv9+9aI+9E/1C9qrJOSgzG6V7FQMpVlVtuqOU6/BccUj56PCoo/tp9/0VzflTjkG9vJJZWhkqDP9MnYbr5WwmRipV3XARfvc1iWnRmZaT7Wb6rPOt0e9cWdudH072Y44AVIjqU7cKuIiMjIr6s2+ffrsLUecR0PtkGmkTerrx5Pb8MedO3OIJnSDI6pAE0aa0Dbcox6p+hwdrdN3zhIuEzaGduoeMy6VbXTxXDijb2TsWxnYgf00cjvvMeQF7prujtd661a7VWX5tqdJgQxoqlSqqX3iJ+WjkUd9cA/KJ/WUM07bXPDCIbeWI754vONn5VfHFTc80H7hn8qf/MMxJRdKtsAOeAIv4En4rMKPTtgzwpFvhV1l5njw+DHkK3xLuYHlI5t6Ra3Zbt6WlaUQC+BKjZSsbgpF5zrW66EwgY7AFGQTAY4I0AL1Hvm5F2MK9ZgBSwWuiQyYAd/wp8MARA8A1oBsBdJW4BV4VaAHh7UHTD3gRFmr7FT+kqOTvi/jQLo+pWYgDQNphoD0VQFph4AMIbKJVWQaiJxiJ9IyRqTmW7mx0gydTLyCDH1PzoG0ItbzWtG7X/UrVe8T3j6/3+j3315+/qXvH/f4hlvgo9wYOet//+mdGx/tu/fbwLKt0avtWXeyk5Vu7KQ1qU6Vk5KRSUkn54HVBUJdIYyafjDzo6DvByM/1Csv0MyLAq15gSY5BP0cNCjmECQ5BPMcgivPQOqeb0Mp+RqUELhSLhcEj9RnRkdap9Mw4SjehItwb+2Yx8idii9F3YWzkKmPoY97H0MCYxhZwreSwr5HQ7o1vD2XMeexkVny10XnlqzmGcW8YTrUr8d6jVnGIvs9trhccDW6f55M7X2tUi4n5XK1Vqu7phh5tankOjX6ALzMzS9q+D8doV1ej3uBwGe4uQY0iQT3HqK7QpPnAdMZNeoQCxIeEQjnYOd0Ly6hGOdC5hCdI49Ab5oJWpJjYrKcrFJ4JfoX/RG6yBIEtMA6T8+dJ1DWgxinDEVUgIAsplH7vdBEgH5bGk0XqPSW8cxtgU6u/N5h/CLwJkg9xHGwsqQ23KlH5/0y6SpgIHL/BEBmQy1/ko0sNBlkfAnG8ZRANkJOGOrywp9dRxmdIuB17Btl8CZjvGRB8Ci9oPV2POEomUeGET1sWrIXYv8YC8JbvM7owTMtMA8TK6ydj6OMqrwKP/YpqVNj8HA75AFQtEGGsSJJYCYBDX3DKIN/TZGy3jvAwZmfSGeck0qDWlNSV4RKht77fh5rPL31XvKMvbDJhBIEW4ttXMIippnGrFxAlsPFkm/K6UvUToHZv2Qwk2X3+jbJYEKl4VRUB+Ut/Xrug19E7YY8iRJS2Zz0PimW7rZzb9MtAeFt9e/ILqRM3kQNOwLCtKiL6PKmK/rvSZisrjtvsth37R2aGqJTfbYRr/7cckwaHzWUVoCr/G/ws0URJlZLilKu2DezCBw0rOZ+mpnVOYc+sunUtWrazyqjiE4QmrypRZNIjs3MIZUpiq7pPPcFr56RuRl0V+OtDMtJFzNbQz8sJjHQ71r9ZkHEiMb4kKSIX1/zAC8qXEybZsVMFsOTcYggnY9ng6Y/jF8dost7riF2Q1VDWLq7KqU//5DjIMioRqgQGxdEBpd9d1xxFyN04J9SbblkxCLIAN7kv/dT9feX0H1+ekQB0MhaXYycQfYxqleIRqqS2KoT/6pStxmmpE515ugNz1xCDeN4ynsFvYS24LfaOMkHM5DItCpAB3oSM9IF7TT79T6KLz7KbEXL7k6BUJ1PtnQk61wA8BwDE5Esmyk/pGk7xAwzkdULiCmZZpQpvieE/kI2wsRpzHElxe1jby/76f3ZWLByKn0K9F0XCZhJAfPnmCfyKpR+R0hBbUonjPNpuLf8z3c4AUvT3jRppu2QsdTjO0iSqRnoH/X7U0QDzQVwKfc3AkW4GajgBUuCjOoRKuw1nIDN/zssBQG22KrtXNfA0LPedL2dx0tcMLWbWopApPpLRuz+YkFpOtZNRy2wY5PDWkpK0yfyMK+KhOlVhGLOy10+k8v+DGRRN8RQip0TCvmvB1jhk+hb6f7lNaU2D+TFr2TW8rjpM/fLohz/JU+l1oVIV44K2iwzb1RlBjndFm987hhUG8fNCUun6xWa/h9yTCiy0bMPoatmKE7bLSqHeT2e0A5UY0NC9RHq1jO37IDhUjmmeHV052eQsD5C5Xsr80g7zLB1pwIRLCr5XxGYfGA2D3eFbzRZv1kEkPFPMlZ0dxgJ1pDZbRlLx1lWROxHKO6HCp/MjRuGtV7lJBfbniGouZQ1BeZhmicpH3DLL5FVdd5eQgEuGwMYwqfrqIAR0VcZGe5pzlBTi1W4hAnnhZYAg6vHKBA8U3EDGV1XAfGRbC6qcKgxWe042ogsbKx3W0roopYxxrQM0ArAsCwuSF4+SCq/zxJ9gIFsoXTu/DeRAmrax6g01FDLpPTZwbPtY0HMTiJfL8kngWhtddFYCt1pXJHGqtu5DrENaqwttMGXW2aFC/z1337jgZhxcev93AVHdhoWrrfYs+dtTr3W62au4qWFhft39FXBXHu1XWJETD8bw+Oiv+ntYvHJW4nuV6qh4aAj9f1JeLJlN2STDqiRPPvmJZNo8rtY+pqaq82gmWSjyXwr5s/4ndWzt9arzOaVcIKuav2KzB3n723XPEfIiTWIvjc/ydidmEmi47aAjYYrDW7KIkrS/o/w6WzaPPcUmsp/M9y/655vNdczIZe/DZvDpf+G4p+amCz13HkJsYNHrEASzBD0Xczor7Cduzl5mCtEiGNnm3MPgteOZfRcI/u2YjNJvD1y9HgLHxQ5hQQCC5Ojx/CJ3iEyTh6v4eKEi3rZSdZ30InBco65htFpACH72ASDCPgXM5BYCks7uMZVI9uvaUf5FDA4rl8Bwl2EdwFsyABjGb0KoTHIGIBMCvUPrGSXWLn+pKc63jxE6HmWIw0dj8O0Ofd7d+EGyIYMOUZOTHeIdF0d4Xz6mDb/mXmE9mEbT3gfvWDvCy7neiCXm1PsTtBeCHQ0zll7C7KTV7o5YcDNsYEk/3rG9aaoiAi+faNgus0cpJ2MIwGJ8zu+ooB16HwmaxraZ4jFIekTFOfkib8/wtR4Rk840cDBpV4eKUeS/0e3LVRHIzIcfe3/ex7L4PkTtWGwwTYVP2mutnhrYwKv0aplQKSbhWQfFNVD/198TgiCgdGb93Dy7AiOkt8vqgETyg+SXrGFIQgGSpH4MueEgAdL8oKyxi586DZvCLy3ekGjHccu1twe0+DAc1p7+X/TwcnTEzw9d0YIvAGUIG3bgLGljyBfS1+qBdCymbZX4moeDKbUv5XwGma9Kqu2VQd9pYOsApq16japiZ/k5wSUlzXqFUsSByQQ5wAdKH3Vs2cBjwEHvNaLkqZfOfg5n4k9x2PZWhcubL77ZRK2c9//do7tFMQ1NdJOmsOGmJvmt03736dBXd/hmCBSKUeL/K3fLZrKau+g9it9C24FkjRBWSmLNa1VTfV7J5g0eAJtlRF2FWuQEiaVIbYjrnkfkJ6u1A8QoeW1c87tfAWlwERqrJWAg4a6uPxrAspqthe/wRFAlLo/KLaJ7uJJ9FQEYl6VCoEDRWwO6RO4BDYA1pgZ8concULM+sBBQzmu9OV1JaoyYYRMhZC37YFH8D5liXbz/E8r+nUOaMc/X0FKUWfIEXsbh8RsizfL6Q9mEnB+Ve7owRHRbGnya+Y4TuPpMY1d40qDCtpssZXw3mq/J3S5whT4feIUYOZonbUqI1rgaCQiXLAew1ZpmCJPUL5P54Y3CuOSWJYa2afm/KCSlh4WIWmw8c8Ktn0T4G0W2WO+Huqtk+/bV59yp1+dW4HKPGPr+fWKDqezcQXdo8cnsbEzVB3DDhoTFMHKtM+Us2MqmbUhJj1YGn3LiNXXucFQtUtMuQ5EUsfYIEebbY0l0397kY/jPJGaDQ/DjQSRU2A0NA1GsOV9oGyP5MjYUAxvRRPGeiV5C1GMQxsV83Zh05hZwxuHFytMvynRagQyKEgX1Q27VKJRqTeG2EfZLgHZ0+9PNXSCM/vLFa0qFqp2KZsj8AB/gu3xhErrMW5IGEiz7GQbszjKf7Sd6Y2rju16rfWoycZmT9IkJutwA8xFckMcLFWlwkAPe1sEE+vMCq/CbmFoxAK1aOpQ7lmlzmCqyXEtnV5SWYHeonBfDCDKJltx/SJ03BTvvHcoSKoDmwuWLhTNUzPlXAU+haCJVsNlzyB4SHyKQj422OxXVIYgzlaCNKVz3D7/tIFZLX7ry06TULaDJ1wCsnsJWk+2FckrVjGQ2FLkANECgK5E90uV0HnIV68L6KSDYooYQEG5Fl/yDBzQMNNC7R4EmsCFwKj+aTRkVSiZEFBS1OVShpSKHDdlGDnyrvtjvYcGNB0Wbqi8/KDz7aifnwydWg4efRa1umaZB0feHNLyxOh/Q+FYw1q+F902UQB2Eq2BXKbSsn+VBsbUv3cAW4EpuIjwJkekAY3FooMY3ZskVkVuNPdDzz2nPhpvFAOptzdVPksFIaio0jdajp0Uy+EOkBJ5RObHQT/MBLbFns1kK4Pn9SC95nIBngV3rBxCpSBWoxuPmhK6g1Oo7aaRMBoXkMNHD6IjuJ8dPHf1LIe+ooUGxnFILQN7Iie3a6ip8baihsojGmxaIHW1OG03v9+YmsBYGq2S115DAzdHziUjLgtTQ0uvlAk3rPyzYEfnBE/m5vlVKlWuxZzmW69zud1wvEyUUcs+UIULFVuB9OKJ3uq9Ilz542PMA5AViJoinSWNkXboHoaU0FWRkYBBU/uEOsDQoTLD7dhP6f40k2fV3kPmyFBOxNnr9T92HMhWaT8CF6zILRYjP+5eJ4OyftzEjmZjvm4d3gKfxW2NtULUsFjn6uVgevlUhFyKdUCCKugbH4eMkYqGMD7Wefq1yDk5zoyF+xuYWLMtzhV3V9hLEzRS4WldM9Ne7qwT1D7MpNvsJ2+kfMYa4/xUkRYZ16XVSeEe8LKbUFN98dUpfsxijNj5Wb6jnAKESFrNFcOwB1IN4+7U7bSAVQtpOwfiaIEb63K1AMZWQ8ly8fHosU8lXDY2jH/ywoAG2GzArCkWnl1gcRYbMumEaZCVcoHsC9eO5uy4HcK8sse4G5l+C6+KKjJuNOYS71mVQZg3xKZ2nvkHMBa69i0P3bo1cbNayKuC/y6Ek9ON7zPjQ1/SuyA2OQ2J0fA2EGQwuVvvjMv4DDSB6aTzsZzbNZoHouyVjtqIfNOAqX4wn7OYdCyPnTIp5G8glRe8q5Rklxdsilmbj2V+LL+6YAMoLmN7QBhI49bYTBD9+KH9DPorrgBAUKrJrdi1KeNg17g0rJGYK+HwgmjrVjgfnjqsF/Ti2dNoecQ9gwSNFxrOD/BY+FkRhuO2/4EfuNU96au4V2M3jmVV7c4YWat0NNXeNHncl8NkiwUKM4EmyWK5DCKo2dXhmwrc90rVGLaFVXMkqeP+plbp8DNLSVjkx1yLHrJVv9DLVfpW3olOgU80lwgvA2egenJB55ptb+R5lJ1QzfERuFmt42pocrAQ2vSl3Lq6Z2eKOlurNLgCkCdz3T1Js/uaN8HFCumsZtLLeULANhCQ7q4af0Li2yRvEwCodEoba9GfRttUWJJK3XtgY+qymiszQyeROdnDejhSaHMlHtgp7YwgFomiLGoULQ2C7Tai0ApJWhrXAhOJ/t3GIdbrCTjjMEmB5jpaTeJc52xNiEQDSm+8zsPXkqCBwMAYjZhkRSV6TZbcBiPR0WhRle6eeCQxr0mmaK6U41H2DH/w+iPV3pAQkkU4x+6LDDO7fNB6sKJ7A7QnStFXt9/l87IYhxYQCtrDLYoVOXyQ84JSdAo2iTr0UPehzHDhFF0enkNFPhuXFpxHUBmwQ82TTigNlKV5J6oza7uPVzq4mbFez0B8yoeYRELCbRF62/FSyv6AncC8AlXJyAPlo5h2nr36pzKqm2W+RrfVfKvkQO47KRj99Uf/c4YNphB1lSb6gj7ociXdasKDvNgofdZeW66tGQSwzw26yF1taEk46sw367Ycy7n2Ag5+FN2JByRpH0YiYYkjPtfi0BSW1GRRJMpQVOWEW3GJrrIHxyJYQ9s4cXVPea34BnTs8wGsMEd3tWFxu6b1B1cBJzyjb9EDSgnwzKSSAwixbedmkKJ3dC6z8+TbPJTdXLaXOgC1cBUoP8Ijg3uOwdgpbE7eUE2xTJSYwAyTJQIX1juvPoQDRVHf0PVERLQaBMbyIdj3Q142Xn4apzZ/LDO0sNqAGH2gZC1qUmsTAvxBiD/xjBhaTidk17giLCmm4HAyyT4BpQs8HiKODb+DpUznaWaGwM/6oO8DZvvCQdsAJOIZSPU8fcaHygRMuf85QcWf9Im8SgJneIDR5dEnbTrSpNpMR3LC+dc66UiwnFGahpIPl8PV6SZHLrq2qydnaYbgsLKs12JqxlATttCPSV5kj+5HdxNGsJxe4JkujgfHhUaMpuY3XijO2xAla14ojy02z/90erwiWpPpWQ028+ME9Vc+VSt5gKW5qxTM5TQJBCdXMWTM3cWwVDeOrTh4zf6ybDjUoFJPrgD5+kOYhEnT2jGZJgebbBM/KUYZwRrqwiqknV22gWhWnukZQxrFYMNoeUPbESZvQrcmVDA9D+wMeqnjEEqwmtIiaka50zHj5e6oviDdP9QueziYFC2Icno3IA6xxtO25p/tSLLINIZqD2GGd7Iob9LFJbMCl6Ea5A2DB6lQgvg4A0XPDMmRMOEG2C0uyx4njHZUKNwKDogiQa+OL0bOs0TimJ3WF8hTy9TxjfMwDuJF4BfuBySWRvXyszYkEp3jOSK31E35aJO116HT+EOZzukkDQk3OzZbhIqkpb9AsPxYZ2P1/8nKtd9ByVARSj5ZzoG+gIyhLGSrJDxDSvcITeCEsy8xYpDJwVVEU3tEVpUQ0fakdA5KtrVmVqYDzPx+yuOGB6ZRdknzZ46H/IZoC1YDx2NEKv3obBBKPqfi8JeKmPOytWHZ4mX6ARwNKFkCpCZc10YpCrXlpGX98OpGBRIWLpi7cSC43nK8U2cmXA9sUe5ojKR4famvhxtQ9gZ7y10m7MVWaLEvPXsZloTJXlEBI0Zt7HkiT08jRKEI3nJX5Vy8XE7zlQ2GCqEPJRlOfV0aSoSm15wvKTN9WzeLH0CJPhiIFxsDOfggymBTSWr1livPfzI0VEfKYkQKu+uULQKKIpKilDJctBEgMjHX77sLLH8HKHzioXor5iZzGKxqAe64EhDfnjQpvx31vgi7WImmLie+DY9kzMkAtJd6rgJhPS522HfRI4t/w+VHFe7Ak+6vQcflP2DUQgztDD6NWnnQVU1OV3ugMlQSxaWFcXtgAhVeUyTuxszxt5LDotbcF/7X+6khBgiPi4T4jXA+hY4g4h96y3tfFZiF6SanjSNwqda5DhwMDO1HZjiDIx+Ev7ilBMXVZkgtMucTNpX5T1rvORxKA9wYpmit2wNo94o20LBc/wMBE7s/zJAU+qicVySycZSArmaIi6O0cFEN1FAMtXjIKDGUUTCP0aKXB7ddoB2yIuwpzIC/QlbutpbVHuvMyCj6MUHAmD0LS8P4kuhNV7+iV3LQQLxHVJLK7CJn1/IdOOjZhp9bcRha0Gx5P+JBQRwMZznwumc1WHexr+BtLSot8Q/PoiULiZiiIv5kSDdKtTDckAcjR/3i+MFmTwadmlX0vOFk/AiVzbuegEAaUGCiskWn1IoJ9V5ZKGm2EGXPM5VCtobRbblyzghUfkATr00KIoaxnEZYzcGbTGxlWyB8y66e7DeaCxva9lkhN9865QBT9q9amkrAVIK9anw47LKXrBylaVo4NFAXiNaNXqpx/xaJlYdlppwU1LWcCAeKtI6fvtp1D31e33PVngUhRaISfhmYYsF60vISLhJYqmUOYQoMKKI2zkxMmrp1M2gE3j6BVA+KMvsOnmH4O4GImM2tf7m4FJV0JNLuksuVgyHAWAff6ZT+176iPfCYSR3tHiF/hZpk99y2m5jXWuvGnWMLxHIz1jnu1p3LFGfis26ykNjw1dVINaqbZde/jt7Bw83uL2J0KiJs/ReDrrHDUbCLeMsDO0+nskOHow0sosTAx+bf+Wj5S3tMH3WMM5Zp1Y3rLJOt6xF6qAJdkozS6/kN29cUb0bsdRsUfe2tNapDx8/RVnoVV4TjPClVW4vnUhe60PCFFjQNrlt6WXNzPvUULnOu9Kc6cXVgYxNh0bBLiRuAy3qSpbvD7L6VuLWr4W2mOtS2zTsFVc6lwpPyThd8sUr0K8J1/oD14vvGg+Z1V5O5bDG6PZwjJCQboE6mtkj63JeGGKnoQ+7c5JcBov1xbXJXuWBvauYQCmqCZgDcAS1mL7QRMTVGGQYX2sAVeQ7404kuzW2PS5hYdSqiQpIdeS7vBr9q063DWhsVzBSZ19lPeNDLwlZtXIdlSPtbWhRl3+XQuNty3kBTW9vShIG7Wc3mWRSYSnPZDGGMrKB7mvFO06BNHaZiHg+hMUBbP5sLm6TWr0+jJFzqohZx2H9HeQCezauo4G+P+lCyyJwV62kop09j1NNI+0+/DrAiBBDTmGqFCCSa+hpq2+uYbK6HmZuC40hgglFmI6HS12Gfdqnqy+4lmaG3/b/v6WGq72lRCzOap2yGdqMpFTMPJ8VTNGQWrh5KQK+UN9BaDCKBuTShJ+QbLvxJrxn6b0JDxDML+sBg4wy4k6q9LAcQHTq2PN3qpgMD+Vi0dbiFcVkKNEcWQmmphoJX8I3NIG3VqVfmIqgoJMx40FBLsyYGZmXqJG3tCDMnpGXfKpYDRekT1ob8uwB/6rm9MA2fOOfanUir3HQpKpNBO5JpsJHRsou6KGg7VZ7RWCpDqhUc9iJpQNbOkgPB6pSHfcNSDsLO0vDFHfYDikJFiTkOCpgHZIVJrJVBH2b1A2EMKc0vmynSB4coOlpmScyAIl+c+Sa3RZxEsuvKDzcVPnSUoa3HHT+V8d5sQDJ7uqrwOp28Tlsm91J0XatvMEyzUWAOi/kdvnryNyZmUpC4RY0dwL5lu498arhjhzAI+KSWts1YzIe5pS77Ry9jZEHtNZqiWtDYJwx9T4kv8zkHk6nZ5ElWOx6B0pnpxwMOp01TeHbjmSUpsfXtQW9yueUt8P/0K8D27mQPMJ77g1mFRQFTUvbz5tekN7wFurI50iWTpXltr9l92y79WPZB79ec/IStvX7wLivPwt7G322fXmBrZRfvtv2G0DYc7w98+83oen5L/rwvC185sd7I1RnXz/mgzeRah8otbNFlA5rpe/R2k1pPVqBjmbK8xTHSq6O+Rd44XtbL9EQD8dX1bjsulYD1z/GgzqSV5VfK2IvpgTfRz0dAILK9xteRThpbuAf1mpW2vk10JXHG4SqrAtD/HQ+iqsD4iAxWSjqa4wKf20lerIokGiIuPO9mnKPtJfpCWxxPsqk5UpmGW7xhlrxajqX2V8HmirCflziBcuuSwTpWv5p877Mo0urJwy9i1B2PVj54doifSyDQRXv/YHd6o5X4vsy0Ko8hq4J57c+7Qcv0koqt/rFnWmn81FRj5S+tIbRXW7UNkbbPWAH/jA/Jwf2hk4ZrL/3AfSJi6iKO/d9Ojy3Y8aTCaf6N8cz96TX2hVP7dQoNPfyfvOGb9/+68yYMfx+LlO7iMA+ZX/eM44X9Bm2qt0P7pRFETCiO51ogcKCPAVMFvORsdobJgyFmmwd34iwvi4iwUIMUhoCMNwvSq+9WWTn4/zd78HdjN6uYe3W+90JaIqJU6KaBDi+G/rAHQZQqzf0CHKZICNnwc4yCAGffjjj3r3z+gEzb939S3Pc/UjNf+14OsR2//aIpkLPzUDejjdmObunF9WcDhpRUFdDFJAZEIf+cuPJe3Kw/mTZPm/LNYOHrESJEIYiqZZ6wAPL1RRm1lr4O98TaO0JEkpk6TIddA7nVuIKfXrzX1oS2d/LDTMAcDLr1dulfO+MoRIyQVhZvkRo7lSpTcZRMWtOEI5e7Fjpgw8kJ1NL2F2+0mM6/eqcf3U/u+Xtphkc3Ug9Z6O7zg3/9U9Pf4d6SWpNeFo0rjKY+FZTCEmo7pdUYCY0Cs2OSQKP6nVjPfijm81d/iX6RbYokfNkwV1VN37FIfCReRcg04ZfSIFk4LscBBBisv+mt/OF+e47MH10sLbSL3o5efpoX38D2sQxi9lwO2k28Sa34dWHmYtkkHGGla6z+kCNr1470ouYxLf+MJR/Hf/+2Ld7SXNFYL2iVOERtjqaG9e3LvYsdykurbFnc1KXbhr+xuUvr0Az2owPxP4Ie4dXZC+lhv+r/s7WPhwo/i67dz1vc6O3jXDqKPUhYCmltSp2Opxbziy1qr0ajt+nNFIMfzr+8cHjdljKqIhNRwCa3bW7Jl3qTtRDln/imtSGT24//th3RabNqShOXXE0APPftSy7oLHoyOTV/PYNwYbCRRNPda8Z6xie3VqPJRv550GUzjpS/ZjB005r8d6RFh95N7GI7KMB396WQfH+6WU+S89DmtYfheJSgvQSIDx1bkyTAOlX7L5qDKdR4Q7QIF9joOt9a614UW1YHwfg0o6ad343DmUl2YbbSwHVtDDCP3s/BRerxt14HE0WcduRQUh/Avb/9e3Zr2zQddpWqy65BU7psdE2uJziZawTFZ3ok4cw2Pa5HUmzIMxiUX4U3Xmhf7lzOBvxWcNPQpVTUZbP3+r3rJm9t9pjPRobZtFV6NrQl0DpngAnc8TLXkMdrz4QDdXmyTpxqF/8laWt3guZLf66yZzCTQHcA/+BiAcxrdLh2ZUtFY72wVWIXtjmaGvs6lo+fZ6HpVb9imzwwFwp19T+9pLprS1D7o7GVRhf57cHtr0ZIvaJKhjLlyoZiTob3G2VnpotfoQkKgydAN91t3fnK8rqzPmBNy5GJtH9+dpXGKpbVB07hhsw+7YHBOQuBvvEvW9609GrFqga4zihemlwNXnkrskKGe2K62A4r4Hv40uggWPzBna7zr7PtF92ZvPEB5c9vBa1CNZA/63yNbO8zJXffVKzL5rozjL/r81Toh3AfaOJmEUeihYIaacpAyFNBha7xSe77RSrSYoAtNrXBwEGq5FN6gRSGw2pZxmSUp6Mqvc4jzh57ztvx3bNfrkIb1IQb0zqsiMFmg4COWpDb0xQpt0m8aNH3lTT76I7Vpo3eGIk4eqr5W7GcUImllVNqJQFeohKbmpCnm03pUNxe4spxuS30BGQRS3RmrcyEqrRGgxyIsf2WwHZbuPhpLxeIuBeXpzxbGlraSltn6XnwCR/H9Hfe5mKx2ESI1xF2S/FSrcmAD/O/9HMEvWJfRrhHjv6uJ7MqYImzXWiTgKc8eH/ySPhLQc3iti5umPHa+wPp/i1aC05bbE41qD8Ilhg7lS1UL85Y0kZbrnsrtPvVL1sqWVqBZfdG8H8+geku3ZYTIG1IoOQhUTNF3Mc1uJpgK6nR0pjOCNhqS5uYrwFjvOQ/56w77J/ZTy/fN15WhBKuW/BztIQhPMTHeanHrxiBFnuqjTgsxgtE99S2Wr1OhbU2J2StV3YtkJOk8zmkYHB6zraMMSS9g6FIbiB0n35PnF4gDCvucb7lZmgCCnU5IJrfSoE5EeNcTj0laLte9deBAKbSSJGmrp8haPv8zbD67aDpvE0UA5mN+1+LLIjN42u6I0hEoGKc8ftIRAlidOthoxuRIrK9Klt7dSIaHEktcKlWr+OjoPqeju8igj6LNRiiEjZ0ZByhHWv1xkELQxSuSeEqM2vhDExP5tFGbpBXrGlT002Da2CbbRI2DVLJiQ0yl94Y/gO4tCzooyxBHylsp6xtIioYIMGvL+SSlureCEX+uj95BNW9qdfE1GJvUIzgHKpsKWqu+9hnXouttgrxmk2OoM/i36Sv5HZksta6eWpiY6qnPn4HnIDxw4VI6SxXzs2xeYH0QCScHvQvyvO7/+KOLRNZOrvaReB9zvvzhPEVjN3Kup2LXY0j1zaY1txc39o3YMN/hcSudv6d+VxZSXjckwbDGvdqTfj1zvaWji6TsFId1lZpxW6+U6n2CIWsKjGtMzYVWWUBvyYkUoaQEJj7dohpQigKkVJ6bRRKH5HlNYrhmEyVJK3G7KjMCifvhA2IW3RpEP2bj2G6W+/zSZbIpN8NEdQfiADFhVPRgN3h85ILFjvKmk4Gt/3SIneoUY1HoUMknWJKAqtYkZhX932FpGZP//obOmKmJkrdvg6VJixSeHV6lTcmgPX7isHxu9YP0aK/xVIEFov/koGHeR2mtd7IBCpzfVsrZ7Twyjtu3mlGlseEEE4I1HKzni/R6YJqaRIlZZmQQtd0mhOzWEVYUdhs0+DGANaVLR1kNEuTuU3lL7VQzide+ZXTnYjO4NCC1zzeNFN4dK2EoMf7tPoegoC7e7U4HJQ8cxrHe/x5GpxujOpotlIC+YMvws22FqHxadzpLQogI+ehfkZXeSBHHesL8LmkixsIez1e+WRb47HQalFWWcWEo2yEHU4TBzwu5p3iu8M7Xe1dFSogFVjdL4/7/YJ8FuRdsSfU4DwnGDWPzvFwRUcuA6vQv+V+L5mazcaY109vbXNvXcBySQau5q86JzjDPnnWvtStiHNyT5eQkYEj6Y1KMSruskqXJKtDmb5APDMSfVe7e4Bbxpv4Plehf+0IeJY3ZFRbhzhS2d+rt8/ZGTiWTXeZ9JBdtagZsYhf9ETERLnS+mztBv2zYDLlpTsk3Nbykq9w8vaaYv5ZQE8Z/XuK+kS/iKDHU1pltwlTZVIaDPaLb770A78tEe+ow5qKmutwvF2CehjM6GYM4PnwmEZhUkuUiLwi5RI19IWzQxOZx9dztEZScRtBclvcguUZqAKSBiISNFrIp3qvqyg3/yP/W13/AT3B6zANbrMzSNMzuKNmRgvvvuWWr/xMsisn6szCj7rsZI4AMhebxLSspzriJQaJ0Cqdn7Se69dng/HcaPQtAYd2md1hPnVOcJ4nvDgBLr4WNy37cNvj7ol8ZK65YAOJKIMIq1ZnssASVLyroFRti3Qh5pxamUAhWWie+OYQiEMthfQMmPjtE8fRn3yMXM0PuzFNKq3Sm7Okv5TSkWZ9WqVJYbgmk1LpiZTxeXyCa9haeRDs+fbXdDoEUzYIstr0kM2iK3rVytRBlA2GLBQEWS0QkIkPUDdTWNpKRuNNHdsjJRpEyK+O3PZVTojUEQ1YpJ2kUaT+Io+PK2XOQKdGzrZIrYqOOuSTydZHPtLTjuVWN3W+FtH1YSSQWXi+XjTj59ThNrlC6HR1yhWutoG96kUxjoLlKr1BBrtwZJm7sKUZ7HEF01jOAr+eYxArih+0pqdIZuxqoFqdclgZiImQ2FhvSK8aq9eveuXbIboDlpuJ8l+b7lOyMbW6DtF8mg8NmLtjEnSn0gBe4bZ16RRMR6dN7CXRwgTGDG6QCIF4Q5DlwSDvgi70VvxIweBITmmkNnNGfOA4t4g9iMu4bQqPUBTCILVu4GkPHsB95mt7GZ4dVJqjj37tkHAdXsaZb/XgJGw+ZwEr2C/cYSunAAwvghN/ufc/vqs4JPG/P0q7ivZWs77awtY01/YdfW0gskoIFAIOkECmog3JXPdmER8SXEsZEcTHnXgA3OzBceCMWACWrfAbLOiX9lqDU/g0n2Fke0x6wglxmDyb1pKD49sqsjgNf6pLrHttJodiFsTwv+ZheAf0Jxv4g8cqspQ9EKbpG0Bo65BO32sywT19DitMzik6s01c8YT8CAtPELBdUBm4zrxh8o1fC/Igix/l5ll2dj/53ZBytbbvzGR3Y2Eqc+WWbVs6niR7YClyxKqjHpmrXUiJItJbZSn5DX8u81CULqiQZ8hskQGHrj25fH57QnbQ4LINaqEcgcGZIQ3lHjSkzqH9mXwnLsE76oxNLYbbdjCOwcG+l6Y6nDLvLkA7r65aJlBwGaV5ZNJcb9ixR2ZyCPcuPoM5yKwZPBLpvbjoc8JQi6+HqdZO0573+J9eTXs4lUPoF8baDK6BIzFPQ4T0bOy4VreG6nWtWcECTzXn57a8LT27XnLc42fB/vOT7sU7BTDLpfKsWJF8GzA0A8o+/PlgTc1D82uCABzhPkNJOp1O9ur0dGEIBEm7POCFO2fCByL57WoDxijvf/z6lq78zfLN/jaqE/HApg+EZ3xGVq0qo57sb7V0aBjCDKjWk3d0Te+gBde7P1nhXrGCRabUClDvX8dyJKAqOE1ZtcvdhSEwu9uRqy+VVspDayY2dTf1dAQ+A79rRm3R+HXkcLNC+nlsmuXi4Pxg30B30JCSKANQXGJA5HIYkQthHGnztqneCZX8J0L0TUQs9L/+/PmES6dzXYcf3pSsouGYL5MB+v9+n5kI+Mxia1u7WUiGfJb3Rjs67g/vTHV0jnaAovNfZz5+QBlffgOKArxSruoprx2Hl5qWDT71A92nUAQ1Q4V16GUz1WV0Xf1/PJE37lg8QgqhwhxthSPD/lnumtZglyhTt1xIf3zB7E5JBVIq1okF8qESprq1SyBQ1YKPO1cUOBNzDSn2/nqvXvm/hNRQFiSmp5LJXH9ye6lmfts6nROtoDJcta4CWPLRTbgQhEYQlqgwipMgUBYKgVBFOHQlHI6yAe5NzfzqPXms7jv/P4T7N6P+9+b6P8b2f5Lp/1WWxo2X+6dh/z8S/E/WpoATT73JRIIrKon6ptK3YQPgXNNLLmyOTSssMgUALdYiLdeh6SrTtGld8fA4NjLunwMUzF9Gz3/p/fSFCqynkq8WxfTPc6jeJDoEaMp5C2VMs7qtXrSg5p1XeetrtliMdnXWBupdrP78z0tR+ZT67huLhriWt8P1ZXhv6B2L3q+HhofsY3UBj9f+TkKKB0iyWsR5bO0Bg6ga2drtOfPpIDCE7yvhZNjAE5cqete3isNlrOb5sOHtg6al1Baftr5qp829+d786VO++O5KIZLzHnYO6oeCkdxgKJ6LLk822tHqG0egCWi1GRNWILllWm+N+PyI+CQ3Jdt02WBf7v+BfRRQ+npbXLPq+kwPwaDcacfVdseQmFDFiONJTCZFjA6t2mhbrnSRr+CronY7PMz3+vdNBQIb2Es2bzLUbLWu6qm4czN7SWgdF+ZnFUbXMVfNDHDJltb1cxfF1/vC/Wxag/sCd/+Vi23WfFsAoL5/Vos3wVRu3kPQcmxQ6J7bpogC8Ow2VF/+PX+sdI308DW3DbzC3/mH4K6IAh1XyQd8Aiv8eU7EnTUqIl0SBRHwWLPAHNvXpzWjIcmrM3N9v04HrAYt6bXlX15T9vpdI1bbdppSAkvw+MA2i6OvDu7oF1j1VMWfRX2AJLevV80omx52idT7XLGBtSQXmAmTHfnw9xAT2fHUbI6Tur0CdYTg40rv2wQVS/sPu0f/+/GvodfuJnHZ9tIoQc+ZPfPj60tDJ+4GLeOt+kjBKuTIowNHr+c39GQbNPqc8dlXbl0ssiN//f9s1td9JC4WH/DyubDDPeD3sp4Bd9Oh0MqGlLqCloXCkG8bO7J4YbdHeCikNdwheLgiZUf//utszj/5SKYq3u/jcjGGzYe83KMacH4uOHL0iKOLL7w7rMPVLlgdN1jRpz+uKio/O1X2yu3DVlN7GqMHQaF87z5zYmziREXXajm+0JR8xGRqdj1rhsj+H92ctCv9zx773haj0zu3GYOJKCITuX0iHewXihmJVup99GFpq9umL6ONCw9Fop3tO34QPBzSIUT+HdS3bPlN+MM3Q7eupfA9ayoC+3TPVZ95WrIrUYqLvlt4ah1Qo5kJLN987nLq6mRb0U3CN8Jb3oxc4LeZy+ennP5Yn/czhzHXA68FOLfwoqF//63O+VHsE+eA7T+a4nCm948bbQjFYQbKbZAaJHfml6ipaKfenIOU3TiqSK1AXniUo4jeMz23TeBZPDB8YSbMtzjIr4g4Yvvqt1hFDDfbNE947kTBKdC9N8HzQW5R9qgbbxj2BsG+nc4+YeU5KdqklSxbWv0K1i9dtmgZ1Mb8MIvft24ZfstL3pveIXVYIb1nmy4/tgSfNPHEOigwiZ+1/ipnolpt8lQ/T252zu3zP1/rIM8g73iOTUW6o7ALGqQp1qHC3Uy++pV/FZzHE/uYDsKD01ysqY9/3zxhmL8gAdLTtJ3Ju6afDu7YIXeOg2wlHBuWPXJ8smJdl2MsBNfSBImKcNDm7OR8NHznkp2D+k+kqRFz7GJ/43DEfwUIHR3OtFR233QbHfTADBvOOREVPCjc5264hY4Twb5Pvwc3ejABt+H70anjvipvHrmIAm4PDPwrj65LL2ZZ2vbyVU4fMrgpSKL9o5AD7O0jSRyf/9+2svfuL02cBPu5tdyuhXW892ZoaOjHqvRJ9csXDLSX/KcYR+lF2tbwui/+GDw+PTuWogyPhY+n9CWq1nDkqSvFXWvlzimVCj5YOW0XSSH3fhlz25tLovMWgH/woy95L9Fkd0NyMRxuNILXb+1U+DaCNQMlqV/gT6bKjt+yAe1d155kCYbyVD5/8HRSxB1REy968VZZb7fcJWbypXNfhIfBxFhHHd7UXIvj7WIDy2CguXfwzK11NnN+2GsDw6pvZwUvPByJwCAcL2mjYRX2xu9XzNeuzPsvcngqC1HETQJfmYxmnlu/jeqd8GLRqz+ICtPnkR6fB3s+ue4idClHU6g6ttVU/6MnUJAKNp347dUb92+wf3RpUvKFD4EKp1ElP/9US3CbLJr/rbNR8LyZDgSj9DYJ+6VSXZmTtrG18XrUG60qFGbhWL3zkqOIjwXJCOwo20fyay2bLlPZInV0JIKvter06OwKSLDFzOahE7wA2e6wP+5kl62IammAb2jWTd4Yam+wcpoki4r/GrTYHQUt3Ge1d2VQFdUCNTheRluEeJYM9Rw0A0uo3nczJ7SeamUXRN5BVvMr0CkxjtQ7Sd7aDNygAGx74O36Fcw/Eg/Iu5z399NzGUjUDgCn6pyhOAmCLoPS3aSnzDrYgetMcMwuQY5Ihpwg2/O9RO+TCFj5PNhoGapM4VF0zkgWdmadTy4MqivU2XKH4h4X/Vck8ibpi95acV8EFYtX4mYlJbHwDuShK1yMHGglKjNhDK2Q0R37Uf1AiNpmeMME031F3BgpqvPlxG5AsmPXazr/eJljdKk3GtY5qM9dOv0EuYajyWIJAke18gxmVubiSqT1VS7xKthqNyJWh1aCtq02NF05uqOJH7NbzRzjrHE1WofkaIrsNatuhZ9KRXyBB17FW5WPXy0rSeaXlus17lWznOI8OGdsmYyjXIFay6UWzVRf7E5+a9aoNzosEEy7EtzexI41lsPNCYqmHUx7Q6OpoqxodpUFNksfL7OaG9BzXiL5hzVpgltfjDW1SxU2eTVq2SzpOssWRxNc6TyHPMgpPEJ2+qhZdFx+gcUf6nk2cGbwagTZKjw1klpw1piYpLLEaqlTch0+6K+JV7DHR2dR4Oel8soyW9fjpUJugIWgvNqpZRQ7xQoaSP79l14uDGCXq81LRkqHTGHXX+aGmon9OcEsO1ZV1paNRZidF5mmdc+VVYTHOYlg48DJM2ME6ii9OVanZh097x2SgDocWZGpPOZPb6pyDFNrmoruMDLU0QGGLPD7O+mXQx6TMRskZRllnAW0mViAgMiMwnFirgmBk6b59jGL7c13/9NBG3WzMhbBvIXtuElBQUYVAeeMhWS7UEOLg4+I06FrcknrX6hM1iSxZKako4d7c9EKz/71QbB2EEtwFE1cfTn67jLB6FIe1yV1WMUXfjnChJFo0K8XDy6tmO86hQUSN4/dwrJOGoDPpOZ5n9xqE+CSGQDg4/K58MRPTwiWQPOMzingEB/9jvqBZH9auHR8Pjf1qoNXtWskh0z+vI9n9/3k+AeSPCv1kt4dahNV3udg5TR4nQCn+SLw5AVqQGFOLEybRsNGX2LnL6osxU6j0+F57YlsDsfX9ELSmipmZtgskrppahYuV+JBeAFIRh4XpLCXHNgTC49T2AL1uuz95lF44VK6xiL6xIbtY4dROfGdHoP0DYoV+8Zslmh2jqDwSJFNcx8BQffnXlYLPrjqSpNopYTefPgalSPSCLLPiE+ftS21KiOswm30X44aMb9XYrlDC1I1ezlOLA34uqNR929kFmGuYlAQUq2FYxwfccYRhyxyriXhDjgsQiylUeWMKgbECuNXiaZT4mAVENRx8xXIE6ivrwUA6hetkGiU8rn3kj3CFYcLkgnroAbOKvdpNZ5EZK/jtIANNskQxNlL7phKMRvtFOtWdWf1Z+TnzjoXWZQc5zvQvZ4VUouXlVXPW8dEoEAywuipiznaHjdVT+NiGqVJLVaVUpUwdWB79qwptyoz4ZgkbyGm2tSvIfmjxBr5EZt0NA+bqevWaR4ofzCv/j/+eUrVXzrpxS0wj+QqyWrzgQfuj5XnTIg73G3TyndAtXh2Vh9jHt/RbTm+JZvihy7hMqxocYfB1Mcf1/Kn1VHfoDUoOmu8QKHDJgcz+KxUGI1xpelwuQ/xnlFHwoo3QulZ1oemiIRrAkFG6HLW7r5M4cImx3NwKfst++NTHMo/wxKHMv7ZxbQizMl/ExlY6XkwzWiO94uiYTylVXWbljRW5IO5fSSdhME+8U0XB6FL0InHOzGV30etiSBGs+dmZI3SaFapDNVJxGUmH6L+7JrCspjf1FH66oVCO3bowm8HZuHVAUVlXN10G/to09kwg6pZ2IXl8L2pI0NUmbnPE14UWotaUqFQ4GnZb4Yq1Gx9tU1PEAuDktJyQ+IaADYKKahJVbfPep9U6chU98c80ZwH+knTy6gM0ZOjvLGo4QKAA9SnZS6/4Ue723sRhw80mXYK3JCd3ti1BdXiYbGI0mvQx5i/zzoEaP+mHymvOr2fJK9vHK+X484b9AYKQP1D2BhYZPfRTNa+2Hj4zvFHSGzVF6b36Y+VV50eC8S6OzxBy4X1aSvJg3a9cMLZXR5gHl5O7i2WWppmniblNksWFf8PBesiG4QLnaQ7J7La9FFku9ad+uok3W2tMgSrx0blKzNy7+eE1ltatm32qpSYmtFnW7YJxlrGEmAh6k+s6lMWmRNkVioY4NJqXHXhta2FTMqx7J/ftKlKngbnjADW61akk7G0OhWhQm/MGFcWTNh0zztPdmIQsoa83IaOjNP4PXGPJiC8+SjXR7aXiwDwlbELt1LyD6q7Cg1LbrvI8ZTqg0270A0eRvJlifh7BeGQeoesO8N9AR0r8j3IcBdQEh9FJv4i2O2QSSizhPacoF4r7fHY+82j6T+Yjdq/i7Mkk69QAR+ZMRVqW7c7rft+UYiWEfBrQ+9mJ4kUnB5rt1JmycPxKc7FviKW25PBWUV2KesJxCmX3sVPicfB7EN3iaMhJCy/8wLbU3KagxMBSO+fgpJruuusOFIHCcTFNGmPcuCAUtNUU8uuLjms8/VxC2iSWVHG3zTlE3MzBKK6aaOYu7obGXs3uQjRZRPO/iKxWi5ri1aXyp44CKOZcUzPeqIjXmyQCG0SrWOlNx2e66hR09TIFGKtkQ5bVHUZWbIoVfPKD8+5hRfHE49Z6RWtgno2m29nhXIE0iGjpTwffwOzi1kI6XDDzTo96TTE1Ola4ejwHJCF7ggAbmZdosPuK409Z5HLSQlPuYTo8DKKkKClCLfFwY4mNJ/sSmOG/VPeOiJJGX3GJULBMQT9uWA4m1aXFQlyRI2WzRvuK/LjVUHig3BER+K1Tp21C0nQZNCio9+EzT3GW1LW3q9rEQowr22nSG+P2ubbIzXxhAKFfeKbL62HYHVP5LHAYzKgLQsaHTYTZnMC4FZD6K3AHCPbN9iuG3lIQ7UvncmcU423hUAn7juESqcFXjTkm13KKzMupjXzF89+EIt/IJA4ggiBpMDMwjnY6OCPlOFDZjMaRrRwu5mO9solbahGPzrl64aTf7iO6tHZ3ACgOXnqNHrxkzU63dKaj4RdXu8mCH++E3jYI1N+S3Yrjaqm4JfAPMedZZ8+Y1/cYoiPG4HTM9j6R5ctdUZzB3IJ4rQ62FEHZfJi/qXpo3Rqjyno///bfBRjinWAqFaLqY4qn2Qz9kQ69Oa73nga8IDUZ5yMdJifhv7mXEMlqORx2QbpOvkQYIchCpvofLXRx5XXxOduVFS4f4KfPaKHBnlES08oVJhNX2PXzbdUO136anlPJNutFtEFer88/Jk6FIsVkHVMA6BErbRCmFyQyTCzJ+KgRxA8Gsq37zWSHSlSS6pPsahuUEVpg7TxNkHSGuVLjYsral7Lf6YemmvvPfBwtJo1MZpSFeC+9eEx85F9+9F52xOw7Va4zXoZbf1y7l+rtmEagEnMLXUZj95LWWbEzL1QvEvjhc1QctEO7dtDhpRLRiQLQck788DMFcHxDzQfs5UW8KR0TUFeq0znE4lZpayDGZvyafIRXBcc/3hed4EwqtQmTNW+e8oTOFRbaUIV7HrmvISg0yfzfeHXSY3NoJ6iZuxJU3tjXZB+XwzP5AdtMi2bidtaTjj+uihUGx7PBJHwdeaj6izEgw54MWXHtBJ5Jz2K7GizusQxqJv9RU8akVqTCr+0ZDNoScBP7S0rWdE6uL6HH4YBwC5bE6a/djNGwMx98qIm9oi0yTFKhjuLoFF3GQzVv4TpHP9lXI/eWZ7rwRe1Z9jibCxUsoBXRDmZp0tExO4KZJhjqrZv1zt6lBE0qBGpv7kETw4wapLEJ+H8BLyvSqTKhV2rl8mjs94JQShn/DJ/COIIAJ4kOTX952vD7QqFwA6Fp9xpj2ZBnN2rQongctgdRzIww+/V73Z0t+2te0EQAWCELl8E0y9zE41M99qsCc+0X5nUemfQb4kb9C1pIqbKEuAAjjPuyHJ1Rpi7A/ENJ9FXxlk2NxLkZ/vkWRUiOxgwVXmlsb1o4fGKu/iCH4BhcgEM68CL2wWdbs4eTF2wvCimzz0AojuQYzrPFdQ1Gmp041qHiZGO0LgdpYtVCN9auCmBwGAb76lijloRhdLe8jlOUdDVTZhJAyIvLsPgPZlT5NOkg5WZo/DGyL3ColEfWajTzdqIxInTGP2qrlT3TjCZrWMOkc64Ld0rlTx/3RqGr60v70XV/0zY0/YOEHgGAUCa/A5nMA3RpdttH7nJuYoBOPkmnDuhHpxsuu1H2U26L3afd7K8ZScIYv4YRFMmX5aILruXZRdc7W9sTieNqeC8JUzm/PrxdC14hTU0TqxrjKWIZQNcLkbDl+7GwIbv128es9f2ob2GGVFjB6XUQ0WPh2UslQCnHI+k17/OEMh+AyJUdBbMoY+IDbx7HEZPn728nu6Xa1NIgVT0BhMW83/0BKh0lecbm7D0UgsNU86mUQJkmkC6gIV1s53GAM+s+Oe0hUKn3HMI6PbgBvRbRRazsCcm0LN21BvnpR2duk3w4+aV+IGX7NxD6JmtCfW0TLjtlfrKlvkK0AczMT3dMeiab97uai+EvFa13YQnlMoovMfZ0OmqUzstz5xFwMxmgm6YY151NLhF4nrnuVPWTLkBALA4ZN6cLWyCSTIVhBoXWblRgmD98yC8AMCH7vmLRJOcx9f2ILNwOFnh0tQ5hlqqf3gfeHwXaMt/uitPcSRI4zbZnE7KkOjeVN9iQSJ/DPZXYL3wPVsam13jcjSGwjpOadb6ofiO0ur24E6YgTcnd6CqxOeedlvRBKIK+7waXo9hkTGxfWxXWaFew5M5lV8Xn06x0y54Ae+OwBaxGATXfKuVD0MpVsDQSeNU7IgJjaaGJwbntShnfDv+L8m5R+e14PURJMcTCYt+oADbbON6PLzIHyjOSSQpZpKsMdB7JdZvtChpiCxZZaJwUHnKS4I0rMnhZK1oIofDx+VrC9htCq1XIuLVail/WpcShuPTZdWC4B64AjdOXpvs1ZkoTK0yoaq2u6c9t6HNXCqbN1QUhGXeeeUyD4QZIsNim21YbIhgkMxTPk/mhQOD3cH5oXj+bZj81YVbLC4cgn8OUOIXfxBCJgow1MFgVO+KCY0lh0f6que0KGZ827+PfH15Iysj8f4J7yguXREgLmQSLPxsqSTWj5uL5uYyE4GXVwUDJOlCddmC7VwkmTdYHAxffBpdW8hqk3O5Xp9G7HmSluDTB4a7w/N8SfwbcP5HF2Yu9/ubx0hZ3EZI/dZtrdGmh1QGg6L9nilPcOKbvv6+pGy/njb1WzPI894NryT39MOMKWdLdG8V4BwFyy1yXJluEhpXIbGcHG/eyNhFMHQklloUuGKsUUCs0kdzKqMhqrcl/Nugjr9h51F0FCHIXz+bp5y88Tk+TcY8XoyWdTXcGFC/YfnspSZBlZrW41aPw2Af8/Uxa2VExmwlkn8IzY1CYJDxNoHIMyb9a/kEv3mTjbIwE6YdiQmMpIZH+xeVN6he9LeO0F1BZG4v96NpOsHCs3sPPuxR0pC5ZDlB4uDoN9RjzmIQQdlMmxZ/UNhqIK8W0MmIQ6Vw/IxUmwWJpRY5rsg0icjVuDsvt2Vqpy2wCoauPsL2VKR9oyCUdOg0UlQrAcv/9HJOW9obIllZV8MbQU1HPilvIbqKNC6YdLAOg+0acbF3kHdde/K+9W8Omdd8KeoJO0+jjilRtXtTnCVHWYj0v/81Zc0UlhmVWRX8PfAAHvUPIeaaQDplKNY30pf69Oo5ddGzAQJ0tcSZCJATxUUaYAchxsykLr69TufUmYpW9i6kGC+JO+SCuu2+jXefbydssrjsaHuToelR2KaitUrUbJfQqdAo3aVvG/WWrH55EvG3wUm40F8StC+UZnWQ1ABJtQglKQApfCuwkMY+rwroKXpMhD8qNDVJo2bCDWnI0yRd9k3eTnMPckc0k/j406ajcRAU3UnViW6cyIyZ5SFflrrGSWToeetEUczDEaUPi5M1DlybzX8HMvTiD6Lm5WnoPbbYS2NVwj25KgCtovxtefzyGUxsSQ/JaQhq7NSPeEz5DO2aNEnDHcnoi6ZVb/RLX2GyDKuxloRzPF7MjzpWcmUnb65r3XdaFL19MfCHyjJ8Tc8HP/AkGEUMf5B7VJ8tON7PwriHl3lAmvZwCZ4sDmAyauwkoI4eovV9Xg1fi8pgx354jr2WNKftBOO0Ye+Agfp6lEZ/d7TGbhzaaI5RkyJZPb/ry+AQPVCnAKb8GuvujU2vNqXuzYlFaI52VJzz3U1GV5/qBhsZio3e31G0LFP7yhibHE81daxzeZBz0BM6s0QXXRnT1uUi41sX3y2zntpiXNdZiy3ssv+yODejS+1ROAldK6+9Hf6/RcovARbcsN0b37HasrAEjVtcDofl1o4HEdVu4G5KJP+wIk3wCbjBV0vF0Tg3S185KKI2WQsoXUrwhi9dRL0hI9AispDQahfdPbZrnc1ordOHoqiLcCx3tRRmyg09e3SN50GrIlqr7bzOsExZxlee8VWzAqFLEdusNrYDpjIWULtVR1sk5xu0MEvoVGrPoBeV7TiteGAOriXgckCFrKeUIW2pbRx9UcIPmwiT20ovRbJTTeXgzeWBapwZnwEdWLMRoUxD16pY7/DspCBjc4gHHkCEkzWcAtERsYEgLlMxO5JqUvDKpGO+EgMjsxPoY7RnTQpVG2aYCaiECe30hbPDs0qgvKAWWIpjVum4TNMD2epY/2pSvDyd/rYTSRCsDX4cnSvcXNlaffpreDbHjZ2WI0Dz244ZkWliGrOc2AIROFk6VKT7XUGjEXOR9LJogCrKBg6UNk+++g2vrwXy5FUvUGh6EqYHnmELozHejG3EB3gvsKpEpCVByuR0fXUn41nPYx9sfydwC4gGlpl8zY691BHN8WvEi5mLs9xZBZhjYgtkNpFn2LEG11IyEsm8AJNz3Jn6k6ftFxY7FEF5RyUAzFw94lLN764Ho3EtQ52EfsG9mM4DzI0ASRZ+aCB4Q6rBAytoJNlPmtaONGwaRFaxSz/M8JGNnI7pbtnz7gzjMocv+dLdro7nZMKL46BXKXArpbJsL1qf/jxvfK5DD8UjYUmNbw6hE2PrYjI63WLdvwnHEbqnkLzqKT2DvRwHs8ZcQ89UCcNRblZ1calR7nQ+UK1JZd0xci0uJ6lDKJO1xJC32R6L1cFh78Xp/49kFypN4O2V6mDXs9EjMsv2gU0ddrhrxa4KR2w58la81xgPwvvc+F/ntXSJRA7WHXuvcxi9TEbWEPTWHRtaLXyBJHOkfyhZWslRqeKn4dzIC7FaUMeEIzGwyBkG1vRsFKaM/oHYgsbiPuxCFYjYEkyVWaCJJRTIedpbIFKt2fkDVPhoRapWjsEaMaWV+1ujDyQh9UMZhzPmtrt5S02516O+trm1pGXkeJbKmNhSVIEn34az0HlhT7IcgdtuP85ECg4lBh286N65/VIHapMAK1FiyfKwtxX3unjbNFL/cMANm2xlpTqTGSESvlgHu4yDIitVcPJVOAfYpUH3MysoC5CBiDCK3ECJlu8K6vwqodxlq7wnVIJIZeCrX7h/R8OOWKvVLtU1d74frzcZIK46dR0pr1XryLosCsjUUtKqN0ipfoNfnOcyfIzfPbgxR/a9scV38N+TiB14w9QX2CAGyazJiMc6GsGHb0tK87pKJbxD8ZdTv3LdO8X176DZj+IZpCQik1h+iOgCO4HdKdN6JWJepZR7Tt2QuTTRLeoKPHkPbILVF/bQFhobf3nsXze3bF36uCLZP/vUdcEgNYmpQXrdP7t3bjfUDDvKwkX0exbrP0hM3QB1qwByc6Zhuy7qLmIskOOc0YCD7XHxmD/J97G0N+f0OZJ5vv+84PjFA1HjHS03Rj2LHtmJ81Dbe9obLze3Pk0Ep/nq1XWYUHhIXuu26nD4I/wQniBHAkqkxVXGv33LbW5gLKAp5XG/xpbfpRCtl70W2kkKoUA+mQPg3cLGiakLcfok0a0ceqNI5RYK3HKZgEmdivHo3na6Dbph1bLPWmqoPfLzQyIpCsmao08s+4dWTS/VxxRTM1XJztRGa3zEhMcRHcHnGvCcKRbQDyEeC+E/jsEUPYppCxtm/xohloZHvjdE2DCt3Ae8umc7a4NePedS4/CLMMnU+TBaiH4J3jcF1GzHyJKhNntmvZcLOHCidBDagC+zlrpcnhOu/OV/q8rgbk+MmRWbZyHIi9YM6xUkCfJZ9OZWBjXgBT6n9N/7er1kcIoXv90nvJzW8pOTnME2aIb4+Ekybl9vnI8nLyJKqUq6I1iI813NpOLPEpvJ2Gm2uZoQC65Q2WGtmY1Sbb/ypxOKV/8taoJDIAkgx5Z+x9AqSLrlhk911rEFRk9o7RCe9VOjiuzJC7RXY5Ulc3RGNDjBs4fUIsfNKdLQEk8Njuul+BDRM7VVnqDE2prcbf5K8L+UNLsOvpFcmIl8kj1O4omDlZbzWnJ4T2Wmkf+HjE/fYy6ikp/1FE67YB9KB8xmyoK2VHc/z8nq9O8sjOmtUuOfM2F920CvFqcGivmPCR+EdPGypCWFP3v8++vHqEx5aWPbN1D989wFOhq8ZzIeGvs2WsSLYlBOUYvsm6i2Bz53QluH7seHlnip2y9QaYNCBaeFVf6YENaWh8Isfmvx0cxZ/nLcBnluDdin09ZGceEbmQdCLx1JMIt5FPzm2x/EbqdY0Re/soy0PpQx44T4eu8qzf6K9dJmXDvV2tJw2qnaGJYsFYzx5xW5TNIZm9aYGt+8NFQ/+91LMS7FaN36A222Q/2TJDSvY/KgCHytViaSxXroH/I0OcJUotdE+7lj365FR++zSGhNFvgQMR86/m1OzKnouKuDKE4YRTk4uRdWRfq28yPd//ZPhwcZTSccSvgD/cDZsGM7wpxpRDSIJ3dAHVOh93tFRNk7l8WItkmj6Cd96E+krCv6liYfLM8Z8OSTu3J90BalSfFsanhzrH4q8woCCJUcMo4un/iB3yt9N52I8WAdVXI6fqzkQnjDaLqcufZIhqAKgMIF+n8Kijw3eKqBPm2yC2qMip6iKK+9sCRXtC6xWOA0/HCqsdk37CsFTy3QizsrgN9nnqcSQk70yjMTCWaIrWZuQPy8k+/l7bUfH7XJdb3DHZnhvBN9E6WZvjJH2z4+HIn1xs5lGwZARIg2H8Zla0vjIAZCkXSPUTSb1Wrb9wkgPBUbOvU5CcR31mLhtYzVlMbIhLh3nthbI6di/OlZPA/jkE+2Nx4ONV1fgo38F1ONYW4kBR1wu5hysB3dtPe7mRxcZtAvDeIRHK/D5etEQp8jkdqM4bM37fk2Wvw9gZIgdavOGYWnBUeVs1y6Cb/0nldKor4Lcu+CJIEesy+nshHlweZcMY33E/boLvapKpbSzzQCq6Ufc2ZUiAtDaWksVUYD10S6U6i2n3sfeesW0qtNMITEFE17u6FhaGzfMeNLeOaONQEqSoj1OCXfHmrCkvGXxdI6U37iPxCkFsDsMvQgLsfKgaK2DzODCMg8yizqusXFZH9clGen9PPLS05+BC6jM9nGWP34ontusDMmfVjkVExhVEWW0U6nxhObb9rmwgaCoQm8vG78hxVydxRgVx0S2S6stbCvTtS80jr0+6cmXWNj/lElgE/e8tVdWqzGtrdY928uCblBAORzHxYLH8K5Cs/osjHWpvBx04YefTAyJPh275Vpm/1LzEtbB24TdlVnIT3Bp4O16j9YQqC4HVtFKWZ3Fs3zhj19hS2FUPFZwaZsd7ikMhPlE7FaMSJ8Gv1/5yj5xE7NfJ5mrw+2wJnx7y9V1GDUMb93Nqbp8utwFIM5biv2Txtsc67G3kEUKY5zgv6JawXFOz++UqRKTucqd6KQxbXJ56Y1DvH55qSkCPDltDw7P6NlOnHxXWctlhKTJu87C7BoFMYgNWYxn9bRM7C5ekYLz8wJrE5bMzyGtplrrtgg5VAgiAzmvO4EC6s3VklUpu7+PEj1AcFptwm4StTopibOrOoZSO2c86Be5YZKicKIsCVeBPiEgXGjm/oYmPyjcYVNwxxy5RsglaAWIOfoitQGw5wWHo1Z+D5MZqkUGHvip3NEkkO30WhEsiNhOvNPOlaQd7J9ZT2Dvi9zXR+Fvp9uZBtoWexZpSE1P6ZDMikMbL0yCAdjJ70ySTCYy8s78vRi4yCbxIn+2fuf3VLB1Ea50RXrSUd/j/aTIcWGVOlSmOkZQhbyrjQI+x2JnBqxKMu4WAriijeuV+owVRz0y2DEJ+nyKALLeaqV91ZpIZkH1sCDTJb2xxpqyYCO644J88RanTe03BMdXcKwiQAJ8SQ3D2BOcev3bYn2RUZZ0ptT0Gns+apQi+0Rqcd0HLFW6RJMI7/IpA5VYG6N0+jSIZw9SAPcl9v1WbNw/JkrQo5IC/mhDIVu60NRFV1XFIOqdNykwhE/Dvae8TywBJYlIh5f/iKFJVQrWEn+Lmln2pGjXejrji/gxu5EolgG35M/iRDY7hOOmzf8fpzI61J+VNTH1OgRis9muDxjlzBBXqA4x6DjMelE0WsBXoc8DFOvfSLaADV7uBaYivItfct5Z6rU7OgZnzQDR6gVC06esd9GUQnAqyuDa1sKAJlg18F68iBrzBcyxREr6cMdDnXQBFJQxoXUoRXe4hPiTcdXohxjPSdacgTB6ikVjvjwRqTGHz9rNGhuwTRT9CHtTRlVj2g/d4ZYvfj5aTKzS2WaRRaHdxXLi1RGUoXrW9RbnkQUjNq9+tLa5Sfcii4NFiY7i78ZG45FeeWCLTugfuuOND0QjAsR0BtlDsObyzmEanLLS+CAj1G3iN06TNMf+9s7b1SPzgpD9d1g5Oh0r83azaGgiGVQ4hkw2AojZ/hkmu1COCkfNxql/a1E678JxNLVfr3sr90BXHxlIntRpOizKu94Xxyzw5a3qMWtxBlcT42lxR0g02Y9lfdMOfUMnz55UsKNKUnUATuD7xmNBcQEbce7nlxK4OgA6IrID1P/4JY24DsHDkFvfKSKin1CxmVHE+x61jFLNEXOqR7VFb1BIQknrTwk3mL233KEIhJZ018xSLL9/n/iIsRYUOHdFhLpHdASHd+Rn/nUv1KA+2Rlqmh9pnafsMIctr7FYpJlnzZwJsLiaBair+F7x2NAVBwaDUXf9sw/CZGeZNGfyiE3KPNEYTdPdmRcywmnk0SiVJeSGUBP3XYvl+j3LeOvwI9J7+Gg0Vev0Va+IgI7FNlBsrIrU3dxJEIFS07+4/8Zqd6aqPwhWPdG/p8FBoWSM11me4sQdyvS+wfxhNqD5COu63YUrpZNNvEwAw5Z34hjKUI4Xc9zViwRF0/zPdt8efaRlpmoqsmReyV27VEOhwC0XQS02wR4DCTsSOi62xzS0UYyp8Q7bHuEvJL1KKZDaj46zHeP+YWCXbDHFosPTWuVYfWc92bySlZ4R0hruF0oIgvzemLH1CNa8HU+zY68A9cA9lqGDUwS8HNw8Z0jXPZon7+0lJayo8yOVzf3+jMKrJFUbR1ip4H3NKt9aq1dokDzuG0yAuthVXUrr5TQgRKjINR+MJg+PuXCXaJxQ/rU1h+Qa3d0W0z0MMNgiNipKGcZlJpTMdPxhMHsnkJ87SAIT3kQUw5HurrHQIJJl6Z6OCz67N+crKGnmXPyy5+eYRAjOEc/1Ctq2wftmTSqUJ+OD7JY+IznIY5KuxzsuDKuKovRWCBxhqITviWEmcmaCPmjhJrFz8POZ75BXUIrpj6GUfSIiNlnIhbWkx2KHXuOqLuC/D/YoMGTKTjmutpQo7zZxf23L43weCaKprInCi3M9AfWqKxo4x3d+/R19o0Bb/q+pfxfC1qXxwXyk+M+G7Q6JGJ4IfHLvpRh250kLEVX3inoOUQ1+sEXOAe8++aFUO/P28mPWW4dQ2mlXehzK2bjNGrq6CkfLQws6eXiwGFrAlVFm7u33+MafvSkIEhOeKzlJefw3O01gfwwj0eX3p3ulDxPNai6JXfcwEpof3bjvUObLnb6szku+sTPWHN254YGfpChKGDVyr6c2guB7Zyw3bkaPCQk4OQZ83MrFpe0LrJsYG+8Y+Mr6vbDPdWd5nsPO1iSnx9HRbK4PnP53THt+1DEv/rvMkfauWJBQLlWmBYRqNuoG5eSVjDptVpdbtlXyPafZM/J3S9kFWg0ecoJ0vEQruToxg8yLULKJGdNISqRd6IHAOyvSlF/HDm1vJ/fTqDyE7FnlENFlYY5RWdUzRGFVVKogrd2wvk5Ouhz45FRwmNvmGsiVvJXw6F+6gDSxLGGyAQvud/9EV82k/0ORa+GIFea4Rj106GIXbVtFFbrWWH8VHgrlj8iLqc8Ehs+NF7Gm7+HxXjwRlaCv/9/5gUyR+JjibyXo5EmsT7pm20NoTV/xOO4+2Fhubvmo+RDizyiO0Ja6XZhpWqRujh03eYAgbtIyhfKDvcLp67o3Khhih68UTh9t26jBJHd95EMzyGkHuWYJDxUG4lrWTQac+qIliaSXxgERMCrhmKOam0bnBJ8MTSGq2jFcf4bJE8pu83nXx29eW7y6PKck6lrgn64NrTfiEL2nxz3z5VEmPGYZtiJq6teyb++RCh9Or1So2I0DuavfSIZbX0lDH5wXvRnc7SQi3RfW1phvoW6aC0Bz2BG0Y1E8e2xbsVTXP1WtHPE9XW7rPwnu3hr0E1ee2vZgxD4z1lkI4BNpl1m24Gvfn3l38+5hbO+F5/ML+/SVcqnR33T+sA9DE24ePB6oEQ67fRStxgxEz02NQw8o0WPP04Khz1DuKGLSm9zysWYJrdu944yQSRCJi5dKom7EC/5kLXLGPQKk/SttlenTlwKQa2uSRxbz8Lk/Sr6Ln9vdxG79G9YDKHFrCLq3H5bvEnQqavWv9HtnTYFRemWuEVCBQd0R3mIyaThs/AhDExpPltip6dwOjMu1KHzAXSCltIoFp0bW7n/2jAbrzGQlWrf9SVQUCGPFxk8dBZl+CloE2WFTrJpw7QwTGUiN20j5KYc8F6RrfajB/Ok2O7qoMeRpDPPPzHTeOGHiBlZ1aJhHH4mEtX33A3qkwjehRXz0+GQl8Q+YWWaI524/edOiUZFem3PddFJm4dd5n4UV2sJzjrL559FIEwE0H1BMJMoYZcrCLlGA9h0uYdBKn0CKa+bL7dFK1pIdr/LLc4RxFcdRUDbWw4NSs0WY9dUmguJo3V/fq3AWpkJ5D15aXV5ZMDWwH0HNaEj+opIho7RajXVsfyddELGdBx8vDKypfcDEACwhWnZlEX2wraCpeQvLrU6sfLLGWfmX+LplZJUdwn/dbAYA+igLTGY7ssmgRMWlwBrnFtTTCB1+hCnUWavj8O8RwR2RqVnHbq+T1k0p3yRESLlWp3X0rJcqn3KFGWc6RsYARAB4Nu8EtYA7DNckyg2Dpj54jAIAsvhoZshXolfrTWXp/3qb7bwLVNeW37wph9fZJUmgTFK30LjxtbEX2Rk0sRs2dGL1mJDDARB39CaSnbcU3D23dgM5F4Kek0Rj9O4olJ1gtBozMqqdGkWWJt3J+c7TXBSyzuPIm4IAVehmQf4lVcBohjEhxB/IDiNjBoJlwtWOq+Jg/qp2xdpq0k1cd1nwBMBB8TSspgKNTJ3KlTh9KAdGC1Q3tz7OWh1e0YDli6o+hpDjwpJFWMeWosCciKXleyyNu35Tyo53cMgOOnnKCy4FEFYrRktBg/W4kJq4qQ0LGQP8G7vAFOx5B5oW7RoXAqsGRr6khtFSMA6jj2xiI/Uhq0jePdi6CPW7OixGO+RhMLQMJ2Do6xqtwq9SRw3rYMgOvlmWOBhswU2A4yB/1XbPaaKbK1bWG9ENilmH0LbWc0gDzaS+yt6sirKxOrEDYiff/ldG+MIFlYxnoJKCeYmBVTTrheySJ3q2iTgn/XoZqhgUQCM6JRIrgrNUCH3n2OBqHu+BTVnsHa25j0OPdFG6TVfg6EmjawTB0GyhjdTJiXXEyc7/iVGCvuRFRUaNOO/BunREKNmlF99zkAfBfUqR59Mr4B8yW2DhgvKimLvhplXigvpH2GWxaaw6ZxILjnf+visnIBU34XFofSAxmJJwy+/9nhK9fts+a9jftZYbZ7KsuVWD7lLiZab9LqozXjTFCUoZC+UhXAfHJgT7INiVmDEHdOOtUj3yuf+cAjvsRjjii9Oe0MUvQ7Fh+ubnI8bOLeVJ4KRgIdmswNHxJ/fihBRRGmGmPTTV2cwFzyv1aD5LBFAh9d8teHnlc41mVWq4hVzEXKPVtttwjSZrMYUg9FO8ypJIf0dPKk9B6PX//7yzQ6rB3HBzgLawPzniVvE0oXsYoun21Yy7j6uecm21IGRIPF0kYZ+swQA5c0db+WPQc/snwsTH52dZ42SadKdXzRQJFppmUpuRCVL4O3V5XNX/zfTs2zVjcENnwZAhBe7unVmT3NVxRv7Tf5kEBYJ7XyXFvJ1iuwiuYS5bq5oPKp24Ydft7c+EyU4GNQhJIt2PO179HwXEfJZqGCISlL8qfQavcnDD9jwhVCRieWT/BuT/dA5YZSdnNFuwfg+FQEPqvM9s0/GOGxGjKjxUP3Q4XGaomIZBIUP/TrxQJvR6b3bTUHkJrFrTCPm112fm6b2RrtgeN8//Jc5UV8RkDlX76Cu5++zVFZ/dsXGInaqBg+ERkXyvLzCCU9+/jluzOydAJnW1Q8+DvnJZzxoD9ixnZuY6114QJ2qH7lUt5PfiKo4PFQxZYcHBNUnOKK0lXii5hnHLeBjfEMdHLFpWqCUMe2dlNDIB43zCnH3tlU5v3kzEUAGoZb5chxTm1B/Z2E89Oq7mQEKXC0SfkQAml1UnVmyjmrTc3meor7hDYCd8UcRH3303XSShMsIHPUcayYJH7OYVfVR1xcpobld7LHnwLNt45ewufNN1nJStG/QvPYUt8vQUj6zUzePP8KHDFHpywo2ZwidJLV9U7gtk7jH7TScWUCWeOKLT16rjbc/vjJT7ijSJB2FsnLZ5gzh+gMB+Yw1VdcQ0X3Xl4tY5JkL+OACNLsluybMn9zsmfecfjIYVBafhpeL1qC8IKha9olkz9PvynFz34+pXugN/6cvInID+cT16gXs44CkU06e/+bTaNobhs/M6/NCI41JBUqSDfpXINLgbiRST9MvnHTFxfB/RpqjJnI0p9Z6A0SyXU4UW/tVLGw6c14gUIkWgGxHAcec6DyC6b2CMFXPAIKJ/rS/A6zf/6D1tAIMxH+5VHZqms72ECBtBgtTiUKauQACbd4LGTjMyFCVBiagxrDyYyr+pvwY6DVCqHCTlbx3cpKvpDq2JQmyDmcLU66w/f2S2GSlpdKllR+SszfmE3UohVwk3B0TMstO0iN9kQYVmE3OHCe+r2Mmyvn+Q4vMz55YXLsBjsz5m3eDtqevJ+9QL8VoM1jJIWeJm3/UM1D02OwdyBxgGDj21UWj2uryWFX6zbuLlRjI08qziLCjvL5J2wriMCdQDpy683jk7IdK+dLb2iLVpw4EzO9bXjrPLDY9x/AUXrKao8qbirJIHQrR+ebb6R9QsGtJqOJ9FanJ9X7R86VcK6XiBsC9+97mJ5MiaD4NalCu5Mwr9j0hDxr1PiRz9vMeDW4aplEP7kHrr3MBQlJ9HtzU/UmL/9e0UOYJEs4ND65qJ48ity/9UEnmhxrDu6GBDUAwzVZccdU/h13jYhxoIu95AgTWQPAQUs4z12KkxtJjDgTmzMLCoY3iJKrNt6qVh8K2kpB4HHmh4kh4d+azbrtjlF8S8uZInylvvWYFkt4uLQiY1tdcVswG7GiTOQTE6M9+bte4iqCMsjg3va3nLihSLm/NUPfPecKLq2tBnYQdA7BCm1APnxVdrXGl2qX68FvgDfHHbziC23vx6we5OBMSknyDEk5YKPz3rpcS7S4ddr4cCrGxtBFg5LO61fTorjbbgY1rgMO+d7z2S00XJVEyrwe5dqcFPO61oNfXtLd0COzSOUA/dTa3bmp7u/Xwpm4cvPf8nGYGl5V5Ck/OM7gKcAzX/lAII4biItMZ0xfMOlCK2C1S4wneLromcyWcPB9x9wO38UwZ5i0eHVBPP+GNz3Xy1VCwRjlKoPTta5xO2muMj6HheCc/bUtCOD2OjRDxozAQJufxGrfF7NXGlzEsaYwGfEzVtw6/XnALL3p/I12msmk6OyVYUH4K/65MW4aMWKyy5BrK5nkvRt6gwcMG3ErGW4b66Ye8LNk80ICHx/+JwZjsieMvyHR1HbCW070fdOchEWCvoPLucD4nr8KvUVFWmrm/IRjKxJx1cKsEYEUGGqbXlO/GG+e/YKyheIAnvNi3P5GMvFMCKtwl83nXgmQ9WZB2rYFs8afGc+/3sq9bGoue7DXWFGezIRiTN2xbDd4MSwMugXZZzPuDH+O0X/nsOTf/13Hw0+sKsnhjBLpr9UBzC7OF7B/+blQNmdQqiFAdJAcHTag04pVdQ+FOUSmbV9JVQ7H8ZyFqN0z+dnIO/xLqjkRJn1Nd9vzafdnXnkdVPoAWVDqg+h2V+DMSmdIJzV5Aikh2F8jVdkvMOZUyicBf3g5doYMbTMlDQ8RuFp5ycKnm2KFCg9EEsg0mzc22PE4HB5w29as3uX/mnoYI9gTr4lZYpXVovV/qam2m3iewlegbDKd6PXOr58CvBLYbmiX+ZL/PoIzHlT9Z/NcymNsEdNWwK/pZMByXwyHdJOyf11BGFDJ/NBz5NrCiXmj8mx3MWyidGXqZlAWpob7tbnLBVBPsQmL0ikRnNBvmR+KRuQ3jDatnL181v7lcW950eeXK31c3Zhvm0vGR+YYcs06LoPKWObcVe95p7T0xht7eQhBVx5MKxMgXTZuZW/g01dBQ/vuiKP59ciH/PbRNJBi6PEXud2Ncg4i6D/+UUf7fUn/YTEE6mwmq6/x9L5uBhbJ5HyqJ8LIBQJT3qTTNEHYRXtfNwhEwHrE88cVjtUV1h1v8Lje1/OAPQhILFJBER/nhaDzU31nhxhZxrI3IDp1KMZvgIl5Of2m4VbbIFw3NbiylZJzzSxNUR68PNRLyREcjyGA++TvevJbKmdLYLf3lKrou2Tr2D+zq1IM7TK7g1ecgAgIz0l4F09ph7FzAWNZ1itYqIruU5xYsfm5hzcMpXABIj8myxyjCyhdZJKXLVtcZxIRPBxxJIu1SODqbrQKmZqHMV+zMDCerokpaWSmtqsBcQOsNCz8JoMeWGcMkMlRn29tHrMKGPFG8EFPe7wa22KUVCyzxv6XwS+zSJctq61e1MhMjlG7o1gm8504LwVX+r1h5yIJZHt+HA1pPR1l5G2aNiP+d0yUl9htSDaYV/zkmDv6mWBdua4F9/CVKknZ90sV3f0LN01f6XKm6xutDW0zxEUe3yAXbIjPcgczHVhKg5MOvXPxiklpW2tHFiVrXcLR5kuFGaG5JcbgsRXmFaM35s2/8JBdK8RXctV8YOiQ9PQZysYWR+pUYhYKSf33lhGKT/mlLGqp93G6jZI3ZIeZ5G2UasBVz4pOxSrWvGbg0duDu7uECz/UW+4Olbm7gVQ76pZYEqVq8V8rB6xlmkppYgrv3cKpzS5+n0UfkHgWNJ5dUE6qDio6Ck1GdNBSBmAUt8QOnoRQtNICauMfn46WEyIojal2Qs8f87qt/8ySvFsDtHVPRe9t7pHyCZGGywrP3iB9quQ673eaSNfw9Qj2b7c7nopFYSIPBSPM/S5p423BRP2CXvrztn0ttcbUgpIxLERKGCIsa8lnsPb28mx7yJY19XfpAESbpcsG4FhO0d15G2AkFHDfoZIF5ooEiIW2R4iQcMaEVhMvi8/eofu1YR1ouxK25vdmGjQxxo8oOppAWa9viOxh9jpTCbW2vxT7ykPm1WlnwEnPH5Y31jEv3+zZGbJeLXg/pNIp0JheBeUH3AkNler3LriaQ3xF/EAaZKWawrwvvh3ZYs/8MumZQ17PY2lFoa1Zv4v++3HbraFddNGf88h1f96T36GunyG7oe7Bibb7Ml8m37fOsq2tu+w8pVKL3oojGYaSaDv9hbyF6eoYCGJwcUJrJeNF+asV24Y5mi/95ch5/F3RHiKB29I8bYM8kuzBdiZLcyWalf4qLC4+Ie3L5ozsTA6A++P0wzE9yi1KV0ca4Ce4Ec/+xbWSNITY9XioAgzbhd1ySTVckboNH4m85KTb9srnNnwsawJAP/srL8tGSd6GzN2R6Nbf11/xngHEv6iNXkl89LrrD7S2+hrf9mf8VGFz9MswUXLoi/RD55UiZN+Msb/87fxg4vJ1R044B1ysv4d82FWnRNIRxCyCn//mXgNnR7NGdyzwP5ytf0d87qykMDfuBhYMX4X2aIoj+7WKp1zIvw/HYyZ6uDl9uG8XNvHF4GTGq6YLl/bzM7Rvp3OPne3hqPgx7ZL/Zn6WLcXEVMoz8YvEOUnm/z8erp2T+E1H5vwx/7sTdAO9Alo1e0X6MtKP/VDaOXSN3SjuY1f7vI16f/LgloAMbrhwt136DoOt/NhknNyicMg5mXfBPxqk751tCjAxI9ehi3c8ASbnENK3foHJMo3KLIVQqPPfsQmsUA1USMY7W6v4GhuDfELGhXemUQuVUWWih6H+fXWpNOGWAonWjHbp5wNjnLwuxuUPlmLWnKkMrxX9dEG9LOUswGBpHFdBVgGj6lyW3dRY4ZOyo2ki7ZM7lqvasDEyLMQNqAJZmf8fMOzoLHVJojrUuopQunrOivceFpmNtRiYkBNaaK/2W68XHMf2JNEUxWX1NS0f/oOg0AqwF9g9oTfbO1Wr7NCqztarYMuFqSeegtLjGpIIJwEwEW3M2i5v2DqVEruuAOodlgONdxhLYDVzPLW5T29Zo7FOozLamQK8glebOUbcMULfJBEcBm1p8p7V/rdYug8rsXQXVShZzdU24S6WjPlNHeg/gb+CrbENrdXYtzmy/V90WH7OHBWuh6cRG0/r0caDFheO914/kw49WXY3pMuTgo/vZC/r1Jr1+yE2Mu3oAMer1DPnv5AadczMnnw+Vg4lNMk5fzjyk0akwSItYVvUVD7QZC3snRhMkualAa8NfSw1/w0V6X5tGbUqKpR4FjHJfWBaiUotW7s/KLD3TJZbpEpnZoIdQg9zEawLLQstp4A5Vic4kqs4IS0HXej7rq3WnJKrggbJtlif+G/kGLax3vEbnNAndGaKzF7KoBvOos3djkSNf+gg9Tk2YPARJWE1ig+jfxXtPo6fLB2MctrGiHTerIjWGhErVTZkUvd2wNV3wCe5tKClOVHSX23VPHOJRjEY7TehJG4qbaCMon1o8VbmkMBg9h+zHyuLk3m6Z3dYjk3sVKpX7mw5UiqBofFhOUQU5GkdRNFiY+44xGdIZtWoJCavVZr3k5RtOEqR2mIy4nVDpaNQAPmxCiSoC7d9azm+UolmZLkP1TbWVr6k4fq415G4dN9Q91F/m1j27P5sGG0mrXk/aEchkJ4HkdM+p8p5TCNSDCgDAbFAPz4MqUA9KD71mVlTtZunztC1ulPSgFAA09tchD9KXTcDrrwy5ZsrA466DcRRzIm7JQNM9zoA1PeHYdOK+lnWvp4iD1pc+dr9jcAy80+coqo6pbpQz4EzPtUx6i+zfzpqCHnYcPmvuq+7aBj0GPQd3vXxUPmGnDSfuIB0ZyEQWspGDXOWZC5v++SO+m8ssYXzdKfP52n13ugKO9FNXqOcoV8Sl5r9aAq3a3oHZiNvRZEHjRZlO3FnQ/QeWJMAhtYCwpB5Kvyodchn5Idnpc6FjT7qNnDkTZxi9amed+V1jasZJ29Miw8h0CpfVW3XWyLt6BZJPFO9h+VhCdwZVp+jg1HTCVwWzMXtmMyE2DbvFL1NMmFJmkZ3/9eIR2+upN4ylP5es0Eh6m/bBfHUz0zL4ah8q4bYJmJK19yeeOmYmAqBQJ7hFAvLuf8fzVhK96yh6/udHkaZq+uDjOe2Jq7Hxs+bIkZ8gy2wF+LOsvV7UPskj/eST6o2M9cifnGkPkBikM9k4opLqHEu07JWYOa+cxnY9xNj/eqktkabCE/LuSMkrJBOUl3yhzLKvhAn8Um6X1drRmaN2O1ea+4pYgs3xEHoAPlIvhtBW9gjM27+E9xgMgF7wBxxj98P+yXFo29iDv2F1+6PsPYSLIptbc/R2kYQiSXrn3R997S7pcHfKsyXzh6E92xK9EXzCYMweS8Hm9m72e1KTH/wUCj3KWuem2tMGNHE6D8KQtg+vrlUoTIDXbfIUgycZsZgk3iHXFocVj48nbQJQX2Xq/+FXp39pK4D/QD9+bjrwX/RP4pYWJranifcB8IEuL2gSD7v73PcLzvJ3SQRiBAD8/q/8GQLAX4/inn8c/tixJqozhtF/O/j/ozXi3rcD/+3O8kC825WONUuMqmUvfB9bz2NPHqf/7GTZ33n/G58Qtwd4GTdOxLsgCFPaT2yn9OYwkQM+tfMWv+Wv+30seJABMTp4QyZOyvPH/KNHXC3WOp+xIHHSKFzhLhhYV1lEy7j05mF0DCwOOuc/eYfzocE70Rusf6DL1kMLDEv40SnUA5vjNT5MLUf83NoQDsdSSlnjXnKV3nLrOwrbzIySQzXOM6lZPDT7hCpI5prLnl74aarUhiZA+qZJlyQ0qE874JYmcSB1vEp6TxIk4o8jSplx49v2AJNq7UvMg7WtmDJZ/+Oe81h2gK7ZIZknol2BsQQsS8JxTGiLB1oMtlMb50ZwSZfsyZJ9xkAtBAFgjh5gJjoFQ8C0lBnPD5+i7Hq1f9dmXyug3/69fb9rHW5Qt/TuzBTtayJ/gpxnfxNVn24kuEMlo1M8uussof0Ty3gjE3sfLLjQ4hnUZQDogqNc8bJx152LPoKzKFGc4bSFUZR5m7hACZ9GcOBC2/1Q6r41nDsSw6cI1e1Geh+hkMl8nNP3LZe27gR+3P+1f22fs9+NHvMuLivxYAi9jBQGgmGE6BCxRoSKxrLsNl7e06cGnvkUH0weT9SFQBHn8fgkbiriNJexra0L3GB0aCpr6YgBk5L29WerZzKJry+0cE9IgakWdy1hGKnUqkg1zdTIAxKjsr0daGdPU1B8/HWQuNwptgR+pilxV3t98Qrs68vZILahOzdbpKEXSO6fuEtcA3fUQyde7z1IgzL1dCOAckvSiLZ1rS+EXFgMosz2sw93zpfcI7MW2tL7rCcEbnQkzDTbtpPHvaj994dxvmnD5xIr4Hrv+ka7qH2U3lYLT0ETze6xuBl8w/VUT+Bl/OVOOqKzNy+A4ZBjknJxOc1LKLiDM46ZRRgz6WCp2e1DRAghKyCoAg3nA1KFjOMVifBgmT8L/lidxQnfLZ61Vj3QUizkMx4OKap0HcUYrKqb6Ir05sJ4b/byLf+VJIxXtTjVnvnymMHWc3DRleazNCqhH9Q6GYDG1lugQaG4v8I8mA9dM8FkCtZmYWYD/6JebsqWjah2/RRW34ff0oVGZe6FPPRCujeYq2Ul5fqG6+Bzfka8SmhXDVh7VdA5lY/7mfYjGWZyyTaTeE3/OOhoXwG4ztKCL+2SyrTDRr8KctjRrv2K/UJibOxmkCCf9HLnVUuUjaXF4c2iGtByUDaSZSDk7V2srPts5UtGoqLVCIi5v2sQrPnL5eJcaQ99Ef0BN0whTVA2MmeVHC09sFLwdTN6o142b8dRE7l1SeNVGpEWIeUXMBuPlnCQcXXzfhAOmCvifGyO+criXHWckBFcr8df4tEDtYwTN9CckIIAHXMThkPKUBBh4gCrABgCsLKuBFUoANz1eN9dESTYnXBzcXem2j6ilt9dx86w0Nh5mwrdTzrApkJ/xrwhGvoTnhE3KCsvfkMECVk9IQytwvRpQjcmVrR+3zkvq+8bURcXSQlZw3rJMDAxGdvBzcRBi4TeRy0U8hek+1PxrMK0zX+PqMEyDANsXC6WViKtZYi5JJB4v4pLMie4G0SY22NxdIKd4cAyCqGcdpolkuOyz4RhsSo8fCXpJTwnpPR7Qp/EN+G4FMCT2gbmLe/9mM0YgoY/C1CGEAAxIC/u9SAJSBJCIQICP42OhXCQAIkCxeb/OzKBMiIVqtSo00CiiUwLhTYqHTSb0G2mSw+DPiYDhowYM2HKDAubOQuWrFizYQtlgMEZY/8lZpaqfMy2UHqYe0QOTeE6KCQsIiomLiFJB3CWkZXTrUdvRb8wLx00pJDsv6SjxoybMGmNtdaJKjDhhBKh7IQUlFTUNLR09LaK1s0srGzsHJyh/u15+fgFBIXy/s9YXEJSSlpGVk5eQRFdcVqqauoamlraOrpYJAEqHNxADBkvEEt3Edy2bA43Dy8fv4CgkLCIqJi4hKSUtIysnLyCopKyiqqauoamlmkiM2bNXfKiJaArB2vRjnUbCCwLgdji8CFNmgB2/QRCfelNFpvD5fEFQsiKbKFUqTErodeFPif8JgKQAeBEbzCazMKAM7rZHVAGGJyRCYFk1gacHhs7BxrDycXNg8WuyPHxC/AkQiIkB5goocy3WNJeffrlDRg0pCDA+H99EyatsdY6603h4RMQEhGTkJKRU1BSUdPQ0tEzMDIxs7CysXNwcnHz8PLxCwgKCYuIiolLSEpJy8jKySsoKimrqKqpa2hqaevoYnF4ApFEplBpdAaTxeZw8/Dy8QsICgmLiIqJS0hKScvIyskrKCopq6iqqWtoamFCGRdSaWOddzLfNGmIbpiW7bjcHq/PrxumZTuu5wdhFCdplhdlVTeX6+3+eL7en+8PQNR2/TBO87Ju+4EaMNxoIkizhbLa7A6acbrcHpbjvT5/IBgKR6KxeCKZSmeyue6e3r7+/MDgUGF4ZHRsfGJyzdp166fMUy619THXPjf4/md0zpnY5XycYZf0s+tGkx2fh2RiJ7UwGVRW7IBKJx2Dnbpl1A1dN/ZCucKV0XH5XPz/Q5guX35J7lSZhiTph4AKQAS/pmBnsIw77boJingEKGPH1SGfhu5UmbzZVUvoG095+IzLXPqgWaIJUzDlu+z2dS8S3CpfAYJD+ygnZRJIMgLAafWnypUiRypuhBqhaxg4Q2FeP1e3IYbh17KeleExrxWSZRuXtGH+QpY7AAzlW51fa2Rp5Xssnfrlu/Ou6d7B5bu2l+ZXM2e3WpGIJAKB1NF3l7CmXcFBtIBaqdZI0RNUfPuO8YMJQZpwBruZ8dGQusY5B85B0oH0kHSQdGA60d92F4bHj7fPk9eTnzINK47Ayf8YsQeWHa9XJ+FhUH3FjusT7xOi7eFkCCbRx937icPnXk9W92nH0eNFw8q+ngZzdJLRMQ5UElbDzScN+GYz+0bpDWYPKCPiSC69ru3o4R8W7IYkDlFpeI+Tx/OT/d4pme+hvXw8X1zsj6Ppf8/6uPu310x9b5ZOHj/gl2bw+fW3jMdff+Dp/f3i/Ff3Z2X62S6er5fOu/8v7k/ern+etu7kHZZfb7Voo+M09ZPj7JxnqzNnP5ly0pDcMo3fEpm9+94C2Hk0tAoV58qeVYLpTleQqlWiRik0IkglE4OTDSce8BGxuWULP0qcOc/sW2v0LUQH0QMdhAPz1olTaM2aJ6NrlxyADnKAcGCxqlAyqEBwIKpWqTVKrCUMB5Kq5KzvMOPLZLQAHeQAdEAHOcDOQSxd9HJbl627L1MI4mQxmx9E6AcimtLBRcz5aTXRWmoiz0rAk7JqYAqYYCqDIR1zy55RPYtTCs0SpGb1VFebOEZ6ym/XPdvcLAG/4ScanEtWT8dvAYLfbOuul3Y5EceXtReW2CrTLUVK4mvx1bIaVlMdApU3j9nqsYTLbM9MTsl3iQQCkhr/vNoDNfw7Bf+8PZ0do7rGEkFYDJpua0QkmrymJFEttLWlTGZYyt2wJMZIj1LCVFBS457Tj7wu5HsOfuJuwsswuu1SR28v8ETD0IuxSKS5yz1q3MxwblhuCkmsxRNxK8NI1xuouWSskduYnmeSNE/cV02MKohM22kaeaxhF8nf19jVBJVatXPEltQo7R54e9T9Z+/4HsAHoqIhmGSkBzzwR6KNPAsXw4CFbBVmWdZg2ra3dcTNiL1k8qzpskDRS0k41ggVyrhsQmFVXBCVtUqRsqS6NncgGRUXXrmIwhBeCu9d63pwJHoE62zEL2V94RknOBVIhFGzRY0sqBrym4Ej9d70iaUwZi2p5QsFu7GsCoFjglfqRldFR0O0lqy9+VVHywf2wgRWiGFV7UjhBkyQzV7iVhqDKFSpZ1Aq+PBo3Mcs9zEjKVKWZ0Rg5RaKnd21wtPBegvNlZ5vNtU53F2NZD2pYXCNKGiYglSUfCXzLYeR9hVq51kfDJBxwzGkJM7qa0VwF7mtnakpTiyefM1UM/IybtqdMkVRzIAAH7I5Ug0hiRqnKK2aFd2t4abqJhcQ7PT6jJ6LuH67J5FTr+0oRKCStUJHfvuH+VNKmBjLaC4xEhQCdqN59lLEKqLUtXQOmBOtCnax2P+4nb7qgA5xBha0hpnwoJhNDEdBUIy1il26CQDsSUKCMA/vfCLoUBq3wKwoa5IafV0RXDGZ4OKmprzTvA2h2YKik8ISFGW65bYmg+cm6XQ5JYqJDuSgpEVNMTXWR06389+XMGK/oJAXs4stFnagUfV75+YeWT7L95LNPSKc0zrKmnBfNdZaEi1rUVx4qhncgcntslS4XwZjEEyhzM67IhQVa4wLbR7LJ8INnhgsyMJCqRwD81wiGlgrG6+MBKtiyUa6auwchhQxQeofVtah/V8wF6i8vsf9yv2fn+v7j+5pN06byx+C1b1hOf/1RtP2PyDZdXHKymLwfLqa9B8XTZTl2kEJ0oHnn1jZ7ouXWLpMZX+yr5bqiORAclRStn+rVG+o49QRPMAjeO38t6ur3qPUNP/FJm/hgp8yq7Ujuyv5RbCjK2o6LRb8nuAnvv/fXwMNNtTa1rW+DTre/33br4EGG2pt61rfBh3vg2/7NdDgDgEAAA==) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}@font-face{font-family:"Poppins";font-style:normal;font-weight:500;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAABVMAAwAAAAAMrwAABT4AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIIACskwvFYLgmQAATYCJAOFRAQgBYNIB4ohGygqRUaFjQNAQL1Egv9PCdqIIVo7JL8miseJSwp2RuaJds5YaL1igKG48JJEY6o1vwTNiKtfuvAn9CDoNi4jBAB16V6haeJyKP/VsqvcTs+lR9O8n059vhbcuD/3jZBklofn9wd17n1/oDTTxCg3ysnYJLVhW0R1wHX9fuC32SNkUjYYxVlBKbTCp1RQQUpBQMUK9COuMZZu14sOzItOF9FHOFsz2RaZSbhD1bfiuPfgLX2x4CJJihcxH7y59d4XjznxDDI/l3j2m+9EmMjIVZA+frCMovGvwbbQHZq6JAjJQ/dh9rLM7b4BK2uWHvPzdf0hqrPJnDrnxCAz9sLIJwPaGn+jP+w0K430Pnx2qYSGtL/m+rLd091LlGU0bv4K1cKvMflv0j+T6WQw+USQWcjM7t1lDkmhRiB3rBjKg0Yh9PmT95BNygrKyd/HWloZyHUSoogII0wRlRyv7T57PEUBtJUgAWb8xHIzBMMDahW0tuXJg+sZs54DXIjaUMM5AUZ33pTauCsI5IX0AtPkXrESN7SssKUzXgtv0JT5Gj28A6BnRyzux07o1njS2wPgJiD7K+NAD3gggQJ0goOBpXhX5XC9Z5UOdMCIWZh4TEU2CrA0qqI2msMfr8XE+J45FVu3JcGdpEcMGrhGE9F0HBkCmD8QwLTFJGEW8lGE5WEOV7R9LP2W2bYNBbeTHrLxfwjVe/X/mlMVSeA7lqFhL7DPn3o++Bz/pbcDt0/deiXhAF/cTmwBBLHWtJGjgfs/c6wFLoHWPwDtWwE0V0C+TS/QZGEvGcaLVYqK6ZVZsRpCx8HVM1BmVgbcpepYUAs7bnqaA8GmXSBMene6Uz8s82Dk9GZCJ/2SVjMx6OHvp1XgiQZ3utVQYl5hCpfEREqKg0AKS85vNT9NlEYk4SOTXYtkJGO06bmi5mXmg0kUCh4fJkKpuanDsqGpySobllPyazJFIzOSdY7mIFNvAgVPJZDx8geVEkIhkWkcSiRTycW13JKPKlTaZFxpLk8LJkepMakJhDCVQolz4ClJ2ekgKp7S2V6CLq/H3V1In1u+NaWP/KSQkw3Lgk5sXMLYRaLnO05UPmJdAN006X/bzXPOsHEOYztPVjlqX8RYPP7Yrbho7ln6/zT0BQYyaQyBfoAN5KZPCdGIn8urooaoYhJQV1VShEPk9nuvWZmz0VaP1aBblh2vuCi28Wkccv7zk5NvxDFmEykcAQYCDVSnBkNhgEdFDcw2hH89Ig5yevihGk6iPlmce/fR2/WEEzWC/TSLUqNC1OsjfT3YiNNhWM+X8ZwLt9fsPdnE1qOA7IHnQd9zorHV+vVFgRzkJIwoOsYOFKzo4rrET0EKB2WYQ5Hz7UW9QOhnX8CjgYo9Q6mPgBsjVFwaebdxtXnOXTtoM15XeAGVqkQ9ETzHW0u11AX9TroXmqTyPe1AT2vIU+EsBNksh0AmpKRWIRHTiABNCVj3wP7HNM4JjkGz/DFaIIcqT7Y4aUFsW3eDvmLHcAvk90SDdwQTCfFb4vdSwhc4t0ZTKBDeYp4boI+e2IuxfWzsAX03GarJfUHFiERPdAAVoyovuzToJrx51ikIWeRaaN3GXy11ThzMvNE8bx0g3E1qhwsZ9pEbsI9NmvlU87wqbN5VsT3ugV/cbPFyOs8K9vu9dfT462kX2tlsq2JgBItP7C3QCQ1EQr6XOF+U6osugF0QMvCjffQ2pgFtyamBSpZAow+o+vWmLHQvapgdR107ww5wYo55RD9PaKzyv/dTjDH8D66PTis3Y1Ys253soGoYZ+SC97rPui5kdGkS9RiYQ5Se3M23IJatPX3khvsn83BQaCVEflZrvoOljM+haHWJpQvv7dsJdqD3GsL8RgYtH0ZXUIVEj2DFAxICUiExbfbyfGo5/YT0hLDnJtFMFnWL6XVnjtDp/e710jQbgdG8mAg7tAwtPVqw/J3mXVO2cpTdk/8w2hHm0QvUgBy3a1ScRZHTvYAUfQWHVJcFns7pj1xGlVfWsexm4eh4bqaEZtmc2bbUpBmhug5MQCuzFW0GEYM0lTNpOaocxeN8I+4ZOaOe7s6ViyUFS0wPDxurckaskbd29MmHidfKv4M2j2ZYeVrwRPJ8PmQNxOg8wOBd0KlLPwNaRIrNV+IF1QVQVMe7oK90o8vz9EF/mazvYWMfcjGWCZ1IDG0xnFzJ2idQvQoTl1ztksJTlkRoJM8/T/8vLbJ06b1kNoqX4dLFQ92h7FokutwsPUN1s9LmRoke2MbgARnZEk0ZKFsRCg54TDySou7XmPhuF/Wu6r5rVB54/nEuq5h47dkkV976zwbsHWZPdViAsfJIdk0cGrhp6OHznWJvvx95JhA+Q/wpl/PW+/RLbbyLz+KXNWQV1/tqg8wDWc58dttL8SzDr9PN43QFzAKdO0/p6HXhqnxZ+UymkAG/Zk/3GeeRFNJKT4pNJrhRrYe3HZr6tDQ3d3iaRz2tlGy/1IiE6BATw9QP18YU5Lwy+2Fg8afAnKrLvYo+BaS9F96x09/gOdyV0Ti6N8KTqTuLpN6KCqm3s1gtq+PtHS3SeLjT495hd+1ogc1Plkr71o4O+6a9HTz/B+6OtA0vSpk7vGxU37M+mFr6xU3nzR9DnENjegiQF7sihVab+3Q6KervXO30tlJqgmoHbSSDY9nqdrW2PS04XgKYerJtSACmll1xOAMoLN1rJcxCx1BrEAGFDMJvd+00Cru14XzDHOfOvm6Vu7NY2u95YZG6F7i/D5x+OnM1nXIs+JdRVfZURR5K9vf65XIZn/8U8cOlVB62zCadJ71UvSYizE9d+XFIGW5Ok1QgUomtk1XSPNREqPanIzw+59uy+doCRaoIa7q0UsETOruEWiA/cY7bUfuEEyaf7Gpr1Gt1Rr1+Eh23lPnmi3S6eaISn2UcihSBL7fGJmgzqb/BB9tGvsbbxBt6vYK6dqjYem7nN/Tp+YnftpvhOmBsrbLxMxvyWOFeFTi/QP7R1QBpbarBAU0pUs/9sJ0302v8qLFAXuIrVY2Y3uOXMely8/J0OUyjSMS0lOeF6lTKNItMP7RDc9X6phEXvXr+RSSfqzG6bTZjo6Yx2To/2rTI7dbP1aiGLKBE4R58/Wq93JFePj9GN1LfoF+g0QxZLKqhBeqqyrlK5TzDQGrI0SESk3YQ2sq6uWcMXna5bGCO0ty7qo1o6/vMXChRm00Gx0fuQlnpgIfShPx4vfWfn6/C1Df30BnYMaCFJ2rXqfsKtWWVcrm2UluIZqKyE9Z0DlxJs1BTMmQxlw0PqvX6QbV/P5rNuuGRJvpcd3k2yySV5ht12Xl52uxco9Rmr1fDj2AsIxpIVKqU5hQ0EzXAt2lamBJD+EDKV2XKqRKTj9z6piJZiPDzCkrrs2Uu1IWrQtNqmfm3EujPvvni7VaMQTyroMyVLYeijEwU2WHN4CCIxCtVfQXXUgDc25kHM+b0rFXP1ZxDGf3oRP/EbM9Y3xiIM2ipOQMe8i+Jv23cNX8RHFv+2Ol3Pu564gZBXmdKbOzau0r1UsLsc5YeC5zfeb2f+Y+5UBb+/kbNjd+ptsFXca1eWeAPfOHzzx75Ngb7nywZeWjPWzaT3rq9InsmpW54NGXu8PKRfV+e7H3yq8GAxAjVAi6OUpOSLtBkf/dzjM5f75C2c4OH2xTTxJUmCPLjiermlFgr6yq31GUV6XwqZF6FLx7kfr2q2KEnym/MpCq7KIX3CCPnape5cvmVhQKFlpU/UkzGBr/cmpH2S/ap3pISU2ufTW3iIoM2w5TNounx2fmfSzH4r7WM38Y8T94ZryngBi2Q79Cfq0os6ONyhDReQytlbaadY80MSaVxzNTuZ2iYUWE0e82SLB6G2JlABooP3x0bCoUUNuG9y9Tpl11dLQ+brxHNY35lsCxyslsr8OnG00GfH3/bE63Zxa8KubHzE2m8+laIGmUu7OWyhbTChlZN2ugs2nf2Exxo5u5BA9iHYTc3D9yQnHyOJG0qkjh/hSsaKDQ08/7DVL9MNBPqplCqCNAAWkR1r+XXypd/X9bf+yui8eohLeJZxMbPn11DZ9CjH7/a+of8oC+SoyOKfvGsVbHPRft6q80Xp5y1qJwA0cT5p8CBvq8rrMheEBvEqwXtVnSb80Q87oq1d1HMmWTfG3ZyYbUzrTzGet6tyBtdm1h967fhBUHXo1kIvQahNaPF4cyH0cmodxwE+13K/JHOKByHdPnzqOi7dsvUsWVRQWxU6Dqn+YPxLf7qTV7NtNrEP1eoUcLnckvEgsWl3Qlv02hvJwgGnLN87abn2RWAc966mipCdssXrx4DsbUBqyikpwFPufY+8X6afcJ5zjluh0RWrd/NilMRDuJERr2jS0NLOcmfFWxSZw/r5cCyPyStrY8b6w8P5Q2txy4u6iuqSqqaflLQtnW8d/dQTQQGTcNLE2+yh3uGO8fRJ/PJIWs0e4+AU+Yb0EwMsHltcGnfNJ95e1ubcYd/1RvdayqMq1vTZDFBF0VtqgbJwOK05n39Pmudt5lg2YOV/S0OgMXvt+U3BztaBERYZdZU0Ik3LGYlk0/MrbBirX7d1i45lO8dfql9pByaZ10u3zW29HeZqsjIuKl5zlb4+kTsRbJO1vHge19OHQbLvjZkTX6z6CX7paN2kDMLDoP1z4912V41qjobZG6X1VylXwTwtxt0Go2+XEZD0kwslilNQX96docL0+tJ2KxtDoc7h8V+bNwHk7SoyWj6VBRtig7hGyZKR05KLjWnhjelyeeGu/+RM0cWBTdfG5i8WtWBRuSAVrsNA/qXR4jkP9FRXQzbhG6hW7cC/6q7a+MHzT0xFybnr6LVlvUpldf6y/DpXYUNu9IsW1MN8NAPEEov9x7YCzPZO3xc+3E32m2rtRltNpvqZX4Sj+PsFlsX1rzS3xZAASBYkBpgszdSHI2F7006vE0rdorM2kIMgpfE8ITDfKIBH+d5uaHIKhbc9zN4A9apsog4iRrHIiXSv2RE0sJifWtwPt7h4wYv3Ypstki2yX8sznuK8YlaSkIjZKVrXJrQ+vqDPYcX73PwPud6j+NvlSiWFKVCcLH4pXgfo8pLHCdgseprAF6+UeQsCVEAH+PErlTgJ8Iquwjg2wb48VwZZ0ioQpjCSV0K9gHwsmuuFjsQZioP5YSVrKxagaizSt6sTUV7lixcDtuVEVxphzEDi6r1gPOA9TxgMW/jvO3hy398+YofXytjkkRuueGGteQl5YaDRqkcMjdTgLOCsqG1WSVpSiXDOpyKsmi7wldtc8Eo6FuKL9/iV43swDyauSaOmoSzUfHHP8h30cPkjQq6OyDMtaAEC7bjtNmr1NSLgZPTHQuYp9ul7PC7mTJdIgclO97Z/Rn7/9syWQq+fvp2fPrivPDPIdC/ybxXOkuvewbyGzX7x7jv2648VbawFeVFAv1loTLDJl3XYzqQTxdDWix9LbcxJ95zgxoJxv5h99lwNsMM+ZhFbpk5/9/EBZwOV2lu/bd8kGiR1yg/1i+XjxENa5Rv6vXlncWyG1DuKwXewg13d32vlDXSAb/grvC5eQagYlxJYNQI4YmfWZ/YWUbd05u/AvuHvaCTU4Vibo61uzDW0rFz4zQWb84nzijdEA9KYWCrSgRkPofbGy3aN9W7tNDUh1lH+RFYA/uGLWP36acLhZCtvvc4iKx/+aGMR6AMUB4LBTmzrIRN//+H1LwuHy6If8sapXzFayUXo8MX5j1mjP6CAsqicix9iSbbc5o7ukbne9toRfGwGXpkoUiwWvC9HX40A6/nPRBogtD96sueNFT6PljgLgJ8uHvFQQB8Qq+yPXv4bCfxWVMZQCtYgAD/so+3+ak055HrVEBn6+7HO3Y0m/vdHKPLHswcV6AEQXp+aE4K6FRzIjgRUzn+1gir4DmP3UGchZCZJ7UoF6jpFJpM4HqOlHsVzhrG7eZeO3NztMUvI4Z8CR3y85ImRfTM49Ugxc+6EAIpRpBbSGUDNb9BN0WQjgtsucohrNlrGOBXCVHBTsjMoPBRapcFz9zLRAjOi38v2ZfsOr2fgtIw8Vwzh6783AqRVcRfW4eqpRiMtFhBzG+pmQkazUCXKwD1QKELiHQArW4AKaqLfgkMzYV0AfUHBSC1kCZIL6SqIM2QMld5VAmD4iivn6Qv0cjJDQvQXBdcIF0iZK6XW64DGU056hYuddkVg86urxSnGJFzvjiK3wIY4L7xVD4EGFhJCMB6oMACrbXAwTREAM/Zr9qBkWD3DqwQa3fgiDm8eN0dQUiMBqHN+CND8IHN+tWevbzEWCO9GqHa9eJSL2ZJuy7/R+eBasWip1HOwKNXr3Y9vPJVaNaknU+3QkxsbIXKmGnoSTAM8zBAb7pxi5uQcTVa+4vepQFqQyqZnItdtgbVxsDFvixhMDeyN6MAtYGS0VGRjYYlCJ+XbcGCXvYsespatR9KfNxr30Ye3VhVRkv2Sfn0aIKai+WyLhvW2T7rYxX8D3MfRGJwgAs8JgjSZMiUJUceFg4uHj4BITGpIkoqGqW09KoYWVjVsHNwetVVWIz3GGYLNFqd3pD/PA/VmEqEmMyghUKl0RlMFpuThx5FTh5fIBSJJVKZXJHHflaq1BqtTm8wmvJf6LgbIYJiOEFSNMNyvCBKEIyg0JjMuB8pDk8gksgUKo3OYLLYHC6PL8ikUCSW5LyHUWevTK5QqtSa/OK2a6674YpETDq9wWgyW6y2jNgdzlrZqkojq3n8N+n+d6A8oULQ/ccZ2JLLY4GOl38iF2op8n5lEW0aNDukXN86fIeBWHmqBXW2bZjVtZqq0tB+he6A1ZQmtc+hW5xdq8+Kbmltg+ak9jksBLUD4VkCNZNvwKV8yz4QvXCER0N7oW0VD/+acEx7jTme/Aa29L3/fYlJiEoLEK6ShpNMcw0pYUzGhmIcvDgr5HCWNCCLIyrCjBWpsxq+Hod6/c6pfX/H3v6+/qq0YbgLPpxIObxLGpDDhmmS52Rtki9MK3eZjc1ra9rUUmC2BQmmNoGkaX+xNGmClOvbIeSBQrGJ1+Rc1/0OJQW/VcnvPqpgP+izEYRFfp8T5Mje/gWHDouTv8L0sMsexTnjyvnWreXEI0zXMXnOb7tl4TcyLLSfkw2/gfw4OGkIm7EcSDZEE0/9m2J4FkmqAwAAAA==) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:"Poppins";font-style:normal;font-weight:500;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAB5EAAwAAAAAP3AAAB3xAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIFUCucw0gQLgzYAATYCJAOGaAQgBYNIB4QLGzgyRUbuF6kFE0WpogTB/5cEDY6w8FewiRFiiIiwCNViu/tsr9/4UWMvAr0KA7RHNBNdUmOa90P/zMU5SgCu8gU+V5YdQeyqIxiyfoQksy3R8/vxm7PnfQWSiIeulsgkLZGk1bOECKHRCMVCMY/8Ozy/zf+jPddGT5kBBiBSksIlqrXBAK6KOdRFtXPV/00252v7LV/kXvw/F/Wq3V+yuRxsSdsZNTlZB2Z8qhgm+oJKAgQ8OBCnE+KkZeJ6aXAi79TZnw/e9fJx5P1/deU/WePAvfbZqkmVOk1BsmTYWYe9icMwPunGRRPAjojGYfiICUgF8Pc6y/ablshB8oyTaqFoolCXGZWhjuurvt6XQforr2wvatHrA+vQsASWj2QHAKurcilZPtQBVt4AQEVcUZ1rg0Wdoiipi46hNqjdeWYRKXPd30//G3rXtrTCjhKGA/C8r/kMFWBRpkxhJ07JdCBWJMAYIHQiGlpEYurVmgAeEgVVEEGN0s6nttavooDcjwlwfphUV+BLAu2zvrDNeYvOXhYowTvAjtWR6UvPVE/etGwD8AAge3MDsE0kIIAGrBIhjImR6mGHxF7JeYAVgv5fpaXNSMbzZR5sS0SkI7IQOQgkgobgISYWMTnxOUnI8VItwtFizYkJiFREJpP6p2oN4+F4b2wbWwqvzX7zsiH/cdUl5+23TdG31z7+Dfpr5UvpezX10o5/seINK+vpVRX1FxwzNN8uq82IApQYvltSvkdaRsdzfSYIrOybI2e0UNIHWaW2ekaoBy0mGJBZoGnlMwOx2klfM+MLUc4EmQTvYGm1G6fNnEZ7yJR6mJk+MOsDwg1O3Y0FgTE2zmm+QL/zkJoEGciOzqm+GNE1RDML2D7/C19vhDBNKzVxSeNkc5Syb6sMFzF2mSF6eAe0VPyjYtJ3zbk6BJmw7qTheiSf250Fcx+feA6J+XbMAfBl5yaNW7RxYhFQjN2GR3TKFtzqRKoz9y4g1dlX/V5mDkMow/vkdJmKYLd8tZYw0lrOkkN8EfIpsavPMK8XgOJZBlHs7BRtEmvyGOmrLVZtU70JNnC5gSU3mW8oMHDliuU0sgRTN/6saVziHxuMm3bzlWv5K1MpSqMLrN8rgJEOny/z1eEbeHafObBXBfJuUq1DR8OuwWYPonwLHaq3WYXPnsQnV7mq9Nn7fGI8uHdOQLSeHoYtW9jd2O5suVA0I8SXsj3o6OS/W/PEqmcl9x6Ceo9CMFJPnt2epGLzGHvgZWTI3UZwxrr6kaWZD4FCXJ/QxciagQHxL7lpkHd+MIxvUbOKW97aNFmu2ILvnozESqA3Ck+UUjU+yiqB0gL3Sp6c/gRjiuQ2BooKFD/Q3QZuwuBUQY/iV2oWc3Egu959yrZNxB3+KaLD768G1+D7RCFg8hqrGxZA6pGatHgQZaDCFyTyb1KRTzzBwdYPJ3slNQbokwuB3eJ46POJeO9VzjfJOpposdjUTE7NGRm47wMHxSTV0wwBcOhfUhz42//wVYQr3tMx1bEUrwV+x8t4ZK1K4CHGYIz9bie7NCkwyNmGTeMvhnsCP5yw3DTxLt7LtOJZ2LuFL8i4lcDBiLblkhTp+/N8+HylOOgxl9RMDCXwQynBwr23B3++plEqUKH0QktsqYtb0MFCHL1Q5y0Nl14pwZLBx5bsMx1OfchXcPIURwl8Lv9RiZE+qu28D9PbCk7z+U43j5HPujQUwu8RICMj5d59BqbbOdMeNq0GhUe/+ZyupT1M5WFcWzI1ZWE065reXu7ZOmtY3Tx5ls3Db6CzeVrfoNrEYsEWfKjcK58+TS/HtqUXD2I62/nyfgz0mwGHu5kXCaxBljJyXBwLKihJ5paMWFC57eWAQygYPmEZl06A4lCmLs40LbIekSyRYvoK5LN0Jcsz68XiCGVIuHO+G5s+M0+hebLBa+mM6gW/B7GR1YY7bB27wYQCPWgorp5U6W5A9L3nGVY0b4XXkquxBBnZ40EvNkiWLPsO69+sIjlqTTV8pd3RdpXF9TjzSTWZPL5DBur/N5lRO/gvZx+Slbu94k0B5iCyL9TDUAqk7IJwCDR60yLWuethMdx0uZ5rVp213CxAdIU2TulfzT/Ub6PlzHMVoiwtQnkJRbc4du2ahZl3UsZ+DHB5P9JYg0nWa/NxcAmygTsLSzMkZcvXrJJeEEuLfUAPnrBcJzYKOnxIgwelUmZ7c4twKL9c9AsdIqJURogupVFdHS+MNjomAGeuKpf5QuTAarLbLeHt0JwaWEvxeBDdCMI30aXdSE8xTPDhOpJVV9tqgRySkrjZYhm5bSZKQrDlYPDIZomxF/ZwEqwD/D9tTNfY49gtkePG7WVV5nFjTlFdHB69ZwchG/aWOrdUUEwWkDRIeaS8wXrdFJfTQxuaH3bjDxsG3Uyac8qQva0n9/w4DLB5C130TOpiV9a9r2RZUML6mkd24vTVpe/lDJRgGn++wtqN+oFr12UwM+Ib95NPkxU9qO0nuuTmNvBOkLqKRTl4iPMFVaCs6p/Vt6QnE3ECLRGA8GtM9SCrBhBldSdM+kAeWAwVUkoB9hVBKVzFndougMVdXxBuwZmyC52dNmMKZt4VB+5veInGcJ2/fEi+8BdGdsMwN8qV97ElARg6vA8+WtBUdIRNDiKv6DmHJA8J1eHx4c5wH8ps26aTBrzS0kmDKNsZMNFRaA1zjBCLu7U9rdyz3ei/L3n6ck74AI2SQXylrDfeahxTgUGp0cmB8Yf6fZtc+uZPKtdK6r036mSHDug2T556OMn2hfiy0ESLz4RsecVodGdNppaPo19E3d3n+R/k5DvtAF5F2cF8TVi8u/cVSmrZdh9YbebxNQDtDrJqq+VpYL9y17SRpQzbdXcQN2V4ayRR3FNQna4zywSjnKs3VuO6eO9AcCM/qMD42p7+9xUA8H0VP+4xyp2soB3JCviLjawvNeicYlHPpPm0ybKsejEPqaSP6dnW2+1kxKvN+XxyPAyFuhWYn/Cs834Gq9Us1y8Hmez/63GOGsnmS3Zz/TCj5tkUwurqiuR99x5xwzfHdnxSuvKbe4m44/vd3oRQ2nqDXU/CBo186nyxqeXcMINjTgMHTBfxfaz/ydXe8bkZdyGy7sjRPPDz4TMmobg+L4R+a7JXyCqRtSDYDj+gU56UIMNsr31FrKC+wC4jn/Y/f7WD4gfX6c68nihmjOCW2RvdcCkOfDE0b8b5PA7x5r7sbDHreWNZIHbHkrm3FPNuvR4YgW1TeedXVu9DXW8yOgqdB6ovz+L2V19CXmsyOsoGVlXHjEaFj4LsHTijg86OUkNqe2xLlaYLeXX1A84ibQ5NytG2NG7cgZgxxuOIbm7YrQWfcxYWQJVwvPPm354+nouePphaUDDv9geg0K/TcLkcEYt1Wo3Xiis2bw757nn3lhlNrKw4jJH1+mTSzrFyOo0GYyiw+MMAqvX6xW04scRPYLrYIrVPhXivJx+LFRoLaXQNukDOgiNNS5euzsyYcYeGBK3d5n1rT59aphXKQtfbsE6ClMcIRWFgxlq/9ORZH6apIjAXdregDu1pSKt1zw0A7I25ij15z6FIgH2cw1n57MmVsRV2sOYkWrkWT+YYtd+cuNUWv9VvLdGtwa/BTXbYak7YZk/aBqoo03c9d6ddg68DJtZ2JEgECcAcnQzzjI8uL450+hb96gT0nNb3tmzhgQuXWkcVo/6lPapEL0vAYmHEqXUJfjb/hg3b31EdQPvq733R4gdd+52aZo+4hcagcJl0tiSrOdy/vKOmqau9WiRaWV0v500wnY+1gNW/vK5WUFNK0JPLIeM3kQOQQ0InWd1ESeP65si6ZqKYw2JCHJLARLOlOzJUQEeg4D6nUj43ewFmj0H53/Wf2Kvse317I99/4XoJFgeUE1JNfomuXohuYkoosA/SNK1omGfyXpSSqUKBXigSygSlHNyzxhPXwXX7IaJS3hG24UBVCY1TTaE0SAXkpoZyWV2rBXuipzm8Gm6Yo3BfO68T8fkKlZAlkkM8gYoP5vQl9bWktsIV/wOKyz4yydxAVMgbiSQzmULRPV4JOdgQVNVGkkpbSYrLWMjeGnebT2cyyvuWiheVU6liFn50QsNmUpUCPk8hpDBUEAd8tAMiUISQd43fkEeA3ERGvbS5b7l/LfzGzf6iQbfW0dDijda5h8/wJOV8kYzFEinYTIFCBISrHv1vr9n6+H/jwMY4V6Ir4X+3BcAr3Xr7lwAa3unyVtT01ngiFFWRB5dW1BLEpA/I5C+IDQySvZrAdUwUwH/PN1ed0Bp2V6vI22qtAsLB+id2DEFusKlk5Sv8CqGxqL+qdEneonRxBpIkSW8i9u5YtSkw7HW/39G3Z9UmpyBngdSC9DcNqs27q7esfPFi7S4pkYdDqbA4Ga6YTczRYks+LQGvNuWWbmr/M7Tyz1CH+rmP4+eA3y3yinISWVeH4yeH5ghrSggqPIOl1IRhNlH+hyuZoWz66F+oDE/g02m7v9gP8t5zDByzVHjPNyKr1p10klj8BiajRS5ntDSU81lO0sl1yKrzDd7KAYtjoBYcHDqpsxz2eCwHTmq8D0MPO839Kzo6+9d0+Wf9YMRy60f7j58ssPdd77ODh0N21O3H9sc4OASg7wedRAcxv1TKgHXnfHtL3TxTlLXXHKeyrdmpsrrR1WJKBG1DIRgnPCUBLhIWgRHXMATGhn6z+xpsNl/DK+/8MTT6U8xvYHoeueywCXM+YwvGireAEesLm92XAX6K2yvw4KOvlB9/9QAOdf+C+BkBVsOG6Bj4OmyIioYBMvqYxXHMtb+SZfuAV2I/llrJq2woZ7SGop3JD4ul9VcZ4K6W2ptohmA6HPpR1Uwm22lv+P4mw/3Bh0FQvaxzxS1yhenJLs1+EfbkZesmXbn5NlLAG0eSjMmaLWX/JHiKZnXCueygL8hms8jkf6EgeBbtxbHMjC7GMyodomByN0zYuYt1eXQ5xKCbG0qENX3V0cZgPkQil94vQdSHmLx4Qz5DwSFR7I0UCZg7ZL9hgS3DdnBz6KZSo5RINUrlTfiGXtzWTZVKu6jCNv0NMDAUObQyaqjrNnQHAkxO6PZQ/7b5++f3gtFQ5xbSAVLfVvxWPFhn+czSd/Cf7f/0fmb53Np3aHbHbC+QDz0a/hf+9/Fw71HdUR24XsmtmjZDf3NkH0Ay96SjZrDGec8F7l6MH3X6WAXKG/ec0/eN4x7YdyrwcmHjq4Xt51aBcygP1gMeD+geNFaAvHpeb0Agglz4MVULqkUzXkVgC9tEvOXa98hYrbQYjZYWYTVUKlYvQw/xrWCsjgq++LcaXy5u43P7tFru8oBIxK4sHVfBM/BCxaoVWVZ09cuqoF316xQDr+MzRKq7V6avk6+sXu5INnY/hTB4gabSbNZUCaqyDd0p2hWVlcpOAa9P75mhmFyPfRzXMtOiDVVuZ0MU+GxwwygnIiGjkm3Ll3WnSpe7KpQ9AkGfXs/r6+GrFZ1cbpcqkLvAKIXoWkkvKJ2qnW6ZhuwQylltaHQSd+NQtaC+pBJ/TdWCk7ECHVydb0f9HLN/Wkek83ValW28ksjyhmrDdoPe+p9PB/hkSSWJ4pby/USJWMFmSxQSIjwDz75nyieBGu/+ta4yEQpGXSv4K7VKJKe7ULnT2TtgkBc/G7//g5ev4Bn44sSPh8HIw8HDmAF4GFdLojnSWN0LFMy6os8v5dSVvdHvpjHBQMlvTCovigxm4EXsMoGwT68T9/fylUrG+srpdNL+5QJlcaWssETLYGA00kI0WlJYrGGYLS4++OKfKgJLFBBwewvgu8qqwD8ywBhYrVh9gsj+FNiVhOOqFkyL4XgNARK2nj5NnwANlhpYwuVxdTkwClaB+7G1WLpqcSDnDhbHW5J94ad78mwKREYTRK5ClgN2RKjhPCsW81Nm8uy9W2/LEL2RJQSxo5AN7k6VZk/nCpwWuVqoLoXs0LqWdavtgIlEwdCAAVkKBfUQnp+wlwSQXXPgnc77yLX3kF0A/zPqLLKjeTc9rY5zyFZ4uHW43Xvdfx2Qk68k9weGvcPtVxZcSeHMAdCQSblFAe/cz5f07h88Oggu2f62B+1/N/4jzwdYdvTXElRejDPWTBZqlDxuFRrxEpEapQSxVhoBz5WES6pMoA39YCakJn6+oau4PI1SSI41xzjzUCW/gi998HYY6Pna9skA8JBaVZ45cGXz7fg0F1O7QKsZu2274piNT49qwFvkjKTZ2VkY/nPnvJlOELT+PeSJ4Tc59bFGyNg8J7DF4wlsVW6IAxzixMfTM/Q3Wag1KxRakxBgLPa7zIMoEyeR36zUK+hcakUNkdvQ1B5mqycH6WQ2k7Pk2tH3lOcEiRUcAfiA8fxs/IMbDOr1mzn7pxnlz4dzvp6kUCe/jj/7krHLU48nmJBICoGAQoIr64Oa02HPsyY1kxvhjSJnPR/Ha5YdKO49oqE8fSB6x1J4Jeyff/u9DqZoD9AYgtSFhuytBgWMmsXgyMiUo2wEO7kix67nksu1106/HGtKYqgnQauIwaDz6Wi0iN75BToCoBty0tLe9Tt4RuDHtw9ZjAN1dcZjdlht7WELh5KBwyYWzGqpaKPdLtqwWm61MDbO3qcbV0mtLGUVhVLH41HrKylMWZMqHqq/+1MBiSUTiVhSEhI6Uh/Pb5ApQBYfrZJhsMWzKJzZYcZG/3vEybFoLdFKHCksOkcknisqHCaCte3Wi1TT7LzYonkzB7arD+H142ZQ/o6DRHQwGIwV79gEkmclxQlbDGaxGJ0isV4B3m/WN1QoolpWLImRsj6ryd2dDcfnxJ6OjT0VmwPa7+qb9SDDVufSkLRFJSoSCafSF5M01RWqFGJXAcpDIosKCtaRwIGWXVOuWdf0rmnu3OfZ5/1FgsJTovmcBsWcuekp6xPitYst2QJqeeHdiKy8U0tFWJC2SU4pR7IzlEuykk+F36BkFWkobLacFm8iXUtJmUhK/DQ1n5aTNpaYeDK1aLsePB5+0Kh70Ak4SBRsvGgpoTE2L/Fj9roPAiiucXAdNekLAgHYam1vacsAoyVCMh4vpJWtFDVlvp2U9HZmWbe0DCR087a4zJkgi1+qNqDJZENxqYZMwmuMMNGjcWryUsK5wsL1ZGKnGA0TwFak42KT7aKttmdd5LSCpaae3D36slBjMDTaiuGaucP43S96HmNWDFQOVAFjN1mwc8wIV9zf8G98QTkLC2KVhm2hBlzORefXhHFN5kacmDhcPykgdnz0g+mHr+abezdHyDb1BEO3zMH25ff7wbitT33YudY9nqqYYlowH12fMXaLXbPfWdvpLgCnh050tujEXGby5W554UyHs39dR2f/2k7/7avuq3f84Ld1e7qGEsnePTt3ikQ7sYd56u49YLvsMKZLcHjMw2zOffewtarhCDYgtmWmF5vYZLWGMFyN73ud/Slf2dFsjfdtw3GwB+CQneWwzfB1/6bex89V62xZ2Wso+CIISJu6Az3iOhxRjiHiONurBfPjz38sSeWqmJIGi8Pqc0YbWtN/xOihpbU4dbqovDSXy5n9PK3wZZmQAUG5MB5A/dGUkKOUK8jJLxMUftiTKg26bAw3PlZbqU2txjMOEdANPVVph9CgcCoOOQuY0jYe1CVvywBsi5JXblPOYf8w0whzUxvktwN2GbIN3UlSn0sXUxiNR6eZG1MnoXQo9P3WpoDh92G3eHufWKNs/S+osL+LLy2VZmRmsIu7UExFWravFSL0FDBV6d4yWTFWx2BgdNIiNFpcVOzVFOlFtwT0PzPrwf91uF67/qu4MQQkfsiRwb3EJlwCQpdSqoFkrX3GJitFxA3KCfXhV5EDtIPFJBHz4PdRQQq651gP+PzXShrUY3yXoArGe03wczhb0XYKjSCPUnv7ZP2Pph+/XGDu857toSnthy32Y7W19gHdvE25jHra02deIJcy4F8NXLBUyvDvwC8F7MXRlBMRPK2Kbe8h0Ypp/CY6StDG4NMlSiYxgQfT+fleurCnfCCdyv0f0LRXyoeAa1RBTK0yigf2Dm7WmzdraIwZPNnLpuNKuKQUX1KCmxv+j5tJiTdTkkcSk0aSweJ9w5iEm/Rn4vmLq/PYnUP3BxnpBfMW1xiCpn2uFBcgqve7vv803TnZU/9KBWxD5dBq/uo1A6/GXPPHVyObf34xeHf6WFFemVRKprC/TK8loVSO9M0tDuBDm0P+vhAQ4XIQB9chq841eNuuBXPdNoUkY9GiDInC5mE/3Na83P2DWVOWuJl76xPFi7yUlLwXik9uuy+8GKS8/RtPCTIsYRnKT7guTdirylfMip9/Ubtanb9X/w5+2uc64KrYQHwO2GGxWOci9QIKQrKq4RZuZNIika7Imr9gy1vB9bVtXGaAPW6UPeky2+Nd54THtgI212pmgD2uyenhsaHZXJHMAHt8vHB6xlOpFKFtxIa/JbdigRlgj/uBPekrp8dLG4XN9QUzwB73jtPjTYlxtl2y8EY3ro8AYAbY44bZk06yPULOCQ9sIjbXNWaAPe6g02Of5b17BHfinSrAMv6lzPNRUiOzHZM0tPS/bc6ZGWCPO8metN3pMSiZAI35gBlgjzvv9Dhjs7EDBms91tTGraU7LTY1LK0dKOTBEr/QrVnwJbmwD1d+e+S5gCCOAGPR6ufaDzf+8m5KIEabh+q7/X0RKxqM1V45QJ72BXBscNQ62uZtihSoN33BsSG+zQLAF3ghOMC/Mlc6sqxB0oa53bXyx1/JxOwbfFDbRoLcmcCxIbXNQiCXzKzjj1g7Eyrzt+MTaeZso0g8cR+rzN/SzDwCmcDPB+d44ACgHs8nkGu3Zer8oT2iMt/MyyuC8WfKO7Myf8fPiFv6H3rhgfOTETXli4TS+JZFZwPmUNebfVkYYKpo3sR57pzxbz4i4inA2xfbA4APa8i3Zp8YXng5kcpUCi+SZvBbo/LCp6mS9XBD+6Xnff0KbTV9n+tRpuLK6XrZWY/R6Yryl1zn5dRLPfxCZdSfWJlW67+iImb0E1zCATP9GOWACQQfTTR+DWx6SbIcKk5BgtkXvpvcb3CFg0i1yo4GnVHwJV3BFAYEuSEnAdKOAvkZI808oAjCR++WVqxKhE6nh0aCDUO4r8KinKCFJQF1RGJDy78xqFwlyZCEfiIhO+FjtzBY+HpkZ247XjP6slleZwl6LS4n5bMijYlxQO5oyaTy6DocfobN//9ThCk4LTRhnSlBSHUQD1afJibDVKvMzNwEYYtrqrj6RVwE4uoz6ESCYPG4sdySQnkpMMhVnKxWlLwNMBPR/eUoLIq4ToKtSdn1DCbr5LO3IFEAX8vF1TmZua2+dDLKIN5P4rKZNAG5fkWsFHHuS6wRM4n4nJWTN7nrsaVGCfSvjEV7n3kMzdPAURULFpT+3/Jyz5x0ZIRIbupWmp6SdAYAqeNylEzzyr6XTEySkhxuyIyjv0d+OjKyrlMsSlKiYQCQOhiSlBqXyZ+Q8v0MUXg7me/FVHVslLEP8uF+llYf4TNRdVIa9kprU747qhOEq0IYbBwfKULnSO9iqal6Z8IBUxjgva3maRMtTLgs0YCrgBYOmFcrQtg0BwDPvMNcYTIdd4VbYLcrAo1NHynqihJH44qWiSwseKrATa3k7tOCpoRTtQrMHQitXi1Wi9BoqhesLjdeSUBGxXs53set+dcIQ65GNbc2TYiwcHCIxHQElOgQigwEsHRltRKF5vno12nTqAJsgnLfaCd2WjerxQh4uO+cI+iC3DUo4E2ATfBkaJViF6RNaf1sQSx3AT1KHfc7l1crYVVdhKYQHoRaD1tis2qwTsvgMloo3JcLHa/gzXwPVMIiQMTfF/1vINYcceaaZ74FFlpksXgJEiVJliJVmnQZMi2RJRvCUjly5cmHhFKgUJFiaBhYJXBK4REQkZCVoaCi7YeOgakcCxuEg4uHT0BIRExCSkZOQUlFTUNLR8/AyMTMwsrGzsHJpaJIg1Za5U27PbXaZhsccsbxZqz3pRV2+NkvNjVrrfd94yeHnfWbX/3umAumTLioUpWtqn2gxqRpd91y2x3P1PrIPfddUudH23zqY5+o98Ir63i4NWjSqNlRXn6+lJL0fh4C2j3XoUunbsv0uG5Ar6A+/V763rDPXHalOZ/72heu+o8hIaPecM2YNc55y9tGmrfRD4Xpkl4mC+dqYtqa3TgchBvaeeUc0iCew438r8hwcRCPLyUBAAA=) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}@font-face{font-family:"Poppins";font-style:normal;font-weight:600;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAJmcAA0AAAAB9DQAAJlFAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAbp1YcyigGYACCPgqGmFiFnFALikAAATYCJAOUfAQgBYNUB7QSWwewcQPnNsX7ivRmVcBHR94BDjDlaj7gthGhWPTfE1p0oIaNAxjwuj/K/v//05YOGRq4PoHSqnVT9x2EiAjIU0ZkU6uqNNVbG20bO6oqMbi1IQbBUNBG4XAnnTCnP10u8Pq53DeveXfsaKt7JorNvIToiXOH8jO0owkDhUyFuZFZiSQyJ97dhA379xYO059vnseOqoGZVuibc0W4T3fDIw7L7z7dL09aJuQRNKKRHGmGCRpRNAojyD95oa/4//e4VtuW2Ghu0Ov42OwJBUkrpJY7/Gf9dO+1LANs1wdRZFYvfMoQ/qP9+J25M7vfUPVGNamW8GyW3SqkgCcyTfTN8Pzcev9vjBojhdFjGzVgbFQONmHAiMo9SrINIvoQYSAC5mE0chjH6YlxYRUo2hhDZG4NIYEeQkKpIfUu18rulbZ3e9f3Smu5zZUkl1xKI4YWuhRF4REVUKOCtYMNBRRLR9/SEPxiaQy/rm93/gnKYFMoYLr4Dp5DB9M5Mf+oWXjohU0EraGze/cBkoRSR5i0tcBOo60jEqbS/7z+cncpqwbdygXz1Dz8YpJiGnSq5PoIosEmDTDWQjtqsJUG89AJPEHHfnwCmjCxAEfSGTuj7JR84/s8T+7mjW8wnKCkLGUlAnUZKo4p93Qa9+hSp/+rvpmB5NgFku6sILqE8mtYlm65DiuC47nt39eWvUdH32+BYV0PF/HDeWs/DTFl42wMNv/SnSMdVUaMUSZiSirbdM8UKzASZayYQ2fY73z7vM9LEyrNeAaj/al/Ch2FQkehUCh0FAqFSjvSqXJGw0YQIG7l4mp6aRjWMsj/CSumx7tbuwztAQGCgxTqNTl6sRoMaMlIxz8999Dmvj8DJLtAC7awIHmEnUQqCAKLC3dgbuIycwm1AP/0+7k8oESOlLhOyCZp4vq+6Ewtw3WxtgRHN0/o9y7QsYE8AOmc6/tknyLueTTNL3pwXkQcRsIgCZVx79MPj5iz7zBeJ6qePCmkDCnw8Aem8/I8zbvzKr5KnGmabaJv/ktnXr/AisVWsJ19OBVvJ63csdO0rZ1S2znvsaOBQTOIImEJJJe2hZW7gF0j2Q95GHXIzGjQwgjkWh5IotRgyRUtznuyt+EtrXISMpZrSSv9ess1e8w118u+HE65HeN/LS3p/H6rsqbHQV/jMGujGAHzGdnwCHACTPozG7qftHc3fUmaSyuHEFBK0CgkRGIA6LAzPuaEI3QZUWJm+IdO1cv6sU7xAr9c1MbsXML1NVSL3O33qvQrOp9exp4AJ2ZhgkHQlr3lMdFP0NpdqJt5oBYVFgYWFu6N0rJ81AvshKgEuZu3dhCgpcEDZf4AHsWPoeT/tyxfurOz0jikAIgBXMkpwo9NkLa6eu6qq7vnS6N0dhXO+euQQr969Wqqu7pHkyTvDzlgMyOYATQyNcrU5kamH36rrtS9mu082Li4YAd4Kxqi2POBxyIWzZnl+fB7KHiUgAU8ATq8AQsgBPr6/d7s6eBMwi4yX0YI9ygwF6oyARIKFtAIcivdmt/slXotyUnvg4FSaGtH69evkX+vi4GGpWWFrPB44/nfWWxQ/k+ueSZJ0s43eSunc37ad4UQuhA6zwgjhBDCE8YE03cdX3uMjVObG7R+9toUeC4IugM5kw3Z44bar/7n2vsxfWs+xJ+Y0b004GTqcSgnr/0Z0+rXiZnZm7Sr9f+ogBVLBaU8QE1CRZ74Eoh4uOLduVgYgE4cli1EIFKHgYzsUQUGo0qMRLZq7aswRUYlCkZmKUtQuvp2uEbNXrWG5weYj+JzjeRCxkaDZbB/UrBSAkXocHYEbFcADm7nrtxUQIfIBzCvP4IEIMEwdxQQqHX2ab25aogRXR9DBMRxwrnMcgA6IcnzN1nkNV2W/foxTeJddo0+4g0rQUdTv1xrj+7JSplezCn11yHOHcED7kFcRZ0SQunlYUssARh19BBCQTxWJAouACIHj4cThcMKvZTX68F9anSit5uhZ/eA8MGpixztoKZw72UgvcpP3NcifOS77k34XTytF+6oJaU7NScmcCfIIMDJvF9b2pjX5IR65feZbbkXE+CS2UMLu6Dfjc5JN2M7txN/g9aGTX9ZCEiDaPRThujipwLRwXvFslOiv+wjqAwJv97mgDqUyQs7UDnjH7dUhSwKlf7za6XLtqXwyMQbe1W9c6MtQU9VcPOn983l0II6o6Hy4FyTp5e5qyn+XjO/MWhjLg/1SCMueBf1npjKxB5TQvJGmD1B4RYsPud0+71f8P77ps3cylcWNIQ4tFU59M17lRVqFMlry3iSFG1upG19N7XVHzZrHOtAiz4GMEbZYCuTm5afeakXTJsfdoCtyEY5rV1e6NY9mmJDHmZRq7jgnGsr0I8/yzxUj0qBQrZRAcrrt4FQ0g5VGW+ML9W/4ekVrsEJu7AIo9APrSCFUsgFASuCRevo11KRkxCiE9HQ7fAPsWjWpFH9OjWrVa1aqYpuuJQIHwcTLQWxiEMjoCBeLhqqBugffWjDkS1yY/Ojxbr5Nubn5rY7xa1ms4G1WRNHZnFkq3En8rOBVtvGYjvn2qWJq3Eca22y2iLWHBZbs2iIlaiCW43X18o1MrG14/tmrPknuhMQNSta+QFPLsI016EPKHywVMhQuahD96JUzjg5OZxxvabQZ/6Ji51KHmmibHoRzlkUdgAWXdOcQah4d29rsG9SiZWC37pZr63yZOCVg61/zrdB509hRK3nANGvOHkBHW8DdQr4/84IhnjqqSiDsw2vgg2WUtAsz0mVlNRHGU1xF10qs3klA2Y/czmUl+Xklz0rG9mFjRtaUxgIigRUpa1GWUi+ebb2E1PZr/zcunNZK2cT15XWenTlRxcFVlIw8Z1uN+f9qvcLlTSay5UduZRk76CruOQ1i15It9lq9v4dbmXA0Nr4NLexY+ZniXSWjjZ3aTmCAANG05O8L0+BoLiNalu397aGY32FqfRZqY+9hEd8rYktE/l0/F5zfGfxivTRLnu7bJUq6TWlo6qhCzuprYIkvVtlUa0Nuex6+99ArNDVINeHzLzk73a6SykWkSILc/mzYwKo8QSDaMRFnMQR12TTf+RpQqWDhs4QA5MpS/Y4VLQwRib79egzZNiIUROmHLTosCNOeOChp57bsAXqoAG6gxoIwSA4hIhKjz4jVqzZ4jLAmJhZ2dg5uXh4+fgFRMUVlfQZM05BSUVDS8/IzsXNA4MjRETlFJWUNbQNEEg0WUBCWkPHwDCGJowmsdp0NxAMQyBRaAyWRKbS6EwWmytSKLW0MFYObh5WCmYOgAHL7UjeHzAOKZHqWseuAgajH0Hva1eqFsSQCTwWp2MDWKo7MN+WuYx/WFOoBQGGsyOA9rjiM4qszKhdp4zvFwV5pJXCv007kc06YYSUPYQPXBvPH2aUYFXC2qTGg6yWpa+zhlrgLkrEsILY4w5lUwLELGALh9tqxaRc8xgRpmazzYafEk2neOsmgBXbZpjmERuuNmBbW23eKIe6UKYgZnH2o2PCPHvWcwfcjDzUMSrTeA6Q4XB60b6yi5GjsUl1GlUrp6emhoR6J5QFRA4ymb23m9AgcQP1zmNtDAv4i1DdUUmqgOmP1ja6kCB96maLWIIk2qwKvxFqnU4mRyKrc0y7mM+cNpsZSTPaJNQ5I23w5pkxRA4jbIJxUuma2NTfno2EkjfuOfijd6y7sOMkycdENHtzg9AwXITMMBlWg5U4fnRQu5N2j6Hf7FyTPilxVXIiYNXE8FulLrkC4jU5BfIYLYHUIB0ah/OcjPpPm+VFFlNjdWJQoMPLtSVz6qijupyDA3H02HL05Xicx1ZVQwuL+CvHTr5cqMrrTPtvhtP5ci6fB7kuzPbnHHTPfP8WuggKDipPgOtO0PcgQsAnwsg8eVmcH0axX7puqcwG0GX5vQhAX0HAKFwRihwX9d/SpHVjvj80HeR6zB//0OQW19p7xZFhws0jXePubWEKjs9byY3tpRrxTXxl5RbjpD3k9nM/L98DnRI/XoiHDUYNIRQIWBQcAuThpIjz66+SOjp1jl9BSoSPLOdm4ZzMs5KMf3FMAF5DACczLTkq1PtFeRkxAS4Weko5HKmExyBhYAA3zccJUjLku3xwS0VOQohOlHPTFaDsgmhBSiPoz0N52RmpSVV0S//Z+RjPUjPL/lVI2ljdlcI0BLuQgjXsdEjKyx2mHAQQEIFQN1PwFKfonIIOAh3T73TRGPzGOsBuZLtzNKrIDdwGFv+5yJQ+IgxgA2ecScpkAA6+XMZi05FTXgC2cJHrE5qcQfIWDFF0yaDQMUcpbAQX11W03wkKtIg+4YITSnoWcBM9eIUn7nFBr6NMAhBmEMCuMcjd9s922oPgZn37JpThkVsu3OK+JxcD0t2vpDs7ruIymPwGeIe/0Mr/JlTitjNYzr4nE9+BV+0EO5zvPJF0PqDbnUwKA7xAoosM+CXGPBwiiCKGOHgkICCJFGkyZMmNhKbs5h3fzMHHLyAoqlNxTPxv7mkXXXLZslW33B0b4UggQtGrcpSrPOWrQEW9elFrAJYtnAXha3Dz2bPylh+38Pth99QgoEYd+dN77e9tmBKVpGSliC+orE/ovbA0U+GOAZmEdwhFInAC0uQoUKKOlBMiuWXCiCGBFFnyFKlQA/iTfnsdUfBIImMHImWqNO5jcrMQ8vq+/KQ0ROljy+2CeQkIQU5EtspCUPsk6xXBH/K/rdLAT9fxpMzPBt/Wv2DlyuByvyd7iw8v9CK3KwFc6heTtnjzfm+i2TnglVOUogAMsCJDtYkdCAJkRVhEEaA0AAchQUTNJ0ubBjvyGbffyeSufrIkRSQySUoNqzKKGCT2s5Bivq3N9trl6GGypSI8TOSnihgZakYMykqOKcFFS0ifGil0AQUfQMq6FXNGtYthVEPkgfJEFMriIaHnXaA4xSth3lVgp8BBh9GKUSz6ODJi3K9rh/YBv66K+gtRtSEGQlpgh7m7XUvFEyeqiImhhUvbvquAbySf/588vpZcfiE5/Eiy+WSyeG928fpk8lJl8Ayl8xilcT+lcidBbiE+pymFqyiZE9AkBtD9c1q3lED1PYa9BMigL/N/CJ3k4Meq1aoJVZ+qRbUDUM9blVuVdymHlB3KeuUWpU6AgCVFFSVmIYlOrz5uh+PmPhxf9GOjCJi4mptFhE4lSCo44EIyKkvc1/7E1Cu+x/wxixj1W49pczfVpQ5q/5BEb5Su6O+FhTwFP8pDNRxsOghgkENAREVUodR8qlBsHlUQIWBVSBVKUPDglJumnIoCefh03elAqcVG0Znny8Uwvs5SdQ5rW/uVwAzZpiE3SvyaVaKcM6FWGhuYPjIvhGnBg7IxK6gFMhtbm2EXdNeXXG5IYxqmuktHPqa4g5iEie6SMQajMdYvCKOkd9nCKJwT9yfRQEbRatWlAA1ZB6hfiol08kKJ5t4ngKX1fQStqvSpDahXBgGktBC6ojVEYtDsZQTVVP1ghvcvzi4V+omTS5m+4VAlptMnV3/Px9wvy+77vVz+imD+fn48Z53puq/9xyWGBy+ZdYoBEy3uaET89DV9o8xBhBAzMfbEQGWzw1Gu9ubR1wPI15qLc4uguJSCF+XW5pwZT47Q3i4iVSQFtoNQEn4RpAL1y/HzKJtkGXSrrUJHYmScRWxkPRtQno6TMKIs1UE5/1lahfw9EvNEWkvbIK/crscFw2A7d6d+TQ8n3ijrxoiIIeIIHpEmQ1aGxy2oGVEUlUSliihGo+ivfaWTW85AURnQB5VJPvtCLmQC4XTl54WmnmGWIgTEmAkLdlhUdPRCbqAzUWllOrGK67MFXg07zaUJJRXVfnPyBYgoIolIkaeAgcmUJY6UtDvEJGU7kDOiqISMkpqGlnbzUQIqFyVqWrlkypqdj0rB/Xw689RYlgp1Gqi0GKCz4UBBTUPLyMItbNg0CxdY2oBPTFzdsCWoBEpKM6csOXMxELHCnimAfFFo02HIiD22iKRuFSMOINHWeBqvgLCIlLyirl4Tw+iTiSlFzijzHDNCvefBPI5uB0VqNOmO0Cez5ScgKwdX1mfUTnZOQEi4f39ORk1TW5dfUlZOc/xVhX4unXyLkz4D+WxsxAL9Njk0VoL5deq1a9R+VcueQpduYxpZDseBQkJBXU4QkbUQ/WP6m4oq6l512pxV1uh63QCpEqfPdl5ByewO+czZZ5JNZCozLA3DoDeJocnFAQOO5shsj+0BFOXCwMeLYmTMQiqmKiqDfTzwRh4wIKPgy5nOGbBmwwFKRU3D4FaDJgnMOOSw49k7R6Mu7XIS0/6CvkSLCXP2XB30m4OO5fulnv+h3+dL06aLxpgZW9169Rm33+y5vP88SbavhCah79NlUVmwZIVFcZZHDvjOtDnzr0r+F5VAGUHosyuEqYmXqHhtjnjQu1B5zJAoL4OF5lGj/OILm10J0h9C5+2/0ZmI3h614+Xfq8OsAxX70l7YHtVu167Sjor+/136qt/gq37klk91/Mcqn0pEsYn+1u7klrqK8k0whZZhPHM0Kf61akq1QkUpAbPA2iNQbD0oh5hIeTUWNfKkiNl3IDjZTvCAdRXYfLDNED0VWVGPnJ+55VpVdi5NjAeWZCYpOpI+Foc+LSRK53UyWZzIXNohUqCwQlDb4DubiJY/EZ3zQT18oVy/qo2PauV9aemFaehZ9lQEDFmuJz9Kws86SVL8MgqRlStYWQ1S+waqbQPUpv5qXr8f0wjRBUsWCYwb1K1Vvd3KFeqVlxET4GKhpyRlwahuVHGgHNXx2mpHfTt2fZjgDS94RHdlvry8rp1FXbiFOzOt06cmdVTjOii9LNWrvWrWZh+1nhp31LlJlOw8PRJStkpq9/V6QTTo165etWJ9ijolhHjYYNQQQibodGoqXpg6XINuqDQNYl061oqWAHOayYaJGKlRDTvD6kmlrryehRhLhDBCaAj99BBI9V9VAm/larXaqrkhr07nUG1+atkITVBJMY1ko6AhJKVVfahb1R2ExlepIZKBlwoonCoTQQmKQvw3YE7ZXWtWnLPkiDlT9d9R8aITRdWtCh2n8jfIQQbSkBLJzroED0ACeIoBRCAsOGVWqGMUay8wRPwgYK6VX64o8kN2nAoxKyv8iag7Un66YSppXH5rRn7V+07I6tZsL1pT6Y/cWxXkU6fzpgdy6Dj5tdXxC/4f/6fVe+9teRveq9wLtfB8aO5Z7imNR8mQ+Mirm0q8fmFCq/MJMb7EQz4QT5n4NCqz5qbkbpBN55bLcvEZPsXHuMc7QrHO2xLlVmfmJuCvsFbm+q5XYKd/bM79fWoMJBcl8EVF3Xz9yLnKx3NM+EOudJaWDcFlXiSXC0O6c0+zPZKzKvicfDyLUzxpOZdo8TtO4Jgc7QwdIZ8c7xdH6GjhQvAx6CAhkiKCAPCryIjQiWgoO8SiWZNG9evUrFa1UhXdcCkRPg6m3DXoTCXsEaF1f3CdCOjGU3QNTvOUbN4vGDOcsp6TARMY53AFMCC9nYlOJdJRMrTHtsb3Wr3mj7A4mEknMb/to5vtSbsIvNa7R37LYncZqyBvm1RiKETPcmuIAreoRM/pkdAcHJG15ON124ODnXTyJ/ScpCaF2IkG1umZ1DM+3epyd7OJvOuKkQBbsZd7bGKNT1GNKlRKhWor29B6mU4qLceIFP8zmo/S/EvFQlkdMWvCYFU/gpaCeMykz3KnnbnSjtx0TqlUFP3scyOysQuZSAMkv4pIkoROU3TNULQfyWDtUHACT5Zk3BlHJhUkRSIlK5ESJ17TWNeLIoJvGsbQKpJERYQRIeFzI2H91gv1QrwletfMQxDc4no+qz/Bn4407RTOtlYGb1jEfFkGPGAkxgnD47LiqvKkrqMktS53mjViOk1U6aCyrq9zibOS2w/nSDn1O+ewWeFAViHt3QQ72vqINtWhtSG0ajNa9D8Y0wjEPARWmDWD50sxxkMa3khnoQE99ZQ4WsxQcDAAogi60Jlqd/ur0qpWJbVcCE1QQYYG1ZsGalCBIohUcAHldXFHAzm5XSF1ip5qT3lJaSfhk3Incr1SpCMl+SnBDHGKsVHEThEOmrcHX3o4evzdT5gnMGFYr3aNZ3N814TJq64qiLL9NXTwR+t31d4X71NrC7y33mZuY27qzeQ9zz1TI09bujPX61Fdj/qaLECovCvYjhPMVjKDKt32HZDE66Y8xvfEdcc2wV+HI4oXO8BWWdXwla2Wp6JNW1ctJ1XbWdWxorrW9pqZ9q3U9zspFW1XKV9ego+FmphHQQGcRFz8UxCjY7khMlKHctKT6tUpwgWjwGcRYB4kxiHf1WSEyEh2UxJogJX6FawiJcBGS8oEDYk8PHLsqiMl+PBQZkelpaA5IiBfHsJCggL8fLx0GpVCJhEJeBwWg0YhEXAYlIebi5ODnY2VhZkJYtaMaQQ44rBFC+YdMuegWTMEpk05YNJ+E34zbsyoEcOGDBrQr0+vHt26dLaOv9ARHurYDoBldlozXAbN48GkfbxkEYavBNGrQtPGR7o2+1yAyAhBOelJ9eoU4frEx498dFRKpODAdzUZITKS3RSBUd0aPymybWa1nssEAAAAgDlaLnSQLz1lUNtXP8whL0WoaE4zUgJgdlpi3TJCHPQQMH1kRATEMiz4Biog5b41y05ZNGVYp3qV8uUl+Hwd5cuTK0e2LLssp6SoIK8LLudGWRlpKUkJcTFREWEhQQF+Pl4ebi7OcDzY2Vgn0LMMB7vqky9HN+BbaN46fLC0YEtQXvtZMlpPu/9SGq0IKIp8khMiQiFSaF5GUt1SfEwUYDRqZODANyUxKpLVvAm9GlXK1SnUG7onYEbSE+J85zEe5REe5iIXOM9DnONBznKGAk5zigc4yf2c4G8c5xhHOcJhDnGQA+xnH3vZw252sTPocNC7zprSOdux8pTT+qXkS8Tpa0mN+BEZsPaRafZK3g1gRzEkfzPIUOw+dGYf0nbPyVEkfn/XQx8TzDuLfmlJmaAhkYfKs2EPSsPjwR2PG1cunVv2chGoNGnR+0JF1FLuQzxGQdQAdCZaABufadtghweAFt7x0wEOrL9z8gTPAaP/z1FqRiFupitrGABXAdAEnQR8C5X/23zELMDI1og1ms7JnZ08QN2M/dbpmXkCUnLySxvTZcxSqGSFinWvwhwmzcyKtFLyscvUjKy8gWm5hRXNGWTYU6TUfPmy+BnIN+BH8SN+/Ggv/9wFgJ/ih0nw07L19p2KbaXWSGGy1/dZMqz4PAbNMG1lBhOAGcOzONH714VcftSAIYuQ+SYnW46n7z5n1LDl5CkgUqREGfkbE5Qyv6LEQiRQoapOvWv0xpouS8x6Yc58Na8/GD906u/qCP+cMrW09yavguybCcyrUdDhWzrrRzL1MANMetdTU75LcpocpDStYmG8I+xTX8muE1UyzQdV9lvfdbF6n+NJvKubz4wFRlyBQUDRR4IO/AD2tRgwpaPS5wJDdw6H0K7QfWyBPa5jtzAVUeDSRghqQnGM0HuDIc6E1mosir5D0RIToCDh1BMWaNEl1KYcYxCKwFCNOQZHE+BJJoNddAAKBmsg8jYwpG46oe0FQk+5EA2niB5pPVIzEXq4CnaAKVFOvQ4rhQqFmDqHaNVCbESGshocSi8jISwiXNVH4F48LC1KIvQe4UVEag75BSbCZVVJMEWB1VJo2MDgqY+mkrdsA9UbGz8C1Na7BqgnCNEJnSq10wPz//+x2QIDWy0LcyeOH5nu5P12g7hRKzfS4e1XVEqdsLVqSr1czOhVO60xo05KtspLfdfb1wgylYrIVFOnKd2rSsh8OIm7fjeABYOxZZRHrnZw6cq1TFxhvnJ50qa4RKSvqXZd5hLLQtx3bRjjGhCg6yC8Npxzp5IN3CmXez1xFu2skdKuFjb0W51ORjaqsdmn0jj2jy0SmUtNJNO60yrV0CN/Eg/9cQI7eHr00aZDJkxsSdlNXePSlVfO9UycK6x2Lo+rdMQVRbrqyur6rmg1krjvXB8msISyw5VpC/fNkr97xWCuKTbJ27xoe7VpLHa2VuP81GwR7KIQ7DJvR2ypxigWmwj3zjCYBlcVMpwp2titywS1pwWbhmCrPMGOPm8XOL2DRy/gFmGPt8fk7A1x7v+n5YpI7CdR0fqVFEZVBhXoVhzarkK7Flj4FlnVw2JaXA9k/+yrfglzDjATOdMXqhOnExa8nIWd71ZoV5w264xYd646rJk7ndMc0R/xyDaHa26HK7bsby+PGQuRqdMp87BJWCVOFyWuD53L5347Z5XM6MEooQOPXlwme97fOr1iKm1hL+dSF2mL07bQlXDfLlB7YJch2COWKZuU5ixk4f6EDXSkJw+LlzJ0mkXoyEb2YhrO/cMct4TbhLvc0tthe9jWtk/OcGORiUjbtFYb84DncN/pfb0X7hkP8MaSRZc1V0w5GDMee+7wSnkd2LLjHF7wXXnFt8AY1kAv07hgcH3plfJIifci8IYucxZhoJHSSuDoeZrjkZziDe9a7qW7tK0MDesXrGoUc7ISKZvTUmBfLJ2GXvB9KWbCWGwk0JRYztpbsyWqd6Sw8HnJRD1TkS0iN8hYZCnyWn4GGQkykChphxF6EHafhY+TdJW76CAHz5v763eF7lWPqj/0Mugw0izWfoTWnWiT09u5b/KhkRg6jDcT1UOeI3URp13l9bG145xqI/1W8IynfxmZL+g08noZayehWaDG7S/2CrXbKbcfPr3h7dcHH37z9NlRXsttkRd62+mV/vund0J2YU/8l1GgS3h8OgjhPGRb21vWyepzyFKnWUp2NTJbidhGxNqRLKNERpHMohxlHzP2SUxjWkblROLhiRAXQZgiZ9Wpy97ltOkjcpp6ciWJQ+nkJI7vYw+wS0KweS5llt/n1rmzYBkXp+Gi9CjVQ26ZYxTJJJI7XqaIZOJ0IxE6Fp4mU8JO/DmbPKu801Xl17UtgVqRpMhtxlMY1moyoy9sidGADps1u+zOg/mCe41atVqu1mqNRvPy4JL4+lxPuk2iBjRx/5njf7RRhyJhfZHEp+lcAE0gSd/vGU4kcYnM0GRZNI0gLMZPDoFMSndCUEw4h8Z5JomAYp/YSFXLx2D8pu8hOsE2kMQOOyDA2G8H0SRiKKMGBCSquUheADBbcSQLuYJmfhPZp64ONxQThxYOXEyQD2kkystcwN0FJkVZ3PFIdgBkiNsRCWS+GqYZI3vZIhxPJotfzT6eTpKPkBNGU4giN30hCzIMHgUjQUGoPpD1Ehpc0yW1LTxpJCwil4BR7VaxN2H+5UCgj5kG0Ev4LoER6gpZtW2hioHHtXtBf7/Bi+ugPAPS4WiBSD69YcxYS4bTCbU/jlAc89TJtSUHScwE+JiWCH2xXg/7dzms28eO8/UZqlLSxEyolEmVEtYIdJthWRtZyFxKWfYVojiBR8o9yBU90rEa8LJkLk4C3ZqEu0WLmSWa1aDw87QcJFj0E3A4FfvAttO2Ya4s9GShoUzai9jVLBLRR7Gh033BruG6zKqzBGdAo9v0f3++YTf8UrGBTZyLT4rAIUOZTc22xNHxNkI6hbKqf4cfHUxgKgpIrfh5FodMt6VzrsIqHjXwoe000VkxtXyHjmQXzgx7WTpeDkIvPwEUWzTPBz9/2vrAxA2UwXBWMbnPV1DV9ATHygDDGhMXGBjvyYqniNOELhMCQvRJRJRrXE4gYWBcALOiFOOBLYkjAOGyZzJt9MILiObjaAoSDd1iO94IT8ODSyipGIjDnZSm1npWAGQjKHoogR1BJK9RSgda11GpKbAOLkRwKbnG/79HAyEYAmM8zroNhOBbKhCRRgOLEtl3MEomz5aUyAzimJUz4+lPP6AtIHEyzMRVDDDLYAq/NO5ous2mm3TKKw5i0MnY5CN+dY4O6IeYVjXG5T67frdEGFhOPlUkVSG1PseggzkBRgkr3fRL6jbhJ6jW9IE08VvyEabLHqdetL+FN2GieFduDdzpJEoqn7vg6TKxXjjmt4lMBdorC3rQuojWGgeEuvuCoPJlNGF+7Q2chTLAeMwGzXc91ts9AX2CnhWoiUeNsAdMWjiOrNfKoagN57o7J2Bz/wzdZJOl0Qc1V3XvyhkOPGa7pWBpJyYeG8l5kk7UfM4YtOs1VPhrM7TvMu6bPJeLNKy0TZjqgwsX8L5DKDBrAonNJt8mz7Ol1H/RFo3LI8F0f9JnT38xXq81L6zzdGC8QC7IIrtcvXf2akEE8dl1c0NdbpJjN2QzI+5Uws1ftDm/Kp+Ob4AwHDhZpKfv4sh+psmkAkRtAmeHbqBYZSOHTVYSaOCD0yEIz5+C8zkrfHzQoimg663bhdwH4H80Dt3z2hyQBjDRQP5dEFdR67kxALwymwOyy8kKzPcaBxX/hN40vK2oQEGt+VipWISYAeyGcUh7hcY/+2zUAMyaShzIbigcdhCVsQpmPZtSCDBl+qBJG6Y+R+2pvrVPEKYgRTaEo2T09QT8mm0w6rImDFGIuaVlwOAyqwFMFeV2EH7eoIGsxsL3zMYAzD2mrW4cXlQ/5BulQcdZYQkPXb3bgkBykgCpZuVFuiu6geTdywyfgWNQVKVtGAkEuu8IEzO9EBfC4peuT6FgP8gOV0N1W+YpIFfl+JrnN1o9GE9T8g2ab8l6DbntXx/CfI1w45d3/Y7M+vsNPrxolmvl7/4FRm9wQSvprhGdhey6ZUX0m41XwoYD7okigI5e+wJPqMmiKpvZHxVe+Hh3bmNyZN97CtcL7WB01bIJNPG9p/xY2bbTaDr5dqrdy7mCn3LwIboBn2DM7jWx1+ebCHwJ9PdS4wicditL7VwwP7jSIrsro3L4q/CpbMocfRJN5r+E9V9D4a956KmKq18225uLL4TCr9rYXRazKX1BOwLfMxsVmJYeuVp5nsNTrnMKs1AS0POO7coqPFRf3rXECf083tXP9dWiUjIwfo11bb1K2M5BiGp2A9xFnxKM98114F7lVt50HWKgarcc6YrfyejBTEzhNoGqhlyScCjqoY+JSi5VwNRE6QLVrPekAZ2wxIE6gkHyMAC9t7PRue7MgqrGS8z3fN/hYagOgPZ9X1fYRZ5I6Jnl6YqlyN+zfcHdbl4xOBKXc1NRjoSC1hekFTACe6c9dU0A9BC3dXMeF+iiYMK/6CTEpH72+blrNE0zqcBMIycBSJB/q8SwRdUm5SGrnMIH+mWnGl4c+PM0AyrgMfCqv2IlUoICiE0MhIkMCSCH/9aSAFswVtnG2HTg0DyLFppGSC1eac3svuKdv0eB3+qsKPDTrfc5hU/JL6fuXHmkQaJzpy2kKPE1WTUDZCfnsvgYMhuHMFzOY9uR0AORYCEY98zbXbb7c8OvVly//ILZlfyoclUTIK1+/gr3cbyrhM73DhA8C37U2goXpkIs13+RqGNVDBOiSt8Oade605xV1gBkhs5zQnBOb0bORf+zkOI8VzNnABfgx1cBD5QnLBWhS3WkS7mnusDchOZ12H9znOOhU8NxvoUjBeNXPKMQK869XydMmSzO1wR4v0laUpnU+mGv3PrV2IN2n9fd4BCWRlfbOlLLPwrQLdfOd3pJeA9Rfug0gFk174lkNFejnuwzXIWVQLFdADL5qpQtjZDSr1G4AxUTqezQr1qpU+/3EJCTYmzeYiXJqV9HTo31trOGHsoFualaSYLrqjKEnXktMO/kE68lCCJrf90r9aha9bXAJcs02Z6gmy3go1KvY4Fc/kMldosQZZtV60kDnDEgSRNWR2eoJsOTt3YRqF2f7OWqiCxfPk9S17gyvNTXBza1kfHUuUu7VRcHmqnLduEyd9H1mudA5i8dMlbRjyjygro3ouMhLWhGpLUY1LwGlk11hdrwrF/5ooY8KLmVsB5gbxQ+wBHI1DbXlQ+MB8SJIv7wpMLBrhQpdSvZYH6FUuMS5QMK+QVnocoacjlknLMol6IV9BjE99Q9YkfVUi1DQbCK53meYYt7hSGoaUeGC6cI0S41uqXpSeXVujCSni+k+23MtPUPNBOeyi+JCI8OLy2GkHUdonyNd2nLwp42Gb6M6GVNrf8YlMjHd1Ix2DV2riqoerPy7nwJQnl8JDuMWZpG5029Wabgr3k3J+1nwUi9HQ8Jmr94xlCTbUSXx3HEiDGrsIoPp8lO0PZzNkW5HF2ZKfCwcKmPNhReRypoIMVIS1GNxCxQocoYHzlyOhqFJQKmb7HEEHGGMSzRcnOcbGwR8TbFyWyFHoHjQkWeX2KV+IntIhnEOwsQy0UNZRN6P873f/RIRS4BptLjaVFa3D1hfqAJUg10kivM9UzIA6acX3TrAmFTL2E6mJJbwreJnOZ+rtKEeFNmtrEfCdih66HT7lw89q/4NykjzUVsYzDe3bKu/H1ZYp4a1MISitiCgScLfnQtytqpIxlqCFKNKUnZB/ioaPU1uITDgwytkupo0X99AZ9GyUwRpVcW1akiqs4K+d6Mr+ZwJNu4YTgjeW/oZih4ABvzj2tDIUzauCCxoJGbq1kZG4sNesX+b4CxWpYBVGzCFKTq/Yh4xQikU7N+BEh+pdPLqHKWMkJ9srBrjJIX1aBfydWrJ3jAGF8uROtDGI+GKyFVJqL+WyfeIonUjC296fQDy5ZnZeqwCiHkgcMwbnin8HOndgZci63S2i83Y2PpIjJsc2vM4NaqtfEO4hRNRZmACRybgShUIk+8+zO2zS3x66LJb7aNxuT2M4Pcn406QO/NlZT+0coeesfTaoHVJEWQtFpTUkuG5yPPBnvKAbcesNUWaEjZZu2ZS34MjmmBe87zLEWGAu+cImmarxJw/VQUyn2NqWZ5oIveQ/rlyPXkdddg9Z82RoM3YN69RbLvyat6Gr6EOJO7XYuCU1t/F1o+7QLr5a5cWqndqHFoqLdEeHquXXXre/RNqYCSVT5FNOrSh00SndzkPTo54aYyvQUolIy2CZqNhF9V2bQVRpwROWQeCI5h9nLsSsajSqZhw7hhEWdKcSDL6sIMOm4mK1HGVrTVMmrqjquSsjmath63GIPa4M8Kt8CMbhLV/rEggPNS0S3FiKhSykjJmRCZVl2c/BUFzqdtxLGvfsXLTCTQwYlIgEWfn5tM4lVcAHy32OJa78A3xzqrfYf3y1tYvGqKQ//XnlXcWgKN+tVOGbXkWIz3SwWTw+Qlv56KHZjKgMtlGmvN9h+L6h8D1FTvoD1NSeeQ02mbfFBEssTMI+vdwjVyAuGbFYp7900VA6fmfNSALbD/hKm26a7RFrnbHNBkeN9hj2v/muXDhcC8a/p62/pCTjrZHBfPDAMLgGrsr9VE0MIJWM+m55KM6gWa3c21zyRwpnfW/G6zHe9O59gsHK8hSS0WP0jehrJ2mKjidaymmUrh+SQeT7DJ28rpgbOI/8Agqo1pkwTdQnj2Cv9RzT0QoCy1Fiv+y7ro7PFZRPP+pIUGurrEjk15kC4DluWBX8dvowLpnfXSqY88rCH1Z/61NGl++kYtFhz/D9Mo2Vy9+cQATbEjFq2Z8B3jnk67praqtASIG/QEWa4UMDQKKzQaqPR/DQebWYdKybGkDs5vWSkaeVJtspPK9ZRI+PmaN35ZygbtJjw+Bt7DkpCEGATrg54PFtfutuJwZTVocgxylZoc/ug/nUpKLjsNsgJlmtiCC4GBXE9wpk0fM55UhR6cYxcVfKsUcwh21anrKftSxhwkBpjyfSDQid+cwCH1APPO/f+rWezWDNHA0coEMlFy7XPg50wlrJVoNTbMJmVMuOU5ohGJu7biyDSSImkdH0p15i5VkjqHZA/FSvorND+iQN4UOCweqKKpVkYMW+APMNwlQyPb4hKzIselhCDUcZHoblKF60I+GpZviCSwggydwNaj7iBzk1OHy/RajuZuvQ3EgLlf6CftR718Xqv54a2TEylNxBdaT7eA5TWCq82ZeRWo6BldlvDVH3Fl6vN/2CLFsR697cBs8hL1eWfN9VwRuHFs1hhlhtTwuQtqLKZxHkkbp5gon7Jsj4xNICkd18XAt/AR8S4XTe5ODPqZEHY/1SANbGTBlfV459zdr1ExcFU/BWcHzeKsKBgy4XE+/jO265jfbIMzlPuopjVP9hpycJNAbt1CSoyT/uaIdVSOWeQuN10YIp1u1qUU4aP/vHH9+FzoYAK7/57p6RLKcKLuEA61beuNdbsmQZNYT5ur/5C2Nf62Hq+sg5Le/VpC7ZbmXsPTRVXHxLVLZ+pU9zjA2iqnnlKXazPalWjcnY7Bl4U++j3HERnS8SmdT+p1k+i6P2EgkKPyr8ScCqkrvc8JrK2hlv3kNfkC8yExYoE5ERMTZlGLvu6oUKH52bACLxT1bn4U9zo8xaXPZ17KxtpeHokRB7csbtrNJBFBk9rXviyOtiII246bCxwkqfEpTRqxIHguiQ+nmCbwtfDsiGBw3bir1tZQUyZ2MQvDJkZP8LhtcUsZuyrYLTOEvmrx3UZ2HleEjtKR3iWpl8mcJyBnAsjNQR3h0kQHHCE5Z9mpTDZwx0lkGpXwDYNjDCDzXBs+OTkH9eioQlFaeyUdrUO8uc33cG4lpuUbkyOEXPD1aQKefDQJxi/MnKJps1QTndVmr/PWGXbDleicStMdXdQeQIfMAPMV825PIYRzZRYPPn2dIArzd7Op9qyDKF3DZXlFNfNpUSol3xh5Yx+WhM3M2TeZFpn62mZ+XIIiotpPOUX46CLBxbRKIDE5JIxntnhxQuehKXmREZjUu3FTwozBIgi4HCOckoyMWVDcfk9KOmAUi5LIiiqhhHjhkt8TxBsuJDqWVyJbeNcvzRaX2MGmMuVP8H1FrA5kehfAKWpoaWiAbEQYuONQ/gyHFTSMAXV5OnjIpYhOvCXuhTufDn5Nkrk3m4Fa4/0YlspjsieYOSXBTsVwQIQTlXCoPqnbo2ogu741RwWbKkEHz1/lccVj9FyXHQ0ERo+CjiWp/8HJr0khyokX4FbjO3j//AgnDUTVqXtRnliJOEzoVy0rkc3PHJ1lUXjwI+KN6R2acd1EOGVoDMGwg2KUWab2XCfiG2qmxFFWTuX2ImJ9uHi2tkHzwYds7LPj82YXCFTt4Eg5YdckLAClh/Mpxkbh8AkaVRzaNhp2cD9Trk5WYAevTAGzU7MU1LXmYUmCgw3jfPv8hnH7q3DYjCXmGUqBzpKonCYoOo4KELoFuH3cf/PERruzDyftM1Vn5UB0tRIy2h3qZl2GdFnF5IlxBqjr06y6tCRs1VskKszm9l87D03JZLwZOjjJquH3XeVFDFCSK9IjQux/EQNynFYARWfazGurp3CgJ2gYKgiOfik7GvoheGXh17IYMVKA5zOJKLMg+9lvgF1vHqkSYmVrXfepzTa66vsH6lFoLsUSuSVubR769NLrREzxqe3TU9WZe+u8bAc4Oq0kCk4tLRd1jRYrqtrBoFo7aAPDxQqQm+PTSILYtQmiqWEPyVQv1zPauzxV/jElwdj3y9b5jGRXNIvP53YEWETLQXw+yoBT9Giw3Y6XCxpb+298ec6rdVCpkWqJGHRq5Vjkc1SOxWnYNDtK2OGj7FDNKS/oa65EwdzKyqzyTYEa1xrGCDmWPXxC7NHFGJJGUMWQungMDirbL3BDLAe3Nih7m3q7+QMYn9GZxKUhjTpjdyhgxYZ8ksSdXJE5xmyPkd5YruipT8YUtimIhOT76k6MCK1oQUKRrMxQsFNtSrhOMEr64JxY5W9a1G5lKxKmF6fG2KX+ql3FN9xsWwzYy98ogoFLZwm6IpRI2COfAPkGiQXfcBjy3SosI1OV7s1r+HYLAqt5dkO/+fZ+AqUnYaYmHl2q/NOzSkJjqUBk4dmVDHaGXm1Wnwdi6isqyAQuA66KgUoUZalWuncd2gnU/+gcZGZAtCWmdAv67A2hyRZR/2oWJw+AGKRa3dW5zjUR7E+xVTc6VBmAThCtHBbKmETKY8hDQVuXsa3DqA339ecUx3sm3v+6T24W14jOdcmicg/FYTrIPoRYsBTLqyQjxMh6Khx6/LfjnqfSDb2+ZD6Ks3aunRbBsR9oRkQnr6zQx0uWUxRkYsEsQRRtmI2lWf92XLbeYfIoZ/BD7SGGCZavmyo3mR5n9Lm+kcBRwVd+zbH5oC9Z2FQcjBSAisoV9RvonQaXBPbyXjopZtWoWMF+LZer4CBsU2WR56/mwarSozjQX3MLMrbvqrZIUyjHK164M7YA/sYoi35MaJuiYk5UK+iN5STRmcqeqU8i8ZQ3D6qU61xRK023s393skxPMpOIynr+PU2aBf6Am36xMhkvP3LbeMyP7Oj9th/M7HclJstFhAmpnV5J4DTi3fXNTUPApc7waWyzrTbG7Rv26V3/asApPX300cUWO7gV7UOOWi94LwSfpXuRWyPE+Ruuv1cqXB6+3hOe0thheLcyX5l1e4SYrQ6y28UrXl7dd8ILpb/XDEfroackiB+w5Q8TyoCd6L2hmcxDuQ4jLm1fL/vve54i/nCSbuK5x+iRwqhMmON/tUcW32QtpE9nsBvkJhpUEh1431GPC7tk1B2Aqc4190I2vXIDLscRxcq7b6hdM9xjb1d2Ir52k3ahThbNLFcdNR3U+dnyqr5XuUdK/cI7E9PMmkRU/bmh9A/ruIlzcnVPEZXfziYBsL+k+vdvBBMhVLyiEIZzo7Se+oKzqKx50begKSCTpgQexJKSuzyCCtpUHXA5eN/E1nvLAuu87cri3mrmzupsDfcSkeCBLbc1W9ybwFKpZ9cUcynae0tSmnkW1BDE2uJI+rYZPVe6lUf2FZsu8rHN8ZEeZFC4QcHw+xePeOXWpxJ0xO9UsUTl5SMS3PrXLaPbqFiECjYc8WkXMLL5g9zcC1HrQWiXdGVNGlITbnkJZiTwAD1SCKywIwpl7+YlQPOGjCWfPBPYLlxhwZV1d3WLXjVgP1B7i8vB2DJ0J+IJMTL+YBJIG+gYBOZb/MbjztRD9QsdE+nZ3QZRkrVFwdjGqMx2q9IwcrmF+wCiOs4saQkQ9xMfGYwxmi10XFnjV6STyaGdJkOQ46AQSrlbrgCR/p1g8LbxtnNha0+5hOqzd2q7m8xp3xEPlBxnDV/5MPkFY++WzkvZDZqdxr2XRGAfyvN9p/rqeTk3Z8fZ1LQAL5kH5PetwtZI6Uy1HTvJ0Wx7rE0eh9jsK16sTRpOAqmkpDGZKSyg1KYlOWEpjtVL++eHdfHsxicuU5Xlp+s1sfbhVe8Akl8VObK/+otG+XOnnXhtQ4VY5q8J7U/tiyOe/51Pff1YUWhD/skeETR5MxnFSlfb1Y8FlsjaitetFxweDOayJ/43Nk/A7PCczGR3rLx1BeA+9lFTRv0V9x6eH61omVTJe35uhCPG2NGNgSuoxNeC7ef/TVYtqZKIlhdB9jJENkqdRPHtQ0CHVqfB84PT2Mw67aa/O6knkkqNvKZOrb/+3xs3GnIIRm/527u9HPbftyFraQShqVOP/0dG0vhrRSDjkKjlDmQgs3KHAxekf4NWIo2PSSFPevT60SlLKhmjt3z5/TRFu8sMPyfDHeQywX+47up3AuTASbV3MIEqutdzCdAwOIIWgCdQUAMXuwtgNezbPKrGXhS+93QKuwwa/KWds+Eb87bXAXNn75/EfeXgcy3kx/9ni2NZXULZ8MUDv6pDaEHPrYBXoVDmpejtPgEC1yd4wL9T3+LbfARlvVraXzmfCZjrb/M/3nGt+P5oPdPT1dGWfvdTm+S48f/hoJ5++L8PLrNBH9i/D2Clr79wNn0Z0PM7ruB/3fEO9mEXVbVV2YR+OcU5yJS2w1YDyC84jx4N91WrgIzR1DGsu4DvZ7X6eUWS1v1TqkRhjDLfWPhzOCPC4jK0RePWMdyRlJf8TM0uApKOk3Qxvb2dDviU8T9omYxKvo02tDcnDN29DEkk4xIL0lgR4SY+cy2/oLBfef5//b77yjW21e/Az8t6d/081vR3xWJT9/n/qADEv4SFyoR6L2iBnkI2qMxwBCHJALmPRuOSSRUeJUNhWts6mgikMKFfCHkiDFmgELXxBBZz1b6yEyFA6/ILlYn8w4//CWiB3+x6zY0zVKqnbAvqAyE7rCatuqEQ9BYdY1K/16A8whCpq6I6vSmtN/t93fgAPn30MGhPC2qoG1qXslQ7nNPTPP82e5U+dznmDadmu8G3JTPzY+hOTpwSgaIJWK0t8KUZ1RBbgXDY9zIZAlTIK7WzUyz1RhiLJ411/70+zS+Jxt2pqHfF/2JHd5AW0Gj3MBwrWGIonIBUxasqYfXv3y+eGHS2oxXCKxm17eQ0ffWv6f5Wf4/Phqid54Mt3OmgvIv3bozhRvRPOZty1HaXdsLTeiCv0HeLzCe+QSHO/kOLtVtE63+gQhGWR9Ik7GDRIx75giZbUaunhW/C3uVkKDCIHAFpa6L/PU+JFKTBVPZyrwsX5AmkTfSWvnRfS6jX5xJqnCNrVsJclAlxTchqfLWMY+ZweUq+XKEW35Z5Zkdl455dPEFnApIqHRrC7O9O38848dPcaAxwDV737qwdqL590Qb7ywzUJyhPJeA1LJK/9th/TY6K6GDGmg2t3JsdVUsKsbzfpikkaj70tPlobrS/a2h0czbIVOOP/NXfqpf0ULybxcrSzSCQ6cvIu9NA6x5DB280Ezl5xqR7v9o9xjMXsq0Mvqtzlyb6SRqda2NbbC3+cc8+4NtTwMN4oQIIs/44qkqcDJKekJSZbCNETemIN9ZbbHnF6Xihyp0ZfoiVDXThh07b0wET9RDcoYdVI9JSZjLr7kcNUPN5ZjSW25GKFLvXa8Ri1lBH85O6jcnGcDxiA//KW21Kua227lBgU9FYhfT6LOw3RXW0Q1qtK9sajoYDayXPPeAJWrpi0Y7xIG3qdc0pJ+iE6Tiw+oHD/CZbSa1nhE6OAV9IQCgxaFZbRI0fUuEI01P+GnLd1ptRsPPkY+tDylqPEqGaD+FqdZBWgode76ina9vbx3XpVeQlVs9uSV804XAGA2rOv9cx77G5XKqmg2zhtzyCo0wor7uXBDZmbFpw+4gjSu0cfuvo1+gvKa2ktc6axaLWS0lIXj57HcHQKqeSFeBSWF81MmnXfTmY6e+U94LlvVRbS2DCayDtZbhxCmp56g6B/NzSAat2kurZfRmwWCzhngJlq5XgZr08oIp7/T2osDQgYqXlGm4qCIlbv054UJb1mQUkQ9l8oQGmDR9L9KUKZUEBJ6tScTMRAcI3k8v3XMJ/h1OnYo+ps6VaIVeF8vgoCgGxmZhPhPHD00Hi1tXdKuPI7oayfWqoSqYPVuPPFey6t8HCErECHg7P9fowPy3hz2I1EgQzKbFSmEIxsemvMDiv0AFbOfgzv2UrOJiPBBNJ//L5IxvafiLLHL9Z4+BtOF/ZePJVnC6NDIbdQtS4YPZLc6VMmMO/2+Qv5jKaBeQMl5cnUOU0iKZrJ6tp4IU4/PHoEc01zRueItNcfTafpRTMFrYmYLwT4ggbZupayccZ7caS0qVPac3+QAGfJm9RW99ENm5RHa4G/oHTTjS3HKQJRUEa7BaTNijf7UxITxEhRMLiqAUQAozrtEva8GVgQkRf4GasId/0Adfsmw5nQCliHpv9gYVK5sjiYVwGmyOJZZl64cN64pQ0OTSdEs35gdL8mUHbT/w/zNQq22EAqxPj9S1tMpdxIhFYni6Wo3dWjTJe0SG/xzwmsb0RlgIeet5ro9+2j5ujbofFb5ws3M6GdjMpr6oTOyHEujyOb359yPCBKCcHXJ/ysxv4+rsqyWB0KD3XNjhRR+OJdHxYrIPJ28sLhe2D6Zi/L7LEGljYg8fBms5wnlZmMyuUNrtiyKToG0Rs1jGZpsdgUfdstPXU+Pvx03BpeQjsFBHBuspEPE/bMyIxm0Yk2h4s2TceJh1qw1+Db+6wWVC5zYKEtgg5arMi4E+7MR4nngCOx/DBR+cB5UFW2GdJJnxSi4DVtFV9nW3dAmKQt0ju1+psIb8huCmlwLvT0XvE6TYMTNo61jp3wQU4NQsBn243OjCADePlZALvD1Z34ofEc8elSC9oE2+jgbcm1IaV1bj6a1CFQa9bluzo3VVUMHy4sGy69gv8FrCJQz5HrhZ6FDbHCKoccbXr/Z4MrGw7QiU8o1PLKwuWSLhuH5Uv9DJZXmFiW3rJcobLbOf7GVBQbgV17d5sCU+O8GgIj9svHr0zzLmRLo5yBEmdQdlZgYxs/w7YAHIHX9sPfoK7KhPHf93haCMjQadYpf8Wa9TYUWMiZLEFfPq65ZGapkpLyzSZibFFogwE36NFVlD41njSnvsJcOJ6doY9XYaoCHIGKAJxlCUIyBSiQIqOQFNx0FG1oY9C7qPQNulRpgzAKZFeGX9nokh3lrZlrUbiZzf4v6xyxJhUiOj5gClmcrwpfIlfyE4iWm4mBIsJvyWWNbDEct4G8dwmFlulGyY2mUg01bU5Yy0Sn41Lv1xz4OsEsEgNg5fiMF8ZOVgdSBOq8mJZXqOW5rpEKoGL9OLgJt5ct+f1M5j2jlaVksS85RIJ1bSSxXs3niGTAES+hMXKRGyddSbTE5UEGRy3INAfC+nttKrWDf62etlG06X2RDKY8g9lxdPE2ePO+lgH8e/2jhMMwNX56ZWNsR3Jxo8Fi1l3oM96xmaiYfgaf7+gA5/R6oEr4OUIJuocEwvPkjTleH1XpQy0yKHXGGCAj7jKP+Ee6Iq55+g8brMpHDaAMydKtE067cdoq4fnLYrMFcIpvD9yKdGi1WpUflyKx1S/vwLn4J6z3G6HTlAqyizz9mSOWKM6KQ9Wsc9QjlmOL4+WojrRFVpEzCVEUNQ5TjZS5VB5WsySCbNx/FEITnfcv/GjRzoD9PjKlBjOqVFeNiVEBU7KgQP38FHWmVcas2C1ERHqNSKxXisEbxxysj8yIv9Crx2ti5cKcXxguPPxRs94KUqrIZP/T6sZpy6XQME4R5GodGdKe3NyHI/B9MrkY/CUSK+M/WCs6sqXd+WtRuJvveHPqTkd+Nv2zR9He3YiFjng+vxiZdz+pmz6QRrxQd3Fw3MXhnZlI6lCJfqat0WHKTE1Hr/Kv5fHI14A1S/+TloWJKLr0z3x+cbhrmEqVyqHICnCJW8rKZ5nHo5H9bhAkEJF7MDHZB9R7EL1CXcP3oNPLR4C/8A9iuXWHqtSlE7zEXVGMVCdzSjUSJovSitVomyaL0OT0h8wzFi6ofMg/AKHX3JQcGE5CkEKlAehCPc2RxbEc8a3AB4p5wIoLt33wwn67fS/mggcEs1AylH6bhFF2xmWRBDTWJ3atqLGLufznBG62Fn023SJB8i3PZPD0f8aNhHkZGKoA0Dw7htj7KZxrmEYZlhsFC7L3DqyrUSpYpbzGKwBGqwRws3p4kAFj6wVzCom0fTc74ZmsmIbPn4hnST010gZ359kyuODXSFEEEgwZa2PiPVoTBjbeg7/Ku1S0BNM1hNG7Lt7l+82AutFH4rOhAPehSPl1hhcTmWXFukbVNrLN4QH4+qBIIWDEXEjbAOvnR0aUNoz43ERCDjbBXAJxrcmcudcFlcun0DHxoOnAv4WvBj/Nvaleqd8FS1GnztnnYWfJhMfC/hjsOn86awit6UO4d4MwCGCCMHX+dEnt0zgQvz3y7uIN8CxbT62gR0s/+3D7dW4sNN7i04DKP3n5jfb+ApbQ4JBXpOqJ/HsPr20NCaJ23BIZ9kKX0F9qhjckyjZuoHX4XMcCSYTyPT8nIqHd0oMfaMvpAq8ani0cywzaS6U84L52R+CmwC9Dbz4iRPZjnxcigoLPXKbuSyV5dUqGV4WmyDPC29OyRBuOORIslLNEQHpiv+LLYfx0q+wMszpF+GZ9ez7x+lPQ89lAB7YlpHq/ilOsP8GttOo5zioAaoyT1jIYWRjRLKK2teDu6wMvu0B7FJpJVGYnzVsRAIzFPe7LF583KqzT+4w94qlOTUqzZaFJldZIchJp60MWgnlzGsyT21EREatCGx+FYRFQtj2AQSiuzSPzQvkhcbBifsB2fz0n3+NXEfquYgRBacmY8Rvk09BsHwaXqziLH+Dy65CZoAfxUtRWZovzqrANZ3CQkMIQtO7OKkhVDkIrFgSNhf8IiLUc5B38zNx+BGco8Jf/ogK8ysasH+vqxqWNg3Htg643/+SAiojVEIYxvueZHfiXWY1vjQFkQhPDPUMuPD7vh+EedakvB+B8R/eP86r03WbbImbp3UdHfUodB+mnlA53OQBaZ802VW9AXgPRn5VVNwCmU8N0m2QW7VAfvb+UcAlhBnbT+P4+AmL352V4ktRELFQgIgpGV9vZ5eCGRseHNtV1Vat8zi8TPJpAoFp6y66Lalrdzs6NLOmSWKuJ8SUKtMcflA6SE7RaGoqeZBP6aIwY0Qyi0iSEivE/AEMFeMOocAarp74aM1bJ0oFczgQ/wsGdNqgX88ykigGhi7sNxAxFoHI7CDUEQj1BLDi05PyJwe0Yl0/dYNvmr3+fuU7R2Xghu0ncNYSjx8Rl7NlQZnFSp6pjE/vf3/juW6XORM2xMny9Gh4rnsnhUgiP6/SdIW16GOPtSMwnWtM0lSJ/thc+w6juR0dzyuDT65iyUBuSWjYOQoxkgxaN2sjkujqTHUWSl1T/PgFDf2UABNjxlbHwIrP0oylIDRdo48yokotCKwPhYC9NBy6HhnGPMD9LrehoSBXmr/iv2LAr5Pz73fif96L/4I7/1lPo5vr81uk/D8Z8Q81XQIussF5veRSdhD1LZ6vfA9Asdphzx2U5HQ8mhtaa+IJSbvBqc38CX5FVfe8oHc+gY7kG5aHrrtKemZP1VXs5YmH+jzl7ka6anjlS//XClc25mC37Cug0V0cvfjocUdOYtuehVUAuCK1P06mg3vmXuT1x/UdfaFoj89GqCvISuBMlS+wxic6ahRTo8o7n2h8dGK9aS7epN11qn53g6dwImotc3aPd+coj7e3VBvyG6DUMO4h2d/xVp679bIxKlV1CxLs6o2ki33R+GQU82Ud0jfMSMOWdlgKRDY/XxmSTgsqJQTrv9hw5LlYeKjR8K+EWw545of6zU3ccaxKW0TbKuYaSEXkCYbQAQ1GZmg8kZLLFqG8rUeQ3L3Oeu32z8N4c9rdqts+pl87srsmsaRqTttEk0UtbkruIUcCnjPAN4itmepVTk2p7PZQDAy7E/ERApFtY7fCzebhLZWHTshz6hwx49Lh3cKcr+7zU4lPRVBzDlrJwNtPt9t6a5QPL66+wEO8gyInO637thbx2N1yCS5Uht+78/ckruJAdB00hcOongD6omJRYhB5KW8tfYffp+m7SXCWY2Pwe0i4/TUVP/olO1UP7MQmMvm9vrXbHR9+C5SyeshC6onBqZVHmzv7oor9jtNeOvpSyVfKe5cfb/aIrrxkePC4lwIMYdL+ScSmWmARabPxqeR/fDx3JVwk9pGcuAe/PvPVTx9PrASI+t/jyTs4D1J3ITc9AJP/9u3Z94EP3OJEghR6OgyWD1x535OvG1NDYifpiUxfOFBK2L39oRBmiug2+NoWt44Kaq2JRDDhG8ryTsquHTCQ/e2tvxPIx5mnO7m8/+k3jWmh+SMWiUxvRBKgcxw8f180ZDwUA8Pf8Y/0DsqkMLKR2P5XO/lRJpXfwQ8Hon/dHRB+opuP79ubk9DDCfamdceTv0Zm6srKg8SSQ6EyA3IU8IFikV472y0++3k1pyevTfK1fgcdZUTGY7tCLJk8zODYISHd1XUuZdaH7UIO2ryuQ9rt1bt12wiJ9vJ/Gnj14fP6M89Eiia3pZLt7LlzTgs7knz0Py79ONoNBHW/aaW7pp4Mr41tuLpXO9LeLCcuLs5bGBxOucLpkv+91Z7G/S9z//AwYjPl/naji89Z6+y3vRme7Amm3lZqFaAmiUSpF1APDWR6i0xxqlyPiwVdGhk3/hNzuIN251EjnbktA8t13rLV16npt7N5MRPvQYHiZIQcs48U5Xzgk0H/CZY89d4tgovxnmfs9aybwyHl8xh4PrRFbf1mtXVbVBor61Ez49ePhUZsViUeQck3WfVDF7hCeSyvvrchcU+OF5kvCQhZCxUEY7evSjjqWCKudNzGravXvrBjpqA7jyckT16ThZN9ILQR0f115m2PLD5QM/4uxKztAc6ozR3vfW6eqNn+novoZgJSPPbs+nRjO5qP2A0+PRm/fercdGlNAhjbFsxJEFpVINmJoDyUouwcEKxX+buKYbMWuF/QI9Ebkf+Di9qaMFwtn+g6Ax4M+Ktw+vwZQDM9vLXyqIqXdN9mIQ0c8Tc6ES1TdzD/PJ+X7m5+BUAkwD787O2OJKLXoj1yxmJqO+gK56GWi2NpSGYDx0ZzUv8W/XZY+OxwNfZgW3n24nluAZSGtruYL/1f39o9p5DDqFpdKW/f87xmL2MHFnVEIuc/1j98rlQ1uDVzP0M7xhU+pxEiuK3+uvsvTJaWC+c15vDo8/S5yEbqSR23k3VTS2HO7BrwPHzoTvoDNt1p6AEw7aDhn55szlFaC7aM5mT/+14aFH64rQS3s700zwGPSHLybF6iC/Rm54YHV7ZUVIvkLDZoUsugFVEevt8MK42IyKARAcbk7nPn+kTmvqqJaFGvDzj2J12RgO4OvpzkoM3N3xTN4HxFG61r0UPvkPrfj+eBsbO5JL17MsNYeQvBodzXY9/AsAPyMXhf9aGvpttLDgAp/hL+BoV7AQbh5zPoaH0V3f/luxhIBQdFwnHn/P8IW/9OIJL8x+kLsXBJlpZ6QDAoWVs0iTbwHOEIcNEF+3nGLxxoNvn/PG7CJbK76HxYz8uAe8GLAC84FeI/Ffxdg3ymd/LIUDKBSKL/n9OYykZeOwt5/vvsyYf7XMjCWyKQp7Hfz/zT3JRHMrz2ZQTI2Pxzk53jD9ciFqmkMg3v3ptnDYsU7AFc0846wK99I0DG/zscnDzI5pGguwRN95o2MNHup0ZglC9r6Gng0Bb6GF0yTsHyIU6dz2302DuYvzfiZRIN6ikHOw2PGLefrmvgKpA8boj1k1IdECLhQiohJJ9OWZnPzaGmxoniunmUYQ7TDc+Dns2fSmI3uApW0nYflHghuh9exHxFh/Q+4xhBGuXgL5f06Jw6egkWrqx/mkFG7r4MZskq07BayF8V28JDXOVv6pkwxLriZonk8tXuo4FaGVjbOOB+WLu3691Djq5EbjKpMqB9Zfb6q+Ju8V+OjSqQhUWcjEILZ2M8GeGXVEMDhKBCWK5iy2R66J+R/j6DU6VAMI2uPknU93IVSU3oQBN806aL4zjwxPna6qZdDy+B5TSYq03kvuVDwFXQfa+eLgGZqV4to2faZCmUPsq6exvtYT3ez8X1FE3VP10uUhz2ohqNUmHQ6ZalSDZH4eIaBOMCGZgfayozwVPfpSofSyWB/7yLJL8YdXSqEhkxjpx0D/CnbXNn7/TYzaZI2GCue/LA8zGcmX+mKNDacrN5fLWaH/5T4AqYFvi7UrgMPWkz2w6XE7Ca3oZBz1LAFV0rW0t3mrbVUQtm29l2zlG1OA7Ivx70zR636d17mKp2JksDN1jxZsWN1jNJVkXT3CQcFELqcT7ft3F1rFthG9pfLzQwWatd7y6+f7lZxJWVKl0uk2H4/n3VDzI7QTIXbTtCrVs+a0vvQZsMktOQ9N1nYUt4iKxjp6yIx+7kOTfSJVEOP6mrAT2U3HkUSEHUJj1jGgVs/+ouNVPvyC9avtUoMEtYgoVLmfcYIleJWcBV8F+cDcvSrMf9TcXNwgPlHTHJyGAnq5g0dGNfLr7EeVSoGeYi3xLXKTD2uDrhnMDRhcg5ESVBYWPufkJEgBcRu/xTMc4JRxYb73+P2yEmXDG4aAZPNrnYdT+bSjmQ2wK86Lnovsz5GbYbET4cxfSyM5HPSL99yKfElY3VOo4GaoLIKxUzo18nXejvyAAt5GnnQYeyOb4PYvHiiiFJRRaZbp6+vfjGweCdH2hoGyyqwoq8gd8Le86J9rx+xgQIzmSFTYBFCdNPdDFoVDIna7vMN5H/YopHAHvGGz6c4BwZNvNpFuV1QLnIfkGHbXMDUdIPB/SZ/yhkyjD3yOdPGpDGMN1bZe1DkJ4qrLSezOd/djB4AbxMe0HGQpucK5s65O9OgusiJwLmZyVQr9MkYqPnHe3NHe7V+UYyJVs+j2njZRDx/QUIDfZT/lUctR97rqcDa1g5xU/SQOcBAz7BBuXFawH4Y4Wrvi2c4b2BibNstw6oNzGs096H88VlOmF7n3+WpCrRNGnFG9Fc5UKMaHzr1ncUoB+uii2NtIpNOfkJPYZSjNYT7ZiwKXo8JMiV8cxv9OiNpnAIW/E8xzh3gVwW5cPLuYWLDVrRqXRUzu/Wc7L+YhkKgUoR3cP8il5Y1070d2dKN+ZkGw6ptJwLQsntiu3FWU5p+HJ4hJnCDSuFgYngzsY8tzyC/g4oTtUPHSHlNuiZcBw1EdNy4EgnIWsskO9HTdJxJuhhdTdsanmVbXuEy1ussunumMGBY0T36BLrgunM8SUN/OuE8edf1so6BReqCthw8GSgrz9hnStC9nGJqKFixI4fNTseZQArfDN0zT+LUhX2QQQtA/Ngkl1dcnQTStHTcJlzimxb0Cmv/exAV6d7IVCvdpmq+BALYO4xzFfGjnT50/jKpJiXUy9vW0nPrj99P8KW8p3k/ftbYRlVJ3s05/C95lmwsiG7TacVgSg0/pqTUd2dBqO3hwgIEkSPYC8vtEcVmUsGPXAPKMZqw7zqMQudZ+8dv2jlxrgl/dd4fpqx2vi38b/ZEzbuGv9TPB7xU9u6RFQkePQsQPUrAS/Slrsnm35Qt+MB2uLhBj+ejabylWieeZ6ZGHnPZaA5m8GFhBi8bfzSzphA5Qk8zXOH37U5+sX6IGT5Hd/evYUiTgxFgPQj++s25TI/tsUw4t+2fAs67c+Ejkb9nE+NV8xxa/QH4/1AlVNAPDP7qHj1at8tCTrPHL0Fmy13qXEjtIcGPcsNCq0Nx1agByqKd4Sh2HJq/V07pcKeJ7mIuW6k8fHdKoePiQjc8wRnOWD/OPVshJqSEgDXQhNeyoYmDMZXSfoCMOhCQVLdWFYt1q1K59YqLGb8uewjdSnA4KQv8+8SQ16WhLHlSuTXUJGAHLjM0LTvlNW4+auVCkyva0i2eQd0K3QhdeMZpW51Eir1AHAVLIhvzzo7FB+SMGa4D48jUeYMx2psy41l8QwFIcfgbzyO00fhC/y0x6fcVZj5qyLSBK6C7YihvELnuqVB6smueFPbaj+jtIy7jy5TKeWR4Ti/yBxtpGyiOyr20AaGndjzRBGggoMY61bGoQkjo2GmkVydIkXtfkFHzBYRyaZ9owm4cvITDODDlXzE4nPXttlFTgdQ4fP8/nEgoyUVz3XyN06rq+WyhmNb0AOE0wEhuqRn3iyOS4/NcinzD1ENdXZsbHQgd0niY85Eh8YyzhUBQpyZgDuHH/bT5vOd5AOTHzz5KeeLA3ccFYVL+FSBWvScrB+NhA8bWeKaq2Ss1/5qX/XyvevtN2isj7E/lpbWV4p7rLD8t1TfKfWSTEkpSq+mNnxJi59qydcIgaxirP2BbPrmfgLqeK45O51LNDRNnN0ggoDEXC2mxGLNLnBdVuJ+8f40zx0+7/fmN5TrGozsYRaD70ZiPgoS6w4bAECv891LzN9wv0XPupwwd1A7DrMzmKB5NCtwekcF85uClXYzgftCEa/YFxSCXHKnzYF9DFSO9tcN9oep6LHlFrMGcZYsYbwvPEvQVFgRnr2yV2RUEOkDM6I36pA7BqxgHWWRw6AxwLfChbf84+4LByV0XrfZqNPPSFi2aPPb6a/H16aRm+1KR2FlnNdMoPVrFmrEgnCMi/Bd5E2TpbCVxSUl8tnlBjZof2F+34HFHgFWGan5JVh+Zc/WOvGBHUw5pv6prsNOPSyBydjkhQsA6uDB0xdzzp/r6vHp2MUd74ObuRRKkkrbpEfeZAD0qOKaYV4SIcNHj5p6SG3OYgNhtwUeMCy6pbX2FwNkg59b13Lf6Fs1ztUDV8CjaJ7RhBegLg5srxMayAKHlfVnidCaD/uEw02Yez/7RdOf/ZwtNnwKXn7LP+G+MCuh87gtDYT8qJSZsXU7shkxX4/UjqMILElO2xibb4ps+n9mKFrnVVl6JfO+edYR4oY0osDTAuF60NCld/cT85NJbjIvAvCENs53SjG/HcbKHc4mNCWyMXsSC6LtRHoKWJnQGFknC4I0CR29lqGisR6gQNIPanTJ8NyLkGFu1ScMkRpuUFJqsQGrC6qndzkjk+NQEJAwZ+ffsXZpvIyrzevmkqhlrBItQQtqMzazA28feoZP++x0rThaLxuow1mNwhxTBWWY8mmjqlVOg3H+yrI28cR0Qlu+p4xlGqnHGV8aYe1kRffXiS4ZA3rufclh2HB5gwr5t5i8+uX/rBwVcADq820Vt3Hv7Y4aCKLIShJUkUdiQpHzshPn5d4rrxtBLGk7bj0FAJYI+v8hubAbnLVOZxcXda0siZ/FcvOYBIsg30Q0xrYPiP2SzB1n2XE4V4xhsZwGLLhxtMIPUV+5HUwRyFP5qbikq0N5HKZCuAvrH02EoSkdMjU+HHOsSLMIhthPu9nWUIoOpgIoWkUEbB4qu0NCXTJYcZaGuO3CMNGTBslQhOt/yfCUmVGbmuVxUT4kB6ZNIJrXHOy8Db9v66gTnLotN85eDJIl6iyDRjLN+BU61bjgrgMQCJu71M82kzZxhCBhT5Hugx9u7TcGJFLe2c1HO41MZKqRTcD1l5MNmrrxDhMZ/cdlS5XU5dpv776Bx1I4tvh50e9gDMGBWtP7AINmnbcVi0Et2zb6Iu63gCXU52/shnEuMwIxrDYKh21uHdlaShwwy2Ema4gO64SQUoKmzx1VIyNuk97ROquSgz5OUcEEN3nPtj3ifdd0dcuCgkKp+m0yIfuMV5WkjWydot7XIXld4jCIZLArAnDx3Div7uWL2ufPcnN75a2soIR0WbYqbcyiwuFWaG/uWuwcwHkR9N7AW1grZNeVVRF1lWqMQFAoW1yJNL9vNww5BeyTZXYtem6O8mQVoXyfg7bN1c570xik+VEPFcJ83HGNBl783TnHonkcm0n/hRk3JUpiAC+6qke6MAs1/iNw3aC6RMweEZDL+qJstrmAxovsZlcFqicwjHcbSmNmPWqOst0uARp05h0I0dDLVWQMgZWnLKL2OVE13u3uGKul4lYmAJyWWd5+luTbayzi1fR1ZmbY/kfgkQvmmiilFd1c5GGiGAOuIf/7mtj2Ohh4ClQR+iiUPgp1kz65jwZMilu0376zNKLSbpGjkcVEllcW/4dhFLtNf7plOZ2O8Zl8VBKgse08eGCaia7PTVUdHdkvdXMLDAbgGjjQ0ymR1VCCRMIVKukBfWAX3+ebPPQ0QVX2bm1DPWnanQarbS35GLjDAq6BO9+5Dk7o9BsNki2kVdjD4tdahCkX41+thhJWjxZBgJdzR8BVcKQTOLV2oWXQ42VM+N2mWm24faEmj3WVXgCYy/xdCiM2M4WbtbWdPh0dbYPV6h7UNso34c1rj4AXf6nWcSypvAPtVfooJbMwZqU76nHtUuSQnK7H6XTDbFRyqK8muuv2UTcQlMIJzAzodP5aCyVe5FrXYNC25VtGKTBR9CILQ/XICaKa7RmsXhEhQ/GOLfZdgsEXAPi3g7Y7W4KLXf2pECLnfH3hOmuYbD/oLHvlPig/j+jIvd6rbnha8bkGRKnTqURDhS2lFQgyywqL/85R3+xtFeV+JTw0qRTz3L8pQ34RisT6uZY19lH8HDx/piV8lEpjWJ2UE1o7H/ZKVKrEEMdsbuPH5akksGeBiOMXorJIMWP4m/DCeBwHTMrjE0+p5PF5ciWwLmj8GdtkYislBgd75zPovzW2echl/XC8F0xmBDEapYMGWaksNVuGZepVJR6vdgQIFht8ZoE1ej2hqDdw9Yiyhv23CKy84W3Fh4wyjc6sEg11yqXP5paVsHaOxMth+gUww32zNRySoLJYH2TZYJ+AS3DpzD6GC5IqxBzWD0xhBwbAHuEXWFwqhsRM37kTTJdQpUwMcEymgYxdPyHL9cQq0ycOFov+WkcH/gq8+MVVplAYZHy+QQB9Lv1FVymf/y8cnhjYasgX0+geE1t3YqCvtHQenf5boyT41IyykaZVFYakK2L4tF8AggjzmpkzUSGpok6Xs7pl31uvqbVZEcQ5574C+4Wnv7ZYDAVuPl8ZjRra2WIvhxEQ8aj2yp8mAUmwlA/Wmin4WXjug6tMocRkfD4mQ9P0aCo8a6OgDXzIlCgFMPtJJnhLMl3fwskVEZu2bO7irlrbyILyJcSuLZjT+JZAjGVoOUIXMv7TRPrQItHFV6lVjbHPdIaWyWkCn8cp8Q9evEukRWMKk9fcgxfxqfEFcEEyXV/PyXUjNlVan55nrI6Z9Qqv2SHV00jrW5vWr1s9n+CEFgptMrXJY1VYhwLdtnFTfdaglcdPzhvLKZhfjz57A/F78wQeFu3XiYfxERTr18Vje2pO6Bro66mbR4pLCDO67vZtQ9p8x0Jp8JqZINSZnKrVQwYKPxA/2IB/pNvqqy61g0hGRmUStt8DizqV6yi2ZMwCsS0PXeBqKEP1Cjqf8d9mMrJW+kptmmJK+DB+4z2nl68QBmuIcg0Pph83AO2vEqyYOuhwK8x00npFywbJqnlEVxMQLpfprB4LColMXSStrdNmVHBsXNrhCwg/dUa0Zr9VYd0YVuDcZI7lDBp54p5Zh0S1Hu2sQBjZsAeuwnMD2cCm81MrY7tMLKXE4EBv/VzC56XN6qQvsCHKHvK9BvgR5jTw9Z6//mq3Mkrk1awr1nl4c6meQVpX39hIu8FVMq3RaVaQWuRzHoLt3txWpsjLYDhhHtt2tkSW1abyKxLBsAMehscHMpR2kDUmmMd41BASorQs4CZPrSFjtMvhHn2X5ZLVvSzWLJcYVlaWMdJFGfIXzAenPSLk3uYYdsvZBmO0AyO6m2mT3XokJQ6Fk69R2+gRXOg39m4yx3s9Mz5Rr9a9eQJMgC7FfVnHkigWuIVVRsUhT/IUgewcK3NC6nbaNmC0FMFJdgsQ1tI+IjmqMzRhUZDRLyRDfzM7+k7f/DDbZEuhm/FV0dad1DtVWtAxg4cLy+45v1Mn6N5dpF7jFuJ4i7sMeCGSO8Q+hw9O6eFS9KJBiz3iRMJGFoPvK/N9+7SUQC7MTX6rlarXImqfUqaLtQ2LLN/FU7u6vCu1/zg0GSm4p/15SXznC/JGLKiTVR88sXBciRrwyK76csrGtzZak1qJsQM2TXEINtvynDd6By1T+2EgAOv2diAfqZtVpsB9nOuJoZS8cO5EJROVQudoSUknDfE/35Kueo/61Po24f6NOdjN+wqIYExJEKTTp+rUcN9VJl5thdu1ZHwN0KsG22rftnLRwpPSHIVerfSMo80Zg7fCsAkbeK38NFyeCU8U4E/Z5lYb1TacY6JQMDZQU4ir+VScIpL5qr1GWLjEwfS2dugERPWJYO27sUq8u09jFPD5WqlyXZLSsyM9vWt/SvFnAQlI3rKdSnhTp5bXK1jS8dJH2PUbRehjsNyC2CZYsqYKdTkcfJ/NLWZYHKRUzU4P54vtQYJEA/WR33YPfx1t66NQyhTqAVUG87RTl3jka9IGm1gi0qOq1ThUs7O7D2eUFdQnczaMZ5tUJVI5B5S6FC4UF4QdKVrQs+0iTnXAhUIgphLVb5sb6ZzvcoayuVcbOLiHrUv0FheE0SNmcfhQBccAAYd9zl4wV5yX+7Ku3cCBGMNKZQi/02qSyqR/Hhl2rFQiMahWU96Zk10+nFXWd/sj/ItNzaCxTsLcHvw97jgTZEmZJsK5YBSePYzPk9UWkUiglanWfrl5mZnFQxnFow88wTt3A26P2oOO2ywYCpxw9/MnbECtqLeJWmjqA6+URBObtScNtgPzxg3WFzqK79vIAdUlQJ+2Pdv3PElVBUbNazVf3J/Ela1zZZp2qoXdhhiGxa7DWijPfQwe38ydSPd3xFxzWwC6ymo247K9Umls7LEeiS+BUk9yeEqcpv4M2pkAT6AE2o6EE53u8OcVDnWoqXM6t9HsIJ9+Qldfs2j1qvtuMAfE/d3SxfpByKzDlI5P4Z9vwT1+7vB5kEdm4FdOTQnaCQpFcBWcvF/YB+sxJInUBMvWP3QMdllr+rYViuJDJGLlmgA0A/fxvL9eprYRTiT7eRP2uaUo0DoXlCHVnoSIlwXK3fGMlwKAOeg5Ub5Qx9+pKxP2HY9dfDdh12/w+ILmfZXXQ9duH+naY8e5d6rkPrtHm5A+KuQbiYW5UwT8H0QdZiMyi6hBIgRYesTz9EMy4/TQFlfAqeLvygbblujoL5mB5za1r3Cdl+iJZTUMX6wZCeFDkRls9QpaPmR+s1cT1NQr5gQrvVEAzPS1kM6CvcBF80ML7eKaQYzHjKhyiFGk9B+WH2n1Oz0pr83nMy2bn1/T+AGp9RlKPiWOK9Jb07N4/jPwOTjw8kyoSYrbjp8bZTKOxz282XGk12xHZuX6qUJTDPRXe4rb5g43biNtLWeJbyopOlAJOKUq7BssTamT6VL+FMW1Wi0Or+cLajN/h1XyWzlqD7twzvFIfimn8W1duqiFmGUuSM2ni9spwzRwTTxIbaymK4Iq6h0a7Tom+oEOKVc/uonHbYGNWYsBEqlWzV4tkXP0eYWvA7E48Ri+67fO1HRBm/anVxxNiblFk6SI6wmAJKlYKssNPMrQIWnotaiO617SBF9Ws/2SLdowcWuq5Bao73I2g+jf0WkIxCjKStMJ7iS2JMBl+QQ8juu9fIaNH9+SnM3z74etsOjlWbuG62P0+rHC2JXHQjV+/a+nSrSVq5DCKDapF9Gp9pr0XbpFbhz7yLH10FEKNyLq3AAmle7bK2j7aOloKezJxJ3BsisksPh9PX5HMO8KKPxRfOA//BNXTuvObm9eRnoRPHJJLIsQiITmk5S2OB28DxcqY9usUoej8hwY/5/3sd+weGyJCxKtM1yFn7/hby1yWqeG5xzVbbJShDExtbmN8J6ZPR2IgAXpfxHjpDF1/Tj9YwVtE13oZNFcMJdiTR80tAvfe+2AtduGwjDNfdGJQn/UkHOEdguw6AoKKZIE9OxWJmTMbAoNctZuT2DwSA+LuIZDAWhKDP+jtAAV6iHEuJ8UcBivFsdHOyWbHHz2ENHYqhFZYBvy+kxbLnkAXnnLlo1w83j1svqpeBFWkzy5DA5VUaGHdKdRqU2f2+iI3q7OBe9A5nn2Ot2GGTy+8GdtLYcS/Ykm6VHrGDZiIo6cOFzp9GkM4unXLMmWCru8tks+3tCpFSWf+fTOLuLhcePfHbFsNAFg48TjY7rRC0pe+GRgBhDi1hxcDlKFwe6Ym3j90s1M9QKhg3JRIMVAtCkijAhoTCXEVWF+3ZIv4SUL9rp+cmOLmNKHzF9GRy86ZyyKh421az5ONBwwuGs/tR0A247v5+pq302v/sAclVj7cNdzCgcPeuZlk+WZBuFJ/SNvcFs090NK07Htb6T8aEK5Z080M9ZM+ZldEXNXUeXfwdVN1vgL+F2SNErTD4iK9OPKyy5iJRQ4JEYvpkknuQ5PIIjbRWJGf52sGxE0fRF2z11MOX3reaX2M/zGMtbehYuUZsWVDsJxMpIiWHWZLPVkpDH23E4WAR/LUTFPJuiRyxTaVAPgANGIIymPqf/GoWvIa35myfmQK0QXiKJMvk8iF4VSTEQ8N0gWivzU55fW8TPmCm9CbZenjPAwZ/ZuZiqBHIXZmynwT8dA6DXc3phPYOEo4I5HuRU/TaBrhD5ZbAMDg2CpHW0r76sUbaanNg2yN56ttNxyvgTNtXnMVZF8/AtNb1fGHduWWrr8Pdwv+V+QTpdDA5voC4S9m3zs1mJ8cTNJLi7/nkxTk1wZRMJh/35O5fmmx4o/J9QaK52AA3RxfKAYX9wU94A3oilZ1DFbWEYGGCmwlKlet0t/r7YjDBtn60aT3pvgbruS3+Wiwt9AjMiFvgb6Rftz9Lfb6JnEl78gJ6V5/lF8iCcggx89qlnBIEhMEv4LNjeaLjzim2W76iSjfGzXm+VK72WnLXkURDsuiL+2rjEqhWWiWAbWdFz4CW0YcBmrF0g5oc/ZsbQpujYHYOyfOyHi+E7Yx464vh8E9AgOLq29NpcSONfICm6fmeFFrtnmC05yLBGFyzh9mozzSyu5wh/j8PTKBZQRR+pTY9VBOHi7sP9QbapPOJUMnbsBIjNkxETFvGjEcHZ5/lugzOEilyxHAc7BrbTx2q2jMdOIOQWK5VyM5cvzYjekeIGmKU/4yIlU/uAKh0eEdMDh8MI8LwrbKJD8bDbCufLcZFbZPOUFw8jJxom3Y0BWPKoF5vm+/Bw3GYmTQ7qN+NvwL4JRfStTPgFPpDPQWlob13NGJ8yxB+XB70yv83OnpaoqGqqxA6wz9hFm+2TiNIxtqic4MG8kDvSWid6UY4Iz0K4bDR24ucRNvBVtGxOaDJwxEk5bISwRm1YrWvqIp/1r3QsTTTVna4VmUQatsFyiq3NpELvA1JvM1+MhZHHpe5nmjlzoXgthq/ePdxAyGkqwg/B3O+kAs7VAGXVzeel87IYjrJ0cCDdQA3QP5MOe505D2ifj2QYwZRsLs1JAayA7hCTsdAYmo7RLvLO11ir6jwSczuM//HXqnKX11zK09FhkmLDbdi3qtc24Z1Be5wH1QhTT464i3LyMUeRLrIxtLXaq+olLggNbVdJlQ9tUqjFC1LK9AnF5c3rIwQqyb0we8gjG2dsNaHaIG5uB6/kxd7NqoxZ74ADpdDOgFManzdLKa12ydKwInUenZay1prytWDQ3nP+OlK4BaCmOYcTn/QyISk84Hu3nizvmoh6rZelfxnjhAC2K7X/7Tdg9PdVGOp/x3qA4dxyPb4JJuXcds7kde+Cop/fG7nD2Y8XKOvpo21lt4fy2mIwa//yt6arsKJ8HTAxayB3bHaVg81ru9yHFHwvLekPKkI8aa0OPHmnr1AYL9CieT6lnt8ZKxF5zKPRhOLBqr/L7z3FEmKTN8qSyfqdrzDQIwRlU7uSWSKnAj+yIpHBkO57tcX3NQaQTkwP7kLXqMZX3Gxag5wxCfmUOGUjoCuUta71ts6c2cz+scoSYqCOwPzJLaRK+SxVyclaXB7j3MxNb4a7YlZIU79zHabRSkRRD+89pv2wjlJ+TSb2cI2XhbCXC5bmPAryUFZRi6Bt4yZ+FqaLIegaa+OI1ZnS1Z7mJzk3pNyPxJ00uXsE8E5/EU2Mz9y+xuFp4JGAscbSGaXiGdOvRW6My6JhzmmF9tTbCEjyB3ahao1UFzCSuBJS4LSfgZ2y9rLuTyV2/mduI61fKdZYwmuyHlr0PStjLCb0OFh+Nfl/SzUKDPY5ydruu2I9I/nqC1jIHewNBTuZWnqL17H1bnOi4zE9jUNq89ZfWAyWWk7gAsIpXrdXw5SoZgZwOJ67MooDFntW/YHj7Yh6TBLLutb5mAWQFut0qJN66YZN0oR3zAcDwUVq7ssa/9O44DzIU5+qB34Xe+UUrgabYAKGbPxAB6IuU7p98VnD3dKw7CeI5OLtC4taKpkHU8M5drQLzF1sjbJHAIkP2vnEA9HXbUHox/I/9dtcOLstCHXjd4Ffqcu0mSH48Weu+n0wUClP3vp4mIDsf8F1f76W/M+PDJbCfjOlMZ47JNdidjS92HjUlkHE1dw3gVdHgkXxXTAeTBRFYIUiD2+ux5ZKYJBTR4H1DRaD62O4r297cvKExLZuejfXogJeBaXp5nGbHA6/TjzaoGiyGVRDMzwQvU+Rf8rkcPnWgUyVdKTV5HRz3lfse6+hnkmDZNinRS2LdRTAwAoOF8ko9hXSZ7PV1KC6we0mt3PCY/V6wJMl0jw7of5SlL00fceQSOMZrJKFmU6gOl5lnPpu/Lfyrerauhnd1JsadCEt9cvf9QtAyDqfNnaB5Zixol12I5srR8Jx1XRz1xqaatl6pNEWZtfjSlntNt52IW8aBtEVuu1NpTq1jI0Z77VZKOrkD6fJGljj0Ihn8GISXrVW4XswoD2IGAqQiHAYbszMBrr3HVxIIkznbaardDOpjJIIfKu7ZI+sa6IzF6id5WxCfIH3w7Zk1dosxbTCP+ri4C9iaxHrx6L32NS2KeI+MQMMl3VdPI2SgAQNCVfZB6adsAY5zB3T0yl92k95QV9sBa8xK1DF72hW7Hq6b8I5wkoqevOuyrD/UXSQF20/H6TIkZi+bMco0zkH7zhFF2t7+GkuTqst8FW7QIl3dYh3p24D31Bp75FfPrrNm7XKw6hcXVPhnGBZRbHvb6Kc0hbaVKoheOS1FBRH1pRZwktouicYI6v5URgYcyTFl8uphu1sviqRoysLcGlNB8Pld3zUsaEoU/932dPmQD4v3quRaJVVhk6itGL6pOkhPKI7T/1iTZqgQetak6b//fpsm5nvIDw7BQSF3lgipDqAif4riF89/0bqlboq4+6eT0qQ7GV6CSZxoo310PbC99TbZKFFG4mq5yupXfS0GO62qdfEvN5AxfHK5/czovw0NYqyVoqEEXJjFFox/X+o98OzbBhgSO05PdPaF2Jb1M8Q69+XM2YO+EufATLSWtvqz07BqmZD0D2V5x2WZP9fotTnYGFlIaP1Ok3KcCXSx41r9SkWavPLnLh7W6Ud0yy658pRtH4GLm7nj7n7eXs+8eQ4Oo3EYZ3ZnaP12ryrO7z3rXBrgOew4fCfQOPc5TIyGqpos44/TJnLvLa7+u09vuv9BxzjAydFJohklP1mBREgfnq7F9k3/TeBBRnls/hCcKi3s4o6eoyn5MusFgKeZgx00kfVWeewMbZargcqYdqYCH/nd2q2mStPmfRVM4jNyMxbDDLeXpn1Zlaej8F2IJcFJK3+Ar7dmrC7WXYyZOnXL5It8TXz0lwYr5tXIANuaHPgaXjoOO9YJyUp3BlOl+9iY/TGYVrnh8c+NUQJMU41J+22BqjRE9QyVaCgd4R8w/kvxcSn2Mfxt03J4zF5o4yQ7adcHfhgeWPGmkZEHi9X16oSf6RQRnzfLzGD6Mv2VwQ0A6CxSEkUQJ3GZk/Zllb1q+f/efTZaT6F6fNXwSFd/4C3YGYhvupEfFn1MBsUYc0XZS0unrRUAoDA4Tg4okk6/bOI4S0kmKOma/ENZ05xZc7ayVU51eyeqvAXvw1XR5VdrGBKhEUKrS2FZoTSL7FLj9O5wAX+zyW+cectuDk931M7bGLK6lTvs9bIpFNjBibgrSzthB8r2PyM4ZrgEtOrg3D5708jkAXXa5i7kRsH1435MPfncICqpwTL4TnvwyBL7TRgqu/hZYY+gRZSTpxu3CotIrmuoYU7IX6sPT2eEbp3sK1o2eapfh678M8WQnKcnz+g8vI4mmbL6k5zrwMqk00wSuNhXgQOALlu1FmeqJ48PeFFgX5wZ+FZM71Cp8IU3p8hrPEqKkiN6UHl4De7tFF+FDFX4AHNkZHbHe4ZTjuXJtSLbsAA7G92Pdw9dWdZMBYay4m3EYwpHfQ3qW5c8wspbhmTwSrl26gaPMiy6wYed3bAXsakf5N4z8dtDPCqapg4F9RpljGAp2YKdS+yKxfz7Re/+Z9/Uw5DgCXoiWw4Hi3EH5T8k+/28TE36/DlBfFbhDt8obf1Z29tlDBR9e+sf+xWQ17JpZBXnfQPxLGlfaKsUbqzWpy8NF+VBxg9ljc5prWWssBv6jS1y1wHBUeIhQe/+DkEH81oWD3mpPDuMrED2GiIC/fEg9kA0tFngx7Y3sgWtlXXm3koaAKIh1RsFR9acrZylq9EN1ZCKOYUgn6a34FB9x3Xl++FUIW8xc6mZBUUhkeEpbKpvH4+z/mKTZsYZ8Z5VRCWBnfhgWoAYeNv7vHnaif58vLB3V4797kVxZQppUiwnAUfWUTN/rbuxsMN+lABn/yrndpUwEEc+QKssnC5UorntbzF9kRB2yU/XcyBRpsWUaP+lfy/8Nc1z5ZxnntpVyMkdqIrtT/lwmxq0f1lnMt2xYDHjDvTFQ+WJdkqFV7Okb2FIE+498y0iWS2FE9JJb7ZjQVVPiWbpyuFte0pnLqsDjntb0JxuTGiV3S7sGgkFxD0yTNetLTB1C2qqU0VaxzjbacyNZjnvmQ8o26KzTEs5/0jWYnQS8zv0/feJHGUSj6vt8rZSsXxy9nQSmhniW3lRu2/nY/jfTUWK7V1arY/PB468KF0aBIr9XAXEWrBUXr+vVG8VrrINhozOWkqgWJkdr4HlrNWKoL1c1TpUG3Yu+Gpy4WGzDIWZyy5RzKec25f+Y7X1ZpJTGGsSVp6cYK5Z65S0JOxiJCFJVr0mGdwGEyKgcYdIzL/h1K4jv3UrOJAPYV71cvlrp2lcVpx72a5SG/3utY5t19Yhjt/WYBABIAxFwCEm1hWvdq2sZXA5+fhypuYHaTy3ZBH9Sy3S1/TjhO3eGQDfHAFA2CcKrmFVAMlWcgrLB93Yciwgs0NT41+IOywSYxqg0NaEGuOQSJefpVVAGm7St5tVpWKY225vDJMKPQb9L4NHLZaIl3JDrTlojrtIvp1D0IcFVco/LDSuYXgCX8D31xkputhFdRe3w8F7GNiTVRggz9FyMujB1P4QP5euXets3QpNsIujBS7+vMasaJPCcka17Am7SgW5mf9ytR6vq90DA4sA+BzNQofNNiRT91VZdzxog2Fk+71DpRG4WGNzvBlY2Xo/ZdnZRpjxvobQt/OjrN9zqps3c694rm9Iatw8WIcdIcb/bgNiHAdwvoZa9PjQG8djXZiaq4SwCFsQB+psjpxVmJ6o+ubdpjmCnO1v1CAJFjUwdlx4Wq1zw0fywHuRXwC4L7XhJU0LceeCddZn32tg6/Jys0pBZVUuQvs4cIorJv3DCVqYMxuqta2So/EB2kzegumI/ZrMyWdGQLl0EFwTJvXMXtttKhVJ03SfSJwqWlqgFXxKYVfEIYfwJoqhLB4sZN2zgTZbx6mGtmAn7O536u0R1aJfRvG8xQfynAzIyrZ0IefVvEU1KIsrZxJRdcCpPgc2s5YvzipnBp7JVm1ouhbbP/R/TYEaYcyRbpUumNz8GzQlT7YdhjSJz6C+RpdsM68oIwPN/yWev8to+tY9f8o/EIu6vr/BxHO22Ihypv9YtQvD6VgdwI9lfJh0QGccM8voaaQcOCdZ23TklrdDsDjLdOg8te6XjYIVKymoJBCAp4+udS65EdmJLlWye76OkxYgRd+yWyFLVtCKu+y7T2LQSkDAqdDmSpZOoo1rgPDZULFfrDfMUmMK7AwMNa016Sjo4wVuuJkblm+nCyALSvCqVuhVUskBS/UaesJ9Dp5jlk24xYQGx9128WkoRUSzm4pKst1CoyrJ++ye/zo2NLUFvzBtYaOK8JI5skq9VHVivAUEZVXLd59AMCEPlVjCTbB/M/dACUcCFe969eg64WufBxD4MdYhizC+uxnYzm1Z0Vego27VRUvPshXhqro5LUqt5CpDbdOeqdBHfq8wLpUEKV8/u4PnrWuJh9ZnmUoVc+lCBEVF4U0/2JCL6JjldDA7VpwTeMdCi4tFOTUqyOaE2sAJK/VaRsL9InyxqpZ5aHEpdK1UJ9BpROJ3W6v3vYpHAJyfjTPx7hRY6l8e8drOnkKOSXtbwgb1U1rIyXty4d1w92yHB6EqArkCBtz9IX7Lup+mN7H5XCXCWkofyk7j2370IcxtVLU2HaDwFU5pbdu2rpxG6TPtbE1VUMJiWf10KRKksS0cLs2CnY852XXmB23byONabRxKB9qaKQXvhgiWPQJFewwDG7LWk7LaT8aTzLeO8Q6S3ua+cgK0nh4wXogKvLiLchr2AdvKlUgrgtYUCMrTHwtvKWiTPDfgqKPa23L9+TSnZNxujmc4EuJOvYf/3tk810P9Omyb1mMuyeaYU6yuEypXy42TLejsm+6JhiDRSECGGRK+4VrugKBTIjMx6xrzEHnJuFJ9xtgOmQPHMOoZeHNjYd/Dw4no+NCu5HP3nne5JadOUCrJLHNOd3QAcWEu25yij1u5XQXPXuSACLPL8AzeJL8ISUkThQdZKTQjU2EN/BPLuKmgUepsD1tL3QTP1RS6sCsL14rNosV3iLcyH6SRx/W3jlHXpPTL5C8FFQdergLaPiVH/oVLrZEWuz3sDpNn4ycP4n451sNFjOjeoA1cakGSF8J5OzgWcwdMDnOn9sbI23f4IkNpXswnzHErp5cVK15PuPn3YfTX42eHgKzZdI2S2IUvTw4A3VHUt2fRvHL7tdLC3SWxFOHAawrMebuX7++pLdrWVd1yhS78Yd7ARIPSP9fhNmtA6NhgX7Hgxcjbou8Kb/jPQyea++bWeqMy3aw+T3RXBNF6Pj3taHH76yvBvM7Qmbn4pZaU0K4yz9lL0Mk2d5saxhy5UwCr43/Yc5V/sM3bUBGzhxTtmYot35DkjgvwD2Grn+VgqfaM+XrPTzbZpFaY8iJ2U08uBtJ4hb7wU/zjWIdfW3yY+rkDZJzbWzcf3cWVGuUgQ7aGwsWhzO4G/psfhdsmqpQCxPCmyk3acvcI7Y+HGolx1MGGLPiV+YX8+R7N43UREC1XTQjM46qeCDOOZBuBXzLm5TvIx4+FMHGO5wYAv7BhDBIWg6STNZ4RBibNpU+hlJQ+1Dp99A9nJpg3AxbvF3TEH4/9XQG+9lhw8rjX8shqRisS8mAZzWKllq7d5RrQfXSuuLAHfuZAsnMrjsbEP+WKICePaj9lGuNN7hnQNirOe7eykQZr934TQ5VSo4VvPV9NGiujg7dhwJWpI0lhzEpzdWErFWcCTqqIj3V7ojV6HZo3HU8R+lsieazBCpX/ikGXSv3015eDRKLocilcV2Umap44yEB+syVKbZYZzx95PhZvkTqAFzRd2BNji/bBTolgGPG9jYEXIairjbr0filxRW7bRSCWKgcuANtHG9/h/Avp63ipBHilWBnbrUi8ukcovYj6cuPRItnwl4DtGgSfA/yZyvVKFQ8NCm1meC0khRa5H1D0SgFf3FBjgL2EDbCobrzBqpuTxeKs4HgOA/GMg6vgLR5GfIxzciRgb3HHQHCZfMriwkHA6HfbQnBAepQCj8+COjYBd+ZyrzdOYSJlr5nnN+5FHka8otPZoTTMF2Nof9yXvLt+64Cb6ZCRe+o11gPpe6/5bRhGPLuRxFGJvJQvQDzeHoh4tklJZOfblNH84zzyVgFsUG0uXi3YMrv1xmJ8V2UAY8f/vU714jlvamtmyXKpE3Pw/AxuUG4dzWGG/+LPlrXev7lYTD1abl2O68bsynh/mXhpYAw753yUQakl4rrsvB8T1xr+i3c6NjG7lg1D1nnjEstrOyu2Xxo7yV32sMjK9p83kt7it6jKXT93GAfqhNWiJ2vuzB5HtAtViqkGQaybTWlsOXoAiZ1XEkQPYoMiE9j7jfDNNko6CrsZi2PL0ePoY0WLAK+sm+HCjRnZFcdMWSiL5TU0U/08U/R6FqqTzbqJgWFE7x5YCy1wPl1YuVdrB9FuS9c1IDx3jKf9R48Fm5k+Jh1l2I3tuCwew9mvZxy4R6HzHLV4s5oEzQyAhZhtFoK7n/UUgJbC1ld00sTR8cAIQQvM6+ZSSuo/Zb6gfhuPR3zzfCws+6AFhkcZMK4p41B9OVJ0MomlOQh3cPqPPl4wh75+SveuSvpBGuFF3f0AQaHcpdH+0vyjqQ6kinSYSjqKYcR5Z64LeNym8+BPV6/q8sOJYYKb6oZrisKHNBt8J4atpGqRSKoRHPtIdqMIJ+BmyN12sHme++ZgHr83XjpHEzhk2l9CZuGXYekhG9HjPktKu+VXjis95agErHvb+It1m5YqL5tL5RD8mSllcGzYIbLG6XJxI0sSFb9GGWpzskwyliKKWGuhnxKwAftON/w2W/32LucC7UdmmNfmqAPyZXtVv7TOSfTYjD8JVs4eWsN+nApgpbi0NMwxZRAvh+rhLVw6l29pbTtGtwWTNinXF2BOhASDnfO9Nge58roVsad1BA6Z7mTIIThB+VXq0307tLhFOqRKPPa7cazHhAkUMlXqKLOgf24vO5Jow0+NeOp13p+YUq1BubCIIgs2tDatfYG45qzGAs2CpkcVV59Wbm7YMN+CRhahWoNUgsphQs0M+htjjpkuTXUWfIggHGEL7e5ZO128twS78XsTJaL8Hg4/ZE3oziRdrjN09ymEJc1H4YXvbFulOkwsMqolG7593ORpIfUmsm6EHXAyWMBVtS91E/Yq99xLIefhfTD9IfzTV/zrZzX6mBtOklq2aICgG5nrZaXm6Qgm/1nXkNeb8MgPMJ/8ZqASw5dg6ODpLvcZgfzCakeXyTD2VIQPnn8Bl4IvkXiPzDdkgwc7UiL0hGHG8INNy6OL6sE7EggnovX5iNBNZujpC2tiZ9XSaHpOeHfEVfkVn+xo4uP42D/gDV5We6cNs4arLN1V7yqv/5tq+Be1GJ73wjYyNRJv6U+t+Djmbbz4JUuddc2h8dIlqTpA6jc/MQpcuxrqyIz1PGznK3h6qRiFtGhEpBWdTge2PE07Flj58pVHsNrZu+w9taaPKNbCU0ke6GqMvF98ZoLVo39zOVW1c5LAzWOJ79ANQdWrjN0rdHTe3C2xwLnHveFT0/V//PuecDQRnPDvduZv//Jn7iKZdw1mcz53d6CLa9Ib5zU2CwltnsEnh7x5CDBDneiwntqqAdWTLz2hapOH8D8KuY1GytQH6NJlj6VquL/TZtaDCk6NqhcfcB3KWXF/lk3VoP25I9dFqV+us3D8KaVWDqpvfOmOVGP4XWynt7VUaQMHC9Ut0xpZ7k2eLmpiGQ2XX1fSZOlJJsc+IX9Oo+mZv0aBZWk4PXStUCDt7GJKipQBK0OmaToy92vnnaI9UF8GVT1EfTFKS3OfnpJ6JixV3Cw7TdUNEfALDJXRlwWsvEI1M8SI+IVnrE/tBpw95tg+nALDXksy6KpzZBLLiGcpbb+RJnNfSTBGt2F4zrzwfNj7PC2iKOL7QnVrt/SeYjw44Oe+arUiaKk2XPvqfj+UTEkBIywYoO004V414tlkqmIx4HVUwhlViS4PzVJ1r9DxJdBrmsStlje05CYJWb4PZZ7lryCiW2hHSsSMrB5oFCDQ7R0YkUWmiiYqCFnYZ4699Of1tjntjYE9eHPKbbWP32W4BWkt72sy+je9SbI2ROiUMJPMbm1/zFSmQ0Q4yJ3KyMlO+njCKPIr5jlHwdHEUHOvfTOsguUzS+BQzrODdq69UOhipQrPxbK2g89s9OEb/I82YOE+7R9ln9uoMeH8YP94rlDEYm2Xr2v8mEL60F3MUQQUSoldY1p/eovbiCYzXV5UFs1zNO7UrMOugTvCR5XCfw75C74Oow+Zg6bwrVvlPxkkPbpEJraFibBzwFblecrSa67h/awY0Lr1z3FV0GSwjGY0tCk8KT3hg/FuUcyteurs7gnQHr4fUodNhkqPLY7tDi++Ltz+r/s2r+w6BqiXf9zpr4sbbolsrG31xgRg29a1nSuAcezno/5GGda+xL21l3Jw24LVDwD21uuv+1ukbHLyVNTizJgPbKve/njHBoCyrn9uKJdHwaLM45HL5YMUI8aY86vZ8Wb7L0N7KAC3XpQcXZQ9E/VhwyTFbJRdX9r5qX4pEH5CFg52SI6ChRqv9wW9oz0LFJtxNvJWdXY4P3zV/gyQ3EaXHe6WHAELtUHvef17fztNdcy6kdLwH/YXgaAX06Dr3xonOQoW6CL+j/UfP7TS7pl1o73Dc2SfAHFU3aQf2pogMbZAlwh8a/DyyVvtftNVs39kqex7IL0tRNWPbkskjIvr04H/0y8tP9AKXrLFBkfWy34B8miOwDBRl4wfA/MNuWAV4/LN11pRynLl6vjICFE2G6C9wirDDfXJEqNgPlYI1TJ+evhZO37Jlhgb4cqWAHU0z4ZtqU/BT4gau0NrmH/+iBLTZhIFzckSO2Qt0N4WDWHTDVB8XMTUFyay5v1G0MleHkhtKnGRdQBDtKDTuLMhFT8KiA9GuOxlNas6upKK7VtK/BEuMF4Vrxj3NokZ+4J5NCpnN9e1kYqXgreXRiEIsGQvmvTobEoXGwM1lolYDw5jDZPUbam+qKZ3lfIRDNiu4nd79DSni43jrFOxIRwxUUQqg1Jmb0ku4gXO7MW3eva3ZIiNgjnWrXFJXC1XRapY4ens/pIKVgJwtxLu9hxu3SU6AebYtsdncV0yC3nYUo1eTFHnYGkDKxP4spc87DnWliU6DmrsuxPKTWOGAHnMetneeai0h1UKuGj4xZaWMZiZLb4YWy7OtrjIJHZZ8HdZTI8tTR2x4B/5A2GgddXEuzvNQSDSEOlZ6jT08Dm/s9mQYv4WTP+moqTugUrcZN/BT3LpiL0/JQHRgY2Qr0uzuS6eDHG9id3DCtWK4WAn11DakYnJb5H63pyToYkNHMv6nvU7I/UYTEYLvBXQT6c5vT227Bn07KxvFLlnlfUGaNykvMfFvYlqSapouLRnY13Brs2ZIv4tezZZIpFOIhUjIvLAA7sFF8AdC0XpKiQPhoWfCsvjPF6nQcPPd0mwTJ+ffkfB0ZITe5OzSvMcG3sPO9uKRApUAkvlfKEYFYHq/Pz8TvGQq/IF0F9LNYM9ea7FkufCHpgH2c4mSvwypTLRDxkMfZAyoZRJAqnrJ9uM2Xca0c4wmO8aHL+iFsBspVQkQmUsSCUUgE9/NzKkvNRgwdbKRFJcUcZQmKzc1Zh9+Gil/p3QP6RP8+EAb+PAwmkzkRSBYamCB4kVEu9EgPlrr+ndG5MBjEAA0AI5L8BDhj244U0dhDrP0tEO4y62AKH60jJx7WkCC3IbWqRyHHr0IA8GYb4Gk93+gCW1mbN2LvtREh1fkls+AZ2byMGQG6iA0VlBgclP2bSmrrn5D+y43zfg8LJ1aS9toXfoEwaOx8snqvb6Jx3SKV3SLT3SK33S3xkwV+x9+5h0utcjjKvW9oe0Vz2DYb5xCSOdSyiM8kf+TE+APegGOWG1ycUSSC3cgggxLm/y00AmAsBBLGiETPyGdLFEiErKr4p04Dm23x7ZzKzxntG42ME6iN51rOuShnOxsUbKVLWo3pKLHrlNrkB2PkrErkNm3EbXFMnOvw8uVXWrq6ayNdJqEwy2Q2W3VEHUAlUUvNrwNVuLGlpDrdOu9atLPbrPgEYKNwNNg4UdzCP1iZAip5eRdlWMywdgIC17SyL52A1vAdAKCYC//O86e1yXA3mT0+m/V2P9sFXxlflqZDuyv1gO+OVirg+M8/srfw6wE/7+tOh7/afncR5TkvJH+W90y7Ykl9J2L8keLG9lI9kbc8r7t86XQlD/fgnocIruoXyqwfKaRqb/lmixCOPudSwFHG21XT7JlQ39SJhC5a1nUAHrrTvoE5OyXmCwbltVLzEEdFA38AS0RffYuf60004on1/Q21itb+2iZzisv3pSxnSuGZUwKZJ+9HvomHemV3R5tdPwko0IKHa4VC5/P6m/jtOxrecN3/gibzJtxQrEGJS5MpCqXovlWz0UcjuFyfMea72bgNua3l9ebf3S3ZDxauNhxvXxp5oD7Ml++x+9fEPRnxOh/3EYD04DeoDTpDbVEh3nya69B8MspwnDBb75RcKSNt9FMJjnAHj3scUDAHw8NLs6fPD/4NRrZQNoAeW/nf//9zO1vXQwvy0MyE3vRnRjPhD7tkzwlchnVnfZ+WTAMl8l2CBVmU+w12qpcX0X+chlr4mTiWkABjUHNJYvjFYmOLPpgN6bhtEso2/w/bpkMM8TufGSOaLa4T7NrF56TPEjQpbuvYxgqdrbZGAHXUkCVmNPb+I0aO5+3XEfWtljP8x4ox2ZxmDwExdDJynlepvrOoY72V5KqXLcl1wz3SSPPxiW6J0ape7o9AhUTP6iCGYHU5XrrmJMAitIJexZUcO1pbGK7WhxKXdlryi4peIXLJip/6iqlDtTaQKMHJDy1k6IAyZ1B5k5Ord2od2YJoW22qHfQGjtwLDVeLacnaVCaRVW3YV80uDm4YhhcbBWHZhN7GwsZCBfDMhy12EEJF1uPJT/H+zCr1/cybhjnDTuGW5MXJ/+5rRrF74+Tg0NMjWzJZQ6DWjs7TQyMI01OlcEqFIiURu6WTx+v0OL8rI7A/UNP8PRWuSnq1bf/+ImMPi+4bC/dVE/U4pEYJMFhVmhnwO41zBkmxpqC9bmsYkiLwDkaFBsfpbu8O0BwJ3Nl5tNm7abt3TX+dg7pMnFYDnTlIWFStx2LWlIiPEHUnVWYgX4URhI66xzi3Zi+7tl0hwY5UznBrY36xSY56P8jAqk6RzElReTPQouWEhCVQnDzGV4JILnHe5kK9I86h6XmLs1hhI5BuR0xt65haD54O4r3x9jZnCTRJ3y9hIR4jPX5XV3xlvu65X15jzd+p324wd40xUjZ5IbJtiGZu1px+wtWEczYpD0Z+5qYa/MzlQd1nykppN2+uq8l78Y5ZMtm5Mtecru2+N1esEvjvqKDZw2jmMLzuesPH9arvvqtutrdSzwo6uTvvzogxsV79vZn0aoETLrib+0799CDwz1+Y7GZb8rYvh+anP1sZN1tuiWbWzxj9Tkvem8YlvyhTbSqjOIrLyMlnuifdpF7WyUxZu0PrC0SQRH7QhDcoqIiQOc/k0eod/ua64J7NRq9UNdF32642yoyKperi7VPrXU/qMDsvl+sWXY50yc3JMaxlonw2InXVq6LceKIQhhXlxnu3fVQZ5eNg56Zhy2XLGo2Mb7w5VNKa7fX1CRvjHrFcVDneW8xod4ryL48mD36z1BBbZ4fwhi+knpfDJaOB5ZKkVD5yY9/eMGt/CfYYnqkolhCkT/5kKZFZSLGH1/TmFTvaYwe73u3haLpXa7LTD3CN8MRJtoD03mV3J6og+Qa3eWcu08WUakWo0rd5ur+2H1vLq0UtaENrRY39xxlPr+CP2ht6Rlfu8F26RgKTGfLfbwGDcyHfWukzaMmTs5oe/jlY9II3h+AMajHRaN7eZ6NCy+/xnQVKNpnohVueFv5Qrlez6eRviT+3ccdDJOPEhl0wQB6AbN8GSbAwKKGhyAPQAOCqCVBLNBQhQAblvdT0AgEZyAQmDwBAx2ogyx+ROEECNAiNtxzYSEXzbggN4eu6iHkOGkWeK6ZRU1qgc9KwsPYXoVpk+TelLDWBS8X1FWfkIaX0ld0xeXQgEugYuOgcGECwc1MxFSwQCboHzBouwYfD61+dLKcFHdpRh6wwakY2lVyiZGGEsWid9iLikgy0s3yk5JcXSWg3JgGbVQzrSOPYpE2XtWWayqxirowngWphIrP4Ubzuo2QFN5M5IE5X7gPDxGBF/h6gATggEYw05piBCCQ4QREUSUPS/404aBiBR9XiFnB1L+8U+kSIkyFarUqCPRQEZBpUmLNh26aPToM0BniIHJiDETpsyYs2DJijUbtuzYY5FTQCmpqGloD2Rgx4wTWYY5ZuhOPPAdFBIWERUTl5DUznvLyOqUg+tivwuLTtmtR68xfkv7VQwYNGTYiNH+A0w9oc4JDa49EzMLKxs7B2cJwoq9fAAIDIHC4ldFotD8AoIa+asXE5eQlJKWkZWTV0hEWJeKqpq6hqaWtg6H4R5zq+wVGJxSL6fQlnsBdn5DBCKJTKHS6Lx8/AKCQu55LOqkV09ISknLKObv7ryCopKyiqqauoamlraOrp6+gaGR9GUM9CUoZ80io/9C77rD6fL08gYAQWAIFAZv8cA4lj0m9niIlImMCR03yOOj5b2IJVKZHER/dSu1hpwCSklFTUNLZ6NfHyMTMwsrGzsHJ1evRy4+foGYAveYRAICmqCCJ8Ym/N4ueQVFJd169PYq/F/foCHDRowaM05BSUVNQ0tHz8DIxMzCysbOwcnFzcPLB4DAECgMjkCi0PwCgkLCIqJi4hKSUtIysnLyCopKyiqqauoamlraOhycXNw8UBgcgUShMVgcnkAkkSlUGp2Xj19AUEhYRFRMXEJSSlpGVk5eQVFJWUVVTV1DU0tbR1dP38DQyLi1Y2woqmZ3iFM3TJfl9vTyBgBBYAgUBkcgUWgMFocnEElkCpVGZzBZbA6XxxcIRWKJVCZXKFVqDTkFlJKKmoaWjp4BxsjEzMLKxs7BycXNw8vHLyAoJCwiKiYuISklLSOrUw6uS15BUUm3Hr3K+vSrGDBoyLARo8aMq1CpSrUau+2x1z616tRr0KhJsxat2uYIQBH8hQQfPB7iBnpXia+KNiiUTNLlXSdjHNnwN5QxcIcDxFVcK0sXB9If693rq//TojCbo9TSkJXti0q/femY7zo3cvwsf4Ng4EBFLLiO5zoOJB83V/IxtDRkxewPYq/KLpo8YouzNitbal2uYRPs7JKN+fPkGJWo3QsAJVATpaSKWqFO5oBwqP2dh3ca2rmYiQsRP2IKI2fomWtcOytEVe3op7us2mmnCvl+GfZmYftJ6+4DsCpfbZ/4yCxkq7Yv1MPKxqLpsYCwEns2P7GwMdfKRR+NAw+mT6sYw0xbIIK0APHOi3ZaXD+vbPzYhJAUOYOc2d5bUzRuImAiIBbAEmIBsYC6E/vL5iXV68/X7/w577AZVrsSQf2f2nYicf55N4ePovU7M7+fpc8IP/xlrhK/9PP0PYvE744brpduPrzeNGzw91bVV7BwfG3XtdDM9uGXKT8s9e4dZlW9E4djY1dGMSv2Di+H+IQ9KbRr2fPAMjG/Xs9bO9hTf92/7P55v7nZuipAeI2HO/5T75DP+mtAs9//ez733M3Dg7cTb9/fN9f/+nhWpkW4eb9fOuf8f/M8f93vhDCsf6PlV7caw+gIZszE/1Ns7XPrdWbrp001GmoXyyxuxDjL8L0BcJJoaDVqIpQjqwIj7KGg3rxq0+qYqSITnRiCTIJGwGfE5rYl5SgJHqKsr/gsW4gCsgQKSAHulYZNqFizU6Zol6qAAqqCFOCxJDJmIECwIUq8etGqxWXGiVQSOetbzPh0N1qAAqoCCqCAqqBPj+y76Pky9Ut3fjQqiI1Ja3yKkX0iYhU7uEW3f5myXEKlRJGVQiSl18AUcElTBkdW15I9tXo5uzpmU5Epq8dpyhNnzd6y77HFv0w54Hf0KCkRLq9n4NcASq5H2eyl3Q/E8eXthSV2xOlW0VUkDudr7sjYsqUhUXn3uGUSS7i1/kRjV3ubSCEhqYuvU75nCv9JSj5tt7OgVjfdNCgdYdZdAhFpKl5Tipg55rWlNU485U48iXPSg7rMKiipi8jpl516+tMqOXHX+KOqnX6qo7R2eJRU1YvxSKR5sj3qwo0UTphhKKkWF4m4lGGkGw002yzWyC2lFGVcZifuqyZGFWSZ7bQyfZjUZhr/WGOPLJmYV7tq7EmdMd8Bb1fdf5aB7wB8JCo6JI0b6QEPvMaxkZcTmjFgGbcKNz1rcAvbq9S4GPHnMp7DnBYY9SomHGuERcZxuURGLjEkUdm8OnV7qkdwJtJRceXkIrq0HKWI3vWuh0CiBzC1TuNU1heeC4LdgESpNRdtmg5JRn4zsGbRmzGxDMasJbV8o2QnllUjCExwI1JHC4VcQrH2+klqzwfWzhUOiOFV7cjgAiaoYO1xhcYgKgn1DJqHGB7TZ53lWWekTt3+hAis3Eq5aXWtlGzw3kKzpxTrQUTA7SmTzEdeVaGRDg1DkQkVn8n8sKpmfYU6Sd4HA3RccAxXkaD39SK4Gbm1wS0bTqySfM4kFnm5cO3OaKIYjYSAGLJZMxEl1aYnrUGyF93N4WTSLS4g2R71GT2Xev0OT6FgOrdjpApC3godjcs/aqeXABJjxJy4nV2EyF6dZkGUWlwXgNkwV8FPFufty+mrNugQZ2BDb5jLCMrWwHA0BMNYE+yuSwDgSFJRyevUCUr8BScyLoHpUfkkomNdUTwwmeLuZEr5lPJ2hGYrapoSTEVNNJfc3mSIWlzWfGwMw0QHCjAyZ9mwUqw1jsv5n72qSZxQihcz5IY7fyMw6ffOrS3k+exfezZ3iHBM66h8wrPXOHxJzB1OcReVjOQOLG6XvcL9NJiVpAmltd+OkVHFGxPSwoiFiXDBE4OTzPRkbKSNEZSaYK1c+GCkKAlLNs1ZYxcg6jQrMv2w8g7tf4L58G++6qLc+/l5TD+6p91xWB9/vXSbd4716I8JTTv/dF2y6y923fQYPDpcTfqXY02U5dq+Elyjw8U17uxM18/D2pGoTA+ty1JZFJRNOTufQ6rhEDdYRoyW8e3ot6tLr20w1UlQ08soRT0WnslRcuvA4jeMrqFhRpZ44KUT0Yo6LLHFEVeQYPHEDwQtlymW2OKIK0iweOIHgpbHFEtscRou) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}@font-face{font-family:"Poppins";font-style:normal;font-weight:600;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAABWIAAwAAAAAMsAAABU0AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIIACskovEkLgmQAATYCJAOFRAQgBYNUB4ohGycqFeOYFbBxAKDGbxZFiWAUwf+fkhsyBCpQ7z5YpKILpjYCK2Mwv95BEHgLQ3WKIlzSlsYi5H9U43AwcCY894dpanjoZmuXBx2egzxuv3nQ3M/vF5tKTKv7xZbRJW2Lev8YDY0kJvHfj/Hbc+43LKmGTiJ7hURlOl6ih8YQiqZAs9Bp4u8Hfpv/55pBGIlRmGAADlBBkFIwwMLI/MqiLlYtvrI3lynOZeb969Q7fcnPufu/colwajpMX2A7SFuJ5DVqsxdwJNpoQjAE6wJCAQQobK6N9BRQu6OL2y7OjqiERMgBDs61iUQLDgskEoDWGF9Jq7oLgEM3q4bqsDO+y1RRScIVgvjV4h9KvZq0GSBO7i8VHer+0unXrrK78+NMfKQj8uUIi84/RbVFedA06ydtPLLWSeRIIWA58BXnQD4A6oAqQuqBoAMsGuC+vqI+f/Pf9x69HTupSPDZNEiQdP6uv/0YJ3cO06o/PIZz79bGvExc3E8BsBvs2EEiL4kSQA+0AFgLTDk+fGj2tbqdV08G3BXKghu36+I2NLObRBugi6QKrl8xJB05IsA2FKxNeFSu3uCKYT84u1/L5v9+yN2oaM0ZgBeAEjsDnBkYKoAxDggT4TW14LV5wfb8WAD7gBBdxDYuCQglvMQmNXlpT3f68qe2TT41t/005McwAmF1r+5nBuwM4L81gBggDvFMSGgRJSHpKdzW/F2rnI7245DvdOoXwsbk/9fHbF/HtinzNGbL+D/6f/Nf4+HIh9/Dkw+25osA8p/yuwChKIjmho9kHLewgtCWzOhDRZ6h2UKAcTlfyClu1BSlobob0abbIliDI/4XQEv/AzhJa39Ej/Zx2/QBArMqhHOPiw71gwEPyrl9wjL3Ma4rhDuZuSHD1sYUV2kXTJiUGOIUyBEsQjFff6onq162gMyefpXLYT7r5Vs1MbFRktI0Y9RWE2SsoKP9CGKV3+xyBMhhfgp9GEuWEWXWRN6lbpJkL7ALpJJL3mqzPeelkAMemAhR+eeX1n4yEolRpPQx5dBCW/mpaZSO77nVQsdd/XnXcUqQQZYKjwyUcbhhaiV62xReyNyBYE9TM7i8a5hA70eldS9m72IKcxweDu0eqfkBjcBA6Z0g+HL4R5a8H4gh3hoqUaFEGyqlplIuJjfhd+jIPAH8Xh+CI5ONM0uz+NrWTH8NZHEXYgqIDC4FBgIF0lKw/Ij4EI9QQVqFAHfHSk2yPAZpsU01BllcLfghm7DCLTjP0ihVGnS2ah2vSUXvDGRH8K7FRtP6r6vLsu4YDO0heF4pzCi/pNVAJlmEpUbgYhcKNoL1xYn1RZTwdQkXl8rbutoHwgTHk54CibUSFZSCixEaPBnZJDwkn/YYgpY5VgECfnLMDyN4nM9WsO9znt8Jd7+qomGvDUSzqgH14SGRVBmLkMxxrw8wSKTgAjcLjsbnPgmnWjqQQUhLYea2Ad055nYRXTiiC3j4rMBtwUkUsUNkxZOyffUaSpYcFQ4k6Y3nz2HqzeETggeFn4zGye5Sjd7q4ilF0t0eBVXCx1i3IGSBM21v8+842tPAjTMFHBPOn9ZHhvORTZUupbq3Cpy6OFaWC92iL513Kq09GScSPo/vv1B7NOtF837+VFnFoizCxVv3GYKdMCSRkJ9kzreaVsIIHE8PGfjFNf8hrCEmWQpkxAScKJ4aj+161Lf8UG4ZFV8LrEvvC/DG6+4Fk6GZAAa6gUxPJpoeK3mt+RFTU2zIAEFPnZCTMAOi17ApcT4WG0muih93i/ezXNidx358n95E5M8vZuEBKBNLba2zkkx0veTh0mKzep8jNDLwU8fqDlSCFBo9wYYHGmq1QetZBOb9oXnOfplWvC8odzPLd9cuXnelen2Gfu/39FIIFZQSYUYJik86ZsGlweUeLhfeAo5Ag7IOZHoCNpCp3SFFafcDMoKMQxpOwW8Ec7S8mkVIJVYb9lLNw/RSk3SilbpMSEgOmwu9jQikFvH2dvQ0yiF3oScjPNb3Maifo8nnvuRxWAxMPo2B676nxxMXuhaJTN3ieUOSq3RTJeNzbGDwayKJlwG1P+aty9twJDEAtU52oFG76Hivx/lyDp5Tg6VMyWaeJ5ZytRSyB1CPflmB+YEVjbZMmWiteEykr0Cl5LHTli53i70JGh2XtbfcmY4ANXrLHAYPdOx0XswkbcUoMFjFRdmXpGlTeMYx/dz0XrEwYc3fY96Jg9X9h83F7+4m7GXx5fGYTbYrVZgQLKrWia2iUDPpdUV1tDoSCV5I/ndv/34jtuumBIQIc4gRBe0ZuoldLh5exAN2hDfhRrdjbNtC/IKi83w5uQ3ZuvFKsq6n5wFbuJMkypOXmKa3StuD/fP8fatJCiS3rDi/uKKqbG5JngG2wVseIArIts6G93MsfOf0/1SvoNaB+M+5LvgSB+fDctV4Sm7dpgbnookqGYnGSKcGFXA5QYXpVAZNRq6acC7eWF+fO54inyiAyalJacryoqKUpZPS8s/qz4Wshoaysobm8pwzOXCet+lVxasp/erB6cFqID5rifelMjMowQWR3JCCLEqEJC/BVPi+pLnZmJfa0iNIyVPpLi2Qq/RF5tZvqCYUwPkpNaqm2vKnFdU8CsZQ+t176DRc5L37KLjrrEjNUBXkE9fjs3NUqemq/IL0T1fJbM2gBhdxucGFGZSwsEwKROBSijKpYbBh1JRllm6F+h/JEZfH4CZt2hrraPWkgFpaHbzWWUFip5kOEbMCSO3ujonz7NnYBHd6DIvJSK0I4JXOK9RJG8N2+Xvpe9pF5juwsVIPhjiCSsuooEaD41SVmo/y1VVwdmpzFF/AjuQLojYrNyWLmjsY4ph2Br85eRMwVeqDUysV7xe8XwHT6qFme6X90rk2LTZQMfXq6Cf00+ujyweZA0y4VBdaf7uUco2qnhJ4tz33SWE1EIpZndWcKKactEOsJCpjJ9PJTG51FEsh3RbgwWO7e3hEuHnyyGRPAcvDjLDFC/z6UuV0tHAlBfPyLeTD2xYQ6RyZRMyR0aXWwmGL5PlF+ZIWLqdDBlEalEEhnx0SQ2ANW4rn5+dI2rncTqmM09nGiRO3siNbY3s8tIXhlCAuswFSyWkBk2KlXzSjsYWbVD9Upp++eCXPJ4gh5Alkk+mBDG4NPDPB7QO18yXIh//8o8foY7hJamqt5KBkVgSXFsrissgoEeVsk3kGwUu9zVxep1Qq6OzkSiSdXIH38hR1Krixbk0sVw9+sDgugU6XJIjFMQl0ePXPtdR+NxaLEY1DiagMLus1BjDjnZVhRV6e56xti/fdjXGkRlD9goTZ3uycumzt+HkEHS/3xdZ2rRv3RjtSWToBQcJsIgvEXkQld4XMMzAiJ4RaLOCgpDOKeGpJEBRHnPAazlXkKkZUXl1ZK4tWDhT8l/UfyLzwNQGDDdg7tsu6FD0KOFz9rWao6gPnQ01fFfiXSO3sZBLlHzrPbtny5wPzb+W258K7qSeFuU/qoVC0/Xnp8706Ff2zv0QqRmvUH8v70vKn82BTtT03Xxy5zVynLwVRDS3l5Q3NZTnrVzWv2pADEbFG0eva49hBAZfODluI2/JTGLmk43Edcc8zSLMy8yhIWR11HH4tSxbTHkNP82IIqiPDW8U9BD0xm06RsEZ/nc9Q6sDM3SiMdMYkLPefJaFQHZ/SiM3NY+I3x40Y7ErL9fUt5ANwOssTNvrNkoRQnaiL2DhdklDAvZBnZnsxmK8Has8no1DwqOayQ7L8juq2PO6KG0kjMT35RP3sCWAxuWE0Mh1LK6sNXoKw4yyLpsfIFyQofgdViQQiUZeIHuTmRMFeb4aGol+mB6v1yUzAd/eZQX6pqZHmJQz5BPGzI3CuHF/RX1pDi06Ht0hD4scKi2LSyEwMrawWTB+TWcz3iHHMl9du6ZP+HR1/sGsdqtY4GvSE/BITFxcTN7cXx+Oqv0JAtUWJtXDVi2jdUujY8ieEgqpR2h/qGsdk/0V6gaywKAb8OxZaBuyd069eo4/RlVMvd37CmzJ/kJkQTTT6Ut1+h7d9mVFhNBslIcvaRlGpL6LTgALhqxAqexNIwaEMGomBpZWuS5NCgkcJLhMnKLQNIqdQYUozZtReaeQj9Cy74pXnaz95ZDQcLC6pto3CV8lt+SmRRJvqi7wN1pksvBB1iMDVLKeNR91ZuGGo0fiQY2A2dNfmR2ZVpvLPcDWPD0CsGouKr6Ztq9ZW/sgxCCWntnSTvzp/ePoM+yWmzHrmRxFQgkNENGpXXIOVEoNBrZhNGQYNJSAb0A4fWnzO564aqUFJjiaHTLcVLk+W6Hss5wsvZj9MnukqNR/8iUw/oS6OR5khq4a1ULmwtabVyG41IaI+yVjiAzZsg2ZL2qswWqCTWWhZ7dZ/O3vLesm3CuqnNpVVzUvFIc9q8vxmLU3Glc4r24QOzdUQpOA6EZFC/1DCd5TeGv+tCC+OjCVLVcXFCROjyXm5I+L44SJXuqGWtDBPwkgOCVhKKFzf1igSFSfqCNs1+EXJcYDp66X4pRpUpwX/1Vtmi2RWhnV4XKJX8F+6YTXdzyCnLrXWcNJxaIE8kBhWzYjnZ6aizlM7k6nEzXZkED3P/2xn2sWfOnTBAz1XDh86yfOGVA4zi36U41xmg247vApY/t9AfP6ApF+SD+QJxR3OXxVpvxR4q6SxAp4sjocTOMf5+8c5C/Fj6EXBhxEWk0xiM4OC2lISmaVHR1qocTi1JX4P3YY9eDAbDw8n43/PuohzSxHqRby9ykN4txIBZCUlRU3XCqeTY2EUhMycNFQX0LKrk4ZNJw3UR5QfVwl/9zLh0RWZ89I6bB4ttE1Tg4vkoXYpqP3Z7s2DDvJtfV6/vfzp7tXxVeSuWAZ/8Lyt5Vsz0Ux5uZwnL5VTkdiqEGrGLFpQeiVNVltSTan396+nVAOMoKOQ1LAMelXFUqE+FCxsYEYNrMe6oUEQuNiKHVjDilBZ4R4LPFUBJdUbeAR6QcNpxfVjYpZijURJqYZhvUA2qL7FcMUKe1nhOQuUqsAQNlADVz02k0fBigSqInrYUN1/t5T4YxF79Zjpf39Gn2Dy7xEjz1UhzDRS1YE0arumnkeNzTek2Cl0vesALHBBBfbETdLN2J8N9oFWXWqC2/971N63FFiVd6rKOmyquptWHHoK7o/gmF1mPGvZrbiZ11z3mIg7qjU9dC3rLdNTvwXLHhxTc7Ozr4lhdcKEQlCmphsw62aAdaNgl9vGLqdix91nx51lVQ6pKlswNrQ06Qaxk7o0egQn0pDOYPRQXQ1K/JV4ZkqXREvugGG9/7sEzy+8iuK9ne6sZTexR8g9w/qwF1e9J4JvY5E8vRxSyyL8cs1UAuFx27gmQd+hXf3FoS1MT8xaWK9OUEjn50vsvrBtFY/Hxf/nw8Jc4NzfT8+//z/l+DMAOAa6bco4rW/N7m2dDF3KaIPL+tkzc3hbhzo+ZGGwH8j4xY4ecEDXzChdWb61aji5OaaK17sgQ8HRJYpgP5HRojFA7I7P+f8+FjBRXGw/rGsgkVOz7sothH24zmwwZetSKLa31+uQ9wytj+Wk0aZ6H0aBS8yumYEBfs5TDnQMUCUdH9DR69cDl/Wjb6eM8/pWeR9tZCg4RnTStPNLcd9gWog4kC4lcHPfOcyjKZ8mkOh4mSkQfArBYLfbGqZGOKokfci0jN4mQ8HRphdoOJ18sHgW69+8nGV0AYYzemAI0MoZpf33dyxxK1MgU6uJ5gx3bJI940MUwX4goxE/0q+fitm7PmsD79PHkZmontsBMtvph/HxmTjUR9aQ3Yfre077GAJgA9H59s4zPsOU/i2qqfkc8PFVdgH4ciid+fPgzyb9sxtsYBs0ABCAt+kLd+0xZf6gHg4Eio1f5zP59ewWb3TjNAexp9kMwPmewSkOR8uMhZVTunLPMLconXc/S2AjEDqFvQFwqK0MNcKRYwoGGpOcmsKoCBj6BDrY1s45Ayhz4qFfWviI6Gqk0UYevSrcMgOkjwH8RJpr6GtcpasVzCkW9EoqtajLpADiF447oE9AY72Bo31URIK8kyDIbmKxrnVed5UzyiXltfJRfq8vEyfOhJ3AKS+vSKsCk9PMWXkVP9A2krH5OfqIs6NxLxv5SgpdyxnySsqQvZahXEi6LtYBuSblHUYgZA5rNB/WBdkvCsFqYU2wXlhV3pphZUnluDGGkMSsI+uztKiUojIK5NwQBoMaxQdgNPRDFGmr7mUw0i3dEQTaipBGoJUrWWT8PEAAvNbDCGrpAAIa4EAHwG1gQAPADuTTBERLH8BLp7EVAgTrt9IAE1i+lSYwZXq1rFtpgwHIDJ02DTFMlDYwkBZW23aDv+eI7Mt94fKawVOZMPFHyPHV51613XdcV9jB4wgsUXRM5ePp5eWjMa72/mV3rjJYZ3f49LGfIahoUr+PWbKZlzlMdcIO+e2lLpPHjdQQBnTDpw4duLOsgNLUJgdb6pusKlRxVYbsso07VhOOyw4O+tqKf0GSkQ23kdCAYi/Xe7L/YV6DaCCaoIloIdrgyp0HT0Q+/JGQBQtBQRWKjoEtEhePgFisOFIySVLIpelyk1KPF8ajg+gieog+YoAYwh//YoQYw78AYoKYImZBEPNggg0u+FjEMlaxjo3vfsY2drGPQxxDiFOc4xLXuMXdT7l4xPPwNMuLsqobDz3+2vXDOM3L+ny9P9/ff2FxaXll1WNP19Y3Nre2d3b39g8Oj45PTs/OLy5NX13f3Hrq+Z3J+zTLK+HBdQ916NSlTb5aK+qNZqvdKdqNKHpRPxokupN2O1YaJn10AbIfDjRtrUoqWP+bgS1ROZEUmA9HIHTnppjziUVk6NSaKSlOaIevMFDAb+pJmdO7kMptrvK9iYZS5R4okAoGX6ZyhyuAe8X9ErBJhTH4MjUKU4eiLV6sc/JSPBqhMBUgYnekRhgihDk+uGqSxmAi9LbjE11KRptyDIGYu2jGO1UOtGNiM5BoWwnz2iZdd7jthMiVCV1g25F6AaVDwhxf+HD76Gloq9RHy6QY5h3VJsNx4b4TE1VmDIF9m4w8KwV0yU3B5Co9xgfL8FxOsiVIJwS5SV8wxkRy8rnSRBJFen4yw0pYLE2S12V6dvYVSvJ+qpI/e9LCF2EXmyznwldfZvkYye2aXbazB+O5jrOFVtpIP26smH3p1kogp13OBuPTadMzRcAXMixOn25ssjjAvDAMaXpd+0dm/G7yZnrjYUrRFnvCegAAAA==) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:"Poppins";font-style:normal;font-weight:600;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAB9AAAwAAAAAP0AAAB7sAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIFUCuZ00SoLgzYAATYCJAOGaAQgBYNUB4QLG+oxRQdy2DgAyLbcS0TV5rjs/yqBGzLAPkyREBGREI4TMAKGY6ho/8mlE3lfKXPE5MdOFY4ooV9DLC/sdo35vTdCktmWiFqD7Jm9Z1RAARIOmHUqilx0FDkC4RCMexAmzDs8uK1/ag4y10gtEQQEQRlTBJnLAboBRZYKKYqJZo5ZOHZ1d17ZXl+tbnveWo3pjVXdaN3ql0tjbau3ioq2kxzJqu1FnBOk4f+/zuy9/w0n90qZLfotm4EPsrUehT0LGCKptepFwMqKwgMJL1IAOFCmFeKkoaI+P99dqZrtUqDmQWc6xFB0hhxquKhz7epwRxAg7yFmPwhRCVSiIshPoPTjAehEwolyDJ2/k7+yMz5nSk4hVq5clCEXnfv6K4fOqqYWysrqWIJCoHaG4eryvWM56yZpVy1bEyyBwiAR5O6lj1EAayVJ4nPRJYoCEGQNwJw4cRAWll9+/EPVbiKIdjCSkzZCt2VUtog/0Ke4N+DKgtyDGAVstYqT5TPE5TeJ1OBN4MCONQn/zwHT4qxrHwDPAfS0Xgbs6+SAAkbfdn586vAaloQzTj2T6wAbtFsNIfm91KXe7O190dAE6EYoDIqEZkEF0GMpMFgkLEZZTOiH2j0p76AoaDw0icv4TTXz2Twz355js/5/yEsvvnvxcOXCytmVMysnV46t7FoZW8HcO3936e67wMeL74RY3gb8xG54i9125ChjO5Bf61fQ3p+TH3++fLBiAoK7iu97ux/fOYkbQTaOj7VWfK9Org/4Wj8rfEgvGiMFVyXUAF+iOCwXrA0+5V/Dr9p3vhCGUlDq5C0MP9JrN1gbGCKCil9TGjMsSgKyEROyjJcZBCbYOEdzoD95SK1ZeLvLjs6pvpjQjUlfkgXsgH8NX2+GMEuxHeKK7snmKGXfUQlXuLvMED28A9pK8rg3DFxroW7ocGTCuoP3tedzu4sl+/jEc0TM9xMOgRdfh5MmLdqc2PAoDzfco6s23lWR6iY8fjipzoHqj5I5CqGEr5PTdVYIDnxoCyNtXLFkDy8hney5+Qxzfwr4nxCtz2LYat0guCLD8NR3WJWpDkIZYPsdQmo92x0FpBG2Vm5NF5Xk4HD8+WvNJe/IVclGu5gtVk4ppVm1467QAH/ABs5fntdXAnDsDaxCC7J8jWoDpWYTizcu4doVKal+x4qd2xtu9wganwnrhGPsuTOOjx/PdOH+EJsE1ulz3d8+0xjpnsH6tYUwldKQ1IdrjmP1p/5M0+tQ/giB1/YWVr9S2dyA8ptf6513wSO6EEP0gW47BAqlUhgz5I0Z5D2zTWL1zNXaEq60tPFVqr8cFsoOurFtHVYxNtFdaAmn0jyVRNnwXJuTL78wB03ywaoAK8ugWsqlaR6VNkQd01AkmTHPuDuRp9kIOXtvsc5FJ4VY2qbfX1s0f/64iBJe1wSmqomERbuXcG2i6Yl68GHU0pfE8dNWG6REHhsTbVsrf0JokKGph63idEI4t80h0vndsl6vt6kLeof4vcysA74h3MfEQ87RSbM2/i21Vup45j6gXNH0lczuAOXjnwKaivKklFYKLGDyZ0iHCscrCNLmxKHgCGGY/S4sk3RTLXuPAusytjEcW6DWITxxDZ/Gl/jiS03N0hTK9+pk0eWptnthWIhFhqeSdFO5VpKN2Qy625+jnklBU5niSfjndndgk5CBJrVFh4lrjRMBIdoXRpsOj5hybtkaKck3tP/nRIYDvaNiBtu+u7ZarvIT1aKtUSwdh39XNWmgrz79CqtL1K4Pr6hhpdK4/01OK2UqHdKQY4nBtnCEWrhxbuLeqtkyodzBkA4gxt5Xmr4AZTC73yiygN2CDrrQwnhNi6UJK7PdfRUWOSr2L9owc7fCvOQ0OORD+shssDsTqGqDPPaTtRwnmsp+QY+CdRv3ce9GKPtGo23pMLAyEtR54fFeR9Vr8IC0WQKhYrlPxCfExE6rx8tPaCMGl+gBQe4n13b9Hp88eL7NxPHwEElx1xgGFsraCCGfXQLh99KiJA7jOkM4i5RODXfshRkD28OwF/TL846WBw4U2wrMdw7KlweSPJrIRBJ9xlgiDZeLzYu9rvJ/PnZxWOHQtF/a9x1dehNyIlKVJ9A9XYM+hbiI14MtdXwKSXvE59g7i+BH2tBn4EEKn9Z19+amfCS6FNopu0p2W+o8yzDUNuf0P3IFiA3yjx30PcgXZx76chTkr3+GlWyXiNahFFMaRvdEpoNS103hSmhG1TUrKi149Hnh4wieiehrlZxm1g71s69QY4TsFVKIq1acF+TassOPnveEv9V/2nwjjx1ANtCEZUvSiVVncRzgzGedTLD2xBq0wZe+UZLw/jWsGqDECmJQMV62U3Ar9Ma1C2tzs/NvDPKK77/wnE81uf/c28H1cmL23clCiEJkEVEaU5wTSjTUQ1AOzcVwPw1GsDwTv+RGIZx5sycRxNpyIDbrr+a4uVh6NaUExv/o8hUo4VAtr1eV38cvzdH0yjpSWTY7FO7wxAkkaW8z6+HlNkds+9BAn8gwlzed0ZiWKD/ncLtAE+2m/JhHF7SH+jzChWOpdMf6wml3vlYSjf/WVBkfS9A0snCIS76uxqdPpoInNmnDwy4eiEIZOaPuC/TJo0EReHwlYUKfwkI8u6twGoN4vxGD/owz6KIDGyOnpI2vwX347jsuhQGoxcKin13ReB4iM938GSDs37yEa0eOHh4pDI4F9obHs0tSD+cbxdLvJy06cTo9aUE10qek7pYtzgdTSTDR9igcrmV2i83OpOab5FLrS5LSBaTyoH3J+Ntoozi5yXBzyPnQ2OX87ndNNLgxi/iemKnXF/gLd/zdbccZ3pZvR3t8jyfUpDDGirmEZOp7jKw9cQhK73G2BkHw09DgiMVX/0WS5YVhMg7EjpZyK5OTLQ3cbS18KO9HE6dpur+WZwrRkJKaw9/Bvsr6/AyvQONTbN46HMWd5FtXqKYL6eSuXhI9tpna/qyQQZmN+JykBTk8i4tv1dkzGe5NpC4gMTRocFRq3G7nqmlBBI1t687plzyl8v9UO2rng4TruG4muy54MKW9LA/BDDZ65IjSh+KSPg/p2G3/l3YKTdwNBK3Ldlmv++WK5FC1oHNhwCvFb9LNu4FmHu2nMaziZarNsEhqNtmQQUbK7syZdlLiHgnlXUOodRGtQ4rHoikK7oCyWfZ/0VCRuhrkuNEgOASBmT6OJVEn6qWnb+PewYLDL99PN4TYyIuZbl8uGfz7Xth37vDv0j4OhcNDkYiXPu+XCAD5amPwV/p1X8HWfbqBo29Cd27dsgt+uHeCC9Cjzmw5szVMbzkN298DuAC9bR1boBeu784LgDpJLjFnCdfkcvKqglrMPoXT/mJ+6BviiEJ4jlpY2FZXGZjLydUHNlQFFM5gMcuXZZE6WI5K6IzcXHac/Ari7PaTsJSZ2pMgtb5IKxIVaRXKpjZl59TA4kD/4phYpaYlXk1TMeJHigpEIl2BUqlrsuLCqEl5/AFi0NUqOqiQyww6r7KRnGPgCJV18pTdbXA8QVGWzs4pzkxXQwdA5IYkTsL6z6NOHo+I8qFXjAs91MpDB4Ytvx49bMCocfxsuglqA9+Y7fCDR51Yu34opM7agHh1R22CyRI6BKDvhhLl6I5X96gWDRlqoXb06MGY2VAOho8Tijsz3u6kspqi2EFrzKC9hKov16sDSyx1FMZus8VtA2rk5bd73r7s+fwq4M54Y3wJJx6UBTghP/Gds+E/WAft8IAMa3tnbKz9+Im29+jy3okxaaRphE4fSceTKSLMs3T67N8yBYAXdj66MVoEDK/p1fV2uYtO+pdIpPAgA37Nfa3WhpbNVar8oRqrTopq/N0KmG1dtTVSC5Gso+VwdJ+uGeOUSrKp5XayvH6o3s8xEH6fRrLisuUkzQbXhmF9eiY+E0YdBBlDDtFXe5eLPEXD3uGgox8TPgEb9YKjUiUUq6kW4mrZrq7tLQ399UGlA/1/EJhMKYudzWFiWs70HXsX7FNAMoQcB2hrLsVSuVU0ml0upjvqWAqruzRjX8vFLQsDNld9UEHXrvNiFpPJ47OobC49K5vPBGscEMdwcIVu83dAdr6OSi1ykDUaQfKhpNIoeUsWVmmOQGBqpsjlborAJMhhlZlXg/tJxP1E3Ht4/FXcgQ9EDCpRwGYy+TkEijCLAe7uHsazaWaPMw+O55jJTKvc2d3VMNx4/mIXdn+ttkJmoVPLaF2vnX2DymRzqFQ2j0bJ5rFAWveNe7fwqdsTgI54T4oH+ocOivint38kp2/eA84v2jdVVW4xW/0UrWsO4wrLcSwsHJuRgu1ZR9FbKWLzdRd/qD4ZOawtecWcRx+rKZaR/+tfKsWSFNoStZzVWacS6p53N2WEwMLjafGpeH58NalloqffNe+wXmlqG+/tN0phUaUVqMZNBwtKX7FMDPzxeHBGlTEPE6ZhvkIj2jaK09Bb08CfPbG4non/FvZ+eibzn5rguqUGwSVyPZtOLbBkinELULEZR84lszi5mtXZkliGwZQTO964OoLFnSFtuzQEYO+Wze0uMTWdbIbZ9tTrCAxWBZ1sEQnJ1go6i6Ej1u+B2U+43abdJWV7LODA/AFtyazNVvLqAa3j6cJTK6+5ua6u2eOo+qQKfC45+cD5YB7SMLU41QCezNfDz95z3kN5FwDm59Z8HJ2tp1EsAhHVYqRxNdUFYfI/azyeEElp66ispHpOtGopm+OSTO7jDVAL6J9f8KLT0d4hl5yeDD5fjWMB3Jq/b27aVGXyuKzedZ0o5FbMffDZCyrthyUwXtAPJxej9OBzx0/OhnsbIH23kIxLC+/ZF99baqmv3wl4m8Aub/bde95Fcb234gXIgL2l+jmLeUAcXlk1V1oxZ7ZUrJbIbtPTKTaRiGLV03JyDDQI+Mm2Geg5gHuYbNzE1DWt8y745NbT6Eb2+6ZGvLnB+ZETKDy29oWMSnEjy1U7+JmvnxVP0Dvn8P2nAo7vDOOFexcCcuvpdEO2UO1QRR9I2LK5ieEm4BsZTeBhQCOBXx42jTHiCe3I5MK+DfyoAmS2isdmlTrxkto+a0D5rqjhTDQkLUlg3siP0qJYai6doXfSlSB5vn5B6pUu1INP50+JpTK+QCoTnxo6WazwdLDUqnaW1FN8ElycX50/sjo//QbmCgaw5xbent/f9efAn3vB4sK0Z8PQhld7E1oTwM/T9wfuz97S3y3eM/1r/6+zNyvulgDn/IOlJ94nD5dmp9iTbPBVU5b7di3tGt3HAeLhrzY0tzY3PjeCD85FfG0diPjBCqzvPm88MDc8BycPjPwR3fd4cUf3OMB5VK+8F/xxzvSjtQFA7bzOBqGYXUY4rx7CDOUeqCCyRQ1iXpf2LB4l4SNRKC4iTUIkpsl4qEKYzRISeAAqCCzxiSJeh1bL62oQnzTjL6i9P3iDU0diUR5iauch06RxWUoEdAbJM0cCULuwo1WksfSZY8tmzg5gsoU6jVqoy9aul8/EFvfbzJpWkbBDpwq4XKnGjKXA4R+G83aUE7pT4Pp0iH1pU3Ipn6qC8mbi1P3mKk27SNSp1Qk7twjz1G18QVvuKMpfzqGRRexmwLtgvDh8MceVk2R26Rt93VBXZpwRlBLL8QfUQxlK1uZWUZF7ug5SsX2/BEtmySUy3YEKEksCWoDUNbpwX44JLhKMVKpdLvQSeVwRI4sn4hG9P3hX9xan0YC5ZqpKIBCf9yjgYrwYUF0zfq2NYKmsRKNlN6dBdyT1ecHQ4oOH59z2z9+/8CTmWRT4/Ptig34AlDPEtrZNQi+RyxUwGDwBl3jFZK0NxsufK0CRuNXUMyfNjGxwk9Dyo0USfHKNhGd1aWRwP2irSNKp1co6O0UajYVkeQ0VnV2iXEQLLxUlpajzCrKzNQVqtYqzgweri0Rrf9tYZYT3Cr1EryZ19EftVkFHk1jMLMGekQwRhwrOlmcyRY0Sfmf+WQJaykMgEcmAlpBIaJmgQlAh/mI/WA0E+gSCx2Mpo70Yrw58HVSDZ+fDhnJs6LTP1ifa37irSqZz6RlkeWU6v6qp0j+/DxqARm5fn9R24ory2M8LwD+DGB74+cK6pENQrrvo9LFgnos3ODTY5gJqNGZItFeXRuJWUel2mdBLwAS4W0ACSO/YfmjqY/SRj9DTgJyH2YOeMXWZunbMoYeN+237Jy37jPtAc/1R09HpczEXomY3Hak+Mn0+6mIM0KFjXPip5qg7ia8Nd412gXcb/nZN1z8SPnKN14O6PU+CEZggFaQ8XVWmUwrdGDYzKTAfEliWSiEJpb4ykoAKCywLDsxPTL4FxTQLlWU6FRZSHqRCI4KfgJXNQ3uGQDk+GIFmZ7CGZgz0VnJiD8FuMCpJIPOVkoSU1A4gfUlMNsYNdekezFrVATyntFS40fd0XUhkQmaONdxQVu7+3VtDv02FV5nBVbrnUaQX1sL61R323QxwOHrGugLkjVWFgVqO1gFpGaqtNUShQDtUQVVzV6yomC1WCoX20WIDZu2mH2PEH6FLBIHJTkN+FJ8myKq0kYTORo+vvjPsL1KmJSthbu6SYW9yUDq0IALcYYU0D/72DY1+/s7Ogfss1v937lydZDAmVwc3B+fMVfjgMh7B4Y8yMlbg4MaOBuM+HxgPsmxcHvQO+lpDYPx9wNgwDZ2dFE4IZ0HARJp3xLs9Qn+kYBU2hycrTTiBsanCR+P1V0qQo8mxuznQX0rgRToOmaaeVlOOnzbGgpifrZ7wj+scgbAPhaqMILNGm5Skm8B8w+qk11Zm8Ps7syVFc1arIVaZLZXZUkzslYm3lZfJ7r2KkmIEtqzcvUdWkqOqotHNAgHdwjdHjtJZEC5sPToEyyDzOBwyNwP6yfbWcLEjTwUSRdhcOTYjrzujVl+Li/0QnanEYfMoDhwfgSDhcCQEgo8DPc2FJ9479Jae2EFedCLc87imwH3+ibf/7VrAftdAoRjYLIreQGWxzEDVs9hUwz6fJW7SFUmkeGkk2iKpVFsoKT+jRpFyVRhZgJx/1QafTnZFQgNngsIioKD/lqndBBIMtfpCXY0hN6/WSDdjXlxmdCo8moD3G9zheDBZ23bJ89Jzue2yqAO9A/k/BZg8d0ybrKlX/PBLbCQlPFlQC1fnCLGrbU/9qwPEDWpYkpw8Jm5j7FW/f6QbsVoaX6ZhIWq1qKjGyMjJWDgjORMZkReF0JjBH/M/Wk0/ukEJGjOkfaUoMwv7XfR24nYClydkMHhCLgGom1Vc1ebYSLfbXZpFrLDRNTzwBUZGo1AVDPpwXnP8UGSkN57dXkQEUXV5+ww1oSBRSMwtwjIYxVhCLpVCzC3GMRhFOEIuJREHR6T6ZeJ8U1OJOOBFlpzoMSpgxIckSGWf2CNF+0Lf1oUHLRhuLfdK1uSPUyuYsfGisWJQXsc4+cA+LG1Z7Nu8qLKgcGpl9myrHFzs+3y/K550bg33Stbwj7tW0sdmimdKwGZK8hh96HqxDEX8UGzKhIBVce6X2l+uBDgnup8Juna6Fh47xsvNi9Xgkjv3vM8b9dON1WvRNOwe2KYiiLdCvVNvyV5HgZPZ6pPyLFnkEaU8s4ibWx2OZk9d1bGDnoPHq8A9z9jY6GhJyeiY1+us1+spnXVsHEypZnEt4oJwOdkO+JtbjFV1r2d4RGb9zgLrYJ/XGIUnZJkKkSyTU4/kSoqkWVrg9QIugqzPFQu2eRe3D7ivP1161rK1n0DoZzi/dAKSiWly07WyOjxdk0l4o4qHDI6w7ZMn8FUs5aZyg77RCCnqRywg4fKkJF54fpKElZkCD/t4f1zqAIHtzYrzIgA3d53yaHsen4z/6tOZWPUWcwnLRFjO68j7RU9gFgbPgJbX0SSUNvJ0qnZVdjmaJWsQcNrUo9AgNT+bpuHtfP55geBMKhy+GdDnWC+fidZsqi6AoEz/QLj4ELOMvlmpK5+WAxL5nCNlVtl4pzRf0xHHa5Z0tAoVytvubhecI4pt+anvQ7MTxuFFt0K5qSgZlWqIbQjkU+Q8tkajZYLUPwJo7OdKz0vPLfvOtCD266cwIyM7KDZIiMVaRf6zlA0pHOZZJSHZtRfEsZ99J8PnCyMS8bGffhefgSwhxgcerg4J2eImMb8jP5/f1SQWZxdTPq32PvSGp257JFORaZ+SygEhF6TJSOAqOjNal4fTD2oeXIY4p8rVleM++tnSsrlfWBAXXiF2ETqKpxwQBpFiyfIPsQiFFAvKCwA5uQG0KbaITysHYWAhXCsZz9lE5mo6Sh7oGsapI+kza0i88hBal7xhrUxAp4j5pc8/5yFQMgrFZA5V5I/IuQa1WscEs/sm882TmgmNGTzawWMTCXw2mSwqgcgTsyB2ITp6IS7m0rABl2JA+G4Ohxjzf+aX0YgSeRB3rbZ3YhA1slkaOF5xQ92Akt2P+rid+WSy5rmR4YOJq24geu5e3FP99PP98T7/zBA/t0YOmpa/eKo+glI/NQMnVY1CqlMFKiJYR69lAcJHA4uD/YvgyRM3E0Z2Gz9hLrFp87kOWI02Xxi3LjTu4nxd/hSd29rcdKIZZts9osUzWBW08Tfzb8SFros7nv/WuJ7BAvGfQ/KuC7UJuf6/3PuMPrfvuC0u+eHHCsP2gm9LvwW/v+I+5AagrgMOiACsEgHkZSgR1mcXX2F7gQo/LFjoeYhJHeL73tgG181fssxfdoRvd3mn991n0vh8A1w3f0ntTnaVDJbPF8R185fmbzvZ579CUIo5xxBvyE8AcN38Jff5yz7ZyW6FofP5bnDd/CVXFHvHSjYRs+gRzDzwfQlUXDd/yQX+sp18u2PK+25lJEN8Z/gC181fMr2Tndfz9lDxN4KrE7l5ln7Zyv6lkqsM87qS12Hr2wJrrpu/5AB/2eBOdq8qRVjAsgRcN3/JsZ3s5pgyvtsxv12fvz7uPyjCrcaXi1By5Yns8uRK8FIYnHNz7r1++4QEAHoeEAeTP7Ibdv7repnQ0+Of0g59VyRP3csOCUDfGpeb+p31rvquc/cFIZAT43L9TtqlUuhPEavY/BvyvpZvPvScBkKXPj9c4PPf/t6Vqrw7JfB34UNzKfDuFHBAMNBH5ixl/t3KgQVv0Lb9TnkEDOemJCMDvGsX0SfiAf8PbMPOF0fIkRG0+rjpnD7SIXdzvwOL3lTZIFXesG37a/ofHLkpzcCCN6ioj/j//3cLawSEdWFarnjaBde9SzriNYgpz6Vxlg9gScDRtzuZ+rDs34L8/H4BOPbm4fcA4ORO6icvvn1xEvLpwges4gsgwO9zRtdcarD/0vGO/WXvE3lq8ve3a5EHlKYWYjRL6DDKYOW5rQVw70DkRzX4K4psABB0Tp6XwiomzhqAzU8Q7UOJXWrZsC2E65TM9lC3g7Cp4O2W1QbcBAJsBNCVUPc7htIUNwFsSSTuxxLaTTgAONhPCBtN2MhNX2JzWVI7I/BRaMRivccDIsBr8ERB50taI1K5oJ3H7/tCFwB29gRk2wSXg5hH+vvU8fzJ0UNSRqyahIG1PSDFNGFLQADYsikWs6JTXctU6ZjfV6KGvsQTHsq2HYwFDsQyyfwUqPRYXx8fp4XWDoXAJglqOf98D5n/c4SiAIO51YDiPs/OoHUYqgTZak4oFWwVSU2etSMCJp9KKgTgehgaoOuLy7i1uSSx++THamOqRfhPj/WRdxdoQgEpKGv9IDpvs86d2JsQfQYx0qGFpmN+Qe/ZcRikgmgb7J1Ykb759+DDXhXogpLQ3lmVpPFusFYYsLv0XkPG7AJrdqGQ2sEGewcm3jdfDD5uuxQXlIbCAdJ6xNQ2wIDdhZtxBEa+4MGXJCmJkhaWtf4VlC3Iv0I9XqeuhZMP53kuNHcy3FlqloRlhakXYZMNZ8smlg86ksUNhfWlEg+L14AP4IRR6zQK4MPXRgGAhwCDL2A1Mz8+CwQAr/u4OsQH1LFDfIWaPcQPm6F8zelD/K2lOyQAFDUUessBp1ob34ff5MrKFJirarDtQo3Zn+EK1UrO2WBpFatFCo1zPGCTzfFThcuvrrPxnLUmcgYeT5YWiNRMKEODUPxoZcpV0vPSg2dpqjU2sFL+A21RnVq06oMS8e9paMHOuVoB/BBqkJC9TquI09wmUqu2+JRzGj5NFttjuqnylqty1lXwVdrshNFhamhBqW6y7Yrm6+V05zuIzn8CSH38gN9fAf1vIAjEWsHWCREqTLgIkaJEixErTrz1EiRKssFGyaBSwMClQkBCSYOGkQ4LJ0MmPAIiEjIKKho6hixM2VjYcnBw8fAJCImISUjJyCkoqahp5MqTr4CWTqEixUqUKlOugp6BMWvAXj16XTbtF32Gbfeaw/bFH2xzU7cJjz0xlAAw4B13PTLriGee+suc4z7wvhMqVRll8pFqyz70mY994lO/MvvK575wksWfxlz1tW9YPfCbQXY2NerUctjNqd4mNxKXfhbcmt23mUeLVlu0+Z89tmrXodNDv1twzSmnEwiuu+OGM8664KJ3nXPee/oddcUbLiUIeP0RyBrVzQqFL/+GwKaHbXg8F994BVvzKDqRx1/zv4vxmk4kEigAAAA=) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}@font-face{font-family:"Poppins";font-style:normal;font-weight:700;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAJjsAA0AAAAB8HgAAJiVAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGkAbp0wcyioGYACCPgqGkTSFj0kLikAAATYCJAOUfAQgBYNEB7QSW2ipcYVct1+V4Hxb1Qg8UL96A9Vr/0wc3DZsfeaaa7KqjOh2gKDS3zUU/P//f2JSGUPTggkAVZ1zl/mBAo1AqAilUtVQha2zjeh9ZYAo1DZUusRKI7qtCSttJTaa/djdkEt6BF3SfbX0Zk6Hycci3rgK+kevP1szbvnugbB1RsRxndjSh898X7cxIu5m2uJuX/SOKS8kM+nQshWqgIgqh3ggQ/tvOqqdqe/lrF9PUJxONWNzlOGTafwe86MhDSE8hSAIejdkC11a5o2S58k/XTpjX3OW9JrQEo6ZSNC5FrkvbBkYGyOtH1ErTkT61Be+z7F/PLub5MGHIpFm0p2qsm0VoANSZSUZhAXMHZ7fZu+/D4gSRqMyhpF5ni5cZbm6cI1RWNjoUBGdottYYbHCGHZMmcOc4hAtZ5MQQggkIeYnqnuuubuc5i6X3EUuokTIQhFLwANJaR1ov5SaUResSkW/UKN1YAi22Zm9tU6sxmpgkyEWkWIARmJj1WHlG4mZc+908erCRaq/Cveu6v8XpfL/+BPcebe/W5ZMoxAEqbEICBqBmNMInET6/t+c5r9M3R+Qy8hV2iGnAyzg2buCnJswKCfM3Oy1AwoOQ6VRpub0M9JTKgQlwG8Yyucn1CjEs/dJRbWCExy4kaFCwP60Ltf/tdWSKaq73FKdB9P5mAfzYJYNRbMbpLRgHsxz1+HBK97lXQU+FWKTwXSwwXPoB8etX9XwPOoSC6pO3//pADi240MINykADNuA01w2TiMCOgGkhOi5VpVsK2LPdX8++/iDNRGxKAmFJLyMc9zdc+6u+5POX8KYwBahHGJpwb+4pZkXRPeqR6r/e/zu3gr/f23690L1vvdGMq2v+2Wx9Z35myGpGb+mcPI2Q5efbUSJCWmIQoWqc04JUxGhXyfNxDVB7SNrGUnjAe98McAADobcITiHkIqzb5xcCmahdl+AFP9998vGNpvkQ2zfNQdIbb4bCGfYHvjNf5yaVPrqcGRidcoHUMtKSCF3/s/Sf84N6ZbtruTKCsdCAxUWwCJ6ABegAwQWAdyp0lnfHoItvEks3hBD/UNi92J45iwPY0bMADaSQVgiOSScJTC2xG1JCAkFcM2MRlpJg+QUWHMoEJ01ThF7U8gilg2bUvht7fOez3um8H7d43nP18EXHO25ebbDHcYpHudYC5YFHBZFmmAceniCfUH7/vd7m5bDnZ277s8qBo0qVbjdT3cXh2RQIBy/UB53P819Ukp5WQVdbREmiYpERka31lQGFWGwMS7K6fj0y5zNu3d/uP2p75Z2g7qJUAiXOIHEp7S9t0u5Tf/0ZomCnqICjsEZJg7h0HSNsUgGAtudB38BajoYUOYBeFQahjKC5XHQeWgfUzKfaTBAnfUt+9mqB/upJsSgNNLczsWeneFdH7OEpEOWyJCsRWMRDo1xOIVRHKpataKTPoRUlF+U/pBCdU0lA0ONTZD0rrzhT7qQAwczgEAS1Cp5L4Rcfeq+qKtHkB3xzQ4AB4QLRoUa7oFyts8Uv70V4Jy7wm15gmHvWQwrp9QV/uVHcFu9yBefoiEEQURtQnkSdTY+hR4fKyq6G9W/G+d9p8cufWLFSgghhJAGkUGG5dPr0CGbQ3i1Fdd+vg3CKwFJkQVBBLG0aEr7+NvRu2tMa/QhyR3xWlOilL4Lyn47hrm6aquu/e7RvbUZIB95IYGEZ4BEj7FZ6dqvUEKnuA9X2HB3wFMIwKbleoNHR6sV0KF2uGYi3DLVMDBa73QkHHG2ueBBoZFZnjUhpq249PLOBDB+LYUkQNHvCKoU/PWCJTIQbPOzETA1AQTcnXeFBqAB92c02h9OCBDi6AsDZApbIcu3YkQx6ekn8CAhKpwlLzhA5NlrkK963EPucZubFk4LG39zrT/eez3t+YV5sJ32uAfd7TY3jM3oqUtdOE6NY2O67MnZY3m0jPrz0Knud7c7HB699ts5QsNrs7VDbYVFdhpWthk0m5k+yFB/QKhlFStB7GKwfWsv5C82+0LqOfCftxOH61nP/BiTxgz87dUkfewNW9eiwZcPc9H797peKt9CqcLXwZYh+QHyCobH/rme9fdNwl2X4rvTN39ljuIKQBPJfzNr4a9UELe9fAmXwGF3H4MVqw2mj3YQyWVh6VqoLwpVxdYMtQ0bjXvaVS6dUa/ewQlVUyfDt5YapdZzNdN8rOc+3+NYW2O570HkFjqUM9apmzEs0TiGo4eljfYxCbrlKJ3ZwgU2uDGDVEFFol48Si9q6RWGkhTANI7W1z0R8yKo3OeHj3inkllj9+/NKvshJM15lzVkzjlBRo1oir6uJTxU5ZfdefgN+bG59EfSQwcAW7Q2spLsdL/OdaGpto3vKoHZ17NZVWi6xVG9VXal8Ho66papOlGNMz2voboZGvNQPRo1GmYsAvo7f4Bwa0Jij2s036/+k/KYm6vZm6WJzdh0Td0UTdo4o8JCdCHTkWYkfemIJOKIIowg/LYjvExmOL3pSFNqUx5BcjOWsQwkm1SiCcQda/SBIolL7GIRo1CjE7UQURwK4D8zuZhHzt9PYkff8PzN2XPHOduZF7lLzl2u8ltErtl5Wk0R56zK6TnQqGdW+Vj5Yn5Jh71Tw/PCOcttRpY5vJ6V2lXF2NTBrIZWbgOelRbmdGNenTG8Kt43r/pyZEBH4D69ttjXIXc23jepPaa4dDBXaKWYbIs7S8oKT6ntEbKg+V5OOe1VHDsqovSTIgyboa73tnPcUDEzMKsItWMuzZkhvAXgMh29KG2WCJ5oLLVwUJDyO3XPnSZLMJMW4BYdgkdRqk91eHz0cu5Rl15xwBUXyPJ/QZdI9Db3KwLsFJAlrrojvHXHkOQWTIazurJjDXEpJ2c9xd67pgZaDNgjhbJLz2mNxfXlEH5gjaCPPj0+7dH2kx8lmEeL5o7p8Tx8mH07u88uQvaMD26zkYqiCmdciVw0wtS4VNcU9gNGx5m6fGQUjfapFiIvx1t5rMSVsddzimtbR5WhnQItKpHdwn5qjPnvxhBb0f0YuHQj6llptO6dC2oEO9WVO+FxWYfs2h5e1p7wszZrRD/bxabiwPUy1c236sE9sJ3BSciJhV45EMDjOl2Mi3CvXbHj0iOG/+R5xggBCQ0dAxOXkJyahp6ZhdV+8RKlSJWGJQtbAZ4Spfi69RgwZNwk+A1kYA6BCIrgShnnDKN4eTxd3tqdXn84Gk9ni+VqvTmebSd8vWmG5QVJsVzPTyRT5Up3MBzNV3sXkUEtkQZt+gySmbVgMRRiIBbioBIkQBJUSzPtKOlnELVl0VqeSaaZZ5Fl1tlkm30ueeWdf7i8I0aJHiPm/ABAQ/kOqQJgKwo6Y7Be2LEdPauqbTxT7ZJW2smnFETmlT2/bDRc+qAVFnYtyKeD/LRwQacQz6Q/p39eyjLXM73FE094VHp1QHpu+kIukEPJyUPrwvIh7HXDxN+JR+ogiYrlHY68ZOhXSTMIljNINudtYG3fB9EZRCtFxxgEjS4T8+OTTyYCh5JZWd4kWCZZZ1ZyJBnvJTT8EjsOBZWch5wmkwjTVogcYlZcexHnxWnISCPXbid+ZeGLHvNvRTpMx+nRTO3qbiW7kBDaigWVvYBQLuDUsZkijXQ8wFTKLJiDzRdje84hLYiqhXlppNEcp7soKxTTx3BIrX2iWP3aM3Yq9YEOFkivfjDbLAUCAohbrJ1thFQqmHXPkbYOg5UsvFApltlPToPE+5iRMxMvvHC8xWsRBgjDksTOw2DqsNMT56CklYeN9CBb/+Yow6rzvZnenVgUm7j2g1vg2AuhsMXT9S2VrM00Hdwoh5eFad9UuA/OetXgIG8c3l1cw+dKLsG34maojLZHlj8UVUizo4k4Lje4G4VlMhhWMApXmwmi2AMW5qIj/U1kynfGQ4GF0fj5ess4f21h5+L2k2Fn81LdqX8L5gWCPfU2gBfxWfl8WLB+qxAuV/ag/YVmBYDtclURgH8DAfUuhx3ZFUM7mgXEGJJ79jS1RsTgDgBnIvpPZBnPUHqas63pW+3HN8a66orSojwGybsDZ93rGC+NGVgk2zIwDORFAWWntgp381uMOrVCap2sgaf9Znl6/H4DGczf32w8DcPPmFWvFHPZqU6EDDu2Vff885LCHBoBBeETapKvGCcbMwMtFTl7e/8RxELYpIFoUdKIDPEQIgumSUmN6NMRhJUkxMREhATccfiE8nBCc7AWzBTjuQgP3JYuSZJgOSeFD+Ldjui7NV9JbLuxTyfd+gkTviNt4RUe4KmiyxHtd1tCi6/aUtGrkVX9hBub/3mAP2ac19uyoNLmNoM8B/vEMwmfoJQCymxJnQhm5erMC1Q+OwOk4A5OpINVzIUZWB9kZ4dqVyXbPUfF3VxgISgtSbqt8YSUVrKR8TNjKVYUjEYtsR8/NSRolj2iQUndY4EO2lMmnewkJ43ZsbpfwUWi7W59LQfakD/8ICXDQzxRc9llEmZO7S1Ppbhu3/n5nBYcmYsOpzKRdKl09I/BhQOPIkoQIEKCjDIqylWoVLUbXpOdv2/jFhAU0i6mW/+++N/71idCVaqJNGrZHxf58jzLdz3sEY96zOOeXNu3Lge4sByczeVnR495letnHwXinECGqhXqDd/jPQW402l3udsZZz34Tm94eydwT+OwscX782RUVanVoBVibIt0rymgBAkVlWrUa9ICPix87/fXUYSIMmqq1WnUDPljPvQQVNVblU2kof+qu6KRiJSiqJuH5PvvWTuDf3C1mwmuDPB7WPPBd8EfsdIVXEoO+hkf1vuTcUXwQbJfznjL+oj5AXjlQlVFIJQwUFPPjN9UkEgdCrDiQVWBcIQFAofvS8Np+/0ZX+V0EX2ZbmzQjlBoalSc/uE62xFgD2zcVt9Ssi2H/IUvuslERC6petQgoco0qg5VK19J6pBXeolkJapUBIEMDJCoVYglyn72lMCfqKXIOyjZGCx3OOnUeUCbzHiYjsQcdwK5Gjn46KUvzYp9lz77RtjQkSiBMOTJxs9cm/nmISm+IYjwes+V3Nek1Fdlj6/IBl+WQl+SZU6RbCdLppPkUyfKcCfI8+6TB90rN7tHhjgrPXxCWvm4pPqYVPFRAeGRBkuZD1NwlgM/Rsi+P53/IDbK9nu3tn8wNRgadA6SAOZzVPWd1d1KVPEqZgVDiUMIGI7L55Y8lDFb26tl1A6v5IgXzRQeNEsNdiBITyCb0A6DTYchpL//j7Pv+oMZ5mnEYfV6qfOLVU8t0w2LJq1Jf0GGazF/lZofFaaAICwEpaBoKAXvG+RD6Sr56HaFfHTkgfF18qHIhwjOl0f4Uvk1vxFoPFlJrWsDxOxM18iiEW9GPohveu9pDLprJ9u+VO6jiCjyXpYIpznxUKAkYKdea/DF8gsjunAuxSghvtaA8hkjdJp4bn10gqLdsnSUIty6aD9xKBGKo73+GtuggPaVcW4EJBS0PbblArz/1RLlqzFmc+eTJv0QGQyMwsCjlHccGHMbm8nglC7I6f1HHjF+I4JB39mPhv6JltDnj6gJPX5EUQrrx6/7qD/9yJVf0z2+g+eyZLRhGUuttJ3eSXWRDSUwpNJju7GkXXvGoygiHwbBIi5ekKcI1fMZ55sgPzqREX/mar8BeTh42k2k2RoUhynJNh3bWx7FAM1BGSrFS5TvV3/jmAriwxJEcUGmDmm+G8squxxzS06bBOHSOHqngJzSjFvgIH8D/tGU6Dc4PTf0ee+Dz5bgC4KzgPuUmjNh2ow5C0MQJYSAEBFVatSddYHIF00hEEJlqELDh4F9VAI/zW6XEuXqAnDntPJt+4s9gPlZejNs1OJICBnR5siJMzc+/HjwhBdE4BOhcVKTpsND1Ywyo3QyDrRar55DfaR+7YkfZsr88Igiooyo0LLMcnbsBQkXoR/bS0Wql9KrinXrM0RmJgVIhoaZ5JdnvhEjR+Pl20CtDfqMWyrSZ8SENRvu/GFg+SCgC5atwhMJCnzUokev3xYjQhLUiJZxwVEZ2AjItWA+AwPIXugMmTJjy4uvQIfhsIVJki7HH2KkYvnqmx+adeoyYNRPc6Fb6Vx6DrkWEIHPcSUQ821pojJmvkW/yEYBosSIxZcqV7XnGOJkyV7gL1KI77W33mnTb9iIKfNhoU6Ule4v871B4fNiVz6RuDkErbfWYsGDt21YoqWo2bkf7Y16jVoNhoHa6bY890KIGBdMyiw6PG2XtrE/bIkyFSQ6zKaXU8555Jk/gSMRmpV4He2LEy8xDwo0UDv/uYaGUJyMfS+uiDGDA5K82rEtfmicL9M+F3Jwm+IVCFp9z4+2AIdh719DQUZBxScmIaekoqGlY3JUshz5XipQpET5SjVnTZsSMkb3Yr65CQ6jgzKVGdpR/fdwaMOe90fGHAkbj9SiRBmycS7pXSszBcls7OHf5S6FJyAkogBd7HGc3Pn+PIW4dyf/3jJEwiexu+K3iTHLDhHcrKLyYQ7GbuM6u0ewd2wxs0Fp3v1N59Z8ntbl+0ds6UB+N9oY2Vi7wduASrPr6+voWrbWX0PFrpVw9WApXAqW2ovpkTFQ/Y++u0sas5VnOLlp8lXdo0z1yyxI6/iUCNsD1/VLCckDo14g3g2+xPZkeP0CqGqsU6wFIEH7txu4oc+bfu0PJ/StHmoVtuc3Vu6to8C9VDruL7Wc+oYYthZiBQeh4fKupY5Bxcn+W0c+fiuV94jJa4pUzyMzZArzhUL8KS+/y8NvubvvZ/QE96AP0PZzo3YNX1w/5VH17/F2iZm3yS+/fNsi7zbLq01ybePvdFDnBZV48mVIFofhsX+Eu25Ir7S4EC87IzUZAVYrySe3Q1JGroqOnAJzstLBtQzrrVYZW5W1IrkVKgMhG84Fm5wKkGP+sslPlvnKOK8LRq3RO3sZF3sdf43voUglaT5fdy2FSkdFeeyBm0b069YhzM/JTEtBhIOGkLMSWCo1s5SSsR445wGJLAS62kUDneAgh2yTbZaybS41uMERu2FX7HDYjG+niPJBqbW2LjjXjxqMLELyDy/FOEtpTCMbGmi6aVwOmixa1jbPYPbd89YWdSqstf4M1DWSsoG60PkfcNXoQ2K13qtUqhA7CucjpLIS1cpq86BqWMUKqlIFyskzchxIItFKQDwVgJN92GQXxmqiRqIBsGmypYAMbhGa3ZMYqeNEqRiUbPKLa0mnGPPy3lzh+p2OQ577z71sUuXvvfL2Rrn7noL259zzD/7eu6o7kpff0WQ0Ho1mhuVmqO1qMDNwkKNfg3JEYR9rZY3tPJzcz8Jn7HG3EqvlV3BpMVi1loRvaeXWpfMJH/MhW90smhL/kIvG5KIBWF+IY9PKVzeWtVueaeruV9gqtuyqGOzro+Ezt6+ysg41yV21OazyJyZ8bNt4/4qzUnunyEtauMg3fm2/KzlYQT7L8CrZKmUqy1fHHzomQqA4sGOGRocKPALAX6SGdJEQExES4OPhyMHCFOO5CA/cFnPpRAcrE72NDIS97LiApewlK2txKWMlAeIRT2vwlHi+NNsH5yRmMcOpbjAJCclJjCpE53aiepFLIGJEzw/AG5Qzsrj1BRRnPa3Ij10YQ+bAgRXpbrrnUFZKsa9HR7EXtisrfnyP8pqnwAusvXd0MJxhem791HqmltV84kfaysfsr+q0/5k8hKfYRZCxjP/5X8v8MLJ8wPu8h7sydeeMyd261m0q5uDmv9F1KNOhyRdCb5TiyJLs8AEaSjLj4syJI4rZAUVv7CWTFo+5y1GPBJNDHGCOvcw64yjTSCUsjvnHySlVEz5y/AgfD6L/YQeS456EbkTQhQg6YK/iC7BXJP4WYiCSOzWOZkYYRvsmC4dWb8TBiAMRty0aST998G5nrip67B6xi67hXKSgg3bYJtJppcVmfpqeGYRRSmxIZKwPfEO3yGLtYY0mqz3+yDIwsho3EQJvAEmHVQKotILE8mBRZmmkLHHKYnMsmjkLViHZZgH4he+QN7eF7sXYFU1/msZoKpfJqhqkHt4QLnuRQh2JJFT4xX8qe8A2MGdcIIklhigibVfLJohU6lOXOtBODtPSaM1pamisjLY0gkHQazYsW3VpLkN5V081u0yKS0SQYCVm462FQmH8dvkHPXvI387HlS9LqgRRnl7TvV8msja6YCGiQP+1/f3T97cB0V/RH32/QvRz9FPmyqazy0f0XeZbOfimb+P6jZZk7suWsZlEbH584ok9tM4Zg6L598FJUj9O6LAfjFuU/Q5R+xJF1nIBXKtLAScMqzdqDMbeIhNPydSzMvOazL233eKXUxv0fAwNxj8MyISrQS2znLaLgQDZtDGjnEsGtNe7OIeE4FMdzHSU8BJDdVk2HCALJg3p0KCWQKl8LHGeenAfuxcuAAmOGycWaLQQEQhmjevT4huhSlw5kh+drohq6NShXZtWLZpJ/NCkUYN6Yt9989UXn4nUqVWjWhWhTz764L13BN5647VKFfjKlXmlVAmeYlxFChXgeClfHrZcObJlyZQhHUuaVCmSJWFKlCBenFgxLbqWaRAFjEgBLqDRQM8EycoKy64LTkaOwpAxhW5neuvyRP8ybRfjjkT46mH2FqQinwzr2c1UdLmPOjSoJVAqH0ucp29I5jSHAAAAAAAAAAAAjD0z+krUCnz+9Q/Rw/99fdxtjZv5qCVgrrybtAps3K+m0VgMmAdSMKCNWLU3eNhSxXjsnqt6dQj4JrtqsKNGDBsyaEBOvz69emRl7NUlrVNKUoeEuJioiLB2IUEBbfx8vDzpbnBxUjjrgFzr/DcxyQT8gppthEj0nV/PIhi1l9dAf6zPXxRwkSFEpjWiDoklFF+T6lWTypWrAaUUkFWQeLIQVWrCgXkwrkeTWm9wZUnw1D2XdQuvieJDj+yy2C3LfGWpJfIslmuRhRbI8aX55sk21xyzzTLTDNNlmWaqKSabJNNEE4w3zlhjMjryn66dCdHFI15wYOxy6yvGs3eUIm+nPECVIzznre0+dKb/0hAXv/y3EFNbDAY0E/3tZGQ6rOhaOkhPhoMEoQaW1nyD3BZlWMNqq6y0Qmj0RMhsPEawcMi/RALC/QU55id/mU6lnzYje019Wd0Ga2EAWPJJPjnwCa76VuuDY8Bh/zGUyeLg6fPggQA8D4CP9zvAL6gKf9GPb1y0wkC7QBYATh/7dVoAR8LLClHxklOFgIFNSKOpa2DnwmJzIyFeTpPdq8Dfa558IEhGCqqRMHFJ6LRX1cKBmE6cpRtVU9U74A+i8/yxOKM8sw3An4RmNfjTfVp6W90ZynTaT3BP4LOls7HlE9CPEzedjAM4uepUWsawymT2w8ZNWovaL3naoMEWwQeZtl61GrXq1GvQCPXLFBR9XmfKGkjoa7bdYx+D8qtV9PMT7+upD733XXlQ3xM/xE9JWSNVmPpwGPwyg34aAtMfbGeCGJgStI+mLUhN9QmINRMy0BGVC0k4xHQ2rVvQrRIDNyq0PzcDRKrIiYTelS7WUi5QoTk6LFHXzzbmsyhoitfPQ7S4BQMObEujP48BzTFp79GM4QI3YrBQw+YjsIVBWTJsVc1lF0u1luiRjuSQn3pdoroQTyzLUbOQANmqOUcxpFvlTNAEs42pIBK0D4nULZR4CF20GvV9FRRsG8y0Tb1JjcWU4Cq4PlpCfqiGrqFbIep5CB0MMRmHqACDQ0CZY3EkY8A2ERpkqOi8kozaB3yIif+opUAzBq4qDw1SYLUX9Wyh2NmEqfy93IZQc/nHgLY11oeeIIQHLq2OEtfQv+OXw3xzSK7j/f7l+Zt+8vKla1Qq9dLw9CnVYic9j+sntXI+pFvttCaM2iXCJCf1ZW9VIy1TqTg31bLREr1Dxcc2/b7r2XkfIh2MiCiNTHVtSjPT8mLyUWJylJtiss71taxtc2OyxBk3MC0YqWlAGjrml/apx+h7Z0IZmAxnTNb41IJGkVY5N6fX6nQiwmGN+aokjU1/2yIrsTxurPUBq1R9l1xuOLKbMQ/fDfCFJ2cMHUJhzIySmZj6wZSXpufFmHwyNzlMpSsm11a+kb2YnslTI9vR9DjdRtoIHyNLW3jwvIR7HlU8NK8cYYFlwMQJ20SZs80sZ+TZZT37LCslVhimhPEcfG1zA0va4QjVoCKRUeC2fM0y8edflCPD2ubYq9GrptCtcla/wvIhwpcEPBJwxAq/YfP0K0UYVfq/RNCtGLRZhXbVE9smYcVCOMknfVm+/cD3PmQFU+c2+qY6MTom4uOpX9puhXbFaLPOkKRz6HBLaDSiMdLuSF+Yr3dc/YkFy8vtJiRybmp0QuQXWWZZo7dFTqvO4VO7iLjNTulAP3s9Pi+fHLMbvrpkDkykLaxkJ3WRjhhd/MvSFf/ILoAnDt7zolGR2yLNG0L/OGEOHenJc/4gI6M3KXTMKPPx1K/tfcBROOEfuHL1s9W8lrxuMWMnEydtr7XymCc+hgejjzz4B3jGQkzUJeHAlA3c8GS553P43PdyYHbwMT/5ZH70SwEn4SHZC2fhqIZXcz7xnKGZwTSF0oeJfwDYNOFF6HxFLwJ3tClDww8KVD1FkUSkjNFShnW+lPG9jO1LIZRgIgwFGpKSLZ2eLVHuJBvbrESilolzM5w748bOxc596n72bhDges7wF+DqOuB3lznumfMCb3tD75Y2KqTjd0RXqjvVX/TgdZTSyOkghTaMaGvid+7gSdzICwLNJHSqm5yqJop7yvnEnjESVT8bd/V7Z+Y1sgUNU1YP7vKfpZmnzvU7Pg7gUuT6/Hzmix8fv/yN17e1fCFX5z7VO6N7/vyDqw93vNlvh2naZJ7p47eZeM6KuB3XI4jLRuMS8WGEn4ljUS9Px7rEZt3YumkqoGIdw3EczUHP6vviRtQRV0RUGVBS/Yo1ok2bQrRkkZI4X3r/feeeFsLpxxHviYMiYW4t82CfJuKQ8cfSa4lNkASMrUyt3McThnOxGJ1LCp0Ib5kpfiN2yyzL7do/Tyq/nH0M1Atki9wxGjOZ0moThhQZjeiwWLAMr09Rwn2jXqtVKrNto9G8X6ykbSPW93sNUg1oYj7whruCb+B2achZE5RljlRAbRQkcLFk9ALomsjbQC1JEJgJMwShcEVOdjfWM+hQWFDRJJrsL63fbDD5JppgkvEmCySzxhu/tVz9aIECBUTkqANJlGrKSZYREt6HCqtDLDAWXco+xSU45RXZUuCDfnCvbTTYObL2lChWdibftf69TOBSRKXrACzQ3/Z5m9JjMMKxZBa/xBGOBAglYTjhSIaHI0p9QM+ivZk8j1DswzehHQfpVMV0gIJMa0s/R4T7+Kragqjq/8I+PUFCjJKgI/ogkaHCLmJKKjOsKayihmao/DXbw7uivbp1aDj75AEoMIQ4rpVJg3FC3bGzOB78DDh/rBgXjilYbyrB8oite7lVk42ff9ePBx8Q3LpOkwmF5U8sIYPTRpKwZY11ROaFWBXcEmMcYyIWpuSeNNaKr/ZYsy8h4tqQIo/Rj0cb3FmZGHFIUGC12ZmEawuGZNQU4lRmjcudL1NwXYb2h16Yx7aSkcCB8YIS3Y/D4YQdCEqBSkKcfKo/YQa813830xbQtiyT3FJSCaf9cfC+fnL64Lxt0WXVOfiZIBBmwhG6PO8WAkYgpUSOE0x9OqJBzF4RINg3J7WzUTmcF7+VeRGtU+QkZs9nR689eGgcAAifrx6PcvWflQ9ysQWXoIkFykelHaGnwA3JSGbuVwiRReQGfYHK6HWsS7LdIXrzKQBiyHaCstm2B4KnE+/MQz1DhSND+EXDzGE8KrW0ZJWJkNsF3sbWUqGWaYcc/aOEaI16xvgJJcZSZUnqihymEQjZeu0j6tnq3Q6AgNWWEMXex5mlQc3gpyb/qH8Gjp8Yj5RpI8fkn36KVcpxfY0qpdcARip4Fr8ALLtWcOnsrm8uhCXVDUH7XqqX+LRIdSAhvQ2pPcTDyoqTjRSwi/axCW7E+C6trLagIDwGrQnlYiKD4pqPSMuGBpLJqkESv1iAsHs7ibSl0+FpoBg/pPnmZBnTQoyDUzILZraXo1wdSPNP0CB/tfwsxyA9UxtZSmnXRIJx3tUmaER9E9MdJ7XIQSZe8XjKrgeyfysI8lmnhtllgOW0jbYzit0iAOXV6PKENqRmYpy9XhKw2S+jncDtWslMzjbW1jfCBLjZRlMwiZDjEGz1USVnxhIu0Npe7UyEVYZTnjZQr5eAL497DsD2J8h0C+lSNtf9Bd5QaZhV8SE3e5BiDc8Ndt71OV7Sdil5YS5jlXqB8aMhlhcfVrqudlRnKTPAWR9LiabmAauCGI8nGtCqUM2lcNlYhM6LgvysT4J+Iqt8PXueGnjXJRa8Z5evGD+MiOLS2rCL27QnjiSIg6k4CwLx/A2fDcdsEscU0/WuzYzlC6zaFoPvRX0ZUCM6UTS/E0Q01K9f7Si8Ni5D2tXI4fktI6DBNvxND8vrCxhQKHlv6z5xDLA3jAHbJ3R5wdOoA5gdkzOePXPwMVClcK+Uza5jUwhgNWda2d00UxnA+hAfijX3YKnPtSPqZwxsEpjUZQ+OKNC8qApMus7rAFdLGhiFfk0HfhdciiYst1s3iTAqHOEeDdTs/F406crXcQuYlAR4nhDhK5xYXEOTC1bdIQYUHNXW60VAyE6sUkEL88DhUITh/fc6PkWExwGvchWyp7VCgLjivSdZBzKYL/HF+x3QC7kpKru/8Oa3wz3vfetnZPH066zG4eCyS77SbB/y3fX6UYfZ+Z/lE6vovVYghr0LE50Ia002cJSpuFEbPy+2tpuYjGDBx4Nx8oYJdakwmAWuUCfR5OdIkBjib2zLaCEFFmHndxm7Ho95oW1hgybQk24mhTAhiA9aKQ0RVabDBkCCtjUwBuFFNg6/Po5ieMjldDZtmTOFpsovNOdLNfTxmf00wbEU0DTypKi8t1+xX/0PQfs8P2L9mGlaJD6G/gSQ4QUFlHU7Ay6yKTgrHUkhZu//IX/cDNxN52gR5lX1gBHHfyHN4SVhqHAX3G4s+Nh4f3w7KCkcFKgAHRzYeGaTcc/CeRqlAqMa4WZykdulZ1kgBGDiaqQJv+ZIC+a2Cm6TftxLtDsATUZEZ65HQDOd+gRqZf/dAl2x+lM0zkIa+gC/xflo781GdY5kxFHNmwT0/7h8xky1UjGpENhX/DyiMe4EAuLP23QU+1IWHI3AZeUDbtMflcDZznQin+ER0SNs2VRw2cEfHva/kzGucqQmlzGY/3NlBx+pM9N9oFalEqJctOnIlvxS1+cYkHM0F+79N8To5x2/zTkgKdSvd3DQzFce6PGilhuuFCA04dMBe9FWw6DWrTG0wGxaOBw6y8kxObz9Axd8C/+ZnjQGybju96uZEFjX0NqvUDLj3pJkoqhwkbSnaQP+kkvCIO9MSxlmwi94nhAiOXqzv9rFkdgPoGv4cRdXM2V1ZC4GWHwGV7CrR8MglwlWA3JCX5UGbi3H4H9+wLdnkkIdT3WD2PWgh3iBQCojPubsUSI6AW+wygkea8u/PJar/1YcnciRIFRxHuf56Nb/EuDLOjsAMfcLqq8rShOk7/NHUGmgq8EHfvh3k2GQCgx2HPHYLqfTqyGSYO77M6flDxnaYXCQDfOw8MfCQWeBDJP9y12idU7Z1zVZ3mZzowJ/3/ss04oQWjUelp+mzOwHnb/G8YW7/AvLT/WUG2DvIqS477dXHGSB30q7fVuXvQRPMPG3msSgm+V+y1K5QWpwghfC2x7pn2gZlRYV4dJJTHeGpE+K1BKa3teUExy+iSSqahVf4McHYit/elzX4txYZOmtWDA80dJZVYqkI/1SCOZ2gM5XLYVPYYGyxcejeslOfLbo8U3TKDrCYV+JAo/C7wfYdq9XagYAmIRbWiPtA7a1wDOB1qAFR+pVGWMnhS4GWgd/F6BH842DozTyWrOV1tr/OQRORFn21+audcn+vR25Z5VaKvARWAvXLHm28+JJ0uFW83hC3wb2205WXS5e4Dt/6K9lNlIdcr1349XBCQZjxj4iQYBOh5CTw0VM4Sz4J+Cz18P3aX2fSuiOm7ozhtAVtCbHxoyZF015RlCbJT1lgU2xKXytpR6woN4gg5pfMibzC31Ij0c64Nu3vEvTJxsTyBIp/HAWiVqQGs6eKcdBddE9DQdEtixT1jHstDZT0wVXp1YqQRo90D3WMQ489uf1z4yRngo8TPHiv3QgiFXssUML/WnbIDsvmhm/2vgVMSx4OWXtZF0/O7UyQSv07yK/5OyY/MbRbitLDMLHA9f51BSlB1x3ZTHU0at3wn+b99rZs1emuF718IW1fiL0WsbFZsCjIowP/bm6H2uIqS7ubOgsE3qssodWQ/tdHFRg9JrDH+XvLK1APLEajccShj6rkdLYmIMKDzdtPUenKbHIQsfTKGY1/6JrxGf/5bM+maJk4yJOXV9K93lwRZ0eaFsdwiPl6+9AYO4Ce28rq/XGWJSBTSTwrVBM8y3nfSgipZHU3JVgqosGj0jbFJw5fTHXCPY9jD+/yncU67qKg7KNhz30n6+9wiPmVMmz0IFuWRA6a8dzHH2c6iqfqHwPNXiUk/Ii5sfTD55DX8TQlqHzg6AxFs2ueWFIqzo9IL1Gs31Ih5WwAfnFtLcxoozWbf1WZeDxY/bfPBUqhShj/rzFCjCTorp4ehT3xH0Rw6Aiw9AlQQ6bqCrZ6S9y52PpXb4KJPdYdY4STUjItqsIOSmeS6K1OjbbVSAK0+LqnrhfiIZhI6HK02bcSfVqDiSD3eKbcBaP0FwrBV5HrFcGyyI0S7YifucZ0LPcbTdON2JyyY4rNyRZB87RasZ3ZyApXPe4/3AzDnwFqPAzvhm7P1PM5KVoHJqnrIGtv8WS2sgt9v6VHY9mJh7I+BlVo1HAqL3mWt7JEroYYlWtwdy55jvUCK7d+sPBQOufMNS2+LsqQq51gLgduaGGUnl5Zhoqt3rqkieC87nNFeLkryk9yV2ZoPkWoyx6l1rk5CUShm8nJvOHeKgOscYYqnWYIm8nXr3M4Z7GD6TGeEDcCuU7mU6qDA81bqSta4NET9QUybpjyVvR7Jra2xZROU9tkzELgB+o9mlXQZLggGxpBynNrAal60XtHPH8Gv6vlV2vm/RV07SVyzYsp3OxseK9cipwxHjxpzxNo4SLZDezYcjRprLmjQwbvSJ+nCmPYVoubtHY+iwHI08b/QfwKF//RXC7lwhiWRMA2++1mumtxmhRskICo75cfy9TrlZzgCOt74lAB2gzpnzLsfVzpeSSAfskZau64Pcw3EcYO7Fh3XRiZ7JalGEnixRTlTuk8f9bgZVNWl3ohuYPfNczWvsqPkVTQsWyplkk2JdLUCl8kpI4L8nYvIP8citWtR3Vc/MORLwYhEG6Ln2mGfhooFh48kNEvtjwUeTBUW0/Qdkj+VPgrX6umNyOQMFgPi2u/c/EFSURL5Y1wH8+vtFG1ubICC+55XedW9v+UnxbWCuo0Y7GewnzKLeW2+LCCnUvnyPHyJBc9kXoXIB67UhPiWoerg4BRop9zQPjVoVn2fgsbd/cRqzqmf5Fdg/04H+qtVABO6bNx+rIISu1cUTlLz7zlmyPslIyZkHmLajKNSov4M53+yDMxy1PLkB7dIK8TK7VBcMrW8WLgY0e3RObSAfFowygvlfplvMddgfHTAwHNCbALFlu2g8aUzFdNENpvIVun+sWtqGd7s5897CWhPnmLCNwO6OiR7P3gcMalD7YIXUW0SNnfhGID/etmnv2od/aU0FkN+rvcifl7gFzxnTLWdGAHKG3S05M7v9yj4SCxT2GEgwvRy45rgwybHAxUrZYVFOX9G0hZdRl1frqn/jUnonBlXB0ABUiLvGQB8emFZFRN/ET3FfzOFJiTbRUPyZzjP4eAFUblxsQxYe8toUsMOq0tS9kXcydzG88AOhectsbOOG5BFKoJ3jDAAOnDN58LxxJ9BVTh4pzEAEPiRgylImi4aaRPG3LBSIxEEqyr6+i7lEWzYNkXLpkRmE6BZ5g3D6+3VV+8NmNM/0WveZnPCsvmPhy48lVLkkOW1niSeNGOpad2vTSRz0S+4ySmkmtofiR4pNsFj2q8dMuWsbv88FGWgxPjZGP14znRWcjtVtDaRBVO/BMjkZKHuuI9TnMIgsZUfQtlG/T3wfgJApm18y6WfbUcEBhJY9pXLzjo7WG/WL/KJsoTy0h0Vk922c0NK+wINY7Eop0/Z1G+CB42KtCjd7CBQaSz+4U0/RfKEL6jlHO8xBCoUS+l4GSRuJTo8oLF21y6q/et2AiuvJtzkZe2/UsXkRHTk0jYeKWODsULNNTQcopEjXNUJW8c+Zyo1lNytTNmH4+DLcIgS6ID8IH2XWno7mM7a5a0fm6wODsjo2Pi40ry0Q7I4LeCKGx2T4Hx9wZut1pnJ0NdS6yf0cchZ2+53Em4GT0rfFbh4TgPfSaSx7Y406Fx/oImeIKqWmRrNV7E/rZielroC1PWhMPJ01eKDz4c1iE5w3LFiZVozLR/+IbBmYbKWJcDrQzGyrUOFo7Vo5IdaLGzyRARbJpsXZQRDI3+vNvjtiTmYI4Kix8mfTMjsUaREtDy/3h6uu4FuhpSRc9imd0Hvi75dxneEnBzy9l6clnf3Lg/QsxqKMlstUBwehS8fm7gmQq8QXV5M4za2HfUO71ISyjoxY2QvhEhLc7C+8y3UoZ43Ffa04ElTIxPcv7wX1CCf8P3PrZctUuqN1+RFkiyUlxK2k5dGtuTA31AWYhjgtsTw87ropZkuSdnp3TpD0Co4LDc7bsQtiUonhpyaBzIpwWcyXejzgG6diKT9e/vmm2X3TdmE26LtxCf6a0dsiRh3IyUczIwXTFa9YkB30L7QY+lbmMvOp2YTJqn9G0uOnYEZftTB4ifxCP7cD7VhQ8LGdyZdQdYrEcLZtaiFLlDUmeK8WbNWjtue3RtfzAUxVLoBk2NdphgS/6MnKDtxkJKkLvC/3jbxRdnxeajhce34wBX2gxFGqZmA1T5GBR+8TZMqTJ2VaTK+gsPdbelOdWnsOH1MJCy+9yRYo7Sm6ESTHmeKZWTJ27nezE/1xeEqpHhE5/xSTNdrofCoGCO1y9mm+BKG+urTLvX7yo2H42p0OmLnoYIFLDOk241ueOkC3ThImnZa4uR354VJRKrQWGLv8WISyA0HdirRIOiR366abM2mcCNL9BZcUokkh7NmmwYw8g5kq/W4+H7ktMJdHPPbnPSrQVTtgp0eEmzM1KohxsHuPJhLlrCs9NCtPBEGFSsXaryQleoyFPFhI226F/2DaCpMHFg+yGaqcjjenQerXKBD3hxBybJ8Fpqi3/kAwObkt/fHomT/7bxiHNsSk71RY7h6/I0uFQozwaQ4ApWXNjUVjLnufbR0LM4oxaqWX9zWMFOvN9ST1qQsZ35auXlLR15XJ+s1kG7tchXZQDTB0MGLvCZSgmt2oSRVMzeLHRHXaOy9UjYXOF9t9CB2jVMPM0J2fMleD5x30FGl6+qdgaJHaV7IGEXOSAqy+6nO2zn6gdkxJ88n6mb09t8ornRbrUde0vJMH9xQ5DFHe+YIvh9CO3wYmXerzapk2GjCM6dRYeERrCZh+JQwmHrYDiz9q0TGwRQ5S47axNYJ/duqE9sVquze6znE/L6AqLvAqfX0tJ4SFQ957mpSbqJ1v31qLMoOjOgO4rT85W2/CMuOFKrlqaVCstMN8xAGrFpD+jSqi8ayD+VXWH2EddweSOVtpXbGVIKxp7O6FBxePD4nKe2ZraIqDY9Dbs/JHz4osv91z0iESjyc6RsxSwYtPKJWOTsd1QRJ/YKkgpREEpSPvW2BSD1jPXZVERSxVYI2xXXDq3IAfked+1Jm5zSLnmH6+NW6+18VEWkby61PhERcWaf00Wr2lyxOyMIWf64gkRNyiVGAkqHR/AsXXgsfhhENa2i1UpLx85S/LB5ycQCMHCa+Yc8dSnp1cetQ917mjsWN75qLqdQcwFOlSCxFljwAaVdYzQgOwQOVZ6LwAkiRjb58t3ZOaSKXiPWPQjx/3WT1Zxv4koQkopfoFcxVJcgqO39piciBRU4gkCFjuWYDX9wzsHb1rDF4+ZsBhBAn4nI6Cxwd5qygODf7jaZDR5JigzfNRBPtw6lRiGXjln8vRQl5cchKmxk2CgOzJMPtwURjvM5FpY9LG5n3w474lzwkq/G4yIrYXWS8u8pNycTnR8ua32CkWMuHu7D+UEd6NqNXaroi7f6YM/FVDZE8jqdbPhfoPJli3kmPVMLgHU8zyU3ChOCL9WLXd4GiiKPJpNopup/6irS3L6+QAcZ0atn6GN2aj1aRGXR8h1rxNmRolJz4nk/iQNrpL0AKZFnToNLJM07dRZuCNh9fTdSlxjRfLyMWGMHu2Reu9IcBcvJTZcupOtGceau1+oa2+nCaedRVIT2BmVPN0ahnB+YtdTq/aEW3ohNURQyzbt8tJHFzq5nDWkzEOtoMcs6nxGNN2E/2SqFTtGdIO7c7yP6Px+UjPLBM/L1mMzW/wGn3Oa+vkxjAVSe+JeacOMREfrQevKncS/cq9bP5hIb/mN939uyxtBe2QIrvNsinubUw2lsKtHQn9D9LDWFf3myGmLd5/A2Cptz6Z5j6BT+YGp76LMsj5jC91BLRJPf5LWnJ26JfUdXq0gmjoW178rZoZ6ZNbTTlNNtDDfFADvvK6cNqpHK/JP7um3AefA+CSaxuNwi3+SrY0flXja52mwGFGNGN7yk7uXLF/vYudHY98f+FhN6d1U9lLfaWMKpsjrivHDs8m8tMomSgQO313U9GmL/lBGfr793YsSTt63BdlfYqNIMiy07Gwio/xMVtzhL5iq6SCeddNKc4ZU0V7XZSWDiwZLaU4UlJyg6SoHFDGk/rKtap62Ml3k6KjdYxcuc3S2NqKuYFJO6ejaunCbG+SK8OkzABQjtAxhc4SUzT7CyXRJcRWUp/jdc0Xh6j7RRcImQ0o+bA7rgB+fgsYfi/C12JHHgcqhybH7REootYU4MVEf6EuXd/uIW8wYUtIQo0U2X3BEalGgmoXJct6bkoJAIVoPhge5E0LUkIJrPBIuRDHojvkBqz0bY+deINw4GyoWZSeiCkmRIO6i0Q6RbbSWWsPUqXHCnTSPQC+jLHbnok3bhHwcUK8TiR907lDyaMEuuapmViRf1Y/ktH0p/7i7+cJBrgAsa7UQFyaJFsMeo6ZtRxzQrjWpyOFs45Iq6/IUCBykc+qsC1H46BzoWCMhCwxze8IQS705ct4h7ZMNG5URRcfGaXfoVRn6Pzx+BqpVNHg/gn0C9srzGPJqYcOWGb3SmFcE+us342mAKp28nTX9Jb09nCJow0bhrTvD5/s8Dm9XKWoV5rBS1PFVUrbMxA8piB+MJ13llWrNSlLvT9xot3CZ9G8r0v3JpyX5hqoSdBQ/4AFfXR/rp1JjUJEffmvonT4Ap2quuNwyjTefEoufo2xnd5OqFnPJkaDhNR/v/mVOZfplVpzBEEdQfI+4dNfFSZNbiICXkIZWCF0P68OV0DA+lu0gPAODN77DHhiIEcxMnrEJZRlPfCu6pL9STQF+GSWLtkbwhtwyj1g9mHxnk/T7bJLXDw7PfSSX8Gf6bYzhku4S9+/TtzZPCdm9dWQu98F5InmGtzADlaPI7JsYcX3t/oTEYUnwy5YSbXCSBybD5ilaryidp8bnczIfmZmS30PMFVWHW2aaQ+WQCX1oKDsQmGQU3BMTeEY4xnYIMuCIK5AXqa0hQlNvCpIG46ItY4NILN6Ry+fC1LTUL3tagI1V1Cmroel0r5mHxKq81XrphmiQn4will15upIfD/TZFVY5spYk8JIYjBxBjzVet5J6o4Bf8RHJI4ha7kdMuvmbD27nT+HtIPb+f1+cSGusZKVZ7fHB/x4Q+P+1/d7cv/1+/n4g+Se4Yf++d2GHY232H6b1fBu8jCGX0LOkrqUH8cIZFHKxJ3gDqxd2BI0g041WAAcWKi5K15YwprPZNU7zk+Il3dlPIQyzwCnyXrBIsggnbETngDoxvdtxULwc81m0KRJ2mN89T3nUqH+pLqZlHMXNv6yp5Qn7Y0OPwo9w2DtXB1xtzEyTbBNlHuVVzz9oQ3Z+9v5c7fm2rZSRrZfJx7fidl+z+Pa3PjQDuPoZDOEclYqvbst1hbVdHFFEthdxUge9VRt5mUadoeLPtSKSLYhNBxacucE4UxnJxV08ngVRcN779gBgULF4bInTx+kK4AZuvGlv7comin/YFTGHIg7qTytG9ovsrPgWh1I0Iq8QCDFNfsJstqYsDoPBCfMgnD8O0BljxcMNzcdNoM3vDz317cVHQYWC6zPRZE9BGFz5yLJsFZMpokoFN5bi6Yw5vrxLf8BITST8QsD9wZBs1Sdep3LTMB3SXTI9tp3O5sTirmSirenrkfmdrQok8pSeYQoh5oZTXM2Oy4f8l15WLNdprmnAbg7aT7wTgV5HbH44B0uMj7d75JDnVkyn2YRufuzE6EWpGdFzr5IVerNiieg02au2ZEWavR+gGxyfFlxdHZNuEA6zHGy2i00f6tIUI/3jJhuNr3xM/NUtTL5WXGrEGKDeWt8Q4XOeg37Bv4VpPZJBQt6UY0dKTkT8AsjNKCyjvUygkZWc5jkNNhmiUP5iCLdalc+XruxYf1Npip80k+LKIbcMKnj/UDaohccWc2/WM+s3aQmHWU42211MyByoKEb2D98XlooBsy9ULEXpti5PT6wZrmIrIL/CmZ7xtyVQSD+TF2MKU+PWbyhOBq5l8NTI9x8knsyWgGicaaYLRBuDGcVQDBjUVzCxDaFk5zW7MHHnBl448uJsHrfQRNxoShYmeG4POghT+oCjGIc5kMsBuD+rnrKEb/dXXVKS6BwjBG33XqKEPa5Am242Yr703PzhLGDLPrlhRuiPu/3jhkPojNz23HcSLaBo7HIqqR2m6TqBY7vU1y7kq6jmTfroCXQ60xEAd6j3OrNBr3c0HpvPHC3cUTkj92oCWhwK1Xo/4lgCsE4TBjcEcNyDyRSO2UXFbUFgmST8k5mguOmv1Uj/uNFG5yleDf9HEZUxiczpqdIz6zcjRINM3EMHWK6mreLDYH7yc+xqo6VdryLTsqWov1qQN3DlZA3uBqJLRBMP65bEMg3tyZTPH2s3sK7/Hv2uprGpJgLVIcY8LGnj1KVbwBbw8G3+krwGVRtfgpmVzF+1HYv7GL9W5ort5aIr3qknBTDNpbUYGfj61e7dEN2z95AYDWWVo6C6leFBhzZSB0pM6LffsveQkqMNRkYE+o18xob1Cl5wfzktaWxsZCC62RjD5XJImwFX7CPgMExZUELvVOg4qRBXgvlz8lZFQgWVjCfRrtERByu4fniurF3E7FZ35WbiHBPGvm8avoS8jlgjYoBOOWhGG6ECKYnIi/6oUOgtx+QNKMxwU0Nx3j6NUqo2/wY/xlX+0ClihHwcvmV3MYUb8/Yai7BClVamS96vh95jhG3Gk0pwgBMl9fU89wt2crizo6c7UbP6UKuByzZ+ZweD10Ustjz2jIUXhMcjPr7U9IbY4yxIQo/Aj7bmvjAkHEbipznkBzXRKpLUZpCAtzL466OPqWvq6lY2UH0jrqBzOJLp3xEmFjgq5iXij6kjrhAwllFt0JQy2Y1GF9yAuIJG3UCVAw+uowCDxnDD6P7T30AgDFG4HpFhzU2TiZNEUoRAXDaVql26X6pgNbAjSnzgYKQ11LZ1FJ96dC6BJxZaEAUnWJBEF4b9oY+qwmmvmi6nr0Wz/Jz2ocmgj4BqaiLi0K9suGejUrhmAC+54cuYm9yi5CWTAk3vyETydmG3iQ2NspGPKYzPwLmAL2Px2OKd3DKayue2WOjD+zZ3tryIQzHqW24xbURZrXDJrwNVd9QvMeCyVf5PwBviOtd4JJiY7ir078t+iqCspVNLKMh31++T8M90J3xjbZUW128pOAyg9hBQUq5GKRRrNcL9fpiR9QqXe85dP2i2qAZm5F5gLsLDcGKlDByJ+gQqB6c7rIaBDa52+4zUMGBN5KbbKq0V8Gm4Lq9RiQQaNY+n0QhEGjUfrMjxyV8HndEO02H8/BzgXoqk2fX+NrdARyfXf1pf/Vp1MbZfuFbZrjd7okFzdGtMXmgBQ572eYxjc27uSvUkfAT2TqcAIYklYkuc4s+J3Fgmk5uMXo3DvZpzxaJIfSuiFgU+EPHYUliOVCfm8y/LKteTB+czMieXs3I28V/CF4DlIvI/j4WqBFebZ/aQxyzdyOrzxpmS5qtNzVWIEu4uxxIFv62dIpSGmOyQtGMbH4raTQoDz0djhSAlqN2GdmBRuVQ8g7zHafEPLLqeKIqyhEmjSdU9xrPg7CNwMZgbuD0DfhOR2NLgjzRVG5sNokk0hotiNq1LZU9HnJ5wyFxZPVTQ8FND46+NFD2BK5nh0llIFGxpDkSs6f8AR3O4sWVe7rKDVOALk0WSFEsaVWrk0QwdIubaYKZi/ccYzCdY7DUM5kcceMj4K+J9z0hmcFfyIhVe2Jo7t+jEUfHYfCUbQGIf2wfDlgVEjJRcz0638ySE+vHn1QgFFDKexGJrBGVLF3a3dfZtTbhAhX/B6uULvDImXUoHZzDohnYwN9eF5mh6pbI+nUaW6RFrWI7WNzbcgwZk0/s9o+oCg1W27SxBL+I2njs2qgF48isYwlkiZNOzPaNdygSTF5TGplMJuRl9l3r9c81liCXbdZ6u7o7e6CzPYn1VyV4R/iwKOdSKthIA109ShAKLTO+YDMBdjvh0Mq5Y8Ie87bm7dQWqMxLsJdABwq0Y8obR8V8UJ99Q1VyoJSp2KrUa6g/w7htzDDzRnHCtbrDoNHpPmxZc7NqButDa9Gdr08Hd0Z5cXBsXMGOyD5MWhVLBVcG2MNV2tHdLAbgkurdi4p1GcW5I4ax6Z2uP5ZIt/XvyzmO9urk9PblLlreUcaJzSLE/2jgBlW/nCpzPUxn0w39CcNKGl/fDxfW+umxNh5Tbo1Fx00mxmmVDL9SegUWGYiU1j/aMLetHJusyC1yq0xIURFQIs+6QSMdILtU/M5U9U+HF4crQRiTSiKktXiqsKJHyI50cTXr9cPfwofT0yAvxzLn5GXhexGOLa2bp/rF9GYtUeOvX3P/fLBFGG288PcBwEeoFgANHNwTToTiqGNGyqrXkYFFJoL8roesQsOLy14wWhVoGEeCgrblFDDp3Gqw7q1/ffC9md/dQcrXrAOOmDoFLpWGJyC/SB6Q8s+Ghpl6BOK0V0dpOYgyNYq/aZNd64BiYPzsZluPX+yqu16KVpNMCuapTcpPETZ0ukCItkKS1WknX6nHZiEpcwfC2VcWm4Q2YMhBmSukkU0aplCHK1nIjaieFku6hAF4o1wv4IN2+5j8M8gld/POYOcf5JkmolexMhS0aoxtComV2mVDgSzIUbYNBN/Rej/qe19XrJEbr4zqol5CA6yU9DY5klHWSbWk2B5FNNTSNTx/W3GsfIRI/w1D/Z4KfymT6YfQN04Eu6OYq+bk90EA0faLyPawmzlcOuTDUyYCgJEMYkitFoRRD0aLFD0GW1jmvEfiC+2F0GYFYRiTeIE4HowQs0d8eRzwEfhBVcHVUBqN4Ew41OqnxjG0KZFbMe3IIBNuiHbADvDpyQw7Wl9nADWhuo70FfC9a1xTy9/jdwWyuo/HBsFD0GlwtON/W2rGpmcO5kUfvOy7DJ5A+/iU8CYuu1avC3y0YbGkjAL+wwn+46Jc/zDoBO8K/376DOA9Op+m+qX1oxsJAYwno3+49GYsWbPjPlNvhFh7azWKBeCJWiRBWB8TfBk58CU9BtAC07eyAT7G8HRe9+diw/OCSeMaJp+KxeEr2HM6xv1dudQwohUMmm4CHCF7FaNdsZJfpH1TI3uAY3Aa6486E/edSlcKMQiPuG1G6nSNyeZ9WLcuOSh20bsoHt45NrYy2nRhELPHZWxx/0HYFrK1fD80wjz4UC7fyb52GPw3DlVHanwOV+smt2MCdvY1FCJ00BLWZfIlHrdI6LdL5EN6RxMH688jcnGuSK8lal0VwF17iBR4WTHXJjCl8zhGprEejkqVHxE7/mEKcUUwxFVIOTwLR6BIFj62UMUFpF8rGEoD5+QMwif6+3/ii+JDM4RlWi8dtz1Bh4I0rw/f+08p0F2rE4IEWZe5CfpsQF8ElpUe1AeWvIGOv4g6eXL4FdaEQ2r5MS7FkoEwMkzwLkcI5YI0vPI7/ODcUvJXXw1cz+AEUv9w0dZUrgIINcTcOp37KGwwJCouvoRrr0fUAjQOczsrqGxqUmSamSK9wua+QpsG35y9Fjrr6984rsHPj2/23q1b7bj47aGRlakN685eCU0h0tXb+9JCxjamK2Cygq83s446ix+Dp9zB4nAqL1+CwVzxAri/Srm9A+25oQDYM/C8zPrGe9Apv3TM9Mdk3ZCV3rp8Y31PWLLA0zL3Y55R73FvNP8MovVZsexvZkoeqCgx1R3RdHEFYTp033KaDvgI2XmW+QyBHWluHWvY484IJpjKa63ALeHZ6QbWQ84qwO96TA6L/4XajMRwysWwksolhjLZbUKHHtJCP6iAOaSEWEYCWfXX02Sts/J0/YeEjRJ6t6q5dzx2URa05+bSma0goTMheHhx9HVPiapYqBSyeJUnW9G7myAVPmF3HoAjVDVseoNa4miQKIZ1r7aLps7Phct4TLp+hEfpq6Ypu+o8k4hV6N/h8osSTDpb5J0OjBPyHWPRF0rJYR29fun9kaHhDJLdo7UxtuknSNFg+CGreldPLQbinzhijx9R6EFoUDoPUMxK+EYnoQYDvVWpl5UAcQ74Z/jI1vEEZfj82/LP28O9Ywr9k0zs8N7xdFv4KK/wkogf44k7bH9mit/6pDgvmzePXFSi56mpbPaNzV6RY3wE9NZNF3Qs+EsGR4Mhy7cxa3Qzd5XzSUvOGTLD48Ehq4UEV+4D9LLywVs9xem1XHpem+sWXeY99NSzdN5sitWlXVg338PJ+lVZm7H1Jr9b3vRx2PkcOZ3Hu0uWHsqKLp5emLauLDyH0axtur83xYw9HK1oIUh1+89kRXW+AyXJZtpVje7usUqbSG1JR3oY+uP73/7v50NxITjlWzhvWnzNmx/bHqQ/uWq88xJWEqvV1eXri5917eo6vjnMSaHNSbQPdkd6RiVRiOdjEhkJFyJGqoZtgLpAYDid2QH1sZ+dOVs25w8Qg94uaynf8RY47An4+PzSH7Sd3d+3joKZLPJPxsLKTLvGT9sU+1aIUUYhFx4pacg1ZajTwkzpYS5FnSMZPQC2DO7sYyXkr6ym0nFSF1bCN2slyRqdzVNu0/pCbykpGE07dPeYizZl4HFv16J4lfn+NEW7uhv45o84a11f2b5PrblaLn2ZgA6uTxgQB8b3v+PUXpzNrtm9KDUkcP1ZxYsc4wv3Q1LnVSkCCcyIWOzQ7f/S65JiZ8DFGbFLLloBp8GBOZuW50Z8svYOvKPWd3Ovk/B/rnyt65FCoyuB8PK32r6VE+cjccHkrRsWR8Z5FRZDdQQ7rjuY9/vloeQtDfDBoJ9d3E5/FYrFdiSOXxry4idNCBwHPF2GIKfYP0Z7bCYucGv0nOi9ePfG/c5TSto0hnXYTfQIAeOL3E3cv+5W5ZsJ0GzwDOA06n9Z2bCATMhR6p9t5K769SHemXb9xMoHpX9RL9U10KBN0nlcUmUnElRrMyy2N7zWXIA7Zl7q70h3ZyCzPcFEBtw2l+z6iZQCBtRL7bmyXpLMv0T+yw7izbzyliDN4flF0qiMBzQVA3re5HYWVe6aUmBcRrcOt2Aix+76NCyNEfmx4Rua+eY5q9+44Ao70xPW/CnuybnA4OdNS7h3znmEKeJFxOEfqshbm5hXBV2Xhdt5R1ZeP3HGPSIWctjhLpe5gcL18PtHZ9DDrUqGYEb/vmxLZugOBekJTzPpW+uaLj07MztGV2ndEUOP0H98uv9UVQxA33lg/AEQcp3RLVcvVJkSk6sPBlrPNDS+2lGxZvaatI92maufRw5L393AKx77N/Q0pc+UE+TlH6TdNrGpxDC/VZh2h7aSAs7ZMoZrPfcYC/cvmrR6ujk4KZOqViPsMckb0aTURrlPOAPGS1zYsl6vTctpd++U45osq8kjYAczVwRbyoPYQJfxGtWTq5W3qo1L3TgbZZsg2ovv2bMJc+NLa6LRhikYP/TdiZFSDTyniYxTyYwTqU2RLJK74eHmNKySx1faH2mgfpPn4R8UD0fp4HzRLFszLYM6GX6oQrwbVznv5Y+rDH0eGln3L3LOBF4ahr4LOQYwEC2tBnjWGUrRGAvWaBXrVKzhoeBgBhc+7yuXcGgtGGctgF988v/Xt6Nael69sBs3sgI+pTt0eLqiOE1sf8toN7mQeJfRs6j43kpybKBiNttkONFIWUCtCrXzKQ99T3Dws482l2ltU6T6VT8jtfaDTVH9ZD0jcguuMHHj6S7gCC65N7FPhOYmHz3bZeRff24PbL+q1TYLtCo5vWAU+q+6bevgZ9GQwD158sBi9L6SXvVU4bsF/jBGb1bIlz4NDM5APnMYzO5+X+PHD6icX82Tm9+baGPib5Y/vJazq0Y2Rovodv1zzBicO9N74bG5oZgd0e/lL/xy/4wRPcmQH71Xt1JVbu8PtIchU/G9NGJ9mzRuSS3o1vxw/l/vWjEXYkfMyI8PG/rLqH/+i82LuHmPn3oc7DUO3p6p5+jefFIIdZeXgAIqWfuHd+/D+XVvS5DfvyTBH8A3owoIDV00Ii6S22N8ZuDiQlGUDA8MkWbV5YcV7mq6zuCKISrvPlvUfE4j6b1+cOyWz8vvzM9U3eOXIXVQYEOLeSN9byzAQiFFhAfgW45uP/zh+z2Sy5Po9ya8y8ZscNWKyaSHi4MDvY0/PTfdrvfCRwTFxyV1xjUBKv4I3oON7q+cWVYOD2bTY2aEu6Nh88sX9BOHHRhISC7deNRKLxJ+ffUhDEWRq7dhEMtnR7tnIbtNvqDPHFyELA6dZE44H1lt55D9J1I8ZhmeWqHUAC9ZZi9Lm31SI2BOMRTMCVlu07jeffexy8W0zrE/Hkft99KSHAc6So/vp0yxAp+NwY0e7anw8yaXhnVaoR524IqxU5BLg/7xoY4V24709h4KwKMbuMqVjJ16OwDJbwvX1Gu4WoVor1Saf1UPfaoQtwZOu4STr0JzB3Q61+5CuP5n6gmAu6CMhoK9j+WJ6C/27jVoLblBbesKrnySRFETyLlOZyqX7bAxaGKfuXZASwJ3ShiSX3cYtJP1WLpkQJLiuL9ektMzPpfjYxV3QtZ10TEF8v67bnda6OnftUS1ftfp3IisxdQUsUGVgYRIwP6Q5ogt7qa4CuuBEncId/dlC36GJA4VfEgpw0Wd55N4270MIuipodicttt3eDd0ZPcH2xrLlIQmzS6HnpqM8Gf67iYpiMpdOFpBYFuq1g1GeTCfic/6TVawn64fY6g6tdW+h4FUWEuZC4Asc3633alCcCxjqEy6Zu5TxCVzXhoZxFtKIjmnxyU2WOULh9DC9UgwGNK2FdW5wcIrBbWkK6cc/mAj+TzVw8lstB5QHeN7Rpw946icMdK+OgkN9ab7UzwwicDWCEVF2L57g6jIX11rUGoOnTWtedz+HGPyBs5z2mnRJGYl6meYCmZ/AvzpUH+yBpjmZit+Sy24b1i0A3k6PjPkY7TSYorXo3bUgP5CoIb3KxiUA5P9tzqVYzQfqRykmSgrJIJy6Fbkms1EgVudAtt08K+YELXvRp+j4wWKZ4clnEd1oIrV3dSTtq/9QL4290M/vWsheQ76LxW9a2Vj29fFxTgpoaVZL8ms75MCiaqg4BXnBabF+iuIUc7ebUQjkh5g8DYwGMhlFUfr2rwfD19iVn6mbjEYu9qNaWYT7CU9ehqMMbqgFrjhKhu7zMRJuMH0mPSJhOuC7GfHL10NfT6TcMTHTTH1y9PqVAEafEHzLjdcDb6IaF4iffnCPAEaNEdMrZo27rVS9JUeduOMWzwkQ8La3O1rmGntaYoCoOcKiS95+312N19mTHnWRfO4NtodA8it2dQXLrT3PawHCTsSzNBX/3S3X7+88sdsnCkjpDrkQ4lMIwqE01D1ieRZoehcLIx9kHt34193MMM3guHuHR/ech2eZ5Ofpi0R0Uw0pQrhQx2yIQ+HLpdjed9dzp8FPT+jWFRLFwmpzEBbJ8Ho21BU4I9eyJby53ff2sWdF+rW8dCFBwJawGPVNMbZDIJUL3aRL+5HlCQtAgZ0XrGw/kdmOw8GeKMZlzx4C0dLhKqq2atWC9LCcM05tU7GgjIKUCQpOeLfM/XHUyuDLpe6if+eIP4bDhjl7uwAiL8jaqaDukHC7gQqTV6CjQPDJpYcCJGulVgeDPJCMLptQJe2SPt4/DtJYLLbcicFPT+jUrwbRFI4RiYzeiqUgAVS6+GhNsFlgSAvvz9FSsLjvMH1a8td595Ap5i7XWoVFojR4/LrCx8TKspXNqweOmrD+YzKvs3YXRFqwV1OLdxCcnQmHVf2jBdDlYyRD0vjOMJRmU75g59nXmaNcGTqALn3+f5kuaIvOAlxh54TSgOckRiE9wKOCkVYt2MZ46Y03cyGin6G51kK1GTHuLBI57J0WDBNqi2v7P4ZXjGwrkO0fpWd7R5l+WXh8xs/Wse/pQsDfUj9Xj3UqcMjZzeHVafb6+rhS5tUNZr221y7ovIUI+zUSNdyKlhOA0zZso9SOwo05J+Wa4TxrC2t/TzupuGzeHXD10Cz7BXDmMfV2TmuPs7TRalS3rARYpCFNuqjOV5elSeoATqpGYTjq/6lbDIKQaUPP1xTDpKAZ4ZMhPTb4vsKCiMEOFTqMX6mOrhi7G8QHUZQcaGdHIBbJENm41oNLGCNbR8R3WkX+iiqv09etSuRByJ/WhClydudjNc+7jPFswNyEQefecrpUFAdC8fEQxvt1bgy1rZqr/Q+ipba15EBRSaCvq6NI4kQ28N1guPeWu2rnflQwV6UzLmEwswuOf5kc0+qw0xtNnRxxI6MWyBvFb6vF6n/WCFLmLgd3tco3kVQIJ+JwUDSKPcMCqSaYf6PUT0CyLu7amavV7bPJyoiNrf/syVK7Tsv6xj283l2nb1Q6ewz1yonm4bSv24mxHz2emOtnIGi2fxb5c5+nMvjKohNTxUa+fUTVNeZzzBGHTZ3hpLxyYLRnwTmcprpehfnK0rkCzDRh/6hQl5KOUFzt1/DS3b5ed8FtSM9hbSu0xIwfONEQQnpazMsc7e0wrbJlTXNNVrEe7xpW1EN/KhBncUMQUrtEXy24rn+gfBea0GcdkbGehCREfFHFGtxwSpqdEESWuM3Gy1t2kHJ9QbJQECK/EvJXEIuua/WGyK/B+apiUQD34AzXSLv2OHik7kcM5jIWe7mT/RELoo4ToqrUUbZrNC1tI9+lY6OUKbYEtCQBXrEiQj2J8pYvpFGuUHT/ekFdQeA7dl0HsiJcsBKQSQVILBZbmmeL2uDq2RZBa7wgAshVK/Hi92bec92Py/7lLuUoL7UQyNqks1hgkkFGT5v2jwXKsH4eKZU9ErnJBym+9Pp5EoDQV6hLZCEvVA7rXj2T73O8kGh4Wim8M5qYpLo7rJoc7u90DapqFGdsGt1qyytDlCi3mBuUbDOQuMuqk5z5PabYbG1d8iWtECRzjC4WXrpKlk0HxxhYFXTQM1fGVKX4Q0a9jiKfQGYEDxJCot7mvy7Fh8fPtmIwszOYi79I/2F0yRAXVx8lYJQeHukNChsAk+akDhgdzWj8UjwBfW+E0ze6TNBNujIAPotFV0/dmjENwtMdYZypQJAb3QcWnR5SLrao2Onz/ExTGKvo8cwOTtzVcYp361axhG0km76H2azIcQw+Ce2zQD0VC7S5gTZCioodkFZD3QGP+4U5JMumRfVWvTAJukykjl0O70CFHogvyQGAWBQu+b2iRf7h3ogm3i0amhFGF6IDFxq4Emy98YkeR7EOwu1F/YR3FfZvgUqD4/c6gQIIinhKdkIsLrUcWJyIAHzZO96RsJXssODknd+78QmWEbjutWtYYIIY9t7oN2ga50aCBDge2TeUs0TIWhKqBHqOUqP0IRZJ9r9fEXtjszyLyaqSvWKRykWgrKJ+qLyXx3eUSA0H0aOMTb4ZGpI1aQKmVG6Hq1BEXYZX6kN6rEel2GrQvhCf0EWa0vGoaACjBQwYaPkgQeAg2IwWAjEQEgB6QfkwN9ugqObc+YdCSI3l5NS6INQfhqkFYmkFRkdyP8X82QAGhsCJNjC6nplqyi7kwkyXTxEwrhoiCSsgcoDCQgdYLchSnM++SWCkicFQ9c4b2walcSh2mrU6KAye+TGRuM4y4/QTS7GjTc8aDVILUIJ973pgqyA5THRBm4KKwj/zqtfpRgwuxcIHCq1J03zDp/rFOgZXRU0XhcRO4uVY+iOOW56W1EGawtLG1oenDsOBJhZpQzpZdkGAdJe7Oxcfwd/v79HMfpmF884onvpng3LUWDJppylQR7EYs5rnbnUxKcQdsg6y2CtxxGejfvKQSLXO2uBMn9RymLACQu5QOv+Dcelm1LiTlUk8bStV3s5mtvFoKPPfwRa8gm5TrfodR1o3SqakqDQdAdjTl/zix8jfvuvBcFNzIf6XpiMdNT3VNSQZ2hjCIebqYWKtuCU6oSP4KwuTH3VVZDomE0FC8+ghMx8SKhlGTB7Fghbs1cmCdSzUb32WQb2eZCgzM7H2qmffZSLVuIGnurHhGR6GGwMZ8+iTTbjcvERFC2BPEkl9t1dKjIQHNATgWDxConKmFQuHmxHYMl422dPn6/GEcNpZiN5QgGX4dYyKFIUmkEOIirxnaVoLjsJPYo8Sc4MlqyVJCE6O+8QeQQ4KRI5SB0C9Mt3SR0xnSOmSfgiyUAD4lggP0WJ0xSLNlm5zkNgUfdPW7DaNvfa9ROK7OMopYzmOXOvbhF0sN2tM7IaMJQBGrBew6n8C+rflKvUy2LgyfryDr86ODOfF+lr50Q6eikDr6eXM9Ik7M43t7rgTMVHhgIQCqvsSgEe7wXW9B+/l7LCWkCx66yQl6Be4zmrhdFdTQhDSZLO7XBSAc5+AMKbf5qJBi/4iWL4rklKtGG323E0xGAZh/yUQJUpwOcfXFN2Yrdx3UgEtjYhiQ07dZ/4pg9oKU5a4sE8/W9Zavh/nKqfHaTHYMOMO8m6KsR7kJDBvg6uYWXOYZWuLx5oBYbEhSFBBvSWkMybgaCQs0U5sJdg1ryIwlKTqNBrR27VAWt8t7K9Pt/fw1WAiAgBOoxY+yuZ4BkE/exiGEMXZj8Hpu8BHrwrh+RNOUr4vovd5LIkqiS/1Fn0ZVMc3QgYSlNKvoDFXsNjLWExpD1iVhsdca0wS6eKD4oT1vsJsw7NKHubvl3fBcmChbVfPcJciTuf5RIyCXNNr0mFhI9HO+/durPAtstxwT1CoNiPC/mE4PXomLHBBLBa7uf3fKE6e25Kj1MfgDBvVodJ2hIjrYIqo5b8Im7iSlrWY2yyZf31Aq4aOBLsf4OtRQOFVU0cpm4ctVapwCJiAnq94oZ3frYp11mlXm04R3i9L2ZNzlOqCNObKTADMGd4BpU2xIKRkt55YOdes48gn2Tuu/imFRToZgN7B80675ksVS1dXI0XFZ8omIZGdqxr1CEqK3TfvgQaM9jS5KnZMD62Kb2lRCOlPr4WJbKAzKisfpXj4WKxY2hRDnjSX9HMGAn0Fn9ZCyH47DfBdMDMcZEe0TazAPTsKmdMA/J4aa8YqNyRn1E/t48R4uYu+tQCqEPAJtEcXdQBrw6IpBCK5Qso+kFRVCEVzWibnf84OzoHk2qICar6jtlsrZPlee8QMitTK1KTAXajrhBfhX1daCAFliFR5vJxpoY+vsPwSvaFzmme3T/P0nXoJ0/f6Ji0oDAAm5rdKl4aX4MKVZjusUsBkshjRfwXAyb9qLSZb67LyJFucsa/iYdx1TNOcmwi+G1RKAU+h4BzwRuXGZHbXrLsuef8vIHkaqJjOqiWr3dezObuJpYbOUywMgDiAs2HRVAKpQitl74+8/ldd8oGwLMhjhIQckqf7slVErFF2TghcpboMPAunr7RruyncTSYkF5WqI3SC5SiurbxvOCymBHZRnfv0+s4pns02xdN16vs84l2mAXG4Z8hfbqiBz8KN30qhUKgQMlkKoVCkELKUL6CFLJZCIBIqBKzfCoHLtXbPzLfRZ+NTIyM1fAONqT+d6qvX9k3vNvDQUlAA6qezaluP+tEyA1YjUw2dJ5sYtDUaNZ8fWfFPDNwWPdhW3jMU8VJe3JvE0yGo8gCXEZaw8S7DU8igJNyXaytXN8Bn4ZOvCoFQBAlYLKVQJFQKWdGThw3SdxmzbzUnqcjgy5uGtbtMegZVbtN6xwDBWV13r2luCPKYhx2Znm0MMft+xQ4qfvt+lIbe2SfWQW9bTeD2qycp+J17kW56qk9hVMc1diPUBofCjOE58AXZC1Lbbc4U61b6DJDEqrMKVDhM7Ym9NQfUinApYbHIrdDbQk6VZzo86tpoZ+62aCTRtoFPDA+oJyk4FsG0njYT5IJ1evLwPDA7nB4QHcmz1mUS0yOjZauY2Lv3I/5CRJp2Y7jKPMDwtBZd65/W0/E8i5Gtgr4lhRigsIxd15D9RREpSOutgq9OCZLpyjoC30Wlubhsqn1/k7kaf2B/BwU/1YgZ4TvHxN4cbumH46Hg/NGyliH7YT3Be0wCAg8YPmzSyh1mu1iLw9Se3Ff3iFoRNqUqE3sVRlfAqXbdFBxvipptg0y7fnxf7SOqRbgzzuBod6o8G4NyvZvtrT1mlTgeioiTKqOqe5RnaZZOwufhspAPXM4O+wA410abiU+PjdVSHR+qo/5BJ9y7TAgoSz1vVUwqLGS48VHEQSt/mOLDLM2+BWo8pubk7tq7TqrEIzfa/Q617a2TgmqeRytFHmAyfHwO1XnITdCpze/jUYN0DP4TzgqT98B6Ei2dRYBINBEhDLjxwo4ceivTnbG7upRI822TYqGkKrZPhx4ze8pveCIr5SHZZCSnsFuOdxu9LDhWo4+JXszlyql8fH+t6x0mi72NThKR7jtQBr2RVS/32CABK0B9CR5FpLzsdPy57UgVZgd/AJRv7DI/z5/XTbuI/Ujvb7AdKAggQZTPiNxpWpV1Ru8pYOp3fvSFQnabdmQ5MQvoLKnBEpHqhDz/oezEckbOaabvYaTmMI2wWqM7SMI3NCdtuRRESIdqxTSP2dTwmlMkp9m9JHSDodEW2S4g+WGsF7wF4xHhHLRtbseKCvNqBEqjkP8vXd92ZW8fX+voc9RD51856j2v6/kX3i6N381C6AneLNkqb3kmdkDpgalAZnnMVq4WCQivrNPYP82zLx6kKmvDzllI+wQIknHOGzK7tXl3MTlCsLrVQ8MDuD94D0oHTvbhMTTE5Utt1JgW9msakFE9PdIr9U84Y8ky67BsqV4q5CgksvL1pEBQfxx3CgTfhlthTWAafGfAwPZUhfTjH034SpGAo5BKKybJ+mG2KqF1JGY2hucqoCUspvgovGSwQTGYEQdqLQRHGo9QjzHGP9rNgClrEpEJtgm6dK0DB7KVssOin2nUWx2a1zNyO+MTew7EZl6kRhjipl+bmjGIEu5OxxJU+ksYLo2WtjPZAUlicwqUcJmgOEfcjDoMiArgA6kHkghEeiHcFWfQN/wuXFVsuYzBlPAiBlymn+ZuB1+kF2IyFYPFeFFUDyebzM8tJ+QMeCHGqAuOYrsc4pUmWNGDUF93SZurYBN4hx+FxgmPEY+ieIFSx67xxtcYs1s4IH39oxUf7S4rnDCiFs2l3mnvBCCSeEMvBLLda9qclKyp6yBNU2BJXNeApoRkSsTsZDywDZfJ+lt6zPipw8vJOWPb78MPYG5DRYHqjBj7DUYpoSu3T/EclA/D9exKjPa2q72HOiiZdOoDjo0nPjExtxifOdvxAMYAwIlb73LWCqi16j14X3fSvLrBog81vj2cRUqwHyBRyVZ0mAh0CcK578T+rPT1COaJxeHqrTnkshAY5k+scj6Q8oyrrr/6PGbZJh//eszTSdCMsad/GjNTwXB6e+4Fm2hJOFfn5aOwVsgaYFlN4utgwA9EG8DqlWCt9wP7YL08chhAbnSrIxDz6O3zoqELbnViJesPhhzbaYdqAv0s0CUcHaNkY55Aybt76TKaoVohVIn1T8PPN8Tj0LMzoJe5EY+Mte3kE+MJQEMJE7v+fwwjMl7gXWtpYf0/rTsu+AqdYWo7iZ4GXAQveISEFssU1D2Bvs4Oy+pCi6YT9NCBDlrL04UqIeal86Agw55hSPDnHZU8ezRU4bG3eeYOj5Oyued+1BumCIVR8nepPoIqsuOQFxwQRXfM1C6VQx5gf7oqCHPZxFwxXFxa/6PQBD8m2MyQaCSU5hy/cnCCr5/f+gcY5bxd7e7imhKn93rzm+GVLVi7QwZMin0Gz9OCMsa/PyOWrFxgwx51KOxKn5xa7BvOtHPJbjZ0twW/HHetmBOQJLyCsMVivs4ubQ6EsxF/JOSuWr2xvn6gka1L/82Jybt3pPAJ9qfgMoxZm3t4sC1JPWOtVvQjd2xZFWjPRtcJeg6EQdJuw9l/xOePbopaRVlwa0yoNE4QOYRSlek7iRKVQW7KhLpI3jq1VjCAs98OT8CM2zPaO1Hud/9G+4SUB4K08ac1Wt/Fr5ksxt6miX4eB951dnU79Hj9QjSlvnnBiFaKh1UO5ywH0B1ItobNEqqLC/6WQExjL9RG08pgLiyfbMtVZdlgpvZUwapqK+0Y2llgUi++0MIWGrQRvz9/98GCOezoR+GPcFAtSIDZ9Lgn/zFo3bVqhocI/H/FOlguCPHC0hVhHrNdyGf5X3Ug2vkdO3h8on0jrIXxa/PqBMOq/MlbYtDlu8hic+8c4Z89QHuVRapBdZ/Mb+mNTlKXWzOGV8GDnBtWDwnvbHAj7ryvUxfW6kmPdkb7ukKp6bYURW1rH43647lglGW3wUVic4dvHdeabm7cqfUWOLNBdYaH+hzd5GpFNBHBRZGILaY5+eaD0z1m7r2XJc6/Mhc6OJwy5Tm48XtuIkOBOL6/fpu2YESImmxqaaUaQk4PqN61ZE4o74DLYDOfxtM2U8Q+DtXPZ5Ocbb4aE5ZhxwT7OFwE4xa8k6RcOXhJH48gUTm4LcDu3V7dePkTjqpRY9DJ+fRalmbIbA/wj4gFUBOorNzbZfxzgUGkXD6cJxA4WY8EWMf3bVWeAvhlT9UjvRPtuZkdi9xE/qfUPktlUtQr29vhygs8DfKw08tY9BUMtrQzDjilyhBEmLbEIcJDXu7z8cWxvouEzPRD+0rMY3affEEKbgTuzTAx7kVgpWdm4TsopbwM1PnEukjzq+YhOZZTGXckIy47PJolgxX69693FAZ16+en5VhqxuOaNadsTv4K2ll9cUTmyKyfvb0v6oH+P/XRjRlHmlwzAp1Q1XoShYLBbzVVQC7dL+/Bqw4DdZ+iMZ9gcZex6GtY1S3Sog/G6mLH0UClAHPC2dTGzfnLh5U6eNAEWqwRP8FWCNX9MG0JwGY1McFAqp6poF/Hsto47YOTQR+R2dQgxCEfz79no1K6Zs5iC0+Phe1WjPSLI/ySn0frBIF5CTxgwSLpvgRakL/3jPVQPyQrtPWCyxkL3TqjFvYxRJEePn43bgmgLgLaUDrhyOXsj/PfwNeOv7Z+AhSxIjIjTbTpItQzWyacnmMJGvbEU3AUArxmUc8PPdRDFzbeZKICA6+dhVgyRPjuz3tFQoE3QhdLkwxxu0Itj2WYkGRlmCDiutGXl27Ayw759gKHXsegLdErtVqk+K1uK8e9ddGSKaKt1OD6PgvjE4Cq2xe/8uRTTHcD1wXORBj4XF6oine1DRzIUsoOkVSpVyjykI/4YgxJY35jMwZRrtylU4lKh+H175j2XDaU2JYCRRfFpKsW3lP3ObWt68wxvgqzFl6gDIjmpGrxUJzt8NNXWF2uu5nx9ac8BddNdHnNbqjO5kWL6p6NvJ/8TotZdE8zkpaTx0Li1nVaCBuCBcQdZ84oSbU7KmlwpYbw6ADjcs1Ez1gh7iEsN3XJn2DvhTOnf6LMCweyOqkLCGwsrBUM1R1VG5pyF1pa/f56A0eOZera777jWy0+1L4LvhwKGqDT4yBcbcSn95XJSHbaLPa+HSRJB23tz6o2+lNjxQI2le2spjeyeM6xUvf9lTeKlNt6MNI5pY/rqGKSxEHzGd9GcqbsYtKd6+aMtA/Wd6rKGLkoTANAKUumR4Gln2N2Mkb6lzNhuoHsUfwFDxCu1pZTKyc9qtmshdHDcH/v2vb+gk9Ql9PDJ66k/rduekYrWtnGrfWmii05OAuolJ2r6PZs7+p2SiXW5wxw0KerZaMvHdBdYsq4R6kjWWRiJ/QmO4YDKmJfAyyJBL2n7Qx5CQoUWqzxJu81l8tWIQO/kSb0xGZ5RutLS3YlA6Zg+z5lcxSvY0HOhS9LsMfy2eU0rekqMM3Ik5bCl0nY3nkuPusHIJqwN6zWVKdyMvsjq1QMj2XDzNbmQcxgi7EzIuRrX25w31qYTC2o6QPNlZNtj4MMBLhhxExWm3Xi7OfKCGg6g2DRLAJ/rOCGM/EyID8aD1NQ166Yvk91GEJoy9h9wP2Y/Qw7VvD1hqg5kRGVGeu5ktGU9fr5LsKzpLWlXZiuh60sPDTmoS38Mjq+jnun4IvPOkNCiO7HahtIbWN55gsWZroq0yO1z1gYw46TJNzzioskW8/mIV97LNaJNfpQ2Pyf1pba4A6Nj7eJBgB8vV6Uw9uEF8VRocWRPkHq658vrdXRCXM33r+0x5o9RZzBrUdWZ5Qby524ArgVMAadu5uElshE1AW6rzNpXV3z5R1e1ttaGHdqRBaJ79kWn/HyvbkiyOleI9u1OjhwI0DSs6csjM3/MIdiam/AXjtSPzT5jQ7YrouCOGE7MwKYX27l5RJfMwsYHgmQOTpP32fFmB8Flmwu4Ei5Nh3Ql1nnT5Q/04MAKKF85aQY38JUDZx1yI2D3aeituZsi05sFafl9YfVDTvx7E2gfSuVzNHNVDXvOWcQ3aBNU5r69Zd5cjbiqRGjvCbNRg/mxil2gDFoBgtX9ckOuWoHJranLVLh4vbc5/xUqfWe42q6KbPbXh4LTc0s0gD9iYpAC3XPcEEyOt29aKcSPTOREj+ROKSAWPM59HfEPtrx8gAzFXBJtHUAS9+VgovekDiJ9EyBho9Ya69W9py6s297wjIVvmBTfmZXYJLMrFg4s8ynKRjDkrCDdXSSxTOmurY36JNRcreBz1aCdJz53FbfgETA0/4uSrok5MDCanCwobToEtneNB2lWzWLoUuzU8v4OIvuHYtvUiqM/T63yMTtQcj7I+8Id9QISrbkYG+Bv0VlySh5JMUXUnWxJtE3l1O2hZ5XbHzhnHDsB+J5LIYoVN1uCaIp74Y/QCgApsdLBn+nZWYi+1x6ZR8Bi2FKqbSfVUyyo9DoQppAHnwz0SLAeUHbZF9MzwfXhIVYBs3a8VMaML+sD8ajGV4SCHDbg5tr8laIS8iQ/VlsoIoLuhw8pjSxLxiHYjAtpM04895NgKvTjt0pKyRfwrOYzztwE4BxJJDW2vvzQVgUnaLDzPXTRslaXlYVf0+s3IWTM1nnHegEIG/0c2lDrP2+5kfMRcaw+TTYSBU93ZEy5+EaTVruRtcC2MmRnkRbGaNIEDLzvbjjH044CihytX6/DoOlFoL1D+wGmnJxq/HiN0bi8A0Xu+1gHB7J/NWzh7DqgtEnuMYp+ekNKHdWAtYdCo1RBk5E9zq2xEXyFW9RK4OvNQXikAzjO0eYg4UgTLfS2FokOdLfWbGQ/A2JxVQL8ohan5Am7p/BwuEce6b3jYO+VeuvORiRJbcd7H3E9F1gWngQDZZLe7+TmB1kB84nYGiZ8b6aGMz+5kBPJEvkFgTEQmmDIiqSb3FrLG3NuMktyb6JVKhEkKFpvjtC3jMhl3U1M/mtu5VNtvz4P/Df0luQWzti3WgSRJY1kNzWXKXe3rxEzyjhOU2UO5UCIXUvjPkUdxFgAaqi/TrjOjnFEI/Gj6RLBHo32rV5Ey2E3lBZx/1Pk6rdE8kY7WoSDkcb4/ihDweFLq3WpMUxbGiEabUpExs/Pv9Ko6mb+3tCdoOIGTjf26YBtBZFV+Zh7u9qVid4/XHkBL8Y+eOb+Jlwhi1vjNz7fVGu6A7E2zrd+gu7Nk2uQaZQUpx9Ldxk2zF9xxA2Rac53yp1dvCDLZf/iBMlulGBLmvWK3uHJEbKXRED6oLI+f4/DGeUorFFvKPnYV+7QVNLyv9yaiV00rlb2jVAhL2UU1R4y43Cma3m71ZSBDNPFFZyccX0IK7ojDP1uABTD2uNgh4l5n6Ff5UyG8RPtl5ZYY3BJN39WiASfsfWqI4mGsMVv52wQmuBgWVhrNeKdiw/CuOz42Gk6J0V7SMqfyYdg3DUnUG07ZsbowmLWlc8N+ItHTRKRco1IP5y1i9llnV/8dlwkUE47Tu+J/ZdWCa/p7d+OhMtwn2distBy3C70VJhZ/qNlZOJ/r5NvytPMuwNr1Ql8cpOCvoXM+dCa9CPHig/MAzTvhP2/xYwYjU1smJQAun141AU2Oc3BhcY5OSLCXfTqYI0hi5fk2UahkA1hXk9rWzqJDy0ObcH7+sYc6651eis3CHB9Fa3Luw9LYtlxqFeuQxILamuFDH6/9XyEdpy6hSh6km8BknwNncBxuetDH4IyWwAKxPuvSX0y4mlsZaP74BSA539SDqF5sLYHqma7aKe2H7Shv0DnJjiixMwMDG1KwYatllxpaNec7pKy7QrOnAKarJQB75CCnWOhPEYkGytFCTkV/7SpQgtHNLR6agIYAaLNRjNdRo6pYc97DIU+vpHoAumCRCLK4MfhiXf8emp4e7hw+kZU4/x9e4mBJZ9DXLY+gH0u9JG5SkVu4sWe9u49rXUonHoIfh22+4Opq9IQYu8aj8RHb5m43izv+d7hyp982Yf41wtvMu9S/xoU6I4lYNZeDQkr7ktR/Xqd4+K/80XJ30dh/Kh9q2Lf6jQdCShNNOw2M2G+Nj+nfcpbUFN+UbIo3b0iyG8oyHrakDieAsvU867+OSmo5mm8sicBWifrzLYBKdDbIHKmykzN01pRENrRihGYAXtmIl5ceRHo/z9fF2vXvj5/55Nbe0LI1qsX64RplrMEDG8c/qsyXRoCEKCs99SN++5yjLu2fqBqdmfAxTQ1lPlRlK3OuWjThM/2wScYPYbPBaVDZfbt8CV9OhT5cxC3n+6NBWMI4Nagssweo3LUwaBUVlMRKHJtZUckn1DrLwaxgvP3SUW8s9uWihi33Uh7tCEp9MdpgD1dGAFblCoWIXtJECTwze6q87VvtDhfP5bDw6FfecraZNOpag05ycwcnH+NL4mCHxm4oxd3gcjIM6Ee3aKQfL37wi7X/izpDbv7cUv2aSqUybYA8kT4zo6zQElgJjwxzKZGPpqSB4J5dkd87Ze8nZvsWFjuaSXC+VRJmgjdnP4ezt2diKB6VzUEyhjUaAmcYsllGxdwMsn34s7nlTb7+0tXncA1aAw6VfYDGtibUQcod5o9GgZoXkpVeUEZaHa3dYldqfoYIYY+69w4+WUzAHn4MD4q8ToBsK0antdhbCgrsAazN5ITbw4zfwEu2YjEZtOxRVH/SHpE+LWsja5vGRq4Q1WIDYAw8xzvY++JzXTFpSk/QZhoctt1kiLqK0L8W33yh0WIhSKET/WzezQIYhl+4DTf+1owzvO8GIVjEJ9hvXNCh7GlFIlObl0F35G5AnVgd1HEOVIEXwU0ojJO5pQ2fmPY5IHZW0YEpnEvQnS9u2HelasgN3FN0bPMoNYO4pNdSQUj1eTjgQjQ5RqqcD5+Nlzj7VhXKdPWx4rh14D1TGUmLbXjLynTchM72h1diyJT6USisMYz+Z6xLMYG1li12YOW95AcmQRPLDbHgxwDUQJ2kdVKYJqZjuRLEaE/Y15nNSaSadiadmvFgVgDruvRceML7IKxj52K72bo/HCB/EzPpazeGj5XJnRm6dp4W+iSdzdXOvSKGPbHzhyQNvU9xq+UmcmfyEr2rvf1slC5ulWiDUQ9TwsDlYxdP503boyKnl/q4QdTHkMqA6Y7TZd/UvBaqqaMAlMsoQpN0CaBoK94yviJd9YINooMnJzuoqGrRVBE6lG6ghHAMukTwg/l/dCLShYMVmy2+E41OdjR9f+qF4uGg/7IGdBw2nugcOWAJ4qPTVkOVFjkHJE9HXqWyN0KSTJd++0JeZrdN+UvqvVj/zuWThwGoBwsMee+l2DiZWeln2G1LJU1+WTavgxisQnW4ObaEVbCHcojNsBAH0rHBBd7lB1DudViqrYjQ3NT/qFoy6Zv4dk0OVqCyA2vtEIWKdExp58A+9DSu6bT+WUQiRj85sIW7l1EVJqAQmbObzU/LEsKPtYpcpenmQpyCFR8m8Bqgh7HJ42V5yaRTZuwXkUZT3wRCvyVn5oWUb2lrdSvXhVpXoF7KoFTt1MesyFdzFUFxVcND8gK0XLTTFdxEc9rYY28WNgWjcAAW0L1fA7411t44eKZUbKxXRqUX16pGqOk3ScKBJkigDeS3oIhoGvdKRQ8EARbEwFo/yys+08sHJi2NwnkBmT+gnW3YFMDePUFEPKzsvw8uYRNMACzAFGE8K03dHICCMMUQLour9EUuXCiPrme8wTCDHO/h9sXwLaCSJDzdSscoNScaaBM0GA7pOBw+okZcGd8VeaMwKmNUZZpHL0cfZxSJoGllqWMBqM9rKUDpRbTgYcEOsK+UPsCRiubFdF5ZYw7M5Qjzt1lJ0NyylV4tSNi6Kh/josCGgzN3AporBrC6DXPGVkBRDdo9D+fHehiumk7+oluptN/DUPHYPR3/FAeejl65oRkqfiPEItfIRsBKQV0c9GSwAshvQsgk5pcNlgKwdl218B1mmYOe8JGTZpXWtVf9q8ljMoFwH91zQuYQVEfcvSe1IL3cJro89hyIo5s++VLe+Fq6rCo8g6AG9YXxJdzIKYK+VmnDL2U32x8A9TpuHEYxKSfU0+cjykEKCeLNMem933if0M4AEQaeEqzylVjJzouvgk0gxQ59BPgq75HpUkWi4M0WF7l62QckAIBprGgod4v/75aelsh1QpCPBHXrKGBNAyDEShA1qG++tifipeeXsQwaGp+WJZSbksb/opOkF7Gzx+1WrIPISameFFXlHosqTgJ0maHhTbFTH693+56xnE3Hl4x3aAOBcusYZ00GroQX94dg+VzmHzq/BDYfcnKQpXbs1B7mvRONKFLsNYey0htYriEOGrS14k0zAyWbQw6IgMEacDITGNjOvGPquCHoI27CVtcQI32PF+QyYGTv1WC+LUJk5gckOEnK+faeiRirIalTCdFRttT2AP1lHs2oNwol5muCDMbPlW80or62Mms7S8qCG8hXTO59A+tiay38BW307OKePXqCWPUMbxw2F8ZzSio3ujYU/LYkMjg7IZpARc27fxgfp5DZ2Zxmep5fTi8mzoLkXilQS96BCk1ahs4YhtwnzElpLoiZ3Pzn9VhqRstitCV6piNI6LyyFY1zzm6xSc6V+WVaJan9RFPaW5Z0RN7rrZ9oDfQdiPgGlJLRx2Iax1KZ3l5VACFTxEqu+mkMrKrWPBzRk38nthL3DDdCbl3etogCkn6+S8/cfYjjjHdZ97BxU52jy8c00/t8Q1y2ARc9/D1x7MAjMe/saksROoPP+aYIzWCy3W3YI5Y0YX9jChnRDp8gUEbNMNC7t2wLCDX5xWjPYlbaj8BYpF9NRlmK1qLtzBn6HNcA+8a9upfbUPF4O6t41rQZeUOvIx+FZIJd9iCw1Z2KBCsm4nVzaHArTXXxWshOPgj/QRsC9uxvN4LgrVxpTrQ7cS9LbGT+x4/gDKAPpV/gBsoqXpCcYDCO8/HAM3H0FB4kkYbDEeiEGH96mOaXqeIflk1bxx2ywngJLlXzp5kokUa85yqA6c7vK9FkaQA+S9ZCyPQwhKfQztQPjULUz4mmiFIHqYAkemx2VNLvjvsx724YppJVve9hnhWPt/Ez2VbN45B3QDoNYIHbv993IfJAYFjHhlxCDIKwPXshJdGhVZgCP04WNhp9Zwo+gFWUDsSq06Q2WH6W9W4G+/UbatVPfT9+NKYa9Ycc0H+xLSkds4XgaYgEFZI7uo+81HiXd+usA+U7NEZLH1WJ1Q/iXWnel1B/iunHnDowNJlkp2woD790Eor1TxsRiZlKdTYb2QgiPk6i11ZTizSUevW1cCPRvtHau0jfjQBo3ANWfUXGZzIKCAsgTfbmxCYPEM1q5dufx+E90doyMCXQAIpJ4niG4ZzAU8kJXyUqCUeIhrcVn7RZYLLIaYodiOM79QdppBcSo/PTqMVDbway+0hJgSFhYQQzsva0ZovsCii7jD6H/tp+/4WK4WRziWviNaePsni6lb0TWoYbAiL97ITgSiFl782LBQEDr3bi7oZnNq4gC/fWOqi/bTl2DNqqU2pYrrCxIYG1W3kVBHnyZNIc4E2ds/XB4QROwh70S6UJ9Z3GNQyZU97Guppt3xZaZaSh2+tcZ2WxT6bangvWglDSGLsUu3q5u8lbV1Up9iW8mvsFJ9WnCVQ7EUcHWFq5qlua2ZpaVB6sXzQbqQk/CQ7U/HgMBvFyWOzgMqby1rTn4s0Bdshdaz90O1AbbyuMR/IWXu3ZeL3AtWD9Wk9YRU5G/0zR4x2E0ayXOZ1g0cWBA5i78uguaEhcwOfBzpqvGVY+IGFaaeX8bd8Zhs6CWuSqY7BoErQIjl9RoFW2LG65SwJBoUySffMl9C5Xp9aX0Rr8NX1U0pBfDhJE9KeihbGNhPjKFfQWcIyy5wmc4FrDP2Aihng1MGAU4DFk9DhDK0er81Ry7kAEgzg1oH6jFJtoQowhzyAW/HoHOXDqZHOc8eR2zh8YMEm9xxs2ASmFrG0bcS+LfSjKogZe6xnymaiutRDCBBEWa0WQmEUCSZZixURk47CXDyzijEntbr+1OV04E089i7xqXczq1p4ohJ4jwTYs2kfw7jar1Cj7HkU7sWu1v7oA8saj2d7UlX6gn2ycPf/h0DmQP3vmPsaN0n/wzLpNYr9q8GT11O02KmczcKUvQDxys7TOvNKnGYbcLZH8Ggcy+ZCjqwdmWEYxPRALghEYPOvfdvBCkYrYs30dNuKVhShlrl+J347OYLxFWEyu0YYaRKk6XlRwuow5m4FEwdhmrlTXLmzmYDWK0MKXMPzLZvdq/u11wavRJZD9AIdml3LBEvmoSnnxGNMO2tSU2vsA+8spvTgSp6UERnegIQL939oY+EWuia6dikN+AMjjQpeq/kJeAraSzfqIjTa63hGL7Zdm5FhEraisgG3ArETogK44idC6xsSoAZ5WHR8ayEyQGKBzDo3HMf4gzJ0i4wJv2TBVjEkGXh+wvK3KNHuA6qxolq61k0JtxNVpjqOjg450+FQo1+PCWkF3UajPQfvfNjRSFl7odzD7ZinDKnwKq8lbWonmL+sdqhcn7isLbO7TvoLNfLpAqD6HDKfrtCzva6SKB7dt5OA3l7oI9g2DW3YCRwK42/G/6Ev4IRs3jXh6dP7BRUlAuqH+/eB5weGByMLFL9namaRsMSUe9lDkh5ZyN7EYGmX+DkfySstxVx5BXir8/R+zu03Pq23DRt894d1q2Bc8y+NuFSRfig1gLoTO3uH0M5s54Yliy71r+sezyjhTTWcW1br2YkmurzVBatYr7R3NxM1Ln8RhHT7iSC7Ny83TrKZiaO14eO7zBUx4k95tkF+/S/5VhlF7bNfmtYWdtyI01NDztsvKnHKv4xUPRVFRH5wbZ7JlBhMr1lKTdZNGv6bYqihk8ba9dXVe/et8a9pmGmumqytumthtV226ysxmSRy3UQX/OG6Nud+XqCKJpM++WCQJDK6fDl7zFQdwT68IfduRpR/L/nZfgS8mfdRZ6t62pXponBSbV42PhxYvYbWYRcbxGJTNpTGme/2HLYQugKx9xyltdBupTXVbubeYuGOYOf8XwOTsDQ2V28tP/r8+p+O9OIbGwqbwJBf4lQD9MKwQU/havqlHgr4JPtI73U3KxgUo/BAMoZxf34wU71fLxZPW5fGB54PIAs5ZD1zhdpTdw3X8Ola8gH7WdPNlxbe7Qhfwf45jEIo87VI2l5mMq2MksKR5tfI5AL6ZGdzA+7asqAy8sHshnZ7R9oc/lSBf5tyvDuursM7KvHz0fD7Yhw5CI/lW5hlhaONT9uSKqhWzZjS1QqRvGAuqJ8syog9qns78wLTbd8TKB8zzJ6ncjC8hIxOtNKu+RMofCaAt4LQX3VX642d9mqHfl6XsvmA854cH73GWWO/jwIzwaNhaL2kHHdqum1m7G45ynGVAoOPr6NIVq7KAtRgvpH9RXr+XaDF7EcsUj1Kd3ZDA7ccEkhsTtaUT/saNPPZlPDi43NHyCx2r0+9J1CJXASvWC8TW/Rg5Xo1fagpaSwG/sBCf8LsfaVh79d45/t67Rs92GKtylvI/t9bfjeK2AoLRxlbHk83wO/ldCZqg1WVgA+fEgJVqpfDYXMsjwkfEmuevBCxkStscq6ZnofInto8gUn5QV+67ufoZRPfx3eLPGLCVM/7Qqq9iELRkZWp8hhz3F91VCA+v0nY9rTqiqBZL71J5OUb8QIETCfMUEEkj/0Fw/qjShMn5c6dxWHq9RsB9RdqT7yrcfY5E6J+pacn4C3euj/3tEXFws501F/5dUpVxmC1thkRfR2Bu+25e+t1QeVg/sCPwEsSQiEHOq9fHB0uDO4h2HuYhekTNWGMZ6uvTxtnUJmVLLP4EsSgUVi6NiSwaF4uG0q2aMZZKjjQLtd8WcuTdWKKmBuaUyNEdC8R/6rx4b1osRyr11iZrxx396r5EHprjPVWROCoBcD8c1TMZ+wtNeZDXhtlW5+D5/mSS6ZigvL6mwfepCEmWxsukHZnWdtBNmtiRmZzUQ/llRRVHDRT8XUxTW2bs0wDGH6zCJ4FPKdEbcIqNH7Ulnbbema857TVPYbjnHyVNSfUOHToOeal+AUnCPaGdEj1tY1bNHE/xCScDUxtV7eZnTU5n5A18jCHSmfStHeQ1Onu/LvMAUucM8nD933nv+H5yF91gUgm6WWLNTt/qqHlSQ8RxuBY+t1FNgTHkbOwwu3YyMBpl3RCQtze8B+PxSDU+FkbNRe4GyefGraAnOD2BSAuyrziCVgR5DqomJ4S1DawCxBwvU4FRJb325bAsQ+xc+vju1kqywqRPcGV8AyPwlPnqnk9vOta4CxQe773IZMe857f33uxzuznZ+3bAD2irW/Hj+4Buw4zp4ebCfQIn5sFfAfAt6stf8dP6x8WCH1QPC57EPaBoPo47JAcv73A6uAcHRJ4d1HlQ+BNUefYd8u69Mx68Xf3ttzfX89kBRKK44LlY6s0Xn9T5ssN0zq2AxfkHg8N/dN9RqQ/SlrOt6jdBgUhwQCr5uc7D6h4zRIvsWJ4TlR1TkgeruuyTa+EKO0uMYQDlwwfXR8WcdjNH/ZG5tTVH8JpCvKCbapvbGKi8XGeOhr0xcfXdFtM1geOkQ8OTm3V/UzkP+p4No2NMQpHC02JUO/UN9/4WNM0PiYSc3M6an+BdAGNaV9U0OCwhGwelV3+3XaZ29/i41+UZ1wIVJVBDSFKqt9S2OiwiIoCusNr6H9+Mmv2ITR+rDpTdAFqga6/TuD9h1NSfJLRbZcpJb2z7fXsZ0mQF1b4WEMEhjb1XTadzenyB8tsg9HMfRVV1dju022x2H3DkjGUIG5efegY28LX+7IKsd4jMmoulE97jFFHlgisxsGYYTA1q5ultjckiZ/tMg5FZcxkGsQuH7zg2X3wCiMFjiu7t1JbGvLkD0KVm7cEIJn0mvIuCHzSsX5RM8BmIJxAffo+kNEYVum7JFC96ZQBlOC4uNG0+hhQT46GHhb991J6mnPkl0EKzdtCwtj6WkQfhKWeo8KKtCxoG1W42nSYEeOzHKhd2d4AssnsuCnSUrcd4ugCZ0Ggm/VnyaNdObKLK30L4TnshNaP36Dj+Sj779N0IsuAhS6cbmhodb4ZP2LJstCTbIaDTmbVJf5CxmMwjK/GjQMunnnh6edgb5JK2bv77TkeMR2HO5umztE3OpcP1czOjYezywcS6CVbv9jBvBWwcmJpm42r00AKZ1Pi88p6RqZIJzlmsZ28cVG7pT7lYa/R4/xmgqxHcH+gooZReMsyLsAY1258/PPnCA1kArHCuUW7tq8G9BGC7bZ6hpJpriKmpEPw6XphGGePEa/K+iuIf0jFvM3GupU9MDRv8FO4RBWyIyDbu7Es+Ijk30GUU+/1LKYtjS7kDtf6RUu4kT0N2csFlowNEwKhkavpoPr8/9pu29Ty9+zAbS3Yuz4/hzH5ern8P08Hst2J9MxINXpUhNck2mCq0vpZMKA/urJHw3wl4n4/3C4a/iNV+vNSJuQjCSJApuD3zZZbMnt3WETkq5IcARpk1HS0y+27OPPHS00vzuOHjV3iwUx0XL2giqFwaZQMDQyhgHot/MXB/IXvQkBcLBSAAvomwAPXUEzri2UrLhhpSdHWtUbSGchAGK6tysCWyosKEJlwKmCZwJZXCYDQxZWBKamWdcUdnadyiDTZhxI6N7axRoONF1FLdD1G3qB4dcRgal/aqrJ7TRYbUGmE/U7qPVmPd1p1znZMdk52bc9qUXQUVPGaMYwlnGMZwITyXSS0ZR3o667lXL2sEj8V93c1B/FD8f0a5WGW/wqonlrp7ylqOpO8JANzfs6l6S2hgf1Wp2Z+GuB9ycmKAVKBIpQ2SAsjuwkQU9ZS5zqfK80tWqmbp3M9JSOO/1tROx+8GztCN6XR5g6c8Tz1759isu7VgO+p1t+hf51P3IopD4PN4OBSR67h1kWBSyk5F99na4N13XtsXmt2sDsa0dzSEvHLc9MaN165yMDcv0NTFADrx/nTOu+BRT+3AtHdq9bCgcgkMV/DQHYEbj6L4AlNJ+GRGfnL+Fopr/sJ3/servqwLr82ZoY9ZKbJPAC8mqT+zjXXu5bS0Wf1DPZqon/Op9zHzkp3/PyoNqX3HP9LcJgSEpOhbw0b5KVjcba9f564i3A2ItYF/YZXHbirz+h2VC1g64WmJER5puHhmy9omd5BwZ+E9ZWeI+/Rw/QiW7BWLENPILFM28Tj2IP+HG/w0bAN/ojfJ4Fh75B/+mCX+PyTHp9f8fpWbQ705F8ki6nOq+jmTH8UsP5Q7eZVwXgz2yDwcI5vh+9SBqEdpVWh+A5emDSPzeXQpOgsOlbL+230nWzp2PXaHl8ie9wuHIdgc+6/NlzZK4/4r2fW1zWfH71lhpAnzSFxW/qXyfJj4Cd7Ly+mxTYzb7DmOeHjOO4YzBB5P0mmnA37/x/ck+X5Hc8ig4B4Kt/udUAwLefeDWLX/5nrSYwTxSAPwdn/8uS67elkf7W6fPDT5f9qj5TPvv2ulyB5Nw/VUCNnneuCW8y9EE0RyBqt56c5B+8Umu3V2q+c7igBpjmvMdEVnaONH1GQfzqyJwb/ZjuFWX5PSwI2Joq+Aa/zG7cyUMINP3DFLr4sxvD8fEGU+B38EIbvpcrM13iLFxtmti10qcC6mGGmHhhK6oecC8h1PzuwS5EmKWsYiNjyVskVKbXSF6LrrbhsncvXzKR7G8izaYQXGwrOKDNU1C7T6rU3pP0E8W4HE7csT3SYmdzVGvpLB0c2ZJbLguRASq7DCiMzQPXwWgTwh7SvOJFuBLrXaUxT7DtglQm9kWwsSlkadPUf7h0BM6xQ72PCZifvUWx9wzi02ZwQA0PqHBX4ACUgYYRBvz/xTr1Xu63bL8s6GawMPjAfg8cQAHqY9guKvcTRYG6f5bEyrMDYh1CzHgz/Pq8SkCdwko+kbKsPPZGieMRV6cqPaEm/JRTdlq4bf3k1VCXE9ud9vS8X+h5GIoROc7q+DfW2S0neHoH0asfunV1PsU9PKEHZHFXwGp9SeqOPdnC7m6+e9E5d91sh2GQBdfgaGaFQBiNEQIVS3U8YHUMwi8leEM/9PC+P3ZaQWC0MoK7y0iyKLi6+K76Ayc7Bo7rtqqLlghYGAUMpdSf3ngCTZFbbKNPelZxEy+RTBlDyzUvmpgeWnQRuVEaflabAi6sLFkr99W1ZPCbGCxlC06JWkseb9dlUhDYjnZEv4rDJayUFt8htYZYr5Kux3q+4FOuR+7VsQ7PRk7qJBkUIY7WB/+H/Q0xgX+G8P/J0msiHOcHvWo0cjfK6ZQzfzzwoLpm4i9m1i8V0q1hh4u1KZLtRuVZVvBetfTez8IcNCr66og1gvt8L9zqvVRuDVPFOw6qxJd7IsLaOMUpK7iXhpyvifYhWh9V/SM8zTJXAdSIEOQJHcsqZIqDGShI+3ap5SzyQxRMghhsaP0XlDLr1qI5Y40f/uZGAyFiS7Y0bkNv8K0ymAP84xcFDesU7dmVZvrVZvg3msCxw/PvE1731V4r0lDNOYsrjtlpIjy37UchCdkbeLMwm32xUkykeMrdsp0aln/zCA9LeW0vqTzox25CkWtTYsc7OIMcTl7Q111gK7t4AUt2CzRM9qVVXGNnoB6PJbTDj3gwQGD5g8tI5X0d1Tm98H3c8h7n466l3jeGc3FDr71keSujbmBjPjYp7uxJERw0ypkv9WOPp9LauEWP1WxNWCqwf+TJHPECiscu94vdOGbxLmllpM9Zgk3j6a0Kj4JMuJsEhbbOs2eKn/gCeZv13fty3U/8aM+RZdq10r60SGl0AbNdaQlblH7+/RHY2tjj530oum4BRoUeddtVmTOk/Mfpq+wWfygPikEAfpXniFxUCAKEqhDAPQABAlhy2AqQpggAb6hsXUEgw3E47bKuoLjov4JBh/8KFiXCHHfveE5ungEeMFRu7DdIhP7+oIQBXfp1YBDt39Qli6bPgE50Nlpmdn369evSaxAVpE9WBw4aBgbO4A7E32TgpmUjhjjTSHYvJdwSJ3iugFRVU8dla6eiAwgsjDJGcF9KJdliuwEOdEtKIGOlYde0Un+sOMGaDZ26XvGw+DGJhw096D2T6nTYheFlGw8YpxWa3EGUz7O+qwQHwTqwgYygAEUZfQOuPONUlMpDpM1zBWqoo4G4+YsUS+VKtVZvNFvtTreHDvmB4WiMEfmGmxDF8UvdJrP5Yomnub3d7Q/Y6Juz/jTXu/tiqVyp1uqNZqvd6fb6AwS+dXLLn6Onf+Ptbn84ns7wgqb5AVlRkSNXA19xY+sDrucjSb7eKE6ut/vjibu+cjcjaiPrW6mabpiW7WCxf+kgFH56kWgsjhb5ldKZbC5fQKf80aq1eqPZane6vT56+w8ynkxn88VyteYoqKuMLnqkoYBuW7bjImr+IkEYxUma5UVZ1U2LtLkOeJ7Pnpd129Ew/9IQvxzX84Nfk79lU9Mzs3PzfxYW5UtYRQE3/mdNpQ3Tsh3Xk5NXUFRSjqaqT61rHEWE3TcwNDqSiGh6i+KbmesNSys8zO2tnb0DLuZvcnZxdedeUUlZRVVNXUMTt/Ob9/QNDI2MTUzNjjQix8raBhH87AH5+RAZ/OWI8q/XYLLYHC6Pj2v///qubu4enl7eaAwWhycQSWQKlUZnMFlsDpfHFwgJi4iKiUtISknLyMrJKygqKauoqqlraGpp6+jq6RsYGhmbmJqZW1haWeNEEplCpdEZTBabw+XxBUKRWCKVyRVKlVqj1ekNRpPZYrXZHU6X2+P1+f0y6TeZKdNmzJoz748Fi+Q6/CIhK6qmG6ZlO67n5/KFYqlcqdbqjWar3en2+oPhaDyZ3oRRfJvM5ovlar3Z7vaH4+l8ud7dF0vlSrVWbzRb7U631x8MR+PJdDZfLFfrzXa3PxxPZ3gRJVlRNd0wLdtxPT8Iozi53u6P5+uNxmBxeAKRRKZQaXQGk8XmcMMJAQHaaz72OxhBU8Rf5dEKhqqo64akBrabdZ0ddRT3/oZSgyRsEFd6XdF2OtBqrM+vb/8pftIsd9WtwZR5o2LlTSd819GIUbn/NwgE6TAgFriugzoMdDaulzGZ3BpMMfSqbNTE0zYzrSkztQZq0LiQvWU1KwcxKiGmPYASZOEWSBViLSEAuUBiQ9550k6T08wpEGqyAwf3zFIQfURU1Uk/bZvq1E6t8/1yrzcLWgXWVAGgSlXg3juaYFa5L6qmldJiHLRgacX8xGZrndXcQYo+GgIPpqKVRjv2tKAAcKn15K0mbV2VV7yUeHXYpBxsxswvsyl62gvWC6YFQ8m0YFowGdFqWT+rtn++/85f8x6aOeZjn6n+1Hzqe+PX42zbmc2jjE+zNHa43MyV+Yb+vP7MAoanm7cp4zhs73vZ/Huv5Ljw5nv4EPG4mJ//isDPi5yUnqnk1PPmwsfQZ4rLYXOMH87/jg8O5sMSHrd3885pwYju/dINPu7vd45gxm31+HRl5DRiNtvTi7OVv/g6MC3uH+9C6+fn/u7/TI7T24f7j6dt9OT/+7f5+2kvhXbzA44tA4iwUJLpjehbmFru/vtJbM3adOOs9oZlVm/HeJJpcRvgIsn0GDREVsywDXnCaa3evGrT6pi5IhPfGCqZJs/Sb4h9H0vJBZMy1bYW4qscLApWJaNgJZiXScPGUqzZLVMMUVeMgnXFSjCvQSJjMAECCDfx6kWrFlc5K+SSyM3cZYbiJgwGBeuKUTAK1hWLtVL9eL1apn4J/RejytkUafOvMYqvRKLjaI/o8PcpAzdCpwAZViHD0DtjPThAk44Tq3tpirpqO1gdc1GRKeyzNOWNqxYf+Nrakfuho/Sf7GlSIg3e5czeASi5r8k6Ej8g4lLzocN2W3HtdTQ0qctZmFs5s2xpAuiJl7jGJLbzaP2RBlZ7j0ihIIyrP6Z8Y7L9Q0o+ng+cBHVV00OD01FmvxuBSDQ17y9NwhzzPjMapx4lqPu7JN3VVbZH0q5m1L926vkfq+Qq3u1nVevjY49Sc7CnSVXRpDui/oudXFc9L6FHMXMl1eIyAJd0ZozsrdlhsV+ePaXaxmB249hBscAAtHlr7cyfJLUuY5P77coAk/A+dJ15GBfMV2Tn9bA5yczuA3whakcCNCbUjWxmu8039XaqZsxexbcNL3ozkBbOB6XGFxN/alOyzEcEo0/HIHO/sMi4RG9ERikxAWJF8+puOM0r6IlFTU9ZydncYMhMKCfa5wEqAjyGqXWeH2uxCV0lwAYkTu11Q5umI5IR+wSsRU5srjKD+QomTcKgYj222CCoWO1CQaPaHPVBKwDNnvsDUntMaA6psKCytzuIwU3YoIPmqEdozqiSUAQbHuosMX3V4a86qDp1xyOcsIsr1VoTHiXFlDFYJ0+p7isikt2bMqn41KsqncuRmSsykeZPNb+tqkXsVhcpY2bA55ePaWhS6S28Oa4dz3VKy4YbqyR/fhKLuK66ZwgaN8a8oDTn76SZqJJq05vWINnbEcWpZ/JrbqwYzq7NSSy9l2dJo8r0OY+RKwj5gASZXwWp9Z4MACwXc+IOcTNkU+o0C6ID4kIFOxnm9vgHx3X3q/V/QbgTX40DvZcOZHm1OeZmIASWnWAYbgEgS/+OFbx7QXfAYlaYX4fpSXt/0bnHKC4MoXjomaJcUhpOMAaKmraEoqImmq/f3n+ovRis+dIYgVUPkszInGXDTjXsNr/a/+lVTfPDpXljAzjjkO8FJt8Y6d4hHvPQHSHvE+H9LUj7IFfvvHxS5pardKid8uLRbB6io/XxkVgVQGNJC9+LkdHee5aAhVkDVsVN3hiyqIhNI1yVzIilKfbNG7yYKErC9i3zCTJUUHWaFZl+ZPnoxt8xn3/PR1zJg5+ia/oBvu1PaN/51+jWV8/05H8T2fYOs9B1IcINvLVWlfMTiIZpOPWCtILDCmDYdWWTyd7h9ZOptcr+8FhDE8zQRaUpN4W9wiECDy0NLmPa6DLmnfyOtbzMbSircoKaNqNU/8QZUzeLzEuD/zcstGdEyJ0Nmw6gfi8YpKikrKKqlvUyBQYpKimrqKplvajAIMVbAg==) format("woff2");unicode-range:U+0900-097F,U+1CD0-1CF6,U+1CF8-1CF9,U+200C-200D,U+20A8,U+20B9,U+25CC,U+A830-A839,U+A8E0-A8FB}@font-face{font-family:"Poppins";font-style:normal;font-weight:700;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAABUIAAwAAAAAMjAAABS3AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIIACsgouzYLgmQAATYCJAOFRAQgBYNEB4ohG4QpRUaGjQMAkX8bUVQIsuD/ywE3ZEgfXivhkliS0txbMokQAgSEksKi6ZIRil/WITyH3gPsiRG6Ql/HUBAFgNZ0+mEaN5hfPI54Ho5cQ7T1/S3ExO+5MRLP5fnn9/f8j7nWeURmeuk16YvJTj9BIcnqgDKj0t0/8NvsfWGwYRQgJtgoZQUSImgzUEAxprMCI28m9lJXbeRfFlyGLk4Xnco/2Mb+uyOExMY6SLCIRVM0pGjV++z6qgZJ1fTb6B/AzJmCaHv8yeik2XT7EMOK6MHB7v/s++AgMV0vB1RSMR/G6tiw0UxdrhgFGbTcbIWf0RAL3PgSVGHOYTpUHhT+loXnDGmZ230DVtas+eb6tJOdmU+UuysACrn/CzWyvsJUJpPM7mYnWUw+AWc/ZQ+zBQBNvIcloucJVHvP91Wo2np7wteffmbzwCndXkIshp1YyELO1d/LfaYsh/r2H2UkqIToeY0CLGTHDnLgwXFJsBAWMIYwHcXEhBlKOefcWh8gPoAs+mR3PfrUhXXGAlBXVzJwhDxeTuOThA7mq4g54B057BiJFHaD9auwNr9BOZOmqtYB3AKoTeNHYN3AIwrontUwECrGesq32D4bMrAELXjEljMvgaIiS2py05w1WZtvZTtS1nQ6vHH4RKPRxmmnaDpHyxmo/5kAshBxQBcgWFySkpGCrfhrUY5qdXjt8BGf/JfQ+GfcGZ7o3DhxYM8GBRkRdr7m7pq1zNXt5dHxW4dvrrqRBn57fQPMogrPzw0+73npL85ZuJb5b7DoDqbrqffzpTkZ1eIklco6/q7dwliB1aOilDxAOUHv7NB9x9ht6gCGRQ3I0uP8Q90Kjsilfcyy9CUcthD2ZJaGjqNTVx9ecNuL9W9dm1G0ExLYj5V6tiMJdWVGJA3xnsyzHBAJ/4F3G6r/iq2Lhv68aWQka4rEpUEj7ZP2cUgJbDzet9m9dDtrUz1As/oPXhmtQyAXYaxsVTbF6YO0WLanUuZipK9MehOXhyIEpJEp1P//Q/LnxASfaBRfoOKMkhefZHUaC39J0jTFwuwsq/8VtOQUFU9AK6vvsaAnagEGimOCaDur/ci/Jl4Dgmr2784WCrQwBzWWpAouIydIvmIsa8dM4MJekOTNcupm8A2AwZYp7mVYMDaTxhVOqkBAzw2TtMf4EgrYZYABHFKBJdPlPbvlHNVrZHKdzo8+Yy54tlGt6SJ89ZP6JD8vsNFJmjq8XPfYPB+QAmWRtULffwaiS4po7WAakEEmYYUGrg/RWYsW6fRZpYTAI5SzH9ZD6pKBMHjmUVTGYGGDhQIqwMG4jGYhG4TbujueoA0hSQvtWYR8F91fKKw++9xYtfShrXQK56hm2u6NcX8+wb/mecSRuncmzmj6JF8LaKTbCEIMo7DTutx9x4uMoYt83daLF+s4U+o00M8ch+ic+FSS9IycH7GSMu1svISH5npCWL4QDLND+u4P9Fj4npUOomOkns1sAQsrJOJO4wrgPSBJaslBre5Rql8nZJ1WqvrsPxRW/2+o/rZN6YXYQBFiWTHgL7ji4KbF4e//biTsk/fUHh7ssPs7jDoxDtFmDoJklY2PtWwYnztv22Qk8Na/+x+IYgIqBAn5aV9d7DQywNJPb4wM/NKy4xHIPjIFWEXEIPi5IxVT9nkVUpqb4FNpRWXnvAs5+KZS7lNQBGCgwxR0JLELm6nKenB9//OG6mzdVcJdqHZVStyiHAV3YLIWcq1/EJD0co4DZ3TZ81R5cP4CTm3ZnquKZSVJj36jbDw4XxBR7rjpzv+zqAFLl+jqDC5IaJAGtHBprjA5f1pesviSy1DZG1XIWdhU7QVpw97zIZagwooQngGMgdGtgA1uU48OK6/zS0gC4Zq2yWvIARnWQ8jlGFD+5dMrE/xppPjdl8lFjeg0bZyP2g5FfLWxMDm2lWRi2ZEeLCpZq+2CcbSaKtJFpR1lVTPfy3rLxZQ3hzp0MJTkWYeQy4oaCq0zbS05WNjItUqSadf3jTc25kZrAIli6ZREsIe4v61Yc67Ii9ZO41s3ulN01lBCZ9vQIpWI7T4ZvOMcIUtm6eUPVBSUlZBOFrUH0qP4gNXRvutHWFHZ2His34ZRMdSOKshl+7JykpOuzZCI7RhKd5k/PUqU6P6pdUJ/R+5nNTuLDTg4YVLatm/k8TM/cuxtc/q1vXLz3Jln81x00bcbrh7ta6F8saxNShwjH99EvXirvnt+Cw7OPv9eNe3vcSLfNUwY+wTEkyEeurM43ML6v850kk3PFQHnu3AFCcc/oWZHda157GzhPvD/nGlRpDBMEeepp8dzThHciuEqClJNk5el1dHdL7s6X/Lcickp0xSU11bXtBUsXWjUYlVgx7WrMq+C18twHssOf9P99k13VDGvpACg/Z4yuFud13Sw3b7iTGwcy1uaVZqW1kak3neR2DO9xoPapjzbPiBloAAOvzeiUu8syFfvGlWV4fV4hUdxYVZWcXGWbLMMHvqtvtdxbyumd59+Xy+Y/uYkcfFKzC5JzSooSeMr+aGXmqt3cdSlK0TJBYNq9UBBgXpwQF3QvKfBthge6vSoHh623+xYoUfh0DP2Bw6ietT+0GEU3HDDqZnD+fmZQzKSnc1ZGUNFS4aH0iduy9GkpeeUJSlySjMwVgHDNy30WBThDyOHJ0kojSMPkJa1FXGeedKfcYrgOa7BOyoLiTgWcNHV7RDVxtH1mYio8AiThS9dVVZZ3X7psUtPms+4UBdTnd6JSCJykkeYlM/lZlUFSyFA13vKH/U/1Qv3dMP8MBGXyxfxh9GhDGlblzAxUSuI1WYMgSBcf0w3pfm36t+pg7rjOXONc2fq5nLnYNN7r/9/iD68eKiful27XOHNCvbKl1rGfubFWwyf/6x9mdMJtqWCNo1YHJrMqZWibFTalcwJjdBIBFrlAE8S7esriRIIJDEyGi3wfLiStmaxvHBlKSn7mCacExgVEREYxQnXHCNlrdIUyJvFkjYVxOI92n1HGYLOYzNRqlLvCHmLOLJNpZK04RkkyppEkqakfUzmYRZjoBTi/L//zFnx3MbG6PTGLdWE7ImWI0z/pyJpl8orVAyHKz09W/Q6qDf54Z276F1441vdrJFMcoJ2eHvvCOKgbDRmvcozEB7hteKYNpUyVtsulsvbxbJTqYzTdmgP5rUuIlIkCo/09hFKIkQCpAXczPcLPMoRvBdjzvMtSodZfIW3UOk/wXzjTKMTKeQmndQhODzYyy8hjxVZWJ+/ULGTO+Ds8J5IcU+9Ee8QErHIOyAujxEBOSw2Grc+mRkgyAryL44GJ/h8CcD/NXsjS6cqVBee2cRCE1anrz6asTJ+JdSxSHcCT7TY3rb5vjWtJQ2urXy96mDPA8r9VZM94Fu8hUrdSqVtoVEnmsXPPnbY8nttXy18PvEyp/ZlFazc0ndDe2Pnt+7x2gehNSfzdPbdY7zIYQmceG9UlbKzID9l16hKg6fwV/MpeAWjuLiGPqBMWdfm1Zu7ZCA0N4rdmRceyKaHTRwjJi0rTuFmsMcXDy0eS+EEZ+KfWCGWBKkYfyYMJHAVDVHlEbwm+T5XE1GAL0fk2/b+pCRaIMjTE8Ley/ZlzvkKZaHB1LWz7jUtYOY9wb/m5lnk3+obwW8Q1+/MfO4rlIcE0u5HixmYpKTmXZ0Jv2pumkXas8AVY3CaQDVrIwa9iy6u26D4j/X+sS9EIpGJhX7hZvxl7bkrKXSV0aN5Us2w0uIPWCaRS0SoiMex/G74D6/n2LfNvtfv68W0H+bpYv6PNhVkZEZYPn8fctK/uYGPlJS8NYUFsYrylfJFFORFYNFNj7fVi8pK+jUv9UdQfYBPlJff4U7vYDE76O4dTNv/QlPUdZe++tPhHYuNsmH0iyf+Aage9Xvk+6epymZVKMRnAvkXJh49Ru+iW8Zvn39gtSCMGXz2+Pua8UXx7U5BKtV+UcLPUS9Zl3P4GroYaAsKk4gXXRCmQ0NohLNgC422pYwGbaVB2B2UKt84Tugtk1TqZGVN+r9Nu8JMYNFXH88BfSKn9D3gjxCoFlpGokSBZf9WyUeNnrWPFKnGQx4vS5BSCamxOIfcHweN8kvFq5QhlVZCgbow+SM9xL9/ENpSUrPEmO4XHxQcLAsJ3prRTgw1MQkhRjZlGjaUGaiHnYuHFRvt3bYa1Iblediodnh3BOpkqZErLPHwbpfNbv6neqm9p/xB5PLR+i0Z2rdlnZTZeD1idUQP2lO+uvymdY1dWL/KxBXsEumttjyJWCz0c4l2/OhuhSun56vz9X4o6HpvqLJ6TQYJmSm97+Aw+DHFqnBV+RA6hl4YhN+xeJMRsl2PshGTDwSP/96eohwqKVEMyf+Q5edvlSu2FxODv2KEdIXYP4Hz6ZRFZFppT1iiICAjqkXKTI2VgHtTDIe42HiVzO8VoaqUZ9oa99k6Bvi98jdeFUAkFLZmNZn0zQ1S1Gn8W5tRKzUy1Zx/wnFhsq9zeV61Har7Is/ylEo/wdizb9882Kda02cDD8o8MlA6wzzMguHHtspqtyboNS21wB+Uka1K7BWQcSA9JT4+TS23VDjKOByZo5L4lzAtfNssEfr5iYWBgWICktcVQ5okESfJJJRIQklg97KSbNRonWzkmpZstU57siUqqEwujJnuVk0Xpkz3QCo6bWT2E1oXTRlpi8zeoNILDw7P+4/h2L9GM3vzN9jdbCIX4cGCW8j5LVY/7xvspBR1WoVs8s1HX4NjKVLiqW2ZYGPK3abdJkflGdoMbkZ7BoOUWB0YnMnjBmZWBSsLtdmsq+5u11nZAE6AcwBPsMtaVbASMK5OFjJ0YgxB/BEDn2AjpJADIyRhkpgl7YpoXXjhyB9gLQO3ZyyKCfmCNcBVZGMN+0UaVV2tHkicIXGTtGLR1kCCGH8m2UzOQBIPkWCgodjxu5B4JQP9+pLQ/E8ETREZNwn5W4RAN0qczWvYqsXGPjbmr2DYLQPeNozhPG8R7RfDJF3PiTyw93yHTeAMtndtBnJdF7fNtNswDQRPCQ6gKq5yT+6wPWfHaYaZl+/5kdCpqqyFsZb9dljVPNeOyy6xOW89lluo4oD1Ak3ohg7ApKs1pKtWcqe95E47yd2uk7tNkYOOioNGoeUR25NvHXQUt8cYEeNQv+4Ewiaii82cxKKbIcEZVMXF7vfbZUZruMbx+h06lbQ9xyP3A9KkX/AA7c7+4MeR06BPYp3CzK8PT8XgHX2cSxT6L+ziMy5M9ufEJNnRhgHtluYycJEwbVXvxa7Z93v5zjD19c3wr/P3Uf9vBctBfdmN7MbHKqzHOprYQVvlOL7UVF/Y1guahzbk1zzan7at44F6rVFYWf126WHlrzF1cfUcaCK/bXE/xmCU2yN4yWfOnsVSGPU/WM2Pj0FO6fYRyIZf4cbix+PxEXvnxLjEHqtmv2P65QnyQU+zqp6PeUtZ9bKCugubB4yOtc5xfKpX84BMBjSR37b4DGf79XOPzc+d6Nzs3C94HsGdF9DqMJhwwvur7KP4hK1aaH9wd7cLHp/ZqleMG/FjNJHfVvgKjsZn3qhn1mCaMHtgQZ/e1uFB3dnoMPtPq9+q+vnQrjbMaVSQz5sH1J9f8wiV/QDX3Ff3VA7RydynjsP/+fSyzqI+q+bHG9NxME9vJ7Nere9TNbgLAabgnD/+/UsC7nchBvMQ8P3wxPsA/EQe8ee3/74NLtg7JUHgGQAE/Es8smCHKesT5WIgqoNfylv61zdPYXocr5Tc6haz+syxZnXNHrKWFffsXOt6idcWFmHlS8/nWVKU+lHoZJd17YKvJD5xjlBj7CqdQAElekx2DWpNEPZUsaPpTyW4l8JW/ZCXqNEgZLgFC9L0abi6CjuxmMba1JikUTeVDm0WgXDQY7LqiDLLFhUQI+cY0NezjPv/nwhHwmPh+ud2x/EiFFvTeFUkrxFxzyo3qJhXhsblvtaE2fcQIkSol9mYTQDTlZxpXgmZZq9kaGwnptN10FwT80mlKNmIBDbTddHsV4Xoauma6HrpqnxrpitLKKc1AVhZPLa+6MSmjXRHoTm3JAahBQVZxnYbHCzKVgtyGmGkXdojMGxvNZ8OR6hBFhl/BhDgJX2MVMNBGHCAA84BmgEwXx4MZFoE4GFntGMQJvZpBlY8egxGgPJjsCiSj1mAIEHD9XHAVBMBwAWqm+OXqxKCI8uh2SoVKqfiKuyqQiXQNPdavi2dlEScxTTKm72vUJkqLOE0SuTww+bFi99DJu2nFC2JhFQo2hW1LD6wfqmg+0ROLlJ5Q2yeP1EPjQ+vtoomqbPx3GFU1ypJK7LwbGeVUI3kBZNS28bp2dTkK3zYcY2l2LJplOL0tDytq0aZnCO0BkowssWDgepMx2t8/A/zEkghGMAEiywAF27c0Xli4vDmw1+AQEFCcIURiSARJYaUjJyCUjK1NOlWuwyr9HkEu4ND8MhCZBFCQAzhm7kYIcYwH0CWIqaIGQQxZ8ESEQmZFQprNn30Kbbs2HNARePIiTMXrtz6bBZxR+fBEwMTCxuHV7fhQJ4k5MOXH38BAgUJFiIUVxgePgEEIyg0prue5YLDE4gkMoVKozOYLDaHy+MLOi0UiSXd9yKvRmVyhVKl1nTRI3fcdc8tD1Lq9AajyWyx2tLaHc5F2Z5Pjazm8Z5I9z/v+KDVCXp8KwWm5HIm0LHwIPIimYLP9wOCVqVOh5zjZqcfDyBcPjWDun3OwatTWZVK22cT+hVwjWhYuxz6jJm1JfTrotoETbB2OazXqx0LVx2wiNyBUvSr7v5EXyzhw6CemY3mwLexwahXYWnwDg7F7b99I6bCukZRoE1qTDhlG1LUmE5MKG7vxTKXgTCpBBdL1IBJa1DLhn4flnrfh/Kz7H332Td/VU0Y47wPw2cArssBDxOmp9SJR4fMD6lVStqtX7e6nS0CbBuwYGRDiJn2uzZjJohU356hFJSLnbwqU13344n4vgaS2300b9/rMxHMBX+XE/yIlPXnJSw0w79eOPHFD9VV/ZLqA63WEk/R3cHwuantnjU/7GC5/TyZ8Hfwj+mQtnAQS09ySLTrSWEq4apLjBU=) format("woff2");unicode-range:U+0100-024F,U+0259,U+1E00-1EFF,U+2020,U+20A0-20AB,U+20AD-20CF,U+2113,U+2C60-2C7F,U+A720-A7FF}@font-face{font-family:"Poppins";font-style:normal;font-weight:700;font-display:swap;src:url(data:font/woff2;base64,d09GMgABAAAAAB6IAAwAAAAAPlAAAB40AAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGx4cLgZgAIFUCuUUzy4LgzYAATYCJAOGaAQgBYNEB4QLG94wM6PBxgECGX6rKEoGo5z9lwncGCL1IV1YsAiHmNnVzmZEIAZzo65J48q15fjh/igmqjoAnkvj9zM9Lwc/MLg/QhoTy/P87w++fc5930yqCsUaOQkhMc6a6qw2iXXWhAqHpCjc4flt9oxclDZSBkiUgKCIKKmISpWFCqKIWVh1c623Mhffc3VzcdNFXtV2tbjq9aV66N97t+bWkgjmqdD4iUJOXgoQ2X1bYZI4JpZCeRY5p9ao1yr03/9P1+sbzcLxvTP+LnpX7nxStEkHOCDwWgZW2CCHpXbVhggqrFhfRg7S3+ssW3llHbCP0XdVwm0cqlWmDtf8930Lvr61J9le8GpRS/Kh4UAbtBTybsjZEJYpkQwBO+gNIFSX1EBdig64aHqePpY2jVn3dGdlRsFwxhTxums/82fxaklimqUCIiercApq3ld9ngJYCwbG7dyFDBXw5QkwJ0AGITyoBySHPFxURwMBhcnHmY6CD7yMkl7iBfSV6gBX/ZQ8hJZMaFjtwrfKq3L5DlEWOAwc2OEZ9v+UV7g4W70PgFcBeqRXAfuELCpgkO2Fuq19nq7QQ1mv53rABm3WQo2yl3qrX/SrfQHIMCQciUbGIBOQAuQ8Co3eig6UFp30IR0eqViyDRmChGCB7F9VWXvx+GvH1ir/91sFK7+v/PZo8dGZR6cfnXg0/2ji0dgj3MOzD249uCEfLqOfR8lHzOc8xa2jzR5+BW5T9weXTYBkCFJU9d4ZZwwGJDov7p7qas/CmHkcQNGTRkln5SIHI5acXSfYmLiWNNe5wRRu4JZ5CVHRcyfa3UlAUM13xwx4SYAD+tLHDgIj9krRbuhuGmmap9qcJ5bDw4XbQOWq4EgJyJb/SIeJMaM7N8muzONkZFNGpmSn7F2XKqKxGloBBY3cm4qdKleWBOmwL1OuxdPoXlanymv7w68lluPIBvjw45emQ0aJHh2xQjT3a06osgKiTXCh1r6eggvZpuEridhpnZj/TfE+kWBtErIUPY/QJGMWLiS9aL10BPF8GahkK+PTGDZqlwVXpcgPfmH7Td0nNB/sZodg1druKCCNMFZxLJ0mZsWPP2vNJWnRkXx0cqzgYGuVovRG4LG24Xts4FSoVD0RhL3n2J6VyWFLnYFGs7mD125BdQQa6iLYspOx9UNwY4bZQohglvpz8QIFLFOA+/2hvBeaUKVfW0s/n9wrA+LYfDKh+aR6+/V/2P4r7bufZju/QuDV8O/3JxX7X+uHV95l/+ARXYjb9YFuOwSK4dUJY4qiV4S8OzlkXnjcYXOtmc+Q/9tiqewI4yFlsDWxPWPzC4AVCq7lVowqB8vmFvniDejzSz54Sd05tm8MKtF3qid2koOoNjOhQKAKx9rI81tAILGI955Sd+3I1cF4BrT9/kKr5i8LwjWjLaQU4rsPaGpXENsvVq1CaZTdvyGyoh31EHENTw9VN0NzKo+DqvZom8Vn8kgisBx0yKRzUmh9iHS+lqXqak0t6R3i92Byh0CPmxYDPIbsA2pt+Nswi+S9sMcVpDcup7sHGhrAGZYIOUrIYBx4TxBFy1tyvXEoOUPI098Hq8kwY1vLyEjAlzkL7VWzIdz/AM0CL/HEi1ZbTwzo9zXBZelBoYWQsBQKxErUlFpM4IoJxtu9rZqhrLyiRsw6Xo+gTZEEJlaXI0arxGhCRNfQNk+xFdywMVLMRG7OHUmRsCYrFrDpvW+j5lF2QalAv0Sh5PcgMjI8pIS+e0RLeHV4wzgp+rj/zaDYDDaXXbXxDdkm5YR7xxzZU+Psqa0XB1EKPaQXra+ir0GJWjDCGKpMmt6LmokR2XW9Cqs5K28e9Tzd6llxG4YNDkVOH5lmdSpQeYwSe4W8WR6tlZsFE4pZsvYm3rjWKE6hbOxKmptRiwTVYnJtnxlhHcnof3DK+l45aD1cJ6hm92lie9e9tlCbFyLPPaPX/J5hHv3Mqz6yFBVKg8kfPWczS6ChiNLRUuXTExB+X0fxCQ/f+9qHgK9YdkAvs27giPlQMIUrvmzp8JOh+dGKI2jMGm0p0gI4pg1NBDxBu7L/Z+PkR2VgII2vroI8clp703JBdN8TTCnwoG0TaNy0qyc+1MMFNJeP1D1f42lLIqhB+qGLOb7A09in/cTAfWd2POVx9BNjCqsKrxciWuKtBdL4qG4fbGrYNpl6fUE4kStzN4rVCw9HF0gvPjvHVq5qdoQikgorocsnROe6GpwEqUq6xUocE5jy9InoYoWI2IdbCbFx9ekbUXmoPwk8JcUadYzCfmvSHzuf3KVOaVrHU9dTe8Xg7HAr0nmLHsMxw/HjbLpPh9uU9DTtWjHhY6uGDKw8DzEXkZ1ctWxHd5zuuZxf8U65rsvklR9h23+F8u9T11oil31oE8Rh3dpOcStVcHLaeQHwFN4Lb2aCGTR/dktyb5Ft8b9NuYWMSuVFuxYa3+ukQeROLLIlh4l8LvJp5Z+wTrSmouGjCQ6wBC1DLiNoV3iFza+wva6xw0zGK4crTB9EJlAf0Pb2p9QdaHQ1lK9ke+aQRgnJ3mvEKYO3xLPQZKiT4hp2lQyVGOXQa5eZ7i+8WYxlNfVPKb5r8UuzySqb5+DxMvUfE7QtJyXCAYwb2TqPKeC8W2SgdCrq7oKyBNOtFzDGCFreetvrF6avcUekbHzW4f7pLme4CCMtXf+KC+I5VWhrGx81UhgcS8SS7YszbdaIE2Ca/b0p0wPGq0VG5EOFckX46FhhUKDMEnCoFmSDTo873Ivk0j0sHnNc3bM0JsNAW6fH5SDH6PowfUOh1/n6Q3TW913G4kdcUsUyf2ncfLQ2jzdtOLRbotu8MIVrScXWRc8d3vWRHuq5aMfpaa+nR89EZ6T++chsAiwbWN7jZphHDXXP2XQ/juEeW0hVRg3loQfKLfjOMM/R8WY1wMI5atG/DxlMv+ZkuM7hhR91cUWECw7wG3B6BNmnGLVX3c6gV/YgqmeVfp7IjP7ZQ5bzZX1vaiFp990Gdhhx1O3zoguo7/iD6r0qkv3LdGOQ/13oWfo+UEt978cr5TGn5AToMxfwcnhGG4XFGb/ia4XEw9Ttlj7pKno+M829sqfc2lx5uyxVN8syChQsmSLe4UvNgurmKPiDDY4vOKAEnyWz3oJKQ7HXT0LxLmzT3xx6adVQcIcnqZ5l4YuGSlutR8TNCYJDEGj6uFmM+uAv83lOnB5QHVu9jVcE/ZWVRIc+EwD87rYHY4+qqA+6MdgeIqEHi+kmgHVK5Pqvqgcq3eYDb50N72yYGEfuOww6B/quib8JYxOnEDsPC50jHS0TnLn24zgHsnexTOUJUnc5T1Hi6yrzMC8aKQdl20zRQmWasddR4i3nyW0+jSXe5nPq919VBOkjRQqJM/Trd4Zefxwx3hQNCwP/jQJ4lUmbnm7UyuVGMiZr7kDH5Vlz70M6oYASPIYWUhn1xkxMukYErsjkbQS9Ixhoedy8tD55PZ2Xl5IqsotQhwyRtDh5AUkgzKWSlVsm/d8JCfkvKPC1d4/PBThYmRBZczzq6OxMG+PVPeKo5JgpmgKeGrhWXRp9fN6JKzYf3WyzVqInxh3hFuvmY2DTB5sFVW18opVtS/noHtrX5o+f+4PlmcCexfiiJlxTbGKJRRviqg12FeiSSptwjRhWsVUT2lUf2gVYmxdOT51eGF84M3VmAbw4UA53sOEgz6cLksPPLG6+UTmr/oCA7r65a1d0fsFPXBgoxJcJhbAVCTbpvCkU7/AvSwDCEg4FfnE6EUimUfnZFVZZJTPWHBNzlD7rphJUVjCE9Q2NBaVjixWajUMv2wGzrqu6UmqPY+pZqSmKZc/OFK2Qy8opY0gbRms96ubWPSVh5qMpb/GRQ8i4b4hR9ZExMtQRQHENJl6/fFGxS9EJda4bO7JyFJAErEGGOBwnLeATS5Nru/obsmuZyfnkIzmfYclf0qjPSOiT9tkzH4MRdk00m1oA7AoFhlZQ1+xMS3BUJMkm6q+cXW47PywtTqDnSg41Xu4kU4RUQhSJHEgGq/p/9SdWRPE7vgWiC6XMeF0lXamsoEtZJpOWNadnG5LE4uImhlQqCJqYu/yISp5Dv2Ewv8di/o+JWcF0v7ODiOuhUIpwhC4SeNYrY+DN9hwpisyz0Fk2aTrHUZEo21V77kwn6Wi5Ni/DnsjKTzjYsryVQIkjEKJI+CgK8Oh466s86d7bX/UD1di9lL3k1dQDuAn3kn4QoPa7DmdxTpOtEHim7/G8wJFlR9MiteiohshJGDO/jCUr/61V/7s/fPWELudwiTphrEqTxRDEnl3U4ujpKp0sLbGjRJaq+rJ7EP8vaiMBQ6E1ZVdvd3VVLJZaL1Y0Dve0W2SRYWX5uKaqea15smzvyPO/5xNyjNsdFNqAIrCldFQwCjxt9o5tPrOydGtl6ax6TUMNwN6QlpOkayouFy9zShvyVVyePHeFXYG7ERV1E1dx9PgP0dF++JZX2wDytn7qsKG49VRXROUlaQaRmpXvMJnyHVnUDKL0UkTlqc7W4sMG/aQNnFma1RoO2qyGQ3Pacp9lH3VsaUl+fmlpvnyfHPxEH/2++/sJj4GF5YUB4L00AN91t+cuDFoGmx6iRVEUpaXMmG8rMyVrkhM/b6s5RDY4hvg625TBMGmzGaYmDba2+cbwUnBgaRlC+aOgZWib/zbw0+LTuQxeLD1wttTbnT2tNccJHDQiOOYB+PRXBhNahug/x725SRtaBH7qetQ9tAwBxo7lZWh2/8zggdk5aPmtG99f+x6chiJOnoKWoYjTZyAQ4z1jzJuxWvOmZ4wWy4wxZ9pqzZ2ZNlqUrxY6TebCcpW60JHDH2k1UB2ML6xO0tj/h5YDVdVsdlHqfe0KDrdCNZ80A2q9vqE+xsLIbpDs4lHGz1OaY65axS0BzIz5xvphEkJZ81YUckWZjoygycBml538Ow77O9kO/vBupEry3QSLzM+iY04jwlDRv/MD1LFJ8tSCkfKqGv2IeBZc2HI3CpGNQL/gB/KDVLFJWckcTn41OwswlwYuMiDGxQHw/dJMchKfw0nmJ89A0zlZrt4UpbKTJ+3MmQYfLP29dNe+hYuvbVnYAnipy4tL7zvfrX73/VNL5wpXW1Yv1a8WrYLfRu+23r32qPB73e3hj5s/vvYg/0cj2Lv09NOfoJ9CpWt90b3R4NkQafhxJ/4EwT0ECOOPDQ7LhocIBeDaxaGrs+cDwtDKx2CQAN6cmX8SNvc4bH6vClzBzpTNgH/frHtc2APCHTyXUyhM1JHrsiASlNWrIycKnCJep2aSK0qLixNJeDxROu1pPACEnpwgPIlOaxrNpuYUXSiuJfVmQt9BXs96RRJ6tsI7VC1O54Fwh8jVJlSUDDsCLYvOVHK8RCDQhyKnOhcD80ecNkWbUOTSCi4QbyDu8YC+g7Lrhz0jrF7qE9sVN4fn9SzelWgdVIGiXSh2abUiF189pbyVL2pVLRAIZ4j4SQdQHzIdhg5zR7mbrbX2qm0dY+6VBC8TyGA08PESZZyWljRzy3iNv+VY++sExm/8rF4tpVKqkWZI6EHVz/x5XHWbU3SczDpApR5gkaHvILddejwLFFu7MdhuIqF7eLk6FZsEkUBReDjqE1arwcwfi4XVhjZAYOexn3+59mLHj37z8Y/BPweCn779DvoOML+hN7VWiI6TmYM02iCT/P6dQiRItEOJZSQXME69a2EngmdxNXVAe1Wl79Li4sHPPp3CdJdWI+3sEioUimhpNBmd3bUcZadAzOeniqm0FJGAz4MJ3Ly0CGe04aFL0JF7dBALyipkE7hqJEKGMmo7b/dPJfuaIpYhqBYLXMpJIqENAW9LIhI5bXD4KJEIvFf19PizZN5LoQdEgszgnk8lNUXDOEZ4FonEBoQEtS5lwdmpbAo9s5goLmmw+qoPciYj4S8DQjDGhzJ4gsCPyswoxgtAzfYxrdlqsD4QjAr6of6K0YpHobUwUEgkQRm7dAQmL5/FKE1TgIdmB6xDDSOLN4kffz/x5wDjKWkPcUlbYii5tJcIZY6aR8/mDMuGQb99Qj9x4Rzs0uYr9nH9+IWLIZcDQD0x8Nv48+3h34Rd7jC1m8D94acjp/p/DPlh5Hg/MEy73Y0K98vy8dNEqq05WskwBvlGRJCPzDcPHk8X690NdBEL7pvnIw2OuITEDEu01pxTKKH0oFnh6M/cwA8d0EkIFId+hmbAaRZdigj2ke6QRRcZ3PV0cfw8WVDEG5x6uFF33foBkVtckolEu7dGbGX6prRvKbfOZ0a6jWxI8UtpBY8TR7cxBOLTIqavjW17cAGYuleaDngrGov1PnKe3OnXMuh0KvGboQZ1UNd2ACuJY/MSEvStjQNSV+9qsPJnvFno7qiWb+WzBRyLI05c09zqUXgguC0We5ISfGLmbPV+DwxCCQdPOER1SuraZHz8qTX6FW/gcGH16LPwCp32fkr+VDUx+ZT8KBY7jkSMP16+fQjge7Sw+hD4/0rVnV6o907Vlf8PgerC0YBrfcxe5hXgvZMMTUDHA+3PUuCLzo5jyq1EcVF9sYf6mIeAyaIGnvj6FzlaqUui0TJrRAmpJam09MZa8Tso1DsxMSQ/iCsdRyAmEMhxJOJYzvyyg99uHzLopm02nXnIaLUKUNZg1cV3pYn6TUbRQFe6Xg9EzWhaotau58oKmawigcAgvke8rEr9prSdgBa9l8ncGx0aW7xzk7RCmw1CJHi5FE/K7CC48ly4chklA4+Xx3dHX0AiL0avLNBRr1zIkw5qFlbzP6oBuy94Q92XOkHynQImMz+ZyyyglpysSfEF3OT4/HqV4nq1ViKBj07e6axgmlyBSfNOl3zijNyNqNkG27xp42YYGP+5bnsdCLFU5pnNFXlKZUWBKclMoMvjQ2KX4IglPP4dBHweD4YKcxf2ru5dCAv3LdRO1W7z4LXrC4WMvMa0qugND9aFR3bEGoQyiTSFGKVeBUFdSqFCqEogIRgvPdK2JZG0TIlalczuIcE3btq8hbcVzYJhUBtXN8G4TeDf848L6x5Xg1oiCVL0a0jsYO364yx7Vg40jnC4nJEtwXJ7AjUvQeR8voRyJ3gUJWOx2fIE9kROV0Dixo0JAWKXlQC2mSxLea4VECKkZZuIHA4QEhiMOLmJVB+1kUSTM7bFjCPgA1hMIwIxEQP6YzQLB5XKxAuHKMDQW6F5HUuz30cY1o7lurjXBWP3T3+OneqSdWQCi4mTGQnN/alzDh0mJexd7Mh5J6tomEuUr/f+0qQR2UhuS+KcdIj532awB5eZHeOOLkY9IzDM3P6w8+HBlb6jdT8m1l4oXoroO8IVz4jAyd1Tw1scVrijzbYBQ8futmnR+w3kSMdzbRPLfOD80pxWf9Bm1R9iUadPSPJocoiPGl9aOpmsNk/eu290X68c3C4ZHOwfKHf0D3Z3O8tV7gyM45hDQ2Cv/CCxSTxnu0tOGepKus3iWCA1iydhRRvMKWk2wuQpH/R9zrTLqko97IOaYCb2TwBUUfGW6kSNvQdaPtZZpqpmsQt49/VrONwa1fy6GVAMgpL2BK20isJVUoltKLRmu89GTHcGLFXGYTCyCggplsaCdcYDXCUi/GZQMByo4RIOEfHno8GqAMRWHINB8z8eBFK2rJceLE6NJ2GTji0GqJpL9Zwc0tHs6ewjejLb0T/fSqGIpcW/mTmZyVE3SioE3FbFQvRGPjOOzI9zvbzgCMVpwGcCqgaci1tVlaWq9dFYX/um4k3Ne2q0s563BUQKkueN1oyxrnSFvEckc2k0ko5WgYwzmnPPhuB/5M49cD8Hxt/Y4MUXCwRCEZkiEPHKYgrw/1ZTrvo/9t61vZ8ORjYBIfdSZdWOPjFfQhabZKpHqGYSUNQioehMk4nQ0XPT0WO/9mPk9Pqdn4ykCsR8gIorFdZI+C6lku+qEQttiVoj9Ae09gxxFI5oIxCJfjN4QZzQvEJPZ37o/GG/Z98JiSSz0z3/gNE4a7MZpw8a87hWjFZ0os8THVfonGgz5hpHKTPgVvowu5i1hJT5GlN+05wiHFZXgktSTFSOxinBi8VF+KT5W1nlQiRYJBLmsp9dEEj4Av6ziZoiHvPxJFQwMzshr5vIzIXrwMo+UQqdLkyJjxeSEeVJDzweGHA8KBAKuD9kIIA9rgpa3xKqWx9t0gXv/CpTpgUVs6P4UcC4OjcaNO74k1MnnOuqQeHS2IypYEzTwroFq1bFR4LWLagsNRQEttbWB58IMBhBLE4RkYevMbjYATjbnmmHDED+dBjYBDx6Q0o0/Cr3mFpOu5Dlmfpk363b/JLvy0I6Tnc0P59vh0FKoFKkscVHDNd9A7b6Xr/3mC0DTwVhnyEtSvDfc/Df7U0nLbmV7nduvaOUf/SxI3dONFUGv743en4UgPoMcMCWUrOqM2/C8O4j8gp3m3YDtTk55u+HU2zURr5f7AgE1vFveYd/xwzf7sKU2/5gsXy+wcA6/i2lU+z0LIHPtyGwjn9r/jnFPr9SqVKxEEu7ID8eEFjHv+U7/h2Xpth9xLL4fF8E1qm3aDgWe0zlFGLf9Ai2Hvg+AEhgHf+W0/w7Bvl2h6bc9okqkap3gScIrJtxyyvySijPfXmurSj+XrCbOp5b/46x/6jKZWH3qwpx7E1OIQUwqEcAIOfOC4lT7HapOhzYt706p8e/5bUpdhOsiV/nrM+u21fvrDtoi8f+6HzNFK88W3u9tBJcUoN3MvnhofuLEgDkKUBPSH7LHOz827Omoc12Njcl6duieWAl+2wG+vn4wOcgrosbO2Rf4gL5ZXzAQb4xwWQ1BBg9/5GP7q00fwBymuEm9IPRBdXV+gRuvheSwDcmkelzAw5CWOQD9K1rBpt/t2RwwRs6vk/UNWDTLipjpAIXsWsPEAVkx+B6vBcdG6HzmXGja00QedI8Wofvjajvi+At8wDs+W+LBhe8oVrXPh3//2FDL0iKdA2oOZ2ALnfd+9xPnOY/R3ljLHIDLPFmvI/pyd3E+c3Xw+MngG/fPXYH4IedzDdX3luZMq8tKm58uBtGCPxOo7bmwM6of0Ig4rzM/T7Phb682/Oy3LwKO1hFQHcgjGKIARflPmzg0b7dPg2S3hqJQQirAD1hsLnJv8OIaRDeRNE1w3UWtYNUbcVtMFj7MWs964E9PSNaMdg9T9AIyQ0TtrCk9Wubu3OI/wvVe0IiRI0MMl+ODiaeKqwXKnNfH3tAHnPRVqhWeAKY4WHWCtcsIb0qsV/wW2BC+zYqHeJTFVpWNQy0c6hs6E3wsR6oE8m/R8DU4NYMCIyNCd3yRadEp5MSM7+uHXTu8r8gKdpWGiiiZ57JJMjsEdh/euxW8RsFPJvBqw1zLY8h8owxkTjYIG4LGO55Wg/XvaKaIiDnM0qrkkrB4+Q/1oGYfCq0RMS+i0z86g4wmdHzfu/VqcVJO3TqbIoX8O9V0t4ACx4tbP7+EZC3aJNpYyvsYGisGc1QNOYnRLrGG7wJE+GAucEIHj3/2fBDv+LZBa7Q2VZC0qBuyCQA0F1m/0bF7AS9UQsRe4PYYF5SRDHeW81n7QDrAldItWC01gbPAQDQXeA/jaSQLhioZQtYElCTzj/ewC8TSD5HNKaIejQm2YoS2oiKFKFifUFYXijs37CRI+K+aU3gP2ACRrXwItD7xfvADfC97dar4c2NOzhvwMOAwR2wWjEPbosfAN52iSxzs9ECcd/n5pZ5YKpY5imEbpkXf5nEu8cxycZfHHhcTV65QrUE5P7VLKqUqBBfNRKqpIzE2SHWvf5ZRDJkc4ZFFUqUx4hS0b9MIToSSh6MTkYiP09pVESyJEKuITmTS1sB1sGtMOUHaKOs1NqItUg0lHsMSdUMXiQADqRKiL1PLYVjKWpJbY2DrMGxeBhWJcdYrYJHuoWTAzkaK+YMsXKF10ijuIjpiuXusp/zYzTH/R5I3TyAx1++dPPl99sEC22w0f9hm22x1TYBAgUJFiJUmHAwEeAQkFDQIkWJFgMDKxYOHgERCRkFFU0cOgameCxsCRJxJOFKxpMiFZ+AkIiYRJp0UhlkMmXJJqegpKKmoaWjZ2BkYpYjV578eIJp3Xos2eMnvUYNOeCYmXiBQV/ostNTz4zEG/S77oEnDjruhedemvKaN922oIDFdoXeVuSOt7zvHe96z8+KfewDHzrB6rExd33iUza/+t0AuxKlHMqUO8ypUoUq1WrVqFPvFw2aNGrWqsV5k9q16eDymz9cdM9Jp+IDPnPf5047Y9E5N7zurJv6QJZddim+YNif8fPMvDMjw51/m0/tsyUUSgrF9wrGpjJMWirf8//1wjeTRqMyAAAAAA==) format("woff2");unicode-range:U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+2000-206F,U+2074,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD}body[data-v-2b23e28f]{margin:0;font-size:100%;color:#3c4858}a[data-v-2b23e28f]{text-decoration:none;color:#45c8f1}h1[data-v-2b23e28f],h2[data-v-2b23e28f],h3[data-v-2b23e28f],h4[data-v-2b23e28f]{margin-top:0}svg[data-v-2b23e28f]{outline:none}.container_selected_area[data-v-2b23e28f]{display:none;visibility:hidden;padding:0;position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647}.container_selected_area.active[data-v-2b23e28f]{visibility:visible;display:block}.container_selected_area .label[data-v-2b23e28f]{font-family:"Poppins",sans-serif;font-size:22px;text-align:center;padding-top:15px}.area[data-v-2b23e28f]{display:none;position:absolute;z-index:2147483647;pointer-events:none;border:1px solid #1e83ff;background:rgba(30,131,255,.1);box-sizing:border-box}.area.active[data-v-2b23e28f]{display:block;top:0;left:0}.hide[data-v-2b23e28f]{display:none}</style><script type="text/javascript" src="./edumanage_files/structure.js.download"></script><script type="text/javascript" src="./edumanage_files/change.js.download"></script><script type="text/javascript" src="./edumanage_files/makegrid.js.download"></script><script type="text/javascript" src="./edumanage_files/jquery.uitablefilter.js.download"></script><script type="text/javascript" src="./edumanage_files/sql(1).js.download"></script><script type="text/javascript" src="./edumanage_files/databases.js.download"></script></head>
<body style="margin-bottom: 27.6719px; margin-left: 240px; padding-top: 59.5625px;">
    <div id="pma_navigation" class="d-print-none" data-config-navigation-width="240" style="width: 240px;">
    <div id="pma_navigation_resizer" style="left: 240px; width: 3px;"></div>
    <div id="pma_navigation_collapser" title="Hide panel" style="left: 240px;">←</div>
    <div id="pma_navigation_content">
      <div id="pma_navigation_header">

                  <div id="pmalogo">
                          <a href="http://localhost/phpmyadmin/index.php">
                                      <img id="imgpmalogo" src="./edumanage_files/logo_left.png" alt="phpMyAdmin">
                                      </a>
                      </div>
        
        <div id="navipanellinks">
          <a href="http://localhost/phpmyadmin/index.php?route=/" title="Home"><img src="./edumanage_files/dot.gif" title="Home" alt="Home" class="icon ic_b_home"></a>

                      <a class="logout disableAjax" href="http://localhost/phpmyadmin/index.php?route=/logout" title="Empty session data"><img src="./edumanage_files/dot.gif" title="Empty session data" alt="Empty session data" class="icon ic_s_loggoff"></a>
          
          <a href="http://localhost/phpmyadmin/doc/html/index.html" title="phpMyAdmin documentation" target="_blank" rel="noopener noreferrer"><img src="./edumanage_files/dot.gif" title="phpMyAdmin documentation" alt="phpMyAdmin documentation" class="icon ic_b_docs"></a>

          <a href="http://localhost/phpmyadmin/url.php?url=https%3A%2F%2Fmariadb.com%2Fkb%2Fen%2Fdocumentation%2F" title="MariaDB Documentation" target="_blank" rel="noopener noreferrer"><img src="./edumanage_files/dot.gif" title="MariaDB Documentation" alt="MariaDB Documentation" class="icon ic_b_sqlhelp"></a>

          <a id="pma_navigation_settings_icon" href="http://localhost/phpmyadmin/index.php?route=/server/sql#" title="Navigation panel settings"><img src="./edumanage_files/dot.gif" title="Navigation panel settings" alt="Navigation panel settings" class="icon ic_s_cog"></a>

          <a id="pma_navigation_reload" href="http://localhost/phpmyadmin/index.php?route=/server/sql#" title="Reload navigation panel"><img src="./edumanage_files/dot.gif" title="Reload navigation panel" alt="Reload navigation panel" class="icon ic_s_reload"></a>
        </div>

        
        <img src="./edumanage_files/dot.gif" title="Loading…" alt="Loading…" style="visibility: hidden; display:none" class="icon ic_ajax_clock_small throbber">
      </div>
      <div id="pma_navigation_tree" class="list_container synced highlight autoexpand" style="height: 592.312px;">
  <div class="pma_quick_warp">
    <div class="drop_list"><button title="Recent tables" class="drop_button btn">Recent</button><ul id="pma_recent_list"><li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=edumanage&amp;table=teachers">
    `edumanage`.`teachers`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=edumanage&amp;table=users">
    `edumanage`.`users`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=accounts">
    `sms_project`.`accounts`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=school_db&amp;table=users">
    `school_db`.`users`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=users">
    `sms_project`.`users`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=courses">
    `sms_project`.`courses`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=metadata">
    `sms_project`.`metadata`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=posts">
    `sms_project`.`posts`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=settings">
    `sms_project`.`settings`
  </a>
</li>
<li class="warp_link">
  <a href="http://localhost/phpmyadmin/index.php?route=/table/recent-favorite&amp;db=sms_project&amp;table=usermeta">
    `sms_project`.`usermeta`
  </a>
</li>
</ul></div>    <div class="drop_list"><button title="Favorite tables" class="drop_button btn">Favorites</button><ul id="pma_favorite_list"><li class="warp_link">
            There are no favorite tables.    </li>
</ul></div>    <div class="clearfloat"></div>
</div>


<div class="clearfloat"></div>

<ul>
  
  <!-- CONTROLS START -->
<li id="navigation_controls_outer" class="">
    <div id="navigation_controls">
        <a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" id="pma_navigation_collapse" title="Collapse all"><img src="./edumanage_files/dot.gif" title="Collapse all" alt="Collapse all" class="icon ic_s_collapseall"></a>
        <a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" id="pma_navigation_sync" title="Unlink from main panel"><img src="./edumanage_files/dot.gif" title="Unlink from main panel" alt="Unlink from main panel" class="icon ic_s_link"></a>
    </div>
</li>
<!-- CONTROLS ENDS -->

</ul>



<div id="pma_navigation_tree_content" style="height: 537.375px;">
  <ul>
      <li class="first new_database italics">
    <div class="block">
      <i class="first"></i>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/server/databases"><img src="./edumanage_files/dot.gif" title="New" alt="New" class="icon ic_b_newdb"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/server/databases" title="New">New</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZGI=" data-vpath="cm9vdA==.ZGI=" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=db"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=db" title="Structure">db</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZmVl" data-vpath="cm9vdA==.ZmVl" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=fee"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=fee" title="Structure">fee</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.ZmVlcG9ydGFs" data-vpath="cm9vdA==.ZmVlcG9ydGFs" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=feeportal"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=feeportal" title="Structure">feeportal</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.aW5mb3JtYXRpb25fc2NoZW1h" data-vpath="cm9vdA==.aW5mb3JtYXRpb25fc2NoZW1h" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=information_schema"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=information_schema" title="Structure">information_schema</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.aW5pdF9kYg==" data-vpath="cm9vdA==.aW5pdF9kYg==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=init_db"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=init_db" title="Structure">init_db</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.aW5zdGFsbF9zcWw=" data-vpath="cm9vdA==.aW5zdGFsbF9zcWw=" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=install_sql"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=install_sql" title="Structure">install_sql</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.bG9naW4=" data-vpath="cm9vdA==.bG9naW4=" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=login"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=login" title="Structure">login</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.bXlzcWw=" data-vpath="cm9vdA==.bXlzcWw=" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=mysql"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=mysql" title="Structure">mysql</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cGVyZm9ybWFuY2Vfc2NoZW1h" data-vpath="cm9vdA==.cGVyZm9ybWFuY2Vfc2NoZW1h" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=performance_schema"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=performance_schema" title="Structure">performance_schema</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cGhwbXlhZG1pbg==" data-vpath="cm9vdA==.cGhwbXlhZG1pbg==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=phpmyadmin"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=phpmyadmin" title="Structure">phpmyadmin</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.cXVlc3RfZmVlcw==" data-vpath="cm9vdA==.cXVlc3RfZmVlcw==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=quest_fees"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=quest_fees" title="Structure">quest_fees</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="navGroup">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander loaded container" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==" data-vpath="cm9vdA==.c2Nob29s" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
          <div class="fst-italic">
    
          <div class="block second">
        <u><img src="./edumanage_files/dot.gif" title="Groups" alt="Groups" class="icon ic_b_group"></u>
      </div>
      &nbsp;school
    
    

          </div>
    
    <div class="clearfloat"></div>

  <div class="list_container" style="display: none;">
    <ul>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29s" data-vpath="cm9vdA==.c2Nob29s." data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=school"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=school" title="Structure">school</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29sX2RhdGFiYXNlX3NjcmlwdA==" data-vpath="cm9vdA==.c2Nob29s.ZGF0YWJhc2Vfc2NyaXB0" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=school_database_script"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=school_database_script" title="Structure">school_database_script</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29sX2Ri" data-vpath="cm9vdA==.c2Nob29s.ZGI=" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=school_db"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=school_db" title="Structure">school_db</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29sX21hbmFnZW1lbnQ=" data-vpath="cm9vdA==.c2Nob29s.bWFuYWdlbWVudA==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=school_management"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=school_management" title="Structure">school_management</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29sX3BvcnRhbA==" data-vpath="cm9vdA==.c2Nob29s.cG9ydGFs" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=school_portal"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=school_portal" title="Structure">school_portal</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29sX3JlZ2lzdHJhdGlvbg==" data-vpath="cm9vdA==.c2Nob29s.cmVnaXN0cmF0aW9u" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=school_registration"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=school_registration" title="Structure">school_registration</a>
          
    

    
    <div class="clearfloat"></div>



  </li>

    </ul>
  </div>

  </li>
  <li class="database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c2Nob29saWduaXRlcg==" data-vpath="cm9vdA==.c2Nob29saWduaXRlcg==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=schooligniter"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=schooligniter" title="Structure">schooligniter</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="navGroup">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander loaded container" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==" data-vpath="cm9vdA==.c21z" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
          <div class="fst-italic">
    
          <div class="block second">
        <u><img src="./edumanage_files/dot.gif" title="Groups" alt="Groups" class="icon ic_b_group"></u>
      </div>
      &nbsp;sms
    
    

          </div>
    
    <div class="clearfloat"></div>

  <div class="list_container" style="display: none;">
    <ul>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c21z" data-vpath="cm9vdA==.c21z." data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=sms"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=sms" title="Structure">sms</a>
          
    

    
    <div class="clearfloat"></div>



  </li>
  <li class="database database">
    <div class="block">
      <i></i>
              <b></b>
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c21zX2Ri" data-vpath="cm9vdA==.c21z.ZGI=" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=sms_db"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=sms_db" title="Structure">sms_db</a>
          
    <span class="dbItemControls"><a href="http://localhost/phpmyadmin/index.php?route=/navigation" data-post="showUnhideDialog=1&amp;dbName=sms_db" class="showUnhide ajax"><img src="./edumanage_files/dot.gif" title="Show hidden items" alt="Show hidden items" class="icon ic_show"></a></span>

    
    <div class="clearfloat"></div>



  </li>
  <li class="database last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.c21zX3Byb2plY3Q=" data-vpath="cm9vdA==.c21z.cHJvamVjdA==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=sms_project"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=sms_project" title="Structure">sms_project</a>
          
    <span class="dbItemControls"><a href="http://localhost/phpmyadmin/index.php?route=/navigation" data-post="showUnhideDialog=1&amp;dbName=sms_project" class="showUnhide ajax"><img src="./edumanage_files/dot.gif" title="Show hidden items" alt="Show hidden items" class="icon ic_show"></a></span>

    
    <div class="clearfloat"></div>



  </li>

    </ul>
  </div>

  </li>
  <li class="last database">
    <div class="block">
      <i></i>
              
        <a class="expander" href="http://localhost/phpmyadmin/index.php?route=/server/sql#">
          <span class="hide paths_nav" data-apath="cm9vdA==.dGVzdA==" data-vpath="cm9vdA==.dGVzdA==" data-pos="0"></span>
                    <img src="./edumanage_files/dot.gif" title="Expand/Collapse" alt="Expand/Collapse" class="icon ic_b_plus">
        </a>
          </div>
    
          <div class="block second">
                  <a href="http://localhost/phpmyadmin/index.php?route=/database/operations&amp;db=test"><img src="./edumanage_files/dot.gif" title="Database operations" alt="Database operations" class="icon ic_s_db"></a>
              </div>

              <a class="hover_show_full" href="http://localhost/phpmyadmin/index.php?route=/database/structure&amp;db=test" title="Structure">test</a>
          
    

    
    <div class="clearfloat"></div>



  </li>

  </ul>
</div>


</div>

      <div id="pma_navi_settings_container">
                  
              </div>
    </div>

          <div class="pma_drop_handler">
        Drop files here      </div>
      <div class="pma_sql_import_status">
        <h2>
          SQL upload          ( <span class="pma_import_count">0</span> )
          <span class="close">x</span>
          <span class="minimize">-</span>
        </h2>
        <div></div>
      </div>
      </div>
  <div class="modal fade" id="unhideNavItemModal" tabindex="-1" aria-labelledby="unhideNavItemModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="unhideNavItemModalLabel">Show hidden navigation tree items.</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

  <div class="modal fade" id="createViewModal" tabindex="-1" aria-labelledby="createViewModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" id="createViewModalDialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="createViewModalLabel">Create view</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body"></div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" id="createViewModalGoButton">Go</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


  
  

  
      
  
      <div id="floating_menubar" class="d-print-none" style="margin-left: 243px; left: 0px; position: fixed; top: 0px; width: 100%; z-index: 99;">
<nav id="server-breadcrumb" aria-label="breadcrumb">
  <ol class="breadcrumb breadcrumb-navbar">
    <li class="breadcrumb-item">
      <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_host">
      <a href="http://localhost/phpmyadmin/index.php?route=/" data-raw-text="127.0.0.1" draggable="false">
        Server:        127.0.0.1
      </a>
    </li>

      </ol>
</nav>
<div id="topmenucontainer" class="menucontainer">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-label="Toggle navigation" aria-controls="navbarNav" aria-expanded="false">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav" style="width: auto; overflow: visible;">
      <ul id="topmenu" class="navbar-nav">
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/databases">
              <img src="./edumanage_files/dot.gif" title="Databases" alt="Databases" class="icon ic_s_db">&nbsp;Databases
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/sql">
              <img src="./edumanage_files/dot.gif" title="SQL" alt="SQL" class="icon ic_b_sql">&nbsp;SQL
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/status">
              <img src="./edumanage_files/dot.gif" title="Status" alt="Status" class="icon ic_s_status">&nbsp;Status
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/privileges&amp;viewing_mode=server">
              <img src="./edumanage_files/dot.gif" title="User accounts" alt="User accounts" class="icon ic_s_rights">&nbsp;User accounts
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/export">
              <img src="./edumanage_files/dot.gif" title="Export" alt="Export" class="icon ic_b_export">&nbsp;Export
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/import">
              <img src="./edumanage_files/dot.gif" title="Import" alt="Import" class="icon ic_b_import">&nbsp;Import
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/preferences/manage">
              <img src="./edumanage_files/dot.gif" title="Settings" alt="Settings" class="icon ic_b_tblops">&nbsp;Settings
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/replication">
              <img src="./edumanage_files/dot.gif" title="Replication" alt="Replication" class="icon ic_s_replication">&nbsp;Replication
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/variables">
              <img src="./edumanage_files/dot.gif" title="Variables" alt="Variables" class="icon ic_s_vars">&nbsp;Variables
                          </a>
          </li>
                  <li class="nav-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/collations">
              <img src="./edumanage_files/dot.gif" title="Charsets" alt="Charsets" class="icon ic_s_asci">&nbsp;Charsets
                          </a>
          </li>
                  
                  
              <li class="nav-item dropdown" style=""><a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img alt="" title="" src="./edumanage_files/dot.gif" class="icon ic_b_more">More</a><ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown"><li class="dropdown-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/engines">
              <img src="./edumanage_files/dot.gif" title="Engines" alt="Engines" class="icon ic_b_engine">&nbsp;Engines
                          </a>
          </li><li class="dropdown-item">
            <a class="nav-link text-nowrap" href="http://localhost/phpmyadmin/index.php?route=/server/plugins">
              <img src="./edumanage_files/dot.gif" title="Plugins" alt="Plugins" class="icon ic_b_plugin">&nbsp;Plugins
                          </a>
          </li></ul></li></ul>
    </div>
  </nav>
</div>
</div>



    <span id="page_nav_icons" class="d-print-none">
      <span id="lock_page_icon"></span>
      <span id="page_settings_icon" style="display: inline;">
        <img src="./edumanage_files/dot.gif" title="Page-related settings" alt="Page-related settings" class="icon ic_s_cog">
      </span>
      <a id="goto_pagetop" href="http://localhost/phpmyadmin/index.php?route=/server/sql#"><img src="./edumanage_files/dot.gif" title="Click on the bar to scroll to top of page" alt="Click on the bar to scroll to top of page" class="icon ic_s_top"></a>
    </span>
  
  <div id="pma_console_container" class="d-print-none">
    <div id="pma_console" style="margin-left: 243px;">
                <div class="toolbar">
                    <div class="switch_button console_switch">
            <img src="./edumanage_files/dot.gif" title="SQL Query Console" alt="SQL Query Console" class="icon ic_console">
            <span>Console</span>
        </div>
                            <div class="button clear">
            
            <span>Clear</span>
        </div>
                            <div class="button history">
            
            <span>History</span>
        </div>
                            <div class="button options">
            
            <span>Options</span>
        </div>
                            <div class="button bookmarks">
            
            <span>Bookmarks</span>
        </div>
                            <div class="button debug hide">
            
            <span>Debug SQL</span>
        </div>
            </div>
                <div class="content" style="display: block; height: 6.248px; margin-bottom: 0px;">
            <div class="console_message_container">
                <div class="message welcome binded">
                    <span id="instructions-0">
                        Press Ctrl+Enter to execute query                    </span>
                    <span class="hide" id="instructions-1">
                        Press Enter to execute query                    </span>
                </div>
                            <div class="message collapsed binded successed" msgid="741583967017"><div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 28 2025 01:46:40 GMT-0800 (Pacific Standard Time)">
            Queried time
                            : <span>1:46:40</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">DROP</span> DATABASE edumanage<span class="cm-punctuation">;</span></div></div><div class="message collapsed binded successed" msgid="413488520267"><div class="action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span></span>
                    </span>
                            <span class="text query_time" title="Fri Nov 28 2025 01:46:58 GMT-0800 (Pacific Standard Time)">
            Queried time
                            : <span>1:46:58</span>
                    </span>
            </div><div class="query highlighted"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> fees <span class="cm-bracket">(</span>student_id<span class="cm-punctuation">,</span> amount<span class="cm-punctuation">,</span> due_date<span class="cm-punctuation">,</span> status<span class="cm-punctuation">,</span> receipt_no<span class="cm-bracket">)</span> <span class="cm-keyword">VALUES</span>
<span class="cm-bracket">(</span><span class="cm-number">1</span><span class="cm-punctuation">,</span> <span class="cm-number">250.00</span><span class="cm-punctuation">,</span> <span class="cm-string">'2023-11-05'</span><span class="cm-punctuation">,</span> <span class="cm-string">'paid'</span><span class="cm-punctuation">,</span> <span class="cm-string">'FEE-5001'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-number">2</span><span class="cm-punctuation">,</span> <span class="cm-number">250.00</span><span class="cm-punctuation">,</span> <span class="cm-string">'2023-11-05'</span><span class="cm-punctuation">,</span> <span class="cm-string">'pending'</span><span class="cm-punctuation">,</span> <span class="cm-string">'FEE-5002'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></div></div></div><!-- console_message_container -->
            <div class="query_input">
                <span class="console_query_input"><div class="CodeMirror cm-s-pma CodeMirror-wrap" translate="no" style="clip-path: inset(0px);"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 16px;"><textarea autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" style="position: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height: 1em; outline: none;"></textarea></div><div class="CodeMirror-vscrollbar" tabindex="-1" cm-not-content="true"><div style="min-width: 1px; height: 0px;"></div></div><div class="CodeMirror-hscrollbar" tabindex="-1" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 16px; margin-bottom: -15px; border-right-width: 35px; min-height: 20px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-measure"><span><span>​</span>x</span></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors" style=""><div class="CodeMirror-cursor" style="left: 0px; top: 0px; height: 19.6875px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation"><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 35px; width: 1px; border-bottom: 0px solid transparent; top: 20px;"></div><div class="CodeMirror-gutters" style="height: 55px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></span>
            </div>
        </div><!-- message end -->
                <div class="mid_layer"></div>
                <div class="card ungrouped" id="debug_console">
            <div class="toolbar ">
                    <div class="button order order_asc active">
            
            <span>ascending</span>
        </div>
                            <div class="button order order_desc">
            
            <span>descending</span>
        </div>
                            <div class="text">
            
            <span>Order:</span>
        </div>
                            <div class="switch_button">
            
            <span>Debug SQL</span>
        </div>
                            <div class="button order_by sort_count">
            
            <span>Count</span>
        </div>
                            <div class="button order_by sort_exec active">
            
            <span>Execution order</span>
        </div>
                            <div class="button order_by sort_time">
            
            <span>Time taken</span>
        </div>
                            <div class="text">
            
            <span>Order by:</span>
        </div>
                            <div class="button group_queries">
            
            <span>Group queries</span>
        </div>
                            <div class="button ungroup_queries">
            
            <span>Ungroup queries</span>
        </div>
            </div>
            <div class="content debug" style="height: 6.248px;">
                <div class="message welcome binded">Some error occurred while getting SQL debug info.</div>
                <div class="debugLog"></div>
            </div> <!-- Content -->
            <div class="templates">
                <div class="debug_query action_content">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action dbg_show_trace">
            Show trace
                    </span>
                            <span class="action dbg_hide_trace">
            Hide trace
                    </span>
                            <span class="text count hide">
            Count
                            : <span></span>
                    </span>
                            <span class="text time">
            Time taken
                            : <span></span>
                    </span>
            </div>
            </div> <!-- Template -->
        </div> <!-- Debug SQL card -->
                    <div class="card" id="pma_bookmarks">
                <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Bookmarks</span>
        </div>
                            <div class="button refresh">
            
            <span>Refresh</span>
        </div>
                            <div class="button add">
            
            <span>Add</span>
        </div>
            </div>
                <div class="content bookmark" style="height: 6.248px;">
                    <div class="message welcome binded">
    <span>No bookmarks</span>
</div>

                </div>
                <div class="mid_layer"></div>
                <div class="card add">
                    <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Add bookmark</span>
        </div>
            </div>
                    <div class="content add_bookmark" style="height: 9px;">
                        <div class="options">
                            <label>
                                Label: <input type="text" name="label">
                            </label>
                            <label>
                                Target database: <input type="text" name="targetdb">
                            </label>
                            <label>
                                <input type="checkbox" name="shared">Share this bookmark                            </label>
                            <button class="btn btn-primary" type="submit" name="submit">OK</button>
                        </div> <!-- options -->
                        <div class="query_input">
                            <span class="bookmark_add_input"><div class="CodeMirror cm-s-pma CodeMirror-wrap" translate="no" style="clip-path: inset(0px);"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 0px; left: 16px;"><textarea autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="0" style="position: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height: 1em; outline: none;"></textarea></div><div class="CodeMirror-vscrollbar" tabindex="-1" cm-not-content="true"><div style="min-width: 1px; height: 0px;"></div></div><div class="CodeMirror-hscrollbar" tabindex="-1" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 16px; margin-bottom: -15px; border-right-width: 35px; min-height: 20px; padding-right: 0px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-measure"><pre class="CodeMirror-line-like"><span>xxxxxxxxxx</span></pre></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors"><div class="CodeMirror-cursor" style="left: 0px; top: 0px; height: 19.6875px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation"><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 35px; width: 1px; border-bottom: 0px solid transparent; top: 20px;"></div><div class="CodeMirror-gutters" style="height: 55px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div></div></div></div></span>
                        </div>
                    </div>
                </div> <!-- Add bookmark card -->
            </div> <!-- Bookmarks card -->
                        <div class="card" id="pma_console_options">
            <div class="toolbar ">
                    <div class="switch_button">
            
            <span>Options</span>
        </div>
                            <div class="button default">
            
            <span>Set default</span>
        </div>
            </div>
            <div class="content" style="height: 9px;">
                <label>
                    <input type="checkbox" name="always_expand">Always expand query messages                </label>
                <br>
                <label>
                    <input type="checkbox" name="start_history">Show query history at start                </label>
                <br>
                <label>
                    <input type="checkbox" name="current_query">Show current browsing query                </label>
                <br>
                <label>
                    <input type="checkbox" name="enter_executes">
                        Execute queries on Enter and insert new line with Shift+Enter. To make this permanent, view settings.                </label>
                <br>
                <label>
                    <input type="checkbox" name="dark_theme">Switch to dark theme                </label>
                <br>
            </div>
        </div> <!-- Options card -->
        <div class="templates">
                        <div class="query_actions">
                    <span class="action collapse">
            Collapse
                    </span>
                            <span class="action expand">
            Expand
                    </span>
                            <span class="action requery">
            Requery
                    </span>
                            <span class="action edit">
            Edit
                    </span>
                            <span class="action explain">
            Explain
                    </span>
                            <span class="action profiling">
            Profiling
                    </span>
                            <span class="action bookmark">
            Bookmark
                    </span>
                            <span class="text failed">
            Query failed
                    </span>
                            <span class="text targetdb">
            Database
                            : <span></span>
                    </span>
                            <span class="text query_time">
            Queried time
                            : <span></span>
                    </span>
            </div>
        </div>
    </div> <!-- #console end -->
</div> <!-- #console_container end -->


  <div id="page_content"><div id="loading_parent"></div><div id="page_settings_modal"><div class="page_settings"><form method="post" action="http://localhost/phpmyadmin/index.php?route=%2Fserver%2Fsql&amp;server=1" class="config-form disableAjax">
  <input type="hidden" name="tab_hash" value="">
      <input type="hidden" name="check_page_refresh" id="check_page_refresh" value="">
    <input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b">
  <input type="hidden" name="submit_save" value="Sql">

  <ul class="nav nav-tabs" id="configFormDisplayTab" role="tablist">
          <li class="nav-item" role="presentation">
        <a class="nav-link active" id="Sql_queries-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Sql_queries" data-bs-toggle="tab" role="tab" aria-controls="Sql_queries" aria-selected="true">SQL queries</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Sql_box-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Sql_box" data-bs-toggle="tab" role="tab" aria-controls="Sql_box" aria-selected="false">SQL Query box</a>
      </li>
      </ul>
  <div class="tab-content">
          <div class="tab-pane fade show active" id="Sql_queries" role="tabpanel" aria-labelledby="Sql_queries-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">SQL queries</h5>
                          <h6 class="card-subtitle mb-2 text-muted">SQL queries settings.</h6>
            
            <fieldset class="optbox">
              <legend>SQL queries</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="ShowSQL">Show SQL queries</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowSQL" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Defines whether SQL queries generated by phpMyAdmin should be displayed.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowSQL" id="ShowSQL" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#ShowSQL" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="Confirm">Confirm DROP queries</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_Confirm" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether a warning ("Are your really sure…") should be displayed when you're about to lose data.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="Confirm" id="Confirm" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Confirm" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="QueryHistoryMax">Query history length</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_QueryHistoryMax" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>How many queries are kept in history.</small>
      </th>

  <td>
          <input type="number" name="QueryHistoryMax" id="QueryHistoryMax" value="25" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#QueryHistoryMax" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="IgnoreMultiSubmitErrors">Ignore multiple statement errors</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_IgnoreMultiSubmitErrors" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>If enabled, phpMyAdmin continues computing multiple-statement queries even if one of the queries failed.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="IgnoreMultiSubmitErrors" id="IgnoreMultiSubmitErrors">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#IgnoreMultiSubmitErrors" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="MaxCharactersInDisplayedSQL">Maximum displayed SQL length</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_MaxCharactersInDisplayedSQL" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Maximum number of characters used when a SQL query is displayed.</small>
      </th>

  <td>
          <input type="number" name="MaxCharactersInDisplayedSQL" id="MaxCharactersInDisplayedSQL" value="1000" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#MaxCharactersInDisplayedSQL" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="RetainQueryBox">Retain query box</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_RetainQueryBox" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Defines whether the query box should stay on-screen after its submission.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="RetainQueryBox" id="RetainQueryBox">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#RetainQueryBox" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="CodemirrorEnable">Enable CodeMirror</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_CodemirrorEnable" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Use user-friendly editor for editing SQL queries (CodeMirror) with syntax highlighting and line numbers.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="CodemirrorEnable" id="CodemirrorEnable" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#CodemirrorEnable" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="LintEnable">Enable linter</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_LintEnable" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Find any errors in the query before executing it. Requires CodeMirror to be enabled.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="LintEnable" id="LintEnable" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#LintEnable" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="EnableAutocompleteForTablesAndColumns">Enable autocomplete for table and column names</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_EnableAutocompleteForTablesAndColumns" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Autocomplete of the table and column names in the SQL queries.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="EnableAutocompleteForTablesAndColumns" id="EnableAutocompleteForTablesAndColumns" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#EnableAutocompleteForTablesAndColumns" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="DefaultForeignKeyChecks">Foreign key checks</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_DefaultForeignKeyChecks" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Default value for foreign key checks checkbox for some queries.</small>
      </th>

  <td>
          <select name="DefaultForeignKeyChecks" id="DefaultForeignKeyChecks" class="w-75">
                            <option value="default" selected="">Server default</option>
                            <option value="enable">Enable</option>
                            <option value="disable">Disable</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#DefaultForeignKeyChecks" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Sql_box" role="tabpanel" aria-labelledby="Sql_box-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">SQL Query box</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Customize links shown in SQL Query boxes.</h6>
            
            <fieldset class="optbox">
              <legend>SQL Query box</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="SQLQuery-Edit">Edit</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_SQLQuery_Edit" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="SQLQuery-Edit" id="SQLQuery-Edit" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#SQLQuery-Edit" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="SQLQuery-Explain">Explain SQL</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_SQLQuery_Explain" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="SQLQuery-Explain" id="SQLQuery-Explain" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#SQLQuery-Explain" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="SQLQuery-ShowAsPHP">Create PHP code</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_SQLQuery_ShowAsPHP" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="SQLQuery-ShowAsPHP" id="SQLQuery-ShowAsPHP" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#SQLQuery-ShowAsPHP" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="SQLQuery-Refresh">Refresh</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_SQLQuery_Refresh" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="SQLQuery-Refresh" id="SQLQuery-Refresh" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#SQLQuery-Refresh" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
      </div>
</form>

<script type="text/javascript">
  if (typeof configInlineParams === 'undefined' || !Array.isArray(configInlineParams)) {
    configInlineParams = [];
  }
  configInlineParams.push(function () {
    registerFieldValidator('QueryHistoryMax', 'validatePositiveNumber', true);
registerFieldValidator('QueryHistoryMax', 'validateUpperBound', true, ['25']);
registerFieldValidator('MaxCharactersInDisplayedSQL', 'validatePositiveNumber', true);

    $.extend(Messages, {
      'error_nan_p': 'Not\u0020a\u0020positive\u0020number\u0021',
      'error_nan_nneg': 'Not\u0020a\u0020non\u002Dnegative\u0020number\u0021',
      'error_incorrect_port': 'Not\u0020a\u0020valid\u0020port\u0020number\u0021',
      'error_invalid_value': 'Incorrect\u0020value\u0021',
      'error_value_lte': 'Value\u0020must\u0020be\u0020less\u0020than\u0020or\u0020equal\u0020to\u0020\u0025s\u0021',
    });

    $.extend(defaultValues, {
      'ShowSQL': true,
      'Confirm': true,
      'QueryHistoryMax': '25',
      'IgnoreMultiSubmitErrors': false,
      'MaxCharactersInDisplayedSQL': '1000',
      'RetainQueryBox': false,
      'CodemirrorEnable': true,
      'LintEnable': true,
      'EnableAutocompleteForTablesAndColumns': true,
      'DefaultForeignKeyChecks': ['default'],
      'SQLQuery-Edit': true,
      'SQLQuery-Explain': true,
      'SQLQuery-ShowAsPHP': true,
      'SQLQuery-Refresh': true
    });
  });
  if (typeof configScriptLoaded !== 'undefined' && configInlineParams) {
    loadInlineConfig();
  }
</script>
</div></div><form method="post" action="http://localhost/phpmyadmin/index.php?route=/import" class="ajax lock-page" id="sqlqueryform" name="sqlform" enctype="multipart/form-data">
  <input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b" style="display: inline-block;">
  <input type="hidden" name="is_js_confirmed" value="0" style="display: inline-block;">
  <input type="hidden" name="pos" value="0" style="display: inline-block;">
  <input type="hidden" name="goto" value="index.php?route=/server/sql" style="display: inline-block;">
  <input type="hidden" name="message_to_show" value="Your SQL query has been executed successfully." style="display: inline-block;">
  <input type="hidden" name="prev_sql_query" value="" style="display: inline-block;">

      <a id="querybox" style="display: none;"></a>

    <div class="card mb-3" style="display: none;">
      <div class="card-header">Run SQL query/queries on server “127.0.0.1”: <a href="http://localhost/phpmyadmin/url.php?url=https%3A%2F%2Fdev.mysql.com%2Fdoc%2Frefman%2F8.0%2Fen%2Fselect.html" target="mysql_doc"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a></div>
      <div class="card-body">
        <div id="queryfieldscontainer">
          <div class="row">
            <div class="col">
              <div class="mb-3">
                <textarea class="form-control" tabindex="100" name="sql_query" id="sqlquery" cols="40" rows="15" data-textarea-auto-select="false" aria-label="SQL query" style="display: none;"></textarea><div class="CodeMirror cm-s-default CodeMirror-wrap ui-resizable" translate="no" style="clip-path: inset(0px); resize: vertical;"><div style="overflow: hidden; position: relative; width: 3px; height: 0px; top: 310px; left: 405.531px;"><textarea autocorrect="off" autocapitalize="off" spellcheck="false" tabindex="100" style="position: absolute; bottom: -1em; padding: 0px; width: 1000px; height: 1em; min-height: 1em; outline: none;"></textarea></div><div class="CodeMirror-vscrollbar" tabindex="-1" cm-not-content="true" style="display: block; bottom: 0px;"><div style="min-width: 1px; height: 2262px;"></div></div><div class="CodeMirror-hscrollbar" tabindex="-1" cm-not-content="true"><div style="height: 100%; min-height: 1px; width: 0px;"></div></div><div class="CodeMirror-scrollbar-filler" cm-not-content="true"></div><div class="CodeMirror-gutter-filler" cm-not-content="true"></div><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 48px; margin-bottom: -15px; border-right-width: 35px; min-height: 2173px; padding-right: 15px; padding-bottom: 0px;"><div style="position: relative; top: 1613.76px;"><div class="CodeMirror-lines" role="presentation"><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-measure"><pre class="CodeMirror-line-like"><span>xxxxxxxxxx</span></pre><div class="CodeMirror-linenumber CodeMirror-gutter-elt"><div>1</div></div><div class="CodeMirror-linenumber CodeMirror-gutter-elt"><div>110</div></div></div><div class="CodeMirror-measure"></div><div style="position: relative; z-index: 1;"></div><div class="CodeMirror-cursors" style="visibility: hidden;"><div class="CodeMirror-cursor" style="left: 357.531px; top: 531.562px; height: 19.6875px;">&nbsp;</div></div><div class="CodeMirror-code" role="presentation" style=""><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">83</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"> &nbsp;  receipt_no <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">20</span><span class="cm-bracket">)</span> <span class="cm-keyword">UNIQUE</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">84</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"> &nbsp; &nbsp;<span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>student_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> students<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">85</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">86</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">87</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-comment">-- Insert sample data</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">88</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> users <span class="cm-bracket">(</span>username<span class="cm-punctuation">,</span> <span class="cm-keyword">password</span><span class="cm-punctuation">,</span> role<span class="cm-punctuation">,</span> name<span class="cm-punctuation">,</span> email<span class="cm-bracket">)</span> <span class="cm-keyword">VALUES</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">89</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'admin'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'admin'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Admin User'</span><span class="cm-punctuation">,</span> <span class="cm-string">'admin@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">90</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'teacher1'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'teacher'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Dr. Sarah Wilson'</span><span class="cm-punctuation">,</span> <span class="cm-string">'sarah@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">91</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'teacher2'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'teacher'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mr. James Miller'</span><span class="cm-punctuation">,</span> <span class="cm-string">'james@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">92</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'student1'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'student'</span><span class="cm-punctuation">,</span> <span class="cm-string">'John Smith'</span><span class="cm-punctuation">,</span> <span class="cm-string">'john@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">93</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'student2'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'student'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Emma Johnson'</span><span class="cm-punctuation">,</span> <span class="cm-string">'emma@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">94</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">95</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> students <span class="cm-bracket">(</span>user_id<span class="cm-punctuation">,</span> class<span class="cm-punctuation">,</span> parent_name<span class="cm-punctuation">,</span> parent_contact<span class="cm-bracket">)</span> <span class="cm-keyword">VALUES</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">96</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-number">4</span><span class="cm-punctuation">,</span> <span class="cm-string">'10-A'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Robert Smith'</span><span class="cm-punctuation">,</span> <span class="cm-string">'robert@example.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">97</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span> <span class="cm-string">'9-B'</span><span class="cm-punctuation">,</span> <span class="cm-string">'David Johnson'</span><span class="cm-punctuation">,</span> <span class="cm-string">'david@example.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">98</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">99</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> teachers <span class="cm-bracket">(</span>user_id<span class="cm-punctuation">,</span> subject<span class="cm-punctuation">,</span> classes<span class="cm-bracket">)</span> <span class="cm-keyword">VALUES</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">100</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-number">2</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mathematics'</span><span class="cm-punctuation">,</span> <span class="cm-string">'10-A, 10-B, 11-A'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">101</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-number">3</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-string">'9-A, 9-B, 10-C'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">102</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">103</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> courses <span class="cm-bracket">(</span>course_code<span class="cm-punctuation">,</span> course_name<span class="cm-punctuation">,</span> department<span class="cm-punctuation">,</span> credits<span class="cm-punctuation">,</span> teacher_id<span class="cm-bracket">)</span> <span class="cm-keyword">VALUES</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">104</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'MATH-101'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mathematics'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-number">4</span><span class="cm-punctuation">,</span> <span class="cm-number">1</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">105</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'SCI-102'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-number">3</span><span class="cm-punctuation">,</span> <span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">106</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-string">'ENG-103'</span><span class="cm-punctuation">,</span> <span class="cm-string">'English Literature'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Arts'</span><span class="cm-punctuation">,</span> <span class="cm-number">3</span><span class="cm-punctuation">,</span> <span class="cm-atom">NULL</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">107</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span cm-text="">​</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">108</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-keyword">INSERT</span> <span class="cm-keyword">INTO</span> fees <span class="cm-bracket">(</span>student_id<span class="cm-punctuation">,</span> amount<span class="cm-punctuation">,</span> due_date<span class="cm-punctuation">,</span> <span class="cm-keyword">status</span><span class="cm-punctuation">,</span> receipt_no<span class="cm-bracket">)</span> <span class="cm-keyword">VALUES</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">109</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-number">1</span><span class="cm-punctuation">,</span> <span class="cm-number">250.00</span><span class="cm-punctuation">,</span> <span class="cm-string">'2023-11-05'</span><span class="cm-punctuation">,</span> <span class="cm-string">'paid'</span><span class="cm-punctuation">,</span> <span class="cm-string">'FEE-5001'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" aria-hidden="true" style="left: -48px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 16px; width: 23px;">110</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;"><span class="cm-bracket">(</span><span class="cm-number">2</span><span class="cm-punctuation">,</span> <span class="cm-number">250.00</span><span class="cm-punctuation">,</span> <span class="cm-string">'2023-11-05'</span><span class="cm-punctuation">,</span> <span class="cm-string">'pending'</span><span class="cm-punctuation">,</span> <span class="cm-string">'FEE-5002'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span></span></pre></div></div></div></div></div></div><div style="position: absolute; height: 35px; width: 1px; border-bottom: 0px solid transparent; top: 2173px;"></div><div class="CodeMirror-gutters" style="height: 2208px;"><div class="CodeMirror-gutter CodeMirror-lint-markers"></div><div class="CodeMirror-gutter CodeMirror-linenumbers" style="width: 31px;"></div></div></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div></div>
              </div>
              <div id="querymessage"></div>

              <div class="btn-toolbar" role="toolbar">
                
                <div class="btn-group me-2" role="group">
                  <input type="button" value="Clear" id="clear" class="btn btn-secondary button sqlbutton">
                                      <input type="button" value="Format" id="format" class="btn btn-secondary button sqlbutton">
                                  </div>

                <input type="button" value="Get auto-saved query" id="saved" class="btn btn-secondary button sqlbutton">
              </div>

              <div class="my-3">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="parameterized" id="parameterized">
                  <label class="form-check-label" for="parameterized">
                    Bind parameters                    <a href="http://localhost/phpmyadmin/doc/html/faq.html#faq6-40" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
                  </label>
                </div>
              </div>
              <div class="mb-3" id="parametersDiv"></div>
            </div>

                      </div>
        </div>

                  <div class="row row-cols-lg-auto g-3 align-items-center">
            <div class="col-6">
              <label class="form-label" for="bkm_label">Bookmark this SQL query:</label>
            </div>
            <div class="col-6">
              <input class="form-control" type="text" name="bkm_label" id="bkm_label" tabindex="110" value="">
            </div>

            <div class="col-12">
              <div class="form-check form-check-inline" style="display: none;">
                <input class="form-check-input" type="checkbox" name="bkm_all_users" tabindex="111" id="id_bkm_all_users" value="true">
                <label class="form-check-label" for="id_bkm_all_users">Let every user access this bookmark</label>
              </div>
            </div>

            <div class="col-12">
              <div class="form-check form-check-inline" style="display: none;">
                <input class="form-check-input" type="checkbox" name="bkm_replace" tabindex="112" id="id_bkm_replace" value="true">
                <label class="form-check-label" for="id_bkm_replace">Replace existing bookmark of same name</label>
              </div>
            </div>
          </div>
              </div>
      <div class="card-footer">
        <div class="row row-cols-lg-auto g-3 align-items-center">
          <div class="col-12">
            <div class="input-group me-2">
              <span class="input-group-text">Delimiter</span>
              <label class="visually-hidden" for="id_sql_delimiter">Delimiter</label>
              <input class="form-control" type="text" name="sql_delimiter" tabindex="131" size="3" value=";" id="id_sql_delimiter">
            </div>
          </div>

          <div class="col-12">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="show_query" value="1" id="checkbox_show_query" tabindex="132">
              <label class="form-check-label" for="checkbox_show_query">Show this query here again</label>
            </div>
          </div>

          <div class="col-12">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="retain_query_box" value="1" id="retain_query_box" tabindex="133">
              <label class="form-check-label" for="retain_query_box">Retain query box</label>
            </div>
          </div>

          <div class="col-12">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" name="rollback_query" value="1" id="rollback_query" tabindex="134">
              <label class="form-check-label" for="rollback_query">Rollback when finished</label>
            </div>
          </div>

          <div class="col-12">
            <div class="form-check">
              <input type="hidden" name="fk_checks" value="0">
              <input class="form-check-input" type="checkbox" name="fk_checks" id="fk_checks" value="1" checked="">
              <label class="form-check-label" for="fk_checks">Enable foreign key checks</label>
            </div>
          </div>

          <div class="col-12">
            <input class="btn btn-primary ms-1" type="submit" id="button_submit_query" name="SQL" tabindex="200" value="Go">
          </div>
        </div>
      </div>
    </div>
  
  
  <br id="togglequerybox_spacer"><button class="btn btn-secondary" id="togglequerybox" style="">Show query box</button><input type="hidden" name="SQL" value="Go" style="display: inline-block;"><input type="hidden" id="ajax_request_hidden" name="ajax_request" value="true" style="display: inline-block;"></form>

<div id="sqlqueryresultsouter"><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.0014 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Create database
CREATE DATABASE edumanage;
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Create database</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-database.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-database.html">DATABASE</a></span> edumanage<span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Create database
CREATE DATABASE edumanage;"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Create+database%0D%0ACREATE+DATABASE+edumanage%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Create+database%0D%0ACREATE+DATABASE+edumanage%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="alert alert-primary" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_notice"> Error: #1046 No database selected
</div>
<div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.0003 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">USE edumanage;
</pre><div class="sql-highlight cm-s-default"><span class="cm-keyword">USE</span> edumanage<span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="USE edumanage;"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=USE+edumanage%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=USE+edumanage%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="alert alert-primary" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_notice"> Error: #1046 No database selected
</div>
<div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.3420 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'teacher', 'student') NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Users table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> users <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    username <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">50</span><span class="cm-bracket">)</span> <span class="cm-keyword">UNIQUE</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/encryption-functions.html%23function_password">password</a></span> <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">255</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    role <span class="cm-keyword">ENUM</span><span class="cm-bracket">(</span><span class="cm-string">'admin'</span><span class="cm-punctuation">,</span> <span class="cm-string">'teacher'</span><span class="cm-punctuation">,</span> <span class="cm-string">'student'</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    name <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">100</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    email <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">100</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    created_at <span class="cm-type">TIMESTAMP</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_default">DEFAULT</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/date-and-time-functions.html%23function_current_timestamp">CURRENT_TIMESTAMP</a></span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM(&#39;admin&#39;, &#39;teacher&#39;, &#39;student&#39;) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Users+table%0D%0ACREATE+TABLE+users+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++username+VARCHAR%2850%29+UNIQUE+NOT+NULL%2C%0D%0A++++password+VARCHAR%28255%29+NOT+NULL%2C%0D%0A++++role+ENUM%28%27admin%27%2C+%27teacher%27%2C+%27student%27%29+NOT+NULL%2C%0D%0A++++name+VARCHAR%28100%29+NOT+NULL%2C%0D%0A++++email+VARCHAR%28100%29%2C%0D%0A++++created_at+TIMESTAMP+DEFAULT+CURRENT_TIMESTAMP%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Users+table%0D%0ACREATE+TABLE+users+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++username+VARCHAR%2850%29+UNIQUE+NOT+NULL%2C%0D%0A++++password+VARCHAR%28255%29+NOT+NULL%2C%0D%0A++++role+ENUM%28%27admin%27%2C+%27teacher%27%2C+%27student%27%29+NOT+NULL%2C%0D%0A++++name+VARCHAR%28100%29+NOT+NULL%2C%0D%0A++++email+VARCHAR%28100%29%2C%0D%0A++++created_at+TIMESTAMP+DEFAULT+CURRENT_TIMESTAMP%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.2730 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Students table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    class VARCHAR(20),
    parent_name VARCHAR(100),
    parent_contact VARCHAR(100),
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Students table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> students <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    user_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    class <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">20</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    parent_name <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">100</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    parent_contact <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">100</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">status</span> <span class="cm-keyword">ENUM</span><span class="cm-bracket">(</span><span class="cm-string">'active'</span><span class="cm-punctuation">,</span> <span class="cm-string">'inactive'</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_default">DEFAULT</a></span> <span class="cm-string">'active'</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>user_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> users<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span> <span class="cm-keyword">ON</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/delete.html">DELETE</a></span> <span class="cm-keyword">CASCADE</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Students table
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    class VARCHAR(20),
    parent_name VARCHAR(100),
    parent_contact VARCHAR(100),
    status ENUM(&#39;active&#39;, &#39;inactive&#39;) DEFAULT &#39;active&#39;,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Students+table%0D%0ACREATE+TABLE+students+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++user_id+INT%2C%0D%0A++++class+VARCHAR%2820%29%2C%0D%0A++++parent_name+VARCHAR%28100%29%2C%0D%0A++++parent_contact+VARCHAR%28100%29%2C%0D%0A++++status+ENUM%28%27active%27%2C+%27inactive%27%29+DEFAULT+%27active%27%2C%0D%0A++++FOREIGN+KEY+%28user_id%29+REFERENCES+users%28id%29+ON+DELETE+CASCADE%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Students+table%0D%0ACREATE+TABLE+students+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++user_id+INT%2C%0D%0A++++class+VARCHAR%2820%29%2C%0D%0A++++parent_name+VARCHAR%28100%29%2C%0D%0A++++parent_contact+VARCHAR%28100%29%2C%0D%0A++++status+ENUM%28%27active%27%2C+%27inactive%27%29+DEFAULT+%27active%27%2C%0D%0A++++FOREIGN+KEY+%28user_id%29+REFERENCES+users%28id%29+ON+DELETE+CASCADE%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.4996 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Teachers table
CREATE TABLE teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    subject VARCHAR(50),
    classes TEXT,
    status ENUM('active', 'inactive') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Teachers table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> teachers <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    user_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    subject <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">50</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    classes <span class="cm-type">TEXT</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">status</span> <span class="cm-keyword">ENUM</span><span class="cm-bracket">(</span><span class="cm-string">'active'</span><span class="cm-punctuation">,</span> <span class="cm-string">'inactive'</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_default">DEFAULT</a></span> <span class="cm-string">'active'</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>user_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> users<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span> <span class="cm-keyword">ON</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/delete.html">DELETE</a></span> <span class="cm-keyword">CASCADE</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Teachers table
CREATE TABLE teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    subject VARCHAR(50),
    classes TEXT,
    status ENUM(&#39;active&#39;, &#39;inactive&#39;) DEFAULT &#39;active&#39;,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Teachers+table%0D%0ACREATE+TABLE+teachers+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++user_id+INT%2C%0D%0A++++subject+VARCHAR%2850%29%2C%0D%0A++++classes+TEXT%2C%0D%0A++++status+ENUM%28%27active%27%2C+%27inactive%27%29+DEFAULT+%27active%27%2C%0D%0A++++FOREIGN+KEY+%28user_id%29+REFERENCES+users%28id%29+ON+DELETE+CASCADE%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Teachers+table%0D%0ACREATE+TABLE+teachers+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++user_id+INT%2C%0D%0A++++subject+VARCHAR%2850%29%2C%0D%0A++++classes+TEXT%2C%0D%0A++++status+ENUM%28%27active%27%2C+%27inactive%27%29+DEFAULT+%27active%27%2C%0D%0A++++FOREIGN+KEY+%28user_id%29+REFERENCES+users%28id%29+ON+DELETE+CASCADE%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.4386 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Courses table
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    department VARCHAR(50),
    credits INT,
    teacher_id INT,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id)
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Courses table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> courses <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    course_code <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">20</span><span class="cm-bracket">)</span> <span class="cm-keyword">UNIQUE</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    course_name <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">100</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    department <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">50</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    credits <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    teacher_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>teacher_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> teachers<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Courses table
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(100) NOT NULL,
    department VARCHAR(50),
    credits INT,
    teacher_id INT,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id)
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Courses+table%0D%0ACREATE+TABLE+courses+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++course_code+VARCHAR%2820%29+UNIQUE+NOT+NULL%2C%0D%0A++++course_name+VARCHAR%28100%29+NOT+NULL%2C%0D%0A++++department+VARCHAR%2850%29%2C%0D%0A++++credits+INT%2C%0D%0A++++teacher_id+INT%2C%0D%0A++++FOREIGN+KEY+%28teacher_id%29+REFERENCES+teachers%28id%29%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Courses+table%0D%0ACREATE+TABLE+courses+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++course_code+VARCHAR%2820%29+UNIQUE+NOT+NULL%2C%0D%0A++++course_name+VARCHAR%28100%29+NOT+NULL%2C%0D%0A++++department+VARCHAR%2850%29%2C%0D%0A++++credits+INT%2C%0D%0A++++teacher_id+INT%2C%0D%0A++++FOREIGN+KEY+%28teacher_id%29+REFERENCES+teachers%28id%29%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.3496 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Attendance table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    date DATE NOT NULL,
    status ENUM('present', 'absent', 'late') NOT NULL,
    remarks TEXT,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Attendance table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> attendance <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    student_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    course_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    <span class="cm-type">date</span> <span class="cm-type">DATE</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">status</span> <span class="cm-keyword">ENUM</span><span class="cm-bracket">(</span><span class="cm-string">'present'</span><span class="cm-punctuation">,</span> <span class="cm-string">'absent'</span><span class="cm-punctuation">,</span> <span class="cm-string">'late'</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/logical-operators.html%23operator_not">NOT</a></span> <span class="cm-atom">NULL</span><span class="cm-punctuation">,</span>
    remarks <span class="cm-type">TEXT</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>student_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> students<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>course_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> courses<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Attendance table
CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    date DATE NOT NULL,
    status ENUM(&#39;present&#39;, &#39;absent&#39;, &#39;late&#39;) NOT NULL,
    remarks TEXT,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Attendance+table%0D%0ACREATE+TABLE+attendance+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++student_id+INT%2C%0D%0A++++course_id+INT%2C%0D%0A++++date+DATE+NOT+NULL%2C%0D%0A++++status+ENUM%28%27present%27%2C+%27absent%27%2C+%27late%27%29+NOT+NULL%2C%0D%0A++++remarks+TEXT%2C%0D%0A++++FOREIGN+KEY+%28student_id%29+REFERENCES+students%28id%29%2C%0D%0A++++FOREIGN+KEY+%28course_id%29+REFERENCES+courses%28id%29%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Attendance+table%0D%0ACREATE+TABLE+attendance+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++student_id+INT%2C%0D%0A++++course_id+INT%2C%0D%0A++++date+DATE+NOT+NULL%2C%0D%0A++++status+ENUM%28%27present%27%2C+%27absent%27%2C+%27late%27%29+NOT+NULL%2C%0D%0A++++remarks+TEXT%2C%0D%0A++++FOREIGN+KEY+%28student_id%29+REFERENCES+students%28id%29%2C%0D%0A++++FOREIGN+KEY+%28course_id%29+REFERENCES+courses%28id%29%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 1.4712 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Grades table
CREATE TABLE grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    assignment1 DECIMAL(5,2),
    midterm DECIMAL(5,2),
    assignment2 DECIMAL(5,2),
    final DECIMAL(5,2),
    total DECIMAL(5,2),
    grade CHAR(2),
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Grades table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> grades <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    student_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    course_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    assignment1 <span class="cm-type">DECIMAL</span><span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    midterm <span class="cm-type">DECIMAL</span><span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    assignment2 <span class="cm-type">DECIMAL</span><span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    final <span class="cm-type">DECIMAL</span><span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    total <span class="cm-type">DECIMAL</span><span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    grade <span class="cm-type">CHAR</span><span class="cm-bracket">(</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>student_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> students<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>course_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> courses<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Grades table
CREATE TABLE grades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    course_id INT,
    assignment1 DECIMAL(5,2),
    midterm DECIMAL(5,2),
    assignment2 DECIMAL(5,2),
    final DECIMAL(5,2),
    total DECIMAL(5,2),
    grade CHAR(2),
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Grades+table%0D%0ACREATE+TABLE+grades+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++student_id+INT%2C%0D%0A++++course_id+INT%2C%0D%0A++++assignment1+DECIMAL%285%2C2%29%2C%0D%0A++++midterm+DECIMAL%285%2C2%29%2C%0D%0A++++assignment2+DECIMAL%285%2C2%29%2C%0D%0A++++final+DECIMAL%285%2C2%29%2C%0D%0A++++total+DECIMAL%285%2C2%29%2C%0D%0A++++grade+CHAR%282%29%2C%0D%0A++++FOREIGN+KEY+%28student_id%29+REFERENCES+students%28id%29%2C%0D%0A++++FOREIGN+KEY+%28course_id%29+REFERENCES+courses%28id%29%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Grades+table%0D%0ACREATE+TABLE+grades+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++student_id+INT%2C%0D%0A++++course_id+INT%2C%0D%0A++++assignment1+DECIMAL%285%2C2%29%2C%0D%0A++++midterm+DECIMAL%285%2C2%29%2C%0D%0A++++assignment2+DECIMAL%285%2C2%29%2C%0D%0A++++final+DECIMAL%285%2C2%29%2C%0D%0A++++total+DECIMAL%285%2C2%29%2C%0D%0A++++grade+CHAR%282%29%2C%0D%0A++++FOREIGN+KEY+%28student_id%29+REFERENCES+students%28id%29%2C%0D%0A++++FOREIGN+KEY+%28course_id%29+REFERENCES+courses%28id%29%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> MySQL returned an empty result set (i.e. zero rows). (Query took 0.3384 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Fees table
CREATE TABLE fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    amount DECIMAL(10,2),
    due_date DATE,
    status ENUM('paid', 'pending') DEFAULT 'pending',
    paid_date DATE,
    receipt_no VARCHAR(20) UNIQUE,
    FOREIGN KEY (student_id) REFERENCES students(id)
);
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Fees table</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">CREATE</a></span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/create-table.html">TABLE</a></span> fees <span class="cm-bracket">(</span>
    id <span class="cm-type">INT</span> <span class="cm-keyword">AUTO_INCREMENT</span> <span class="cm-keyword">PRIMARY</span> <span class="cm-keyword">KEY</span><span class="cm-punctuation">,</span>
    student_id <span class="cm-type">INT</span><span class="cm-punctuation">,</span>
    amount <span class="cm-type">DECIMAL</span><span class="cm-bracket">(</span><span class="cm-number">10</span><span class="cm-punctuation">,</span><span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
    due_date <span class="cm-type">DATE</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">status</span> <span class="cm-keyword">ENUM</span><span class="cm-bracket">(</span><span class="cm-string">'paid'</span><span class="cm-punctuation">,</span> <span class="cm-string">'pending'</span><span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_default">DEFAULT</a></span> <span class="cm-string">'pending'</span><span class="cm-punctuation">,</span>
    paid_date <span class="cm-type">DATE</span><span class="cm-punctuation">,</span>
    receipt_no <span class="cm-type">VARCHAR</span><span class="cm-bracket">(</span><span class="cm-number">20</span><span class="cm-bracket">)</span> <span class="cm-keyword">UNIQUE</span><span class="cm-punctuation">,</span>
    <span class="cm-keyword">FOREIGN</span> <span class="cm-keyword">KEY</span> <span class="cm-bracket">(</span>student_id<span class="cm-bracket">)</span> <span class="cm-keyword">REFERENCES</span> students<span class="cm-bracket">(</span>id<span class="cm-bracket">)</span>
<span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Fees table
CREATE TABLE fees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT,
    amount DECIMAL(10,2),
    due_date DATE,
    status ENUM(&#39;paid&#39;, &#39;pending&#39;) DEFAULT &#39;pending&#39;,
    paid_date DATE,
    receipt_no VARCHAR(20) UNIQUE,
    FOREIGN KEY (student_id) REFERENCES students(id)
);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Fees+table%0D%0ACREATE+TABLE+fees+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++student_id+INT%2C%0D%0A++++amount+DECIMAL%2810%2C2%29%2C%0D%0A++++due_date+DATE%2C%0D%0A++++status+ENUM%28%27paid%27%2C+%27pending%27%29+DEFAULT+%27pending%27%2C%0D%0A++++paid_date+DATE%2C%0D%0A++++receipt_no+VARCHAR%2820%29+UNIQUE%2C%0D%0A++++FOREIGN+KEY+%28student_id%29+REFERENCES+students%28id%29%0D%0A%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Fees+table%0D%0ACREATE+TABLE+fees+%28%0D%0A++++id+INT+AUTO_INCREMENT+PRIMARY+KEY%2C%0D%0A++++student_id+INT%2C%0D%0A++++amount+DECIMAL%2810%2C2%29%2C%0D%0A++++due_date+DATE%2C%0D%0A++++status+ENUM%28%27paid%27%2C+%27pending%27%29+DEFAULT+%27pending%27%2C%0D%0A++++paid_date+DATE%2C%0D%0A++++receipt_no+VARCHAR%2820%29+UNIQUE%2C%0D%0A++++FOREIGN+KEY+%28student_id%29+REFERENCES+students%28id%29%0D%0A%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> 5 rows inserted. <br> Inserted row id: 5 (Query took 0.0484 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">-- Insert sample data
INSERT INTO users (username, password, role, name, email) VALUES
('admin', '$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6', 'admin', 'Admin User', 'admin@edumanage.com'),
('teacher1', '$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6', 'teacher', 'Dr. Sarah Wilson', 'sarah@edumanage.com'),
('teacher2', '$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6', 'teacher', 'Mr. James Miller', 'james@edumanage.com'),
('student1', '$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6', 'student', 'John Smith', 'john@edumanage.com'),
('student2', '$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6', 'student', 'Emma Johnson', 'emma@edumanage.com');
</pre><div class="sql-highlight cm-s-default"><span class="cm-comment">-- Insert sample data</span>
<span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/insert.html">INSERT</a></span> <span class="cm-keyword">INTO</span> users <span class="cm-bracket">(</span>username<span class="cm-punctuation">,</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/encryption-functions.html%23function_password">password</a></span><span class="cm-punctuation">,</span> role<span class="cm-punctuation">,</span> name<span class="cm-punctuation">,</span> email<span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_values">VALUES</a></span>
<span class="cm-bracket">(</span><span class="cm-string">'admin'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'admin'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Admin User'</span><span class="cm-punctuation">,</span> <span class="cm-string">'admin@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'teacher1'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'teacher'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Dr. Sarah Wilson'</span><span class="cm-punctuation">,</span> <span class="cm-string">'sarah@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'teacher2'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'teacher'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mr. James Miller'</span><span class="cm-punctuation">,</span> <span class="cm-string">'james@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'student1'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'student'</span><span class="cm-punctuation">,</span> <span class="cm-string">'John Smith'</span><span class="cm-punctuation">,</span> <span class="cm-string">'john@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'student2'</span><span class="cm-punctuation">,</span> <span class="cm-string">'$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6'</span><span class="cm-punctuation">,</span> <span class="cm-string">'student'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Emma Johnson'</span><span class="cm-punctuation">,</span> <span class="cm-string">'emma@edumanage.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="-- Insert sample data
INSERT INTO users (username, password, role, name, email) VALUES
(&#39;admin&#39;, &#39;$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6&#39;, &#39;admin&#39;, &#39;Admin User&#39;, &#39;admin@edumanage.com&#39;),
(&#39;teacher1&#39;, &#39;$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6&#39;, &#39;teacher&#39;, &#39;Dr. Sarah Wilson&#39;, &#39;sarah@edumanage.com&#39;),
(&#39;teacher2&#39;, &#39;$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6&#39;, &#39;teacher&#39;, &#39;Mr. James Miller&#39;, &#39;james@edumanage.com&#39;),
(&#39;student1&#39;, &#39;$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6&#39;, &#39;student&#39;, &#39;John Smith&#39;, &#39;john@edumanage.com&#39;),
(&#39;student2&#39;, &#39;$2y$10$rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6&#39;, &#39;student&#39;, &#39;Emma Johnson&#39;, &#39;emma@edumanage.com&#39;);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=--+Insert+sample+data%0D%0AINSERT+INTO+users+%28username%2C+password%2C+role%2C+name%2C+email%29+VALUES%0D%0A%28%27admin%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27admin%27%2C+%27Admin+User%27%2C+%27admin%40edumanage.com%27%29%2C%0D%0A%28%27teacher1%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27teacher%27%2C+%27Dr.+Sarah+Wilson%27%2C+%27sarah%40edumanage.com%27%29%2C%0D%0A%28%27teacher2%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27teacher%27%2C+%27Mr.+James+Miller%27%2C+%27james%40edumanage.com%27%29%2C%0D%0A%28%27student1%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27student%27%2C+%27John+Smith%27%2C+%27john%40edumanage.com%27%29%2C%0D%0A%28%27student2%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27student%27%2C+%27Emma+Johnson%27%2C+%27emma%40edumanage.com%27%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=--+Insert+sample+data%0D%0AINSERT+INTO+users+%28username%2C+password%2C+role%2C+name%2C+email%29+VALUES%0D%0A%28%27admin%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27admin%27%2C+%27Admin+User%27%2C+%27admin%40edumanage.com%27%29%2C%0D%0A%28%27teacher1%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27teacher%27%2C+%27Dr.+Sarah+Wilson%27%2C+%27sarah%40edumanage.com%27%29%2C%0D%0A%28%27teacher2%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27teacher%27%2C+%27Mr.+James+Miller%27%2C+%27james%40edumanage.com%27%29%2C%0D%0A%28%27student1%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27student%27%2C+%27John+Smith%27%2C+%27john%40edumanage.com%27%29%2C%0D%0A%28%27student2%27%2C+%27%242y%2410%24rQZyTI6b5UO6KZxZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6Q6k.e6vJ6JZ6%27%2C+%27student%27%2C+%27Emma+Johnson%27%2C+%27emma%40edumanage.com%27%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> 2 rows inserted. <br> Inserted row id: 2 (Query took 0.1278 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">INSERT INTO students (user_id, class, parent_name, parent_contact) VALUES
(4, '10-A', 'Robert Smith', 'robert@example.com'),
(5, '9-B', 'David Johnson', 'david@example.com');
</pre><div class="sql-highlight cm-s-default"><span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/insert.html">INSERT</a></span> <span class="cm-keyword">INTO</span> students <span class="cm-bracket">(</span>user_id<span class="cm-punctuation">,</span> class<span class="cm-punctuation">,</span> parent_name<span class="cm-punctuation">,</span> parent_contact<span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_values">VALUES</a></span>
<span class="cm-bracket">(</span><span class="cm-number">4</span><span class="cm-punctuation">,</span> <span class="cm-string">'10-A'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Robert Smith'</span><span class="cm-punctuation">,</span> <span class="cm-string">'robert@example.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-number">5</span><span class="cm-punctuation">,</span> <span class="cm-string">'9-B'</span><span class="cm-punctuation">,</span> <span class="cm-string">'David Johnson'</span><span class="cm-punctuation">,</span> <span class="cm-string">'david@example.com'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="INSERT INTO students (user_id, class, parent_name, parent_contact) VALUES
(4, &#39;10-A&#39;, &#39;Robert Smith&#39;, &#39;robert@example.com&#39;),
(5, &#39;9-B&#39;, &#39;David Johnson&#39;, &#39;david@example.com&#39;);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=INSERT+INTO+students+%28user_id%2C+class%2C+parent_name%2C+parent_contact%29+VALUES%0D%0A%284%2C+%2710-A%27%2C+%27Robert+Smith%27%2C+%27robert%40example.com%27%29%2C%0D%0A%285%2C+%279-B%27%2C+%27David+Johnson%27%2C+%27david%40example.com%27%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=INSERT+INTO+students+%28user_id%2C+class%2C+parent_name%2C+parent_contact%29+VALUES%0D%0A%284%2C+%2710-A%27%2C+%27Robert+Smith%27%2C+%27robert%40example.com%27%29%2C%0D%0A%285%2C+%279-B%27%2C+%27David+Johnson%27%2C+%27david%40example.com%27%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> 2 rows inserted. <br> Inserted row id: 2 (Query took 0.1795 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">INSERT INTO teachers (user_id, subject, classes) VALUES
(2, 'Mathematics', '10-A, 10-B, 11-A'),
(3, 'Science', '9-A, 9-B, 10-C');
</pre><div class="sql-highlight cm-s-default"><span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/insert.html">INSERT</a></span> <span class="cm-keyword">INTO</span> teachers <span class="cm-bracket">(</span>user_id<span class="cm-punctuation">,</span> subject<span class="cm-punctuation">,</span> classes<span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_values">VALUES</a></span>
<span class="cm-bracket">(</span><span class="cm-number">2</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mathematics'</span><span class="cm-punctuation">,</span> <span class="cm-string">'10-A, 10-B, 11-A'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-number">3</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-string">'9-A, 9-B, 10-C'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="INSERT INTO teachers (user_id, subject, classes) VALUES
(2, &#39;Mathematics&#39;, &#39;10-A, 10-B, 11-A&#39;),
(3, &#39;Science&#39;, &#39;9-A, 9-B, 10-C&#39;);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=INSERT+INTO+teachers+%28user_id%2C+subject%2C+classes%29+VALUES%0D%0A%282%2C+%27Mathematics%27%2C+%2710-A%2C+10-B%2C+11-A%27%29%2C%0D%0A%283%2C+%27Science%27%2C+%279-A%2C+9-B%2C+10-C%27%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=INSERT+INTO+teachers+%28user_id%2C+subject%2C+classes%29+VALUES%0D%0A%282%2C+%27Mathematics%27%2C+%2710-A%2C+10-B%2C+11-A%27%29%2C%0D%0A%283%2C+%27Science%27%2C+%279-A%2C+9-B%2C+10-C%27%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> 3 rows inserted. <br> Inserted row id: 3 (Query took 0.1395 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">INSERT INTO courses (course_code, course_name, department, credits, teacher_id) VALUES
('MATH-101', 'Mathematics', 'Science', 4, 1),
('SCI-102', 'Science', 'Science', 3, 2),
('ENG-103', 'English Literature', 'Arts', 3, NULL);
</pre><div class="sql-highlight cm-s-default"><span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/insert.html">INSERT</a></span> <span class="cm-keyword">INTO</span> courses <span class="cm-bracket">(</span>course_code<span class="cm-punctuation">,</span> course_name<span class="cm-punctuation">,</span> department<span class="cm-punctuation">,</span> credits<span class="cm-punctuation">,</span> teacher_id<span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_values">VALUES</a></span>
<span class="cm-bracket">(</span><span class="cm-string">'MATH-101'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Mathematics'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-number">4</span><span class="cm-punctuation">,</span> <span class="cm-number">1</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'SCI-102'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Science'</span><span class="cm-punctuation">,</span> <span class="cm-number">3</span><span class="cm-punctuation">,</span> <span class="cm-number">2</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-string">'ENG-103'</span><span class="cm-punctuation">,</span> <span class="cm-string">'English Literature'</span><span class="cm-punctuation">,</span> <span class="cm-string">'Arts'</span><span class="cm-punctuation">,</span> <span class="cm-number">3</span><span class="cm-punctuation">,</span> <span class="cm-atom">NULL</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="INSERT INTO courses (course_code, course_name, department, credits, teacher_id) VALUES
(&#39;MATH-101&#39;, &#39;Mathematics&#39;, &#39;Science&#39;, 4, 1),
(&#39;SCI-102&#39;, &#39;Science&#39;, &#39;Science&#39;, 3, 2),
(&#39;ENG-103&#39;, &#39;English Literature&#39;, &#39;Arts&#39;, 3, NULL);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=INSERT+INTO+courses+%28course_code%2C+course_name%2C+department%2C+credits%2C+teacher_id%29+VALUES%0D%0A%28%27MATH-101%27%2C+%27Mathematics%27%2C+%27Science%27%2C+4%2C+1%29%2C%0D%0A%28%27SCI-102%27%2C+%27Science%27%2C+%27Science%27%2C+3%2C+2%29%2C%0D%0A%28%27ENG-103%27%2C+%27English+Literature%27%2C+%27Arts%27%2C+3%2C+NULL%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=INSERT+INTO+courses+%28course_code%2C+course_name%2C+department%2C+credits%2C+teacher_id%29+VALUES%0D%0A%28%27MATH-101%27%2C+%27Mathematics%27%2C+%27Science%27%2C+4%2C+1%29%2C%0D%0A%28%27SCI-102%27%2C+%27Science%27%2C+%27Science%27%2C+3%2C+2%29%2C%0D%0A%28%27ENG-103%27%2C+%27English+Literature%27%2C+%27Arts%27%2C+3%2C+NULL%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div><div class="result_query">
<div class="alert alert-success" role="alert">
  <img src="./edumanage_files/dot.gif" title="" alt="" class="icon ic_s_success"> 2 rows inserted. <br> Inserted row id: 2 (Query took 0.0820 seconds.)
</div>
<div class="sqlOuter"><code class="sql"><pre style="display: none;">INSERT INTO fees (student_id, amount, due_date, status, receipt_no) VALUES
(1, 250.00, '2023-11-05', 'paid', 'FEE-5001'),
(2, 250.00, '2023-11-05', 'pending', 'FEE-5002');
</pre><div class="sql-highlight cm-s-default"><span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/insert.html">INSERT</a></span> <span class="cm-keyword">INTO</span> fees <span class="cm-bracket">(</span>student_id<span class="cm-punctuation">,</span> amount<span class="cm-punctuation">,</span> due_date<span class="cm-punctuation">,</span> <span class="cm-keyword">status</span><span class="cm-punctuation">,</span> receipt_no<span class="cm-bracket">)</span> <span class="cm-keyword"><a target="mysql_doc" class="cm-sql-doc" href="http://localhost/phpmyadmin/url.php?url=https://dev.mysql.com/doc/refman/8.0/en/miscellaneous-functions.html%23function_values">VALUES</a></span>
<span class="cm-bracket">(</span><span class="cm-number">1</span><span class="cm-punctuation">,</span> <span class="cm-number">250.00</span><span class="cm-punctuation">,</span> <span class="cm-string">'2023-11-05'</span><span class="cm-punctuation">,</span> <span class="cm-string">'paid'</span><span class="cm-punctuation">,</span> <span class="cm-string">'FEE-5001'</span><span class="cm-bracket">)</span><span class="cm-punctuation">,</span>
<span class="cm-bracket">(</span><span class="cm-number">2</span><span class="cm-punctuation">,</span> <span class="cm-number">250.00</span><span class="cm-punctuation">,</span> <span class="cm-string">'2023-11-05'</span><span class="cm-punctuation">,</span> <span class="cm-string">'pending'</span><span class="cm-punctuation">,</span> <span class="cm-string">'FEE-5002'</span><span class="cm-bracket">)</span><span class="cm-punctuation">;</span>
</div></code></div><div class="tools d-print-none"><form action="http://localhost/phpmyadmin/index.php?route=/sql" method="post"><input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b"><input type="hidden" name="sql_query" value="INSERT INTO fees (student_id, amount, due_date, status, receipt_no) VALUES
(1, 250.00, &#39;2023-11-05&#39;, &#39;paid&#39;, &#39;FEE-5001&#39;),
(2, 250.00, &#39;2023-11-05&#39;, &#39;pending&#39;, &#39;FEE-5002&#39;);"></form> [&nbsp;<a href="http://localhost/phpmyadmin/index.php?route=/server/sql#" class="inline_edit_sql">Edit inline</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/server/sql&amp;sql_query=INSERT+INTO+fees+%28student_id%2C+amount%2C+due_date%2C+status%2C+receipt_no%29+VALUES%0D%0A%281%2C+250.00%2C+%272023-11-05%27%2C+%27paid%27%2C+%27FEE-5001%27%29%2C%0D%0A%282%2C+250.00%2C+%272023-11-05%27%2C+%27pending%27%2C+%27FEE-5002%27%29%3B&amp;show_query=1">Edit</a>&nbsp;] [&nbsp;<a href="http://localhost/phpmyadmin/index.php" data-post="route=/import&amp;sql_query=INSERT+INTO+fees+%28student_id%2C+amount%2C+due_date%2C+status%2C+receipt_no%29+VALUES%0D%0A%281%2C+250.00%2C+%272023-11-05%27%2C+%27paid%27%2C+%27FEE-5001%27%29%2C%0D%0A%282%2C+250.00%2C+%272023-11-05%27%2C+%27pending%27%2C+%27FEE-5002%27%29%3B&amp;show_query=1&amp;show_as_php=1">Create PHP code</a>&nbsp;]</div></div></div>

<div class="modal fade" id="simulateDmlModal" tabindex="-1" aria-labelledby="simulateDmlModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="simulateDmlModalLabel">Simulate query</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
</div>
      <div id="selflink" class="d-print-none">
      <a href="http://localhost/phpmyadmin/index.php?route=%2Fserver%2Fsql&amp;server=1" title="Open new phpMyAdmin window" target="_blank" rel="noopener noreferrer">
                  <img src="./edumanage_files/dot.gif" title="Open new phpMyAdmin window" alt="Open new phpMyAdmin window" class="icon ic_window-new">
              </a>
    </div>
  
  

  



  
  
  

<div tabindex="-1" role="dialog" class="ui-dialog ui-corner-all ui-widget ui-widget-content ui-front ui-dialog-buttons ui-draggable ui-resizable" aria-describedby="pma_navigation_settings" aria-labelledby="ui-id-1" style="position: fixed; height: auto; width: 700px; top: 25.7192px; left: 321.5px;"><div class="ui-dialog-titlebar ui-corner-all ui-widget-header ui-helper-clearfix ui-draggable-handle"><span id="ui-id-1" class="ui-dialog-title">Page-related settings</span><button type="button" class="ui-dialog-titlebar-close btn-close"></button></div><div id="pma_navigation_settings" class="ui-dialog-content ui-widget-content" style="display: block; width: auto; min-height: 134.734px; max-height: 496.375px; height: auto;"><div class="page_settings"><form method="post" action="http://localhost/phpmyadmin/index.php?route=%2Fserver%2Fsql&amp;server=1" class="config-form disableAjax">
  <input type="hidden" name="tab_hash" value="">
      <input type="hidden" name="check_page_refresh" id="check_page_refresh" value="1">
    <input type="hidden" name="token" value="62336b6e4b527e4b4e77644a7c392a5b">
  <input type="hidden" name="submit_save" value="Navi">

  <ul class="nav nav-tabs" id="configFormDisplayTab" role="tablist">
          <li class="nav-item" role="presentation">
        <a class="nav-link active" id="Navi_panel-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Navi_panel" data-bs-toggle="tab" role="tab" aria-controls="Navi_panel" aria-selected="true">Navigation panel</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_tree-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Navi_tree" data-bs-toggle="tab" role="tab" aria-controls="Navi_tree" aria-selected="false" tabindex="-1">Navigation tree</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_servers-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Navi_servers" data-bs-toggle="tab" role="tab" aria-controls="Navi_servers" aria-selected="false" tabindex="-1">Servers</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_databases-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Navi_databases" data-bs-toggle="tab" role="tab" aria-controls="Navi_databases" aria-selected="false" tabindex="-1">Databases</a>
      </li>
          <li class="nav-item" role="presentation">
        <a class="nav-link" id="Navi_tables-tab" href="http://localhost/phpmyadmin/index.php?route=/server/sql#Navi_tables" data-bs-toggle="tab" role="tab" aria-controls="Navi_tables" aria-selected="false" tabindex="-1">Tables</a>
      </li>
      </ul>
  <div class="tab-content">
          <div class="tab-pane fade show active" id="Navi_panel" role="tabpanel" aria-labelledby="Navi_panel-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Navigation panel</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Customize appearance of the navigation panel.</h6>
            
            <fieldset class="optbox">
              <legend>Navigation panel</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="ShowDatabasesNavigationAsTree">Show databases navigation as tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_ShowDatabasesNavigationAsTree" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>In the navigation panel, replaces the database tree with a selector</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="ShowDatabasesNavigationAsTree" id="ShowDatabasesNavigationAsTree" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#ShowDatabasesNavigationAsTree" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationLinkWithMainPanel">Link with main panel</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLinkWithMainPanel" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Link with main panel by highlighting the current database or table.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationLinkWithMainPanel" id="NavigationLinkWithMainPanel" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationLinkWithMainPanel" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationDisplayLogo">Display logo</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationDisplayLogo" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Show logo in navigation panel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationDisplayLogo" id="NavigationDisplayLogo" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationDisplayLogo" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationLogoLink">Logo link URL</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLogoLink" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>URL where logo in the navigation panel will point to.</small>
      </th>

  <td>
          <input type="text" name="NavigationLogoLink" id="NavigationLogoLink" value="index.php" class="w-75">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationLogoLink" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationLogoLinkWindow">Logo link target</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationLogoLinkWindow" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Open the linked page in the main window (<code>main</code>) or in a new one (<code>new</code>).</small>
      </th>

  <td>
          <select name="NavigationLogoLinkWindow" id="NavigationLogoLinkWindow" class="w-75">
                            <option value="main" selected="">main</option>
                            <option value="new">new</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationLogoLinkWindow" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreePointerEnable">Enable highlighting</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreePointerEnable" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Highlight server under the mouse cursor.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreePointerEnable" id="NavigationTreePointerEnable" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreePointerEnable" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="FirstLevelNavigationItems">Maximum items on first level</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_FirstLevelNavigationItems" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>The number of items that can be displayed on each page on the first level of the navigation tree.</small>
      </th>

  <td>
          <input type="number" name="FirstLevelNavigationItems" id="FirstLevelNavigationItems" value="100" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#FirstLevelNavigationItems" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeDisplayItemFilterMinimum">Minimum number of items to display the filter box</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDisplayItemFilterMinimum" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Defines the minimum number of items (tables, views, routines and events) to display a filter box.</small>
      </th>

  <td>
          <input type="number" name="NavigationTreeDisplayItemFilterMinimum" id="NavigationTreeDisplayItemFilterMinimum" value="30" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeDisplayItemFilterMinimum" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NumRecentTables">Recently used tables</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NumRecentTables" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Maximum number of recently used tables; set 0 to disable.</small>
      </th>

  <td>
          <input type="number" name="NumRecentTables" id="NumRecentTables" value="10" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NumRecentTables" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NumFavoriteTables">Favorite tables</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NumFavoriteTables" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Maximum number of favorite tables; set 0 to disable.</small>
      </th>

  <td>
          <input type="number" name="NumFavoriteTables" id="NumFavoriteTables" value="10" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NumFavoriteTables" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationWidth">Navigation panel width</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationWidth" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Set to 0 to collapse navigation panel.</small>
      </th>

  <td>
          <input type="number" name="NavigationWidth" id="NavigationWidth" value="240" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationWidth" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_tree" role="tabpanel" aria-labelledby="Navi_tree-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Navigation tree</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Customize the navigation tree.</h6>
            
            <fieldset class="optbox">
              <legend>Navigation tree</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="MaxNavigationItems">Maximum items in branch</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_MaxNavigationItems" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>The number of items that can be displayed on each page of the navigation tree.</small>
      </th>

  <td>
          <input type="number" name="MaxNavigationItems" id="MaxNavigationItems" value="50" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#MaxNavigationItems" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeEnableGrouping">Group items in the tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeEnableGrouping" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Group items in the navigation tree (determined by the separator defined in the Databases and Tables tabs above).</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeEnableGrouping" id="NavigationTreeEnableGrouping" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeEnableGrouping" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeEnableExpansion">Enable navigation tree expansion</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeEnableExpansion" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to offer the possibility of tree expansion in the navigation panel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeEnableExpansion" id="NavigationTreeEnableExpansion" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeEnableExpansion" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowTables">Show tables in tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowTables" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to show tables under database in the navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowTables" id="NavigationTreeShowTables" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeShowTables" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowViews">Show views in tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowViews" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to show views under database in the navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowViews" id="NavigationTreeShowViews" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeShowViews" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowFunctions">Show functions in tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowFunctions" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to show functions under database in the navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowFunctions" id="NavigationTreeShowFunctions" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeShowFunctions" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowProcedures">Show procedures in tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowProcedures" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to show procedures under database in the navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowProcedures" id="NavigationTreeShowProcedures" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeShowProcedures" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeShowEvents">Show events in tree</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeShowEvents" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to show events under database in the navigation tree</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeShowEvents" id="NavigationTreeShowEvents" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeShowEvents" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeAutoexpandSingleDb">Expand single database</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeAutoexpandSingleDb" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Whether to expand single database in the navigation tree automatically.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationTreeAutoexpandSingleDb" id="NavigationTreeAutoexpandSingleDb" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeAutoexpandSingleDb" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_servers" role="tabpanel" aria-labelledby="Navi_servers-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Servers</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Servers display options.</h6>
            
            <fieldset class="optbox">
              <legend>Servers</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="NavigationDisplayServers">Display servers selection</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationDisplayServers" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Display server choice at the top of the navigation panel.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="NavigationDisplayServers" id="NavigationDisplayServers" checked="">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationDisplayServers" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="DisplayServersList">Display servers as a list</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_DisplayServersList" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>Show server listing as a list instead of a drop down.</small>
      </th>

  <td>
          <span class="checkbox">
        <input type="checkbox" name="DisplayServersList" id="DisplayServersList">
      </span>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#DisplayServersList" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_databases" role="tabpanel" aria-labelledby="Navi_databases-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Databases</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Databases display options.</h6>
            
            <fieldset class="optbox">
              <legend>Databases</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="NavigationTreeDisplayDbFilterMinimum">Minimum number of databases to display the database filter box</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDisplayDbFilterMinimum" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <input type="number" name="NavigationTreeDisplayDbFilterMinimum" id="NavigationTreeDisplayDbFilterMinimum" value="30" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeDisplayDbFilterMinimum" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeDbSeparator">Database tree separator</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDbSeparator" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>String that separates databases into different tree levels.</small>
      </th>

  <td>
                <input type="text" size="25" name="NavigationTreeDbSeparator" id="NavigationTreeDbSeparator" value="_" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeDbSeparator" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
          <div class="tab-pane fade" id="Navi_tables" role="tabpanel" aria-labelledby="Navi_tables-tab">
        <div class="card border-top-0">
          <div class="card-body">
            <h5 class="card-title visually-hidden">Tables</h5>
                          <h6 class="card-subtitle mb-2 text-muted">Tables display options.</h6>
            
            <fieldset class="optbox">
              <legend>Tables</legend>

                            
              <table class="table table-borderless">
                <tbody><tr>
  <th>
    <label for="NavigationTreeDefaultTabTable">Target for quick access icon</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDefaultTabTable" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <select name="NavigationTreeDefaultTabTable" id="NavigationTreeDefaultTabTable" class="w-75">
                            <option value="structure" selected="">Structure</option>
                            <option value="sql">SQL</option>
                            <option value="search">Search</option>
                            <option value="insert">Insert</option>
                            <option value="browse">Browse</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeDefaultTabTable" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeDefaultTabTable2">Target for second quick access icon</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeDefaultTabTable2" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <select name="NavigationTreeDefaultTabTable2" id="NavigationTreeDefaultTabTable2" class="w-75">
                            <option value="" selected=""></option>
                            <option value="structure">Structure</option>
                            <option value="sql">SQL</option>
                            <option value="search">Search</option>
                            <option value="insert">Insert</option>
                            <option value="browse">Browse</option>
              </select>
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeDefaultTabTable2" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeTableSeparator">Table tree separator</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeTableSeparator" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
          <small>String that separates tables into different tree levels.</small>
      </th>

  <td>
                <input type="text" size="25" name="NavigationTreeTableSeparator" id="NavigationTreeTableSeparator" value="__" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeTableSeparator" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>
<tr>
  <th>
    <label for="NavigationTreeTableLevel">Maximum table tree depth</label>

          <span class="doc">
        <a href="http://localhost/phpmyadmin/doc/html/config.html#cfg_NavigationTreeTableLevel" target="documentation"><img src="./edumanage_files/dot.gif" title="Documentation" alt="Documentation" class="icon ic_b_help"></a>
      </span>
    
    
      </th>

  <td>
          <input type="number" name="NavigationTreeTableLevel" id="NavigationTreeTableLevel" value="1" class="">
    
    
    
          <a class="restore-default hide" href="http://localhost/phpmyadmin/index.php?route=/server/sql#NavigationTreeTableLevel" title="Restore default value" style="display: inline-block; opacity: 0.25;"><img src="./edumanage_files/dot.gif" title="Restore default value" alt="Restore default value" class="icon ic_s_reload" style="display: none;"></a>
    
          </td>

  </tr>

              </tbody></table>
            </fieldset>
          </div>

                  </div>
      </div>
      </div>
</form>

<script type="text/javascript">
  if (typeof configInlineParams === 'undefined' || !Array.isArray(configInlineParams)) {
    configInlineParams = [];
  }
  configInlineParams.push(function () {
    registerFieldValidator('FirstLevelNavigationItems', 'validatePositiveNumber', true);
registerFieldValidator('NavigationTreeDisplayItemFilterMinimum', 'validatePositiveNumber', true);
registerFieldValidator('NumRecentTables', 'validateNonNegativeNumber', true);
registerFieldValidator('NumFavoriteTables', 'validateNonNegativeNumber', true);
registerFieldValidator('NavigationWidth', 'validateNonNegativeNumber', true);
registerFieldValidator('MaxNavigationItems', 'validatePositiveNumber', true);
registerFieldValidator('NavigationTreeTableLevel', 'validatePositiveNumber', true);

    $.extend(Messages, {
      'error_nan_p': 'Not\u0020a\u0020positive\u0020number\u0021',
      'error_nan_nneg': 'Not\u0020a\u0020non\u002Dnegative\u0020number\u0021',
      'error_incorrect_port': 'Not\u0020a\u0020valid\u0020port\u0020number\u0021',
      'error_invalid_value': 'Incorrect\u0020value\u0021',
      'error_value_lte': 'Value\u0020must\u0020be\u0020less\u0020than\u0020or\u0020equal\u0020to\u0020\u0025s\u0021',
    });

    $.extend(defaultValues, {
      'ShowDatabasesNavigationAsTree': true,
      'NavigationLinkWithMainPanel': true,
      'NavigationDisplayLogo': true,
      'NavigationLogoLink': 'index.php',
      'NavigationLogoLinkWindow': ['main'],
      'NavigationTreePointerEnable': true,
      'FirstLevelNavigationItems': '100',
      'NavigationTreeDisplayItemFilterMinimum': '30',
      'NumRecentTables': '10',
      'NumFavoriteTables': '10',
      'NavigationWidth': '240',
      'MaxNavigationItems': '50',
      'NavigationTreeEnableGrouping': true,
      'NavigationTreeEnableExpansion': true,
      'NavigationTreeShowTables': true,
      'NavigationTreeShowViews': true,
      'NavigationTreeShowFunctions': true,
      'NavigationTreeShowProcedures': true,
      'NavigationTreeShowEvents': true,
      'NavigationTreeAutoexpandSingleDb': true,
      'NavigationDisplayServers': true,
      'DisplayServersList': false,
      'NavigationTreeDisplayDbFilterMinimum': '30',
      'NavigationTreeDbSeparator': '_',
      'NavigationTreeDefaultTabTable': ['structure'],
      'NavigationTreeDefaultTabTable2': [''],
      'NavigationTreeTableSeparator': '__',
      'NavigationTreeTableLevel': '1'
    });
  });
  if (typeof configScriptLoaded !== 'undefined' && configInlineParams) {
    loadInlineConfig();
  }
</script>
</div></div><div class="ui-dialog-buttonpane ui-widget-content ui-helper-clearfix"><div class="ui-dialog-buttonset"><button type="button" class="btn btn-primary">Apply</button><button type="button" class="btn btn-secondary">Cancel</button></div></div><div class="ui-resizable-handle ui-resizable-n" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-e" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-s" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-w" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-se ui-icon ui-icon-gripsmall-diagonal-se" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-sw" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-ne" style="z-index: 90;"></div><div class="ui-resizable-handle ui-resizable-nw" style="z-index: 90;"></div></div><div class="ui-widget-overlay ui-front" style="z-index: 800;"></div></body></html>