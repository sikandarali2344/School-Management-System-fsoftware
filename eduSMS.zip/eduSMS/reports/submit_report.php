<?php
// submit_report.php
session_start();
require_once '../config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_id = $_POST['report_id'] ?? 0;
    $class_id = $_POST['class_id'] ?? 0;
    $class_name = $_POST['class_name'] ?? '';
    $student_name = $_POST['student_name'] ?? '';
    $submission_data = trim($_POST['submission_data'] ?? '');
    $student_id = $_SESSION['user_id'];

    // Validation
    if (empty($report_id) || empty($submission_data)) {
        $_SESSION['error'] = "Please fill all required fields";
        header("Location: reports.php");
        exit();
    }

    // Check minimum length
    if (strlen($submission_data) < 100) {
        $_SESSION['error'] = "Please write at least 100 characters for your report";
        header("Location: reports.php");
        exit();
    }

    // Check if report is open
    $stmt = $pdo->prepare("SELECT * FROM reports WHERE id = ? AND is_open = 1");
    $stmt->execute([$report_id]);
    $report = $stmt->fetch();
    
    if (!$report) {
        $_SESSION['error'] = "This report is no longer accepting submissions";
        header("Location: reports.php");
        exit();
    }

    // Check if already submitted
    $check = $pdo->prepare("SELECT id FROM report_submissions WHERE report_id = ? AND student_id = ?");
    $check->execute([$report_id, $student_id]);
    
    if ($check->fetch()) {
        $_SESSION['error'] = "You have already submitted this report";
        header("Location: reports.php");
        exit();
    }

    // Insert submission
    $insert = $pdo->prepare("
        INSERT INTO report_submissions 
        (report_id, student_id, student_name, class_name, submission_data) 
        VALUES (?, ?, ?, ?, ?)
    ");
    
    $success = $insert->execute([
        $report_id, 
        $student_id, 
        $student_name, 
        $class_name, 
        $submission_data
    ]);

    if ($success) {
        $_SESSION['success'] = "Report submitted successfully!";
    } else {
        $_SESSION['error'] = "Failed to submit report. Please try again.";
    }

    header("Location: reports.php");
    exit();
}
?>