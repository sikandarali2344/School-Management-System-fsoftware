<?php
// reports/edit_complaint.php

// Start session first
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get current directory and include index.php
$current_dir = dirname(__FILE__);
$root_dir = dirname($current_dir);
require_once $root_dir . '/index.php';

// Only admin can access
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    die("<div class='error-message'>Access denied. Admin only.</div>");
}

$complaint_id = $_GET['id'] ?? 0;

if (!$complaint_id || !is_numeric($complaint_id)) {
    die("<div class='error-message'>Invalid complaint ID</div>");
}

// Get complaint details
try {
    $stmt = $pdo->prepare("
        SELECT c.*, u.name as student_name 
        FROM complaints c
        JOIN students s ON c.student_id = s.id
        JOIN users u ON s.user_id = u.id
        WHERE c.id = ?
    ");
    $stmt->execute([$complaint_id]);
    $complaint = $stmt->fetch();
    
    if (!$complaint) {
        die("<div class='error-message'>Complaint not found</div>");
    }
} catch (PDOException $e) {
    die("<div class='error-message'>Database error: " . htmlspecialchars($e->getMessage()) . "</div>");
}

// Get teachers for assignment
try {
    $teachers = $pdo->query("
        SELECT t.id, u.name 
        FROM teachers t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.status = 'active'
        ORDER BY u.name
    ")->fetchAll();
} catch (PDOException $e) {
    $teachers = [];
}
?>

<style>
.edit-complaint-form {
    padding: 20px;
}

.edit-complaint-form h2 {
    color: #4361ee;
    margin-bottom: 20px;
    font-size: 1.5rem;
}

.form-control:read-only {
    background-color: #f8f9fa;
}

.btn-group {
    display: flex;
    gap: 10px;
    margin-top: 20px;
}
</style>

<div class="edit-complaint-form">
    <h2>Edit Complaint #COMP-<?php echo $complaint['id']; ?></h2>
    
    <form method="POST" action="../index.php?page=complaints">
        <input type="hidden" name="complaint_id" value="<?php echo $complaint['id']; ?>">
        
        <div class="form-row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Student</label>
                    <input type="text" class="form-control" value="<?php echo htmlspecialchars($complaint['student_name']); ?>" readonly>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Priority *</label>
                    <select name="priority" class="form-control" required>
                        <option value="low" <?php echo $complaint['priority'] == 'low' ? 'selected' : ''; ?>>Low</option>
                        <option value="medium" <?php echo $complaint['priority'] == 'medium' ? 'selected' : ''; ?>>Medium</option>
                        <option value="high" <?php echo $complaint['priority'] == 'high' ? 'selected' : ''; ?>>High</option>
                        <option value="urgent" <?php echo $complaint['priority'] == 'urgent' ? 'selected' : ''; ?>>Urgent</option>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="form-row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label>Status *</label>
                    <select name="status" class="form-control" required>
                        <option value="pending" <?php echo $complaint['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="in_progress" <?php echo $complaint['status'] == 'in_progress' ? 'selected' : ''; ?>>In Progress</option>
                        <option value="resolved" <?php echo $complaint['status'] == 'resolved' ? 'selected' : ''; ?>>Resolved</option>
                        <option value="rejected" <?php echo $complaint['status'] == 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label>Assign To Teacher</label>
                    <select name="assigned_to" class="form-control">
                        <option value="">-- Select Teacher --</option>
                        <?php foreach ($teachers as $teacher): ?>
                            <option value="<?php echo $teacher['id']; ?>" 
                                <?php echo $complaint['assigned_to'] == $teacher['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($teacher['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
        </div>
        
        <div class="form-group mb-3">
            <label>Resolution Notes</label>
            <textarea name="resolution_notes" class="form-control" rows="4" 
                      placeholder="Enter resolution details..."><?php echo htmlspecialchars($complaint['resolution_notes'] ?? ''); ?></textarea>
            <small class="text-muted">This will be visible to the student if complaint is resolved.</small>
        </div>
        
        <div class="btn-group">
            <button type="submit" name="update_status" class="btn btn-success">
                <i class="fas fa-save"></i> Update Complaint
            </button>
            <button type="button" class="btn btn-secondary" onclick="closeEditComplaintModal()">
                <i class="fas fa-times"></i> Cancel
            </button>
        </div>
    </form>
</div>