<?php
session_start();
require_once 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

if (isset($_GET['id']) && isset($_GET['action'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];
    
    if (in_array($action, ['open', 'close'])) {
        $is_open = ($action == 'open') ? 1 : 0;
        
        $stmt = $pdo->prepare("UPDATE reports SET is_open = ? WHERE id = ?");
        $stmt->execute([$is_open, $id]);
        
        $_SESSION['message'] = "Report status updated successfully";
    }
}

header("Location: reports.php");
exit();
?>