<?php
// reports/reports.php
?>
<div class="card">
    <div class="card-header">
        <h2 class="card-title"><i class="fas fa-chart-bar"></i> Reports & Analytics</h2>
        <div class="btn-group">
            <button class="btn btn-info" onclick="exportReport('pdf')">
                <i class="fas fa-file-pdf"></i> Export PDF
            </button>
            <button class="btn btn-success" onclick="exportReport('excel')">
                <i class="fas fa-file-excel"></i> Export Excel
            </button>
            <button class="btn btn-primary" onclick="printReport()">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
    </div>

    <?php if (isset($success)): ?>
        <div class="success-message"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if (isset($error)): ?>
        <div class="error-message"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Report Type Selection -->
    <div class="card" style="margin-bottom: 20px;">
        <div class="card-header">
            <h3 class="card-title">Select Report Type</h3>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Report Type *</label>
                <select id="reportType" class="form-control" onchange="loadReportForm()" required>
                    <option value="">-- Select Report --</option>
                    <option value="attendance">Attendance Report</option>
                    <option value="fees">Fees Collection Report</option>
                    <option value="student">Student Performance Report</option>
                    <option value="teacher">Teacher Performance Report</option>
                    <option value="course">Course-wise Report</option>
                    <option value="class">Class-wise Report</option>
                    <option value="financial">Financial Summary</option>
                    <option value="feedback">Student Feedback Report</option>
                    <option value="operations">Operations Report</option>
                </select>
            </div>
            <div class="form-group">
                <label>Period</label>
                <select id="reportPeriod" class="form-control">
                    <option value="today">Today</option>
                    <option value="week">This Week</option>
                    <option value="month" selected>This Month</option>
                    <option value="quarter">This Quarter</option>
                    <option value="year">This Year</option>
                    <option value="custom">Custom Range</option>
                </select>
            </div>
        </div>
        
        <!-- Custom Date Range -->
        <div id="customDateRange" style="display: none;">
            <div class="form-row">
                <div class="form-group">
                    <label>From Date</label>
                    <input type="date" id="fromDate" class="form-control" value="<?php echo date('Y-m-01'); ?>">
                </div>
                <div class="form-group">
                    <label>To Date</label>
                    <input type="date" id="toDate" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                </div>
            </div>
        </div>
        
        <div class="form-group">
            <button class="btn btn-primary" onclick="generateReport()">
                <i class="fas fa-play"></i> Generate Report
            </button>
        </div>
    </div>

    <!-- Report Content Area -->
    <div id="reportContent">
        <!-- Reports will be loaded here via AJAX -->
        <div class="text-center" style="padding: 50px; color: #666;">
            <i class="fas fa-chart-line fa-4x" style="margin-bottom: 20px;"></i>
            <h3>No Report Selected</h3>
            <p>Please select a report type and click "Generate Report"</p>
        </div>
    </div>
</div>

<script>
// Handle period selection
document.getElementById('reportPeriod').addEventListener('change', function() {
    const customRange = document.getElementById('customDateRange');
    if (this.value === 'custom') {
        customRange.style.display = 'block';
    } else {
        customRange.style.display = 'none';
    }
});

// Load report form based on type
function loadReportForm() {
    const reportType = document.getElementById('reportType').value;
    const reportContent = document.getElementById('reportContent');
    
    if (!reportType) {
        reportContent.innerHTML = `
            <div class="text-center" style="padding: 50px; color: #666;">
                <i class="fas fa-chart-line fa-4x" style="margin-bottom: 20px;"></i>
                <h3>No Report Selected</h3>
                <p>Please select a report type and click "Generate Report"</p>
            </div>
        `;
        return;
    }
}

// Generate Report
function generateReport() {
    const reportType = document.getElementById('reportType').value;
    const period = document.getElementById('reportPeriod').value;
    const fromDate = document.getElementById('fromDate')?.value || '';
    const toDate = document.getElementById('toDate')?.value || '';
    
    if (!reportType) {
        alert('Please select a report type');
        return;
    }
    
    // Show loading
    document.getElementById('reportContent').innerHTML = `
        <div class="text-center" style="padding: 50px;">
            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                <span class="sr-only">Loading...</span>
            </div>
            <p class="mt-3">Generating report...</p>
        </div>
    `;
    
    // AJAX request to load report
    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'reports/generate_report.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            document.getElementById('reportContent').innerHTML = xhr.responseText;
        } else {
            document.getElementById('reportContent').innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i> Error loading report
                </div>
            `;
        }
    };
    xhr.send(`report_type=${reportType}&period=${period}&from_date=${fromDate}&to_date=${toDate}`);
}

// Export Report
function exportReport(format) {
    const reportType = document.getElementById('reportType').value;
    if (!reportType) {
        alert('Please generate a report first');
        return;
    }
    
    const period = document.getElementById('reportPeriod').value;
    const fromDate = document.getElementById('fromDate')?.value || '';
    const toDate = document.getElementById('toDate')?.value || '';
    
    window.open(`reports/export_report.php?type=${reportType}&format=${format}&period=${period}&from_date=${fromDate}&to_date=${toDate}`, '_blank');
}

// Print Report
function printReport() {
    const printContent = document.getElementById('reportContent').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = `
        <html>
            <head>
                <title>Report - <?php echo $settings['school_name']; ?></title>
                <style>
                    body { font-family: Arial, sans-serif; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f5f5f5; }
                    .report-header { text-align: center; margin-bottom: 30px; }
                    .report-header h1 { color: #333; }
                    .report-footer { margin-top: 30px; text-align: center; color: #666; }
                </style>
            </head>
            <body>
                <div class="report-header">
                    <h1><?php echo $settings['school_name']; ?></h1>
                    <h3>Report Generated on: <?php echo date('F j, Y'); ?></h3>
                </div>
                ${printContent}
                <div class="report-footer">
                    <hr>
                    <p>Generated by EduManage System</p>
                </div>
            </body>
        </html>
    `;
    
    window.print();
    document.body.innerHTML = originalContent;
    location.reload();
}
</script>