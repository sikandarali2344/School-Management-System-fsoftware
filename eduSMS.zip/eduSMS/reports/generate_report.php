<?php
// reports/generate_report.php
session_start();
require_once '../index.php'; // Include main file for DB connection

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    die("<div class='error-message'>Access denied. Admin only.</div>");
}

// Get parameters
$report_type = $_POST['report_type'] ?? '';
$period = $_POST['period'] ?? 'month';
$from_date = $_POST['from_date'] ?? date('Y-m-01');
$to_date = $_POST['to_date'] ?? date('Y-m-d');

// Set date range based on period
switch ($period) {
    case 'today':
        $from_date = $to_date = date('Y-m-d');
        break;
    case 'week':
        $from_date = date('Y-m-d', strtotime('monday this week'));
        $to_date = date('Y-m-d', strtotime('sunday this week'));
        break;
    case 'month':
        $from_date = date('Y-m-01');
        $to_date = date('Y-m-d');
        break;
    case 'quarter':
        $quarter = ceil(date('n') / 3);
        $from_date = date('Y-m-d', strtotime(date('Y') . '-' . (($quarter * 3) - 2) . '-01'));
        $to_date = date('Y-m-t', strtotime(date('Y') . '-' . ($quarter * 3) . '-01'));
        break;
    case 'year':
        $from_date = date('Y-01-01');
        $to_date = date('Y-12-31');
        break;
}

// Generate report based on type
switch ($report_type) {
    case 'attendance':
        generateAttendanceReport($pdo, $from_date, $to_date);
        break;
    case 'fees':
        generateFeesReport($pdo, $from_date, $to_date);
        break;
    case 'student':
        generateStudentReport($pdo, $from_date, $to_date);
        break;
    case 'teacher':
        generateTeacherReport($pdo, $from_date, $to_date);
        break;
    case 'course':
        generateCourseReport($pdo, $from_date, $to_date);
        break;
    case 'class':
        generateClassReport($pdo, $from_date, $to_date);
        break;
    case 'financial':
        generateFinancialReport($pdo, $from_date, $to_date);
        break;
    case 'feedback':
        generateFeedbackReport($pdo, $from_date, $to_date);
        break;
    case 'operations':
        generateOperationsReport($pdo, $from_date, $to_date);
        break;
    default:
        echo "<div class='error-message'>Invalid report type</div>";
}

// ========== REPORT FUNCTIONS ==========

function generateAttendanceReport($pdo, $from_date, $to_date) {
    $stmt = $pdo->prepare("
        SELECT 
            DATE(ar.attendance_date) as date,
            c.class_name,
            c.section,
            COUNT(*) as total_students,
            SUM(CASE WHEN ar.status = 'present' THEN 1 ELSE 0 END) as present,
            SUM(CASE WHEN ar.status = 'absent' THEN 1 ELSE 0 END) as absent,
            SUM(CASE WHEN ar.status = 'late' THEN 1 ELSE 0 END) as late,
            SUM(CASE WHEN ar.status = 'half_day' THEN 1 ELSE 0 END) as half_day,
            ROUND((SUM(CASE WHEN ar.status = 'present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 2) as attendance_percentage
        FROM attendance_records ar
        JOIN classes c ON ar.class_id = c.id
        WHERE DATE(ar.attendance_date) BETWEEN ? AND ?
        GROUP BY DATE(ar.attendance_date), ar.class_id
        ORDER BY date DESC, class_name
    ");
    $stmt->execute([$from_date, $to_date]);
    $attendance = $stmt->fetchAll();
    
    // Summary
    $summary_stmt = $pdo->prepare("
        SELECT 
            COUNT(DISTINCT DATE(ar.attendance_date)) as total_days,
            COUNT(DISTINCT ar.student_id) as total_students,
            COUNT(*) as total_records,
            SUM(CASE WHEN ar.status = 'present' THEN 1 ELSE 0 END) as total_present,
            SUM(CASE WHEN ar.status = 'absent' THEN 1 ELSE 0 END) as total_absent,
            ROUND((SUM(CASE WHEN ar.status = 'present' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)), 2) as overall_percentage
        FROM attendance_records ar
        WHERE DATE(ar.attendance_date) BETWEEN ? AND ?
    ");
    $summary_stmt->execute([$from_date, $to_date]);
    $summary = $summary_stmt->fetch();
    ?>
    
    <div class="report-container">
        <div class="report-header">
            <h2><i class="fas fa-clipboard-check"></i> Attendance Report</h2>
            <p>Period: <?php echo date('M d, Y', strtotime($from_date)); ?> to <?php echo date('M d, Y', strtotime($to_date)); ?></p>
        </div>
        
        <!-- Summary Cards -->
        <div class="stats-container" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: #4cc9f0;">
                    <i class="fas fa-calendar-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['total_days']; ?></h3>
                    <p>Total Days</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #2ecc71;">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['total_students']; ?></h3>
                    <p>Total Students</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #3498db;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['total_present']; ?></h3>
                    <p>Total Present</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #f72585;">
                    <i class="fas fa-times-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['total_absent']; ?></h3>
                    <p>Total Absent</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #9b59b6;">
                    <i class="fas fa-percentage"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['overall_percentage']; ?>%</h3>
                    <p>Overall Attendance</p>
                </div>
            </div>
        </div>
        
        <!-- Detailed Table -->
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Class</th>
                        <th>Total Students</th>
                        <th>Present</th>
                        <th>Absent</th>
                        <th>Late</th>
                        <th>Half Day</th>
                        <th>Percentage</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($attendance) > 0): ?>
                        <?php foreach ($attendance as $record): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($record['date'])); ?></td>
                                <td><?php echo htmlspecialchars($record['class_name'] . ' - ' . $record['section']); ?></td>
                                <td><?php echo $record['total_students']; ?></td>
                                <td><span class="badge badge-success"><?php echo $record['present']; ?></span></td>
                                <td><span class="badge badge-danger"><?php echo $record['absent']; ?></span></td>
                                <td><span class="badge badge-warning"><?php echo $record['late']; ?></span></td>
                                <td><span class="badge badge-info"><?php echo $record['half_day']; ?></span></td>
                                <td>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar <?php echo $record['attendance_percentage'] > 75 ? 'bg-success' : ($record['attendance_percentage'] > 50 ? 'bg-warning' : 'bg-danger'); ?>" 
                                             role="progressbar" 
                                             style="width: <?php echo min($record['attendance_percentage'], 100); ?>%">
                                            <?php echo $record['attendance_percentage']; ?>%
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">No attendance records found for this period</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function generateFeesReport($pdo, $from_date, $to_date) {
    global $settings;
    
    // Check if fees table exists
    $table_exists = $pdo->query("SHOW TABLES LIKE 'fees'")->fetch();
    
    if (!$table_exists) {
        echo "<div class='error-message'>Fees table not found. Please setup fees system first.</div>";
        return;
    }
    
    // Check if fee_types table exists
    $fee_types_exists = $pdo->query("SHOW TABLES LIKE 'fee_types'")->fetch();
    
    if (!$fee_types_exists) {
        // Create fee_types table if doesn't exist
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS fee_types (
                id INT PRIMARY KEY AUTO_INCREMENT,
                type_name VARCHAR(100) NOT NULL,
                amount DECIMAL(10,2) NOT NULL,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ");
        
        // Insert sample data
        $pdo->exec("
            INSERT INTO fee_types (type_name, amount, description) VALUES
            ('Tuition Fee', 5000.00, 'Monthly tuition fee'),
            ('Examination Fee', 1000.00, 'Examination charges'),
            ('Library Fee', 500.00, 'Library maintenance'),
            ('Sports Fee', 300.00, 'Sports equipment'),
            ('Transport Fee', 2000.00, 'Transportation charges')
        ");
    }
    
    $stmt = $pdo->prepare("
        SELECT 
            f.*,
            s.id as student_id,
            u.name as student_name,
            c.class_name,
            c.section,
            ft.type_name,
            ft.amount as expected_amount
        FROM fees f
        JOIN students s ON f.student_id = s.id
        JOIN users u ON s.user_id = u.id
        JOIN classes c ON s.class_id = c.id
        JOIN fee_types ft ON f.fee_type_id = ft.id
        WHERE DATE(f.payment_date) BETWEEN ? AND ?
        ORDER BY f.payment_date DESC
    ");
    $stmt->execute([$from_date, $to_date]);
    $fees = $stmt->fetchAll();
    
    // Summary
    $summary_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_transactions,
            SUM(f.amount_paid) as total_collected,
            AVG(f.amount_paid) as average_payment,
            COUNT(DISTINCT f.student_id) as unique_students,
            SUM(CASE WHEN f.payment_status = 'paid' THEN 1 ELSE 0 END) as paid_count,
            SUM(CASE WHEN f.payment_status = 'pending' THEN 1 ELSE 0 END) as pending_count
        FROM fees f
        WHERE DATE(f.payment_date) BETWEEN ? AND ?
    ");
    $summary_stmt->execute([$from_date, $to_date]);
    $summary = $summary_stmt->fetch();
    ?>
    
    <div class="report-container">
        <div class="report-header">
            <h2><i class="fas fa-money-check-alt"></i> Fees Collection Report</h2>
            <p>Period: <?php echo date('M d, Y', strtotime($from_date)); ?> to <?php echo date('M d, Y', strtotime($to_date)); ?></p>
        </div>
        
        <!-- Summary Cards -->
        <div class="stats-container" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: #27ae60;">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $settings['currency']; ?> <?php echo number_format($summary['total_collected'] ?? 0, 2); ?></h3>
                    <p>Total Collected</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #3498db;">
                    <i class="fas fa-exchange-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['total_transactions'] ?? 0; ?></h3>
                    <p>Total Transactions</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #9b59b6;">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['unique_students'] ?? 0; ?></h3>
                    <p>Unique Students</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #f39c12;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['paid_count'] ?? 0; ?></h3>
                    <p>Paid Transactions</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #e74c3c;">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['pending_count'] ?? 0; ?></h3>
                    <p>Pending Transactions</p>
                </div>
            </div>
        </div>
        
        <!-- Detailed Table -->
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Receipt No</th>
                        <th>Date</th>
                        <th>Student</th>
                        <th>Class</th>
                        <th>Fee Type</th>
                        <th>Amount</th>
                        <th>Payment Method</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($fees) > 0): ?>
                        <?php foreach ($fees as $fee): ?>
                            <tr>
                                <td>#<?php echo $fee['receipt_number'] ?? 'N/A'; ?></td>
                                <td><?php echo date('M d, Y', strtotime($fee['payment_date'])); ?></td>
                                <td><?php echo htmlspecialchars($fee['student_name']); ?></td>
                                <td><?php echo htmlspecialchars($fee['class_name'] . ' - ' . $fee['section']); ?></td>
                                <td><?php echo htmlspecialchars($fee['type_name']); ?></td>
                                <td>
                                    <strong><?php echo $settings['currency']; ?> <?php echo number_format($fee['amount_paid'], 2); ?></strong>
                                    <?php if (isset($fee['expected_amount']) && $fee['amount_paid'] < $fee['expected_amount']): ?>
                                        <br><small class="text-danger">Due: <?php echo $settings['currency']; ?> <?php echo number_format($fee['expected_amount'] - $fee['amount_paid'], 2); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo ucfirst($fee['payment_method'] ?? 'N/A'); ?></td>
                                <td>
                                    <span class="badge badge-<?php 
                                        if (($fee['payment_status'] ?? '') == 'paid') echo 'success';
                                        elseif (($fee['payment_status'] ?? '') == 'partial') echo 'warning';
                                        else echo 'danger';
                                    ?>">
                                        <?php echo ucfirst($fee['payment_status'] ?? 'Unknown'); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">No fee records found for this period</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function generateStudentReport($pdo, $from_date, $to_date) {
    global $settings;
    
    // Student Performance Report
    $query = "
        SELECT 
            s.id,
            u.name as student_name,
            u.email,
            c.class_name,
            c.section,
            COUNT(DISTINCT ar.attendance_date) as attendance_days,
            SUM(CASE WHEN ar.status = 'present' THEN 1 ELSE 0 END) as present_days,
            COALESCE(AVG(g.marks), 0) as average_marks,
            COUNT(DISTINCT g.exam_id) as exams_taken,
            COALESCE(SUM(f.amount_paid), 0) as total_fees_paid,
            COUNT(DISTINCT f.id) as fee_transactions
        FROM students s
        JOIN users u ON s.user_id = u.id
        JOIN classes c ON s.class_id = c.id
        LEFT JOIN attendance_records ar ON s.id = ar.student_id AND DATE(ar.attendance_date) BETWEEN :from_date AND :to_date
        LEFT JOIN grades g ON s.id = g.student_id
        LEFT JOIN fees f ON s.id = f.student_id AND DATE(f.payment_date) BETWEEN :from_date2 AND :to_date2
        WHERE s.status = 'active'
        GROUP BY s.id
        ORDER BY average_marks DESC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':from_date' => $from_date,
        ':to_date' => $to_date,
        ':from_date2' => $from_date,
        ':to_date2' => $to_date
    ]);
    $students = $stmt->fetchAll();
    ?>
    
    <div class="report-container">
        <div class="report-header">
            <h2><i class="fas fa-user-graduate"></i> Student Performance Report</h2>
            <p>Period: <?php echo date('M d, Y', strtotime($from_date)); ?> to <?php echo date('M d, Y', strtotime($to_date)); ?></p>
        </div>
        
        <!-- Summary Stats -->
        <?php
        $total_students = count($students);
        $total_attendance_days = array_sum(array_column($students, 'attendance_days'));
        $total_present_days = array_sum(array_column($students, 'present_days'));
        $avg_attendance = $total_attendance_days > 0 ? ($total_present_days / $total_attendance_days) * 100 : 0;
        
        $total_marks = 0;
        $students_with_marks = 0;
        foreach ($students as $student) {
            if ($student['average_marks'] > 0) {
                $total_marks += $student['average_marks'];
                $students_with_marks++;
            }
        }
        $avg_marks = $students_with_marks > 0 ? $total_marks / $students_with_marks : 0;
        ?>
        
        <div class="stats-container" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: #4361ee;">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_students; ?></h3>
                    <p>Total Students</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #4cc9f0;">
                    <i class="fas fa-percentage"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo round($avg_attendance, 1); ?>%</h3>
                    <p>Avg Attendance</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #f72585;">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo round($avg_marks, 1); ?></h3>
                    <p>Average Marks</p>
                </div>
            </div>
        </div>
        
        <!-- Student Performance Table -->
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Student Name</th>
                        <th>Class</th>
                        <th>Attendance</th>
                        <th>Average Marks</th>
                        <th>Exams Taken</th>
                        <th>Fees Paid</th>
                        <th>Performance</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($students) > 0): ?>
                        <?php foreach ($students as $index => $student): 
                            $attendance_percentage = $student['attendance_days'] > 0 ? ($student['present_days'] / $student['attendance_days']) * 100 : 0;
                            $performance_score = ($attendance_percentage * 0.3) + ($student['average_marks'] * 0.7);
                        ?>
                            <tr>
                                <td><?php echo $index + 1; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($student['student_name']); ?></strong><br>
                                    <small><?php echo htmlspecialchars($student['email']); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($student['class_name'] . ' - ' . $student['section']); ?></td>
                                <td>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar <?php echo $attendance_percentage > 75 ? 'bg-success' : ($attendance_percentage > 50 ? 'bg-warning' : 'bg-danger'); ?>" 
                                             role="progressbar" 
                                             style="width: <?php echo min($attendance_percentage, 100); ?>%">
                                            <?php echo round($attendance_percentage, 1); ?>%
                                        </div>
                                    </div>
                                    <small><?php echo $student['present_days']; ?> of <?php echo $student['attendance_days']; ?> days</small>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $student['average_marks'] > 70 ? 'success' : ($student['average_marks'] > 50 ? 'warning' : 'danger'); ?>">
                                        <?php echo round($student['average_marks'], 1); ?>
                                    </span>
                                </td>
                                <td><?php echo $student['exams_taken']; ?></td>
                                <td>
                                    <?php echo $settings['currency']; ?> <?php echo number_format($student['total_fees_paid'], 2); ?>
                                    <br><small>(<?php echo $student['fee_transactions']; ?> transactions)</small>
                                </td>
                                <td>
                                    <div class="progress" style="height: 20px;">
                                        <div class="progress-bar <?php echo $performance_score > 70 ? 'bg-success' : ($performance_score > 50 ? 'bg-warning' : 'bg-danger'); ?>" 
                                             role="progressbar" 
                                             style="width: <?php echo min($performance_score, 100); ?>%">
                                            <?php echo round($performance_score, 1); ?>%
                                        </div>
                                    </div>
                                    <small>
                                        <?php if ($performance_score > 80): ?>
                                            Excellent
                                        <?php elseif ($performance_score > 60): ?>
                                            Good
                                        <?php elseif ($performance_score > 40): ?>
                                            Average
                                        <?php else: ?>
                                            Needs Improvement
                                        <?php endif; ?>
                                    </small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center py-4">No student data found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function generateFeedbackReport($pdo, $from_date, $to_date) {
    // Check if feedback table exists
    $table_exists = $pdo->query("SHOW TABLES LIKE 'feedback'")->fetch();
    
    if (!$table_exists) {
        // Create feedback table if it doesn't exist
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS feedback (
                id INT PRIMARY KEY AUTO_INCREMENT,
                student_id INT NOT NULL,
                teacher_id INT,
                course_id INT,
                rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
                comments TEXT,
                feedback_date DATE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (student_id) REFERENCES students(id),
                FOREIGN KEY (teacher_id) REFERENCES teachers(id),
                FOREIGN KEY (course_id) REFERENCES courses(id)
            )
        ");
        
        echo "<div class='alert alert-info'>Feedback table created. No feedback data available yet.</div>";
        return;
    }
    
    // Get feedback data
    $stmt = $pdo->prepare("
        SELECT 
            f.*,
            u.name as student_name,
            ut.name as teacher_name,
            c.course_name,
            cl.class_name,
            cl.section
        FROM feedback f
        LEFT JOIN students s ON f.student_id = s.id
        LEFT JOIN users u ON s.user_id = u.id
        LEFT JOIN teachers t ON f.teacher_id = t.id
        LEFT JOIN users ut ON t.user_id = ut.id
        LEFT JOIN courses c ON f.course_id = c.id
        LEFT JOIN classes cl ON s.class_id = cl.id
        WHERE DATE(f.feedback_date) BETWEEN ? AND ?
        ORDER BY f.feedback_date DESC
    ");
    $stmt->execute([$from_date, $to_date]);
    $feedback = $stmt->fetchAll();
    
    // Summary
    $summary_stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_feedback,
            AVG(rating) as average_rating,
            COUNT(DISTINCT student_id) as unique_students,
            COUNT(DISTINCT teacher_id) as teachers_rated,
            COUNT(DISTINCT course_id) as courses_rated
        FROM feedback
        WHERE DATE(feedback_date) BETWEEN ? AND ?
    ");
    $summary_stmt->execute([$from_date, $to_date]);
    $summary = $summary_stmt->fetch();
    ?>
    
    <div class="report-container">
        <div class="report-header">
            <h2><i class="fas fa-comment-dots"></i> Student Feedback Report</h2>
            <p>Period: <?php echo date('M d, Y', strtotime($from_date)); ?> to <?php echo date('M d, Y', strtotime($to_date)); ?></p>
        </div>
        
        <!-- Summary Cards -->
        <div class="stats-container" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: #f39c12;">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($summary['average_rating'] ?? 0, 1); ?>/5</h3>
                    <p>Average Rating</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #3498db;">
                    <i class="fas fa-comments"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['total_feedback'] ?? 0; ?></h3>
                    <p>Total Feedback</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #2ecc71;">
                    <i class="fas fa-user-graduate"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['unique_students'] ?? 0; ?></h3>
                    <p>Students Responded</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #9b59b6;">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['teachers_rated'] ?? 0; ?></h3>
                    <p>Teachers Rated</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #e74c3c;">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $summary['courses_rated'] ?? 0; ?></h3>
                    <p>Courses Rated</p>
                </div>
            </div>
        </div>
        
        <?php if (count($feedback) > 0): ?>
        <!-- Rating Distribution -->
        <?php
        $rating_dist = $pdo->prepare("
            SELECT rating, COUNT(*) as count
            FROM feedback
            WHERE DATE(feedback_date) BETWEEN ? AND ?
            GROUP BY rating
            ORDER BY rating DESC
        ");
        $rating_dist->execute([$from_date, $to_date]);
        $ratings = $rating_dist->fetchAll();
        ?>
        
        <div class="card" style="margin-bottom: 20px;">
            <div class="card-header">
                <h3 class="card-title">Rating Distribution</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <?php for ($i = 5; $i >= 1; $i--): 
                        $count = 0;
                        foreach ($ratings as $r) {
                            if ($r['rating'] == $i) {
                                $count = $r['count'];
                                break;
                            }
                        }
                        $percentage = ($summary['total_feedback'] ?? 0) > 0 ? ($count / $summary['total_feedback']) * 100 : 0;
                    ?>
                        <div class="col-md-12 mb-3">
                            <div class="d-flex align-items-center">
                                <div class="mr-3">
                                    <?php for ($j = 1; $j <= 5; $j++): ?>
                                        <i class="fas fa-star <?php echo $j <= $i ? 'text-warning' : 'text-light'; ?>"></i>
                                    <?php endfor; ?>
                                    <span class="ml-2">(<?php echo $i; ?> Star)</span>
                                </div>
                                <div class="flex-grow-1">
                                    <div class="progress" style="height: 25px;">
                                        <div class="progress-bar bg-warning" role="progressbar" 
                                             style="width: <?php echo $percentage; ?>%">
                                            <?php echo $count; ?> (<?php echo round($percentage, 1); ?>%)
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
        
        <!-- Feedback Comments -->
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Recent Feedback Comments</h3>
            </div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Student</th>
                            <th>Class</th>
                            <th>Teacher/Course</th>
                            <th>Rating</th>
                            <th>Comments</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($feedback as $fb): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($fb['feedback_date'])); ?></td>
                                <td><?php echo htmlspecialchars($fb['student_name'] ?? 'Unknown'); ?></td>
                                <td><?php echo htmlspecialchars($fb['class_name'] ?? 'N/A'); ?></td>
                                <td>
                                    <?php if (!empty($fb['teacher_name'])): ?>
                                        Teacher: <?php echo htmlspecialchars($fb['teacher_name']); ?>
                                    <?php elseif (!empty($fb['course_name'])): ?>
                                        Course: <?php echo htmlspecialchars($fb['course_name']); ?>
                                    <?php else: ?>
                                        General Feedback
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="text-warning">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="fas fa-star<?php echo $i <= $fb['rating'] ? '' : '-o'; ?>"></i>
                                        <?php endfor; ?>
                                        <br>
                                        <small>(<?php echo $fb['rating']; ?>/5)</small>
                                    </div>
                                </td>
                                <td>
                                    <?php if (!empty($fb['comments'])): ?>
                                        <div style="max-height: 100px; overflow-y: auto;">
                                            <?php echo nl2br(htmlspecialchars($fb['comments'])); ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">No comments</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fas fa-comment-slash fa-4x text-muted mb-3"></i>
                <h4>No Feedback Submitted</h4>
                <p class="text-muted">No feedback has been submitted in this period.</p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

function generateOperationsReport($pdo, $from_date, $to_date) {
    // System Operations Report
    ?>
    
    <div class="report-container">
        <div class="report-header">
            <h2><i class="fas fa-cogs"></i> System Operations Report</h2>
            <p>Period: <?php echo date('M d, Y', strtotime($from_date)); ?> to <?php echo date('M d, Y', strtotime($to_date)); ?></p>
        </div>
        
        <!-- System Statistics -->
        <?php
        // Get counts from various tables
        $total_students = $pdo->query("SELECT COUNT(*) FROM students WHERE students.status = 'active'")->fetchColumn();
        $total_teachers = $pdo->query("SELECT COUNT(*) FROM teachers WHERE teachers.status = 'active'")->fetchColumn();
        $total_classes = $pdo->query("SELECT COUNT(*) FROM classes WHERE classes.status = 'active'")->fetchColumn();
        $total_courses = $pdo->query("SELECT COUNT(*) FROM courses WHERE courses.status = 'active'")->fetchColumn();
        
        // Recent activities count with specific table aliases
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE DATE(students.created_at) BETWEEN ? AND ?");
        $stmt->execute([$from_date, $to_date]);
        $new_students = $stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM teachers WHERE DATE(teachers.created_at) BETWEEN ? AND ?");
        $stmt->execute([$from_date, $to_date]);
        $new_teachers = $stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance_records WHERE DATE(attendance_records.attendance_date) BETWEEN ? AND ?");
        $stmt->execute([$from_date, $to_date]);
        $attendance_records = $stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM fees WHERE DATE(fees.payment_date) BETWEEN ? AND ?");
        $stmt->execute([$from_date, $to_date]);
        $fee_transactions = $stmt->fetchColumn();
        
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM grades WHERE DATE(grades.created_at) BETWEEN ? AND ?");
        $stmt->execute([$from_date, $to_date]);
        $grade_entries = $stmt->fetchColumn();
        ?>
        
        <div class="stats-container" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: #4361ee;">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_students; ?></h3>
                    <p>Total Students</p>
                    <small><?php echo $new_students; ?> new this period</small>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #3a0ca3;">
                    <i class="fas fa-chalkboard-teacher"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_teachers; ?></h3>
                    <p>Total Teachers</p>
                    <small><?php echo $new_teachers; ?> new this period</small>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #7209b7;">
                    <i class="fas fa-school"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_classes; ?></h3>
                    <p>Active Classes</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #f72585;">
                    <i class="fas fa-book"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $total_courses; ?></h3>
                    <p>Active Courses</p>
                </div>
            </div>
        </div>
        
        <div class="stats-container" style="margin-bottom: 30px;">
            <div class="stat-card">
                <div class="stat-icon" style="background: #4cc9f0;">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $attendance_records; ?></h3>
                    <p>Attendance Records</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #2ecc71;">
                    <i class="fas fa-money-check-alt"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $fee_transactions; ?></h3>
                    <p>Fee Transactions</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon" style="background: #f8961e;">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $grade_entries; ?></h3>
                    <p>Grade Entries</p>
                </div>
            </div>
        </div>
        
        <!-- Database Backup Status -->
        <div class="card" style="margin-top: 20px;">
            <div class="card-header">
                <h3 class="card-title">Database Information</h3>
            </div>
            <div class="card-body">
                <?php
                // Get database size
                $db_size = $pdo->query("
                    SELECT 
                        ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
                    FROM information_schema.tables 
                    WHERE table_schema = DATABASE()
                ")->fetchColumn();
                
                // Get table counts
                $table_counts = $pdo->query("
                    SELECT 
                        COUNT(*) as table_count,
                        SUM(TABLE_ROWS) as total_rows
                    FROM information_schema.tables 
                    WHERE table_schema = DATABASE()
                ")->fetch();
                ?>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="alert alert-info">
                            <h5><i class="fas fa-database"></i> Database Size</h5>
                            <p class="mb-0">Total Size: <strong><?php echo $db_size; ?> MB</strong></p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="alert alert-success">
                            <h5><i class="fas fa-table"></i> Table Statistics</h5>
                            <p class="mb-0">
                                Tables: <strong><?php echo $table_counts['table_count']; ?></strong> | 
                                Total Rows: <strong><?php echo number_format($table_counts['total_rows']); ?></strong>
                            </p>
                        </div>
                    </div>
                </div>
                
                <!-- Backup Button -->
                <div class="text-center mt-3">
                    <button class="btn btn-warning" onclick="createBackup()">
                        <i class="fas fa-save"></i> Create Database Backup
                    </button>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    function createBackup() {
        if (confirm('Are you sure you want to create a database backup?')) {
            window.open('reports/backup_database.php', '_blank');
        }
    }
    </script>
    <?php
}

// Placeholder functions for other reports
function generateTeacherReport($pdo, $from_date, $to_date) {
    echo "<div class='text-center py-5'>
            <i class='fas fa-chalkboard-teacher fa-4x text-muted mb-3'></i>
            <h4>Teacher Report Coming Soon</h4>
            <p class='text-muted'>Teacher performance report will be available in the next update.</p>
          </div>";
}

function generateCourseReport($pdo, $from_date, $to_date) {
    echo "<div class='text-center py-5'>
            <i class='fas fa-book fa-4x text-muted mb-3'></i>
            <h4>Course Report Coming Soon</h4>
            <p class='text-muted'>Course-wise report will be available in the next update.</p>
          </div>";
}

function generateClassReport($pdo, $from_date, $to_date) {
    echo "<div class='text-center py-5'>
            <i class='fas fa-school fa-4x text-muted mb-3'></i>
            <h4>Class Report Coming Soon</h4>
            <p class='text-muted'>Class-wise report will be available in the next update.</p>
          </div>";
}

function generateFinancialReport($pdo, $from_date, $to_date) {
    echo "<div class='text-center py-5'>
            <i class='fas fa-chart-pie fa-4x text-muted mb-3'></i>
            <h4>Financial Report Coming Soon</h4>
            <p class='text-muted'>Financial summary report will be available in the next update.</p>
          </div>";
}
?>