<?php
// notifications/download.php
session_start();
require_once 'notification_controller.php';

if (!isset($_GET['id'])) {
    header('HTTP/1.0 400 Bad Request');
    exit;
}

$controller = new NotificationController();
$filePath = $controller->getAttachmentPath($_GET['id']);

if ($filePath && file_exists($filePath)) {
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($filePath) . '"');
    readfile($filePath);
} else {
    header('HTTP/1.0 404 Not Found');
    echo "File not found.";
}
?>