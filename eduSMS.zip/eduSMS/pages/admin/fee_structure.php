<h2>📚 Fee Structure</h2>

<form method="post">
    <select name="class_id" required>
        <?php
        $classes = $pdo->query("SELECT * FROM classes")->fetchAll();
        foreach ($classes as $c):
        ?>
        <option value="<?= $c['id'] ?>">
            <?= $c['class_name'].'-'.$c['section'] ?>
        </option>
        <?php endforeach; ?>
    </select>

    <input type="number" name="total_fee" placeholder="Total Fee" required>

    <button name="save" class="btn btn-primary">Save</button>
</form>

<?php
if (isset($_POST['save'])) {
    $pdo->prepare("
        INSERT INTO fee_structures (class_id,total_fee,academic_year,status)
        VALUES (?,?,?,?)
    ")->execute([
        $_POST['class_id'],
        $_POST['total_fee'],
        '2025-2026',
        'active'
    ]);
    echo "<div class='success-message'>Saved</div>";
}
?>
