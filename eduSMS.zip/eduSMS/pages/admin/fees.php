<?php

if (!isset($current_user) || $current_user['role'] != 'admin') {
    echo "<div class='error-message'>Access denied</div>";
    return;
}

$tab = $_GET['tab'] ?? 'structures';

switch ($tab) {

    case 'payments':
        include 'fees_payments.php';
        break;

    case 'settings':
        include 'payment_settings.php';
        break;

    default:
        include 'fees_structure.php';
        break;
}

// ================= SECURITY =================
if (!isset($current_user) || $current_user['role'] != 'admin') {
    echo "<div class='error-message'>Access Denied</div>";
    return;
}

$tab = $_GET['tab'] ?? 'structures';

/* ================= APPROVE / REJECT ================= */
if (isset($_GET['approve'])) {
    $stmt = $pdo->prepare("UPDATE fee_payments SET status='approved', approved_at=NOW() WHERE id=?");
    $stmt->execute([$_GET['approve']]);
}

if (isset($_GET['reject'])) {
    $stmt = $pdo->prepare("UPDATE fee_payments SET status='rejected' WHERE id=?");
    $stmt->execute([$_GET['reject']]);
}

/* ================= ADD FEE STRUCTURE ================= */
if (isset($_POST['add_fee_structure'])) {

    $total =
        $_POST['tuition_fee'] +
        ($_POST['transport_fee'] ?? 0) +
        ($_POST['hostel_fee'] ?? 0) +
        ($_POST['lab_fee'] ?? 0) +
        ($_POST['sports_fee'] ?? 0) +
        ($_POST['misc_fee'] ?? 0);

    $stmt = $pdo->prepare("
        INSERT INTO fee_structures
        (class_id, academic_year, tuition_fee, transport_fee, hostel_fee, lab_fee, sports_fee, misc_fee, total_fee, due_date, description)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    ");

    $stmt->execute([
        $_POST['class_id'],
        $_POST['academic_year'],
        $_POST['tuition_fee'],
        $_POST['transport_fee'],
        $_POST['hostel_fee'],
        $_POST['lab_fee'],
        $_POST['sports_fee'],
        $_POST['misc_fee'],
        $total,
        $_POST['due_date'],
        $_POST['description']
    ]);

    $success = "Fee Structure Added Successfully";
}

/* ================= FETCH DATA ================= */
$classes = $pdo->query("SELECT * FROM classes WHERE status='active'")->fetchAll();

$fee_structures = $pdo->query("
    SELECT fs.*, c.class_name, c.section
    FROM fee_structures fs
    JOIN classes c ON fs.class_id=c.id
    ORDER BY fs.created_at DESC
")->fetchAll();

$payments = $pdo->query("
    SELECT fp.*, u.name student_name, c.class_name, c.section
    FROM fee_payments fp
    JOIN users u ON fp.student_id=u.id
    JOIN classes c ON fp.class_id=c.id
    ORDER BY fp.created_at DESC
")->fetchAll();

$academic_year = date('Y').'-'.(date('Y')+1);
?>

<?php if(isset($success)): ?>
<div class="success-message"><?= $success ?></div>
<?php endif; ?>

<!-- ================= TABS ================= -->
<div class="card">
    <div class="card-header">
        <a href="?page=fees&tab=structures" class="btn <?= $tab=='structures'?'btn-primary':'btn-secondary' ?>">Fee Structure</a>
        <a href="?page=fees&tab=payments" class="btn <?= $tab=='payments'?'btn-primary':'btn-secondary' ?>">Fee Payments</a>
        <a href="?page=fees&tab=settings" class="btn <?= $tab=='settings'?'btn-primary':'btn-secondary' ?>">Payment Settings</a>
    </div>
</div>

<!-- ================= TAB CONTENT ================= -->
<?php if ($tab == 'structures'): ?>

<div class="card">
    <div class="card-header">
        <h3>Fee Structures</h3>
        <button class="btn btn-success" onclick="document.getElementById('addFee').style.display='block'">+ Add</button>
    </div>

    <table>
        <tr>
            <th>Class</th><th>Year</th><th>Total</th><th>Due</th>
        </tr>
        <?php foreach($fee_structures as $f): ?>
        <tr>
            <td><?= $f['class_name'].'-'.$f['section'] ?></td>
            <td><?= $f['academic_year'] ?></td>
            <td><strong><?= $settings['currency'].number_format($f['total_fee'],2) ?></strong></td>
            <td><?= date('d M Y',strtotime($f['due_date'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<!-- ADD MODAL -->
<div id="addFee" class="modal">
<div class="modal-content">
<form method="POST">
    <h3>Add Fee Structure</h3>

    <select name="class_id" required>
        <option value="">Select Class</option>
        <?php foreach($classes as $c): ?>
            <option value="<?= $c['id'] ?>"><?= $c['class_name'].'-'.$c['section'] ?></option>
        <?php endforeach; ?>
    </select>

    <input name="academic_year" value="<?= $academic_year ?>" required>
    <input name="tuition_fee" type="number" placeholder="Tuition Fee" required>
    <input name="transport_fee" type="number" placeholder="Transport">
    <input name="hostel_fee" type="number" placeholder="Hostel">
    <input name="lab_fee" type="number" placeholder="Lab">
    <input name="sports_fee" type="number" placeholder="Sports">
    <input name="misc_fee" type="number" placeholder="Misc">
    <input name="due_date" type="date" required>
    <textarea name="description" placeholder="Description"></textarea>

    <button name="add_fee_structure" class="btn btn-success">Save</button>
    <button type="button" onclick="this.closest('.modal').style.display='none'" class="btn btn-secondary">Cancel</button>
</form>
</div>
</div>

<?php elseif ($tab == 'payments'): ?>

<div class="card">
<h3>Student Fee Payments</h3>

<table>
<tr>
<th>Student</th><th>Class</th><th>Amount</th><th>Method</th><th>Status</th><th>Action</th>
</tr>

<?php foreach($payments as $p): ?>
<tr>
<td><?= $p['student_name'] ?></td>
<td><?= $p['class_name'].'-'.$p['section'] ?></td>
<td><?= $settings['currency'].number_format($p['amount_paid'],2) ?></td>
<td><?= $p['payment_method'] ?></td>
<td>
<span class="badge badge-<?= $p['status']=='approved'?'success':($p['status']=='rejected'?'danger':'warning') ?>">
<?= ucfirst($p['status']) ?>
</span>
</td>
<td>
<?php if($p['status']=='pending'): ?>
<a href="?page=fees&tab=payments&approve=<?= $p['id'] ?>" class="btn btn-success btn-sm">Approve</a>
<a href="?page=fees&tab=payments&reject=<?= $p['id'] ?>" class="btn btn-danger btn-sm">Reject</a>
<?php endif; ?>
</td>
</tr>
<?php endforeach; ?>
</table>
</div>

<?php else: ?>

<div class="card">
<h3>Payment Settings</h3>
<p><strong>Bank:</strong> ABC Bank</p>
<p><strong>Account #:</strong> 123456789</p>
<p><strong>IBAN:</strong> PK12XXXX</p>
<p><strong>Mobile:</strong> JazzCash / Easypaisa</p>
</div>

<?php endif; ?>
