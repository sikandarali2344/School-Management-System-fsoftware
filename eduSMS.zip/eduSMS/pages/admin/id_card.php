<?php
$user_id = $current_user['id'];

$stmt = $pdo->prepare("
    SELECT 
        s.id AS student_id,
        s.class,
        s.parent_name,
        s.parent_contact,
        s.status,
        u.name
    FROM students s
    INNER JOIN users u ON s.user_id = u.id
    WHERE u.id = ?
");
$stmt->execute([$user_id]);
$s = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$s) {
    echo "<div class='alert alert-danger'>ID Card not found</div>";
    exit;
}
?>

<style>
.id-wrapper{
    display:flex;
    justify-content:center;
    margin-top:20px;
}
.id-card{
    width:340px;
    background:#fff;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,.25);
    overflow:hidden;
    font-family:'Segoe UI',sans-serif;
}
.id-header{
    background:linear-gradient(135deg,#003973,#E5E5BE);
    color:#fff;
    text-align:center;
    padding:15px;
}
.id-header img{
    width:55px;
    margin-bottom:5px;
}
.id-body{
    padding:15px;
    text-align:center;
}
.student-pic{
    width:90px;
    height:90px;
    border-radius:50%;
    border:4px solid #003973;
    margin-top:-50px;
    background:#fff;
}
.id-body h4{
    margin:10px 0 5px;
}
.info{
    text-align:left;
    margin-top:10px;
    font-size:14px;
}
.info div{
    margin-bottom:6px;
}
.id-footer{
    background:#003973;
    color:#fff;
    text-align:center;
    font-size:12px;
    padding:8px;
}
.print-btn{
    margin-top:15px;
}
@media print{
    .print-btn{display:none;}
    body{background:#fff;}
}
</style>

<div class="id-wrapper">
    <div class="id-card">

        <!-- HEADER -->
        <div class="id-header">
            <img src="assets/school-logo.png">
            <h3>ABC PUBLIC SCHOOL</h3>
            <small>Student Identity Card</small>
        </div>

        <!-- BODY -->
        <div class="id-body">
            <img src="assets/default-student.png" class="student-pic">

            <h4><?= htmlspecialchars($s['name']) ?></h4>
            <small>Class <?= htmlspecialchars($s['class'] ?? 'N/A') ?></small>

            <div class="info">
                <div><b>Student ID:</b> STU-<?= $s['student_id'] ?></div>
                <div><b>Parent:</b> <?= htmlspecialchars($s['parent_name']) ?></div>
                <div><b>Contact:</b> <?= htmlspecialchars($s['parent_contact']) ?></div>
                <div><b>Status:</b> <?= htmlspecialchars($s['status']) ?></div>
            </div>
        </div>

        <!-- FOOTER -->
        <div class="id-footer">
            Valid for Academic Year 2025–26
        </div>
    </div>
</div>

<center>
    <button onclick="window.print()" class="btn btn-primary print-btn">
        🖨 Print ID Card
    </button>
</center>
