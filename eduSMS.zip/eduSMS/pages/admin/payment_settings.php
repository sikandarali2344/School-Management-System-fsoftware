<?php
// Fetch existing settings
$settingsData = $pdo->query("SELECT * FROM school_payment_settings WHERE id = 1")->fetch();

if (isset($_POST['save'])) {
    $stmt = $pdo->prepare("
        REPLACE INTO school_payment_settings 
        (id, bank_name, account_number, iban, mobile_payment) 
        VALUES (1, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_POST['bank_name'],
        $_POST['account_number'],
        $_POST['iban'],
        $_POST['mobile_payment']
    ]);
    echo "<div class='success-message'>Payment settings updated successfully</div>";
}
?>

<style>
.payment-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 20px;
    margin-top: 20px;
}
.payment-card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,.08);
    padding: 20px;
}
.payment-card h3 {
    margin-bottom: 15px;
    font-size: 18px;
    display: flex;
    align-items: center;
    gap: 10px;
}
.payment-card i {
    font-size: 22px;
    color: #007bff;
}
.payment-card input {
    width: 100%;
    padding: 10px;
    border-radius: 8px;
    border: 1px solid #ddd;
    margin-bottom: 10px;
}
.save-btn {
    background: linear-gradient(135deg,#007bff,#00c6ff);
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
}
.save-btn:hover {
    opacity: .9;
}
</style>

<h2>🏦 Payment Settings</h2>
<p style="color:#666;">Add bank and mobile payment details for student online fee payment</p>

<form method="post">
    <div class="payment-grid">

        <!-- Bank Card -->
        <div class="payment-card">
            <h3><i class="fas fa-university"></i> Bank Account</h3>
            <input type="text" name="bank_name" placeholder="Bank Name"
                   value="<?= $settingsData['bank_name'] ?? '' ?>">
            <input type="text" name="account_number" placeholder="Account Number"
                   value="<?= $settingsData['account_number'] ?? '' ?>">
            <input type="text" name="iban" placeholder="IBAN"
                   value="<?= $settingsData['iban'] ?? '' ?>">
        </div>

        <!-- Mobile Payment -->
        <div class="payment-card">
            <h3><i class="fas fa-mobile-alt"></i> Mobile Wallet</h3>
            <input type="text" name="mobile_payment" placeholder="JazzCash / Easypaisa Number"
                   value="<?= $settingsData['mobile_payment'] ?? '' ?>">
            <small style="color:#777;">
                Students will use this number for mobile payments
            </small>
        </div>

    </div>

    <div style="margin-top: 25px;">
        <button type="submit" name="save" class="save-btn">
            <i class="fas fa-save"></i> Save Payment Settings
        </button>
    </div>
</form>
