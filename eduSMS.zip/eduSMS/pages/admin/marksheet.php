<?php
// admin_marksheet.php
require_once __DIR__ . '/auth.php';

// Check if user is admin
if ($current_user['role'] != 'admin') {
    echo "<script>alert('Access Denied!'); window.location.href='dashboard.php';</script>";
    exit;
}

// Get school name from database if exists
$school_name = 'EduManage School';
try {
    // Check if settings table exists
    $tables = $pdo->query("SHOW TABLES LIKE 'settings'")->fetch();
    if ($tables) {
        $stmt = $pdo->query("SELECT school_name FROM settings LIMIT 1");
        $settings = $stmt->fetch();
        if ($settings && !empty($settings['school_name'])) {
            $school_name = $settings['school_name'];
        }
    }
} catch (Exception $e) {
    // Use default name
}

// Get parameters
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;
$exam_type = isset($_GET['exam_type']) ? $_GET['exam_type'] : 'Final';
$academic_year = isset($_GET['academic_year']) ? $_GET['academic_year'] : date('Y') . '-' . (date('Y') + 1);

// Get all classes for dropdown
$classes = [];
try {
    $classes_stmt = $pdo->query("SELECT id, class_name, section FROM classes WHERE status = 'active' ORDER BY class_name, section");
    $classes = $classes_stmt->fetchAll();
} catch (Exception $e) {
    $error = "Error loading classes: " . $e->getMessage();
}

// Get selected class details
$selected_class = null;
$show_marksheet = false;
$student_results = [];

if ($class_id > 0) {
    try {
        // Get class details
        $class_stmt = $pdo->prepare("SELECT class_name, section FROM classes WHERE id = ?");
        $class_stmt->execute([$class_id]);
        $selected_class = $class_stmt->fetch();
        
        if ($selected_class) {
            $show_marksheet = true;
            
            // Get students with their grades
            $students_stmt = $pdo->prepare("
                SELECT 
                    s.id as student_id,
                    s.roll_no,
                    u.name as student_name,
                    u.father_name,
                    u.mother_name
                FROM students s 
                JOIN users u ON s.user_id = u.id 
                WHERE s.class_id = ? AND s.status = 'active'
                ORDER BY s.roll_no
            ");
            $students_stmt->execute([$class_id]);
            $students = $students_stmt->fetchAll();
            
            // Process each student
            foreach ($students as $student) {
                // Get all grades for this student for selected exam type and year
                $grades_stmt = $pdo->prepare("
                    SELECT 
                        g.course_id,
                        c.course_name,
                        g.marks_obtained,
                        g.total_marks,
                        g.grade,
                        g.grade_point,
                        g.exam_type
                    FROM grades g
                    JOIN courses c ON g.course_id = c.id
                    WHERE g.student_id = ? 
                    AND g.exam_type = ?
                    AND g.academic_year = ?
                    AND g.class_id = ?
                ");
                $grades_stmt->execute([
                    $student['student_id'], 
                    $exam_type, 
                    $academic_year, 
                    $class_id
                ]);
                $grades = $grades_stmt->fetchAll();
                
                // Calculate totals
                $total_marks = 0;
                $obtained_marks = 0;
                $total_grade_points = 0;
                $subject_count = 0;
                $subjects = [];
                
                foreach ($grades as $grade) {
                    $total_marks += $grade['total_marks'];
                    $obtained_marks += $grade['marks_obtained'];
                    $total_grade_points += $grade['grade_point'];
                    $subject_count++;
                    
                    $subjects[] = [
                        'name' => $grade['course_name'],
                        'obtained' => $grade['marks_obtained'],
                        'total' => $grade['total_marks'],
                        'grade' => $grade['grade'],
                        'grade_point' => $grade['grade_point']
                    ];
                }
                
                // Calculate percentage and GPA
                $percentage = $total_marks > 0 ? ($obtained_marks / $total_marks) * 100 : 0;
                $gpa = $subject_count > 0 ? $total_grade_points / $subject_count : 0;
                
                // Get overall grade from grade_scale
                $grade_stmt = $pdo->prepare("
                    SELECT grade, grade_point 
                    FROM grade_scale 
                    WHERE ? BETWEEN min_percentage AND max_percentage 
                    LIMIT 1
                ");
                $grade_stmt->execute([$percentage]);
                $overall_grade = $grade_stmt->fetch();
                
                // Determine status
                $status = 'FAIL';
                $status_class = 'fail';
                
                if ($percentage > 0) {
                    if ($percentage >= 40) {
                        $status = 'PASS';
                        $status_class = 'pass';
                    }
                    if ($percentage >= 75) {
                        $status = 'DISTINCTION';
                        $status_class = 'distinction';
                    }
                } else {
                    $status = 'NO MARKS';
                    $status_class = 'no-marks';
                }
                
                // Store student result
                $student_results[] = [
                    'roll_no' => $student['roll_no'],
                    'name' => $student['student_name'],
                    'father_name' => $student['father_name'] ?? 'N/A',
                    'total_marks' => $total_marks,
                    'obtained_marks' => $obtained_marks,
                    'percentage' => $percentage,
                    'gpa' => $gpa,
                    'overall_grade' => $overall_grade['grade'] ?? 'F',
                    'overall_grade_point' => $overall_grade['grade_point'] ?? 0,
                    'status' => $status,
                    'status_class' => $status_class,
                    'subject_count' => $subject_count,
                    'subjects' => $subjects
                ];
            }
            
            // Sort by percentage for ranking
            usort($student_results, function($a, $b) {
                return $b['percentage'] <=> $a['percentage'];
            });
        }
    } catch (Exception $e) {
        $error = "Error loading marksheet data: " . $e->getMessage();
        error_log("Marksheet Error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Marksheet System - <?php echo htmlspecialchars($school_name); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Modern Design with Gradient */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow: hidden;
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 30px 40px;
            text-align: center;
        }
        
        .header h1 {
            font-size: 36px;
            font-weight: 700;
            margin-bottom: 10px;
            letter-spacing: 1px;
        }
        
        .header p {
            font-size: 16px;
            opacity: 0.9;
            font-weight: 300;
        }
        
        /* Navigation */
        .nav-back {
            padding: 20px 40px;
            background: #f8f9fa;
            border-bottom: 1px solid #e9ecef;
        }
        
        .back-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }
        
        .back-btn:hover {
            background: #5a6268;
            transform: translateX(-3px);
        }
        
        /* Form Container */
        .form-container {
            padding: 40px;
            background: white;
        }
        
        .form-title {
            color: #2c3e50;
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .form-label {
            font-weight: 600;
            color: #495057;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .form-select, .form-input {
            padding: 14px 16px;
            border: 2px solid #e1e5e9;
            border-radius: 10px;
            font-size: 16px;
            transition: all 0.3s;
            background: white;
        }
        
        .form-select:focus, .form-input:focus {
            outline: none;
            border-color: #4dabf7;
            box-shadow: 0 0 0 3px rgba(77, 171, 247, 0.2);
        }
        
        .generate-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 16px 40px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 12px;
            justify-content: center;
            margin: 0 auto;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        
        .generate-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(102, 126, 234, 0.5);
        }
        
        /* Marksheet Container */
        .marksheet-container {
            padding: 40px;
            display: <?php echo $show_marksheet ? 'block' : 'none'; ?>;
        }
        
        .marksheet-header {
            background: linear-gradient(135deg, #2c3e50 0%, #4a6491 100%);
            color: white;
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 40px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(44, 62, 80, 0.2);
        }
        
        .marksheet-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 15px;
            letter-spacing: 1.5px;
        }
        
        .marksheet-subtitle {
            font-size: 18px;
            opacity: 0.9;
            margin-bottom: 25px;
        }
        
        .class-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            background: rgba(255, 255, 255, 0.1);
            padding: 25px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }
        
        .info-item {
            text-align: center;
        }
        
        .info-label {
            font-size: 14px;
            opacity: 0.8;
            margin-bottom: 5px;
        }
        
        .info-value {
            font-size: 18px;
            font-weight: 600;
        }
        
        /* Results Grid */
        .results-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .summary-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            text-align: center;
            border: 1px solid #eef1f5;
            transition: transform 0.3s;
        }
        
        .summary-card:hover {
            transform: translateY(-5px);
        }
        
        .summary-value {
            font-size: 42px;
            font-weight: 700;
            margin: 15px 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .summary-label {
            font-size: 14px;
            color: #6c757d;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        /* Marksheet Table */
        .marksheet-table-container {
            overflow-x: auto;
            margin: 40px 0;
            border-radius: 15px;
            box-shadow: 0 5px 30px rgba(0,0,0,0.1);
        }
        
        .marksheet-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            min-width: 1000px;
        }
        
        .marksheet-table thead th {
            background: linear-gradient(135deg, #2c3e50 0%, #4a6491 100%);
            color: white;
            padding: 20px 15px;
            text-align: center;
            font-weight: 600;
            font-size: 15px;
            position: sticky;
            top: 0;
            z-index: 10;
            border: none;
        }
        
        .marksheet-table thead th:first-child {
            border-radius: 10px 0 0 0;
        }
        
        .marksheet-table thead th:last-child {
            border-radius: 0 10px 0 0;
        }
        
        .marksheet-table tbody tr {
            transition: all 0.3s;
        }
        
        .marksheet-table tbody tr:hover {
            background: linear-gradient(90deg, #f8f9fa 0%, #ffffff 100%);
            transform: scale(1.01);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        
        .marksheet-table td {
            padding: 18px 15px;
            text-align: center;
            border-bottom: 1px solid #eef1f5;
            font-size: 14px;
        }
        
        .student-name {
            font-weight: 600;
            color: #2c3e50;
            text-align: left;
            padding-left: 20px;
        }
        
        /* Status Badges */
        .status-badge {
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 12px;
            display: inline-block;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .status-pass {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            border: 1px solid #b1dfbb;
        }
        
        .status-fail {
            background: linear-gradient(135deg, #f8d7da 0%, #f5c6cb 100%);
            color: #721c24;
            border: 1px solid #f1b0b7;
        }
        
        .status-distinction {
            background: linear-gradient(135deg, #d1ecf1 0%, #bee5eb 100%);
            color: #0c5460;
            border: 1px solid #abdde5;
        }
        
        .status-no-marks {
            background: linear-gradient(135deg, #e2e3e5 0%, #d6d8db 100%);
            color: #383d41;
            border: 1px solid #c8cbcf;
        }
        
        /* Rank Badge */
        .rank-badge {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            color: white;
        }
        
        .rank-1 {
            background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
        }
        
        .rank-2 {
            background: linear-gradient(135deg, #C0C0C0 0%, #A9A9A9 100%);
        }
        
        .rank-3 {
            background: linear-gradient(135deg, #CD7F32 0%, #8B4513 100%);
        }
        
        .rank-other {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
        }
        
        /* Grade Colors */
        .grade-A {
            color: #28a745;
            font-weight: 700;
        }
        
        .grade-B {
            color: #20c997;
            font-weight: 700;
        }
        
        .grade-C {
            color: #17a2b8;
            font-weight: 700;
        }
        
        .grade-D {
            color: #fd7e14;
            font-weight: 700;
        }
        
        .grade-F {
            color: #dc3545;
            font-weight: 700;
        }
        
        /* Progress Bar */
        .percentage-bar {
            width: 100%;
            height: 8px;
            background: #e9ecef;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        
        .percentage-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease;
        }
        
        .fill-excellent { background: linear-gradient(90deg, #28a745, #20c997); }
        .fill-good { background: linear-gradient(90deg, #20c997, #17a2b8); }
        .fill-average { background: linear-gradient(90deg, #ffc107, #fd7e14); }
        .fill-poor { background: linear-gradient(90deg, #fd7e14, #dc3545); }
        .fill-fail { background: linear-gradient(90deg, #dc3545, #c82333); }
        
        /* Action Buttons */
        .action-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
            flex-wrap: wrap;
        }
        
        .action-btn {
            padding: 16px 32px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 200px;
            justify-content: center;
        }
        
        .btn-print {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(40, 167, 69, 0.3);
        }
        
        .btn-print:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(40, 167, 69, 0.4);
        }
        
        .btn-excel {
            background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(23, 162, 184, 0.3);
        }
        
        .btn-excel:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(23, 162, 184, 0.4);
        }
        
        .btn-pdf {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            color: white;
            box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
        }
        
        .btn-pdf:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(220, 53, 69, 0.4);
        }
        
        /* No Data Message */
        .no-data {
            text-align: center;
            padding: 80px 40px;
            color: #6c757d;
        }
        
        .no-data-icon {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.3;
        }
        
        .no-data h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #495057;
        }
        
        /* Grade Scale Display */
        .grade-scale {
            margin: 40px 0;
            padding: 30px;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            border-radius: 15px;
            border: 1px solid #dee2e6;
        }
        
        .grade-scale-title {
            font-size: 20px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .grade-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }
        
        .grade-item {
            text-align: center;
            padding: 15px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.05);
        }
        
        .grade-letter {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .grade-range {
            font-size: 12px;
            color: #6c757d;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .container {
                margin: 10px;
                border-radius: 15px;
            }
            
            .header {
                padding: 20px;
            }
            
            .header h1 {
                font-size: 24px;
            }
            
            .form-container {
                padding: 20px;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .marksheet-container {
                padding: 20px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .action-btn {
                width: 100%;
            }
        }
        
        /* Print Styles */
        @media print {
            body {
                background: white !important;
                padding: 0 !important;
            }
            
            .container {
                box-shadow: none !important;
                border-radius: 0 !important;
                max-width: 100% !important;
            }
            
            .nav-back, .form-container, .action-buttons {
                display: none !important;
            }
            
            .marksheet-container {
                display: block !important;
                padding: 0 !important;
            }
            
            .marksheet-header {
                box-shadow: none !important;
                border-radius: 0 !important;
            }
            
            .marksheet-table tbody tr:hover {
                transform: none !important;
                box-shadow: none !important;
            }
        }
        
        /* Animation */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .animate-fade-in {
            animation: fadeIn 0.5s ease-out;
        }
    </style>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container animate-fade-in">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-file-certificate"></i> Marksheet System</h1>
            <p><?php echo htmlspecialchars($school_name); ?> - Academic Performance Report</p>
        </div>
        
        <!-- Navigation -->
        <div class="nav-back">
            <a href="dashboard.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <!-- Form Section -->
        <div class="form-container">
            <h2 class="form-title"><i class="fas fa-sliders-h"></i> Generate Marksheet</h2>
            
            <form method="GET" action="">
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-chalkboard-teacher"></i> Select Class</label>
                        <select name="class_id" class="form-select" required>
                            <option value="">-- Choose Class --</option>
                            <?php foreach ($classes as $class): ?>
                                <option value="<?php echo $class['id']; ?>" 
                                    <?php echo $class_id == $class['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name'] . ' - ' . $class['section']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-file-alt"></i> Exam Type</label>
                        <select name="exam_type" class="form-select" required>
                            <option value="Final" <?php echo $exam_type == 'Final' ? 'selected' : ''; ?>>Final Examination</option>
                            <option value="Midterm" <?php echo $exam_type == 'Midterm' ? 'selected' : ''; ?>>Midterm Examination</option>
                            <option value="Quarterly" <?php echo $exam_type == 'Quarterly' ? 'selected' : ''; ?>>Quarterly Examination</option>
                            <option value="Unit Test" <?php echo $exam_type == 'Unit Test' ? 'selected' : ''; ?>>Unit Test</option>
                            <option value="Assignment" <?php echo $exam_type == 'Assignment' ? 'selected' : ''; ?>>Assignment</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label"><i class="fas fa-calendar-alt"></i> Academic Year</label>
                        <input type="text" name="academic_year" class="form-input" 
                               value="<?php echo htmlspecialchars($academic_year); ?>" 
                               placeholder="e.g., 2024-2025" required>
                    </div>
                </div>
                
                <button type="submit" class="generate-btn">
                    <i class="fas fa-cogs"></i> GENERATE MARKSHEET
                </button>
            </form>
        </div>
        
        <!-- Marksheet Display -->
        <div class="marksheet-container" id="marksheetContent">
            <?php if ($show_marksheet && $selected_class): ?>
                
                <!-- Marksheet Header -->
                <div class="marksheet-header">
                    <div class="marksheet-title">ACADEMIC PERFORMANCE REPORT</div>
                    <div class="marksheet-subtitle">Detailed Marks Statement</div>
                    
                    <div class="class-info-grid">
                        <div class="info-item">
                            <div class="info-label">Class</div>
                            <div class="info-value"><?php echo htmlspecialchars($selected_class['class_name'] . ' - ' . $selected_class['section']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Academic Year</div>
                            <div class="info-value"><?php echo htmlspecialchars($academic_year); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Exam Type</div>
                            <div class="info-value"><?php echo htmlspecialchars($exam_type); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Report Date</div>
                            <div class="info-value"><?php echo date('F j, Y'); ?></div>
                        </div>
                    </div>
                </div>
                
                <?php if (count($student_results) > 0): ?>
                    <!-- Class Statistics -->
                    <?php
                    $total_students = count($student_results);
                    $passed_students = array_filter($student_results, function($r) {
                        return in_array($r['status'], ['PASS', 'DISTINCTION']);
                    });
                    $passed_count = count($passed_students);
                    $pass_percentage = $total_students > 0 ? ($passed_count / $total_students) * 100 : 0;
                    $total_percentage = array_sum(array_column($student_results, 'percentage'));
                    $average_percentage = $total_students > 0 ? $total_percentage / $total_students : 0;
                    $highest_percentage = max(array_column($student_results, 'percentage'));
                    ?>
                    
                    <div class="results-summary">
                        <div class="summary-card">
                            <div class="summary-value"><?php echo $total_students; ?></div>
                            <div class="summary-label">Total Students</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-value"><?php echo $passed_count; ?></div>
                            <div class="summary-label">Passed Students</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-value"><?php echo number_format($pass_percentage, 1); ?>%</div>
                            <div class="summary-label">Pass Percentage</div>
                        </div>
                        <div class="summary-card">
                            <div class="summary-value"><?php echo number_format($average_percentage, 1); ?>%</div>
                            <div class="summary-label">Class Average</div>
                        </div>
                    </div>
                    
                    <!-- Grade Scale -->
                    <div class="grade-scale">
                        <div class="grade-scale-title">
                            <i class="fas fa-graduation-cap"></i> Grading Scale
                        </div>
                        <div class="grade-grid">
                            <?php
                            $grade_scale_stmt = $pdo->query("SELECT * FROM grade_scale ORDER BY min_percentage DESC");
                            $grade_scales = $grade_scale_stmt->fetchAll();
                            foreach ($grade_scales as $scale):
                            ?>
                            <div class="grade-item">
                                <div class="grade-letter grade-<?php echo substr($scale['grade'], 0, 1); ?>">
                                    <?php echo $scale['grade']; ?>
                                </div>
                                <div class="grade-range">
                                    <?php echo $scale['min_percentage']; ?>% - <?php echo $scale['max_percentage']; ?>%
                                </div>
                                <div style="font-size: 14px; font-weight: 600; color: #495057;">
                                    GPA: <?php echo $scale['grade_point']; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Marksheet Table -->
                    <div class="marksheet-table-container">
                        <table class="marksheet-table">
                            <thead>
                                <tr>
                                    <th>Rank</th>
                                    <th>Roll No</th>
                                    <th>Student Name</th>
                                    <th>Father's Name</th>
                                    <th>Total Marks</th>
                                    <th>Obtained</th>
                                    <th>Percentage</th>
                                    <th>GPA</th>
                                    <th>Grade</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $rank = 0;
                                $prev_percentage = null;
                                $actual_rank = 1;
                                
                                foreach ($student_results as $index => $result):
                                    // Calculate rank
                                    if ($prev_percentage !== null && $result['percentage'] != $prev_percentage) {
                                        $actual_rank = $index + 1;
                                    }
                                    $prev_percentage = $result['percentage'];
                                    
                                    // Determine rank badge class
                                    $rank_class = 'rank-other';
                                    if ($actual_rank == 1) $rank_class = 'rank-1';
                                    elseif ($actual_rank == 2) $rank_class = 'rank-2';
                                    elseif ($actual_rank == 3) $rank_class = 'rank-3';
                                    
                                    // Determine progress bar class
                                    $progress_class = 'fill-fail';
                                    if ($result['percentage'] >= 75) $progress_class = 'fill-excellent';
                                    elseif ($result['percentage'] >= 60) $progress_class = 'fill-good';
                                    elseif ($result['percentage'] >= 40) $progress_class = 'fill-average';
                                    elseif ($result['percentage'] > 0) $progress_class = 'fill-poor';
                                ?>
                                <tr>
                                    <td>
                                        <div class="rank-badge <?php echo $rank_class; ?>">
                                            <?php echo $actual_rank; ?>
                                        </div>
                                    </td>
                                    <td><strong><?php echo htmlspecialchars($result['roll_no']); ?></strong></td>
                                    <td class="student-name">
                                        <?php echo htmlspecialchars($result['name']); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($result['father_name']); ?></td>
                                    <td><?php echo number_format($result['total_marks']); ?></td>
                                    <td><?php echo number_format($result['obtained_marks']); ?></td>
                                    <td>
                                        <div style="font-weight: 600; color: #2c3e50;">
                                            <?php echo number_format($result['percentage'], 2); ?>%
                                        </div>
                                        <div class="percentage-bar">
                                            <div class="percentage-fill <?php echo $progress_class; ?>" 
                                                 style="width: <?php echo min($result['percentage'], 100); ?>%">
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <span style="font-weight: 700; color: #495057;">
                                            <?php echo number_format($result['gpa'], 2); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="grade-<?php echo substr($result['overall_grade'], 0, 1); ?>">
                                            <?php echo $result['overall_grade']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower($result['status']); ?>">
                                            <?php echo $result['status']; ?>
                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="action-buttons">
                        <button onclick="window.print()" class="action-btn btn-print">
                            <i class="fas fa-print"></i> Print Marksheet
                        </button>
                        <button onclick="exportToExcel()" class="action-btn btn-excel">
                            <i class="fas fa-file-excel"></i> Export to Excel
                        </button>
                        <button onclick="exportToPDF()" class="action-btn btn-pdf">
                            <i class="fas fa-file-pdf"></i> Export to PDF
                        </button>
                    </div>
                    
                <?php else: ?>
                    <!-- No Grades Message -->
                    <div class="no-data">
                        <div class="no-data-icon">
                            <i class="fas fa-clipboard-list"></i>
                        </div>
                        <h3>No Grades Found</h3>
                        <p>There are no grades recorded for the selected class, exam type, and academic year.</p>
                        <p style="margin-top: 20px; color: #6c757d;">
                            Please ensure that teachers have entered grades for students in this class.
                        </p>
                    </div>
                <?php endif; ?>
                
            <?php elseif ($class_id && !$selected_class): ?>
                <!-- Invalid Class -->
                <div class="no-data">
                    <div class="no-data-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <h3>Class Not Found</h3>
                    <p>The selected class does not exist or has been disabled.</p>
                </div>
            <?php else: ?>
                <!-- Initial State -->
                <div class="no-data">
                    <div class="no-data-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <h3>Ready to Generate Marksheet</h3>
                    <p>Select a class, exam type, and academic year to generate the marksheet.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
    // Export to Excel function
    function exportToExcel() {
        // Create HTML table for export
        let table = document.querySelector('.marksheet-table').cloneNode(true);
        
        // Remove progress bars and rank badges
        let cells = table.querySelectorAll('td');
        cells.forEach(cell => {
            if (cell.querySelector('.percentage-bar') || cell.querySelector('.rank-badge')) {
                cell.innerHTML = cell.textContent;
            }
        });
        
        let html = `
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Marksheet Export</title>
                <style>
                    body { font-family: Arial, sans-serif; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #000; padding: 8px; text-align: center; }
                    th { background-color: #f2f2f2; font-weight: bold; }
                </style>
            </head>
            <body>
                <h2>Marksheet - <?php echo $selected_class ? htmlspecialchars($selected_class['class_name']) : ''; ?></h2>
                <p><strong>Academic Year:</strong> <?php echo htmlspecialchars($academic_year); ?></p>
                <p><strong>Exam Type:</strong> <?php echo htmlspecialchars($exam_type); ?></p>
                <p><strong>Generated On:</strong> <?php echo date('Y-m-d H:i:s'); ?></p>
                ${table.outerHTML}
            </body>
            </html>
        `;
        
        // Create blob and download
        let blob = new Blob([html], { type: 'application/vnd.ms-excel' });
        let link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = 'marksheet_<?php echo $selected_class ? str_replace(" ", "_", $selected_class["class_name"]) : "class"; ?>_<?php echo date("Y-m-d"); ?>.xls';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // Export to PDF function
    function exportToPDF() {
        alert('PDF export requires additional setup. Please use the Print option and choose "Save as PDF" in the print dialog.');
    }
    
    // Auto-focus on form
    window.onload = function() {
        <?php if (!$class_id): ?>
        document.querySelector('select[name="class_id"]').focus();
        <?php endif; ?>
        
        // Add animation to table rows
        let rows = document.querySelectorAll('.marksheet-table tbody tr');
        rows.forEach((row, index) => {
            row.style.animationDelay = (index * 0.05) + 's';
            row.classList.add('animate-fade-in');
        });
    };
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Ctrl + P for print
        if (e.ctrlKey && e.key === 'p') {
            e.preventDefault();
            window.print();
        }
        
        // Ctrl + E for Excel export
        if (e.ctrlKey && e.key === 'e') {
            e.preventDefault();
            exportToExcel();
        }
    });
    </script>
</body>
</html>