<?php
// ================= SECURITY =================
if (!isset($current_user) || $current_user['role'] !== 'student') {
    echo "<div class='error-message'>Access denied</div>";
    return;
}

// ================= FETCH STUDENT FEE SUMMARY =================
$stmt = $pdo->prepare("
    SELECT 
        fs.total_fee,
        COALESCE(SUM(fp.amount_paid),0) AS paid
    FROM students s
    JOIN fee_structures fs 
        ON fs.class_id = s.class_id
       AND fs.status = 'active'
    LEFT JOIN fee_payments fp 
        ON fp.student_id = s.id
       AND fp.status = 'approved'
    WHERE s.user_id = ?
    GROUP BY fs.id
");
$stmt->execute([$current_user['id']]);
$fee = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$fee) {
    $fee = ['total_fee' => 0, 'paid' => 0];
}

$due = max(0, $fee['total_fee'] - $fee['paid']);

// ================= HANDLE PAYMENT SUBMISSION =================
if (isset($_POST['pay'])) {

    $amount = (float) $_POST['amount'];
    $proof  = null;

    if (!empty($_FILES['screenshot']['name'])) {
        $ext = pathinfo($_FILES['screenshot']['name'], PATHINFO_EXTENSION);
        $proof = time().'_'.$current_user['id'].'.'.$ext;
        move_uploaded_file(
            $_FILES['screenshot']['tmp_name'],
            "uploads/fee_proofs/".$proof
        );
    }

    $stmt = $pdo->prepare("
        INSERT INTO fee_payments
        (student_id, amount_paid, payment_method, transaction_id, payment_proof, status, created_at)
        VALUES (?, ?, 'Manual', '', ?, 'pending', NOW())
    ");
    $stmt->execute([
        $current_user['id'],
        $amount,
        $proof
    ]);

    echo "<div class='success-message'>Payment submitted. Waiting for admin approval.</div>";
}
?>

<style>
.pay-container{max-width:900px;margin:25px auto;}
.fee-summary{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-bottom:25px;
}
.summary-box{
    background:#fff;
    border-radius:16px;
    box-shadow:0 10px 25px rgba(0,0,0,.1);
    padding:20px;
    text-align:center;
}
.summary-box i{font-size:28px;margin-bottom:10px}
.total{color:#007bff}
.paid{color:#28a745}
.due{color:#dc3545}

.pay-card{
    background:#fff;
    border-radius:18px;
    box-shadow:0 15px 30px rgba(0,0,0,.12);
    padding:25px;
}
.method-card{
    background:#f8f9fa;
    border-radius:14px;
    padding:15px;
    margin-bottom:15px;
}
.pay-btn{
    width:100%;
    padding:14px;
    border:none;
    border-radius:30px;
    font-size:16px;
    background:linear-gradient(135deg,#007bff,#00c6ff);
    color:#fff;
}
</style>

<div class="pay-container">

    <!-- ================= SUMMARY ================= -->
    <div class="fee-summary">
        <div class="summary-box">
            <i class="fas fa-wallet total"></i>
            <h3>Total Fees</h3>
            <strong>₨<?= number_format($fee['total_fee']) ?></strong>
        </div>

        <div class="summary-box">
            <i class="fas fa-check-circle paid"></i>
            <h3>Paid</h3>
            <strong>₨<?= number_format($fee['paid']) ?></strong>
        </div>

        <div class="summary-box">
            <i class="fas fa-exclamation-circle due"></i>
            <h3>Remaining</h3>
            <strong>₨<?= number_format($due) ?></strong>
        </div>
    </div>

    <!-- ================= PAYMENT ================= -->
    <div class="pay-card">
        <h2>💳 Pay Fees</h2>

        <div class="method-card">
            <strong>🏦 Bank Transfer</strong><br>
            Bank: ABC Bank<br>
            Account #: 123456789<br>
            IBAN: PK12ABCD123456
        </div>

        <div class="method-card">
            <strong>📱 Mobile Wallet</strong><br>
            JazzCash / Easypaisa: 0300-1234567
        </div>

        <?php if ($due <= 0): ?>
            <div class="badge badge-success">✔ Fees Already Paid</div>
        <?php else: ?>
            <form method="post" enctype="multipart/form-data">
                <label>Amount *</label>
                <input type="number" name="amount" max="<?= $due ?>" required>

                <label>Payment Screenshot *</label>
                <input type="file" name="screenshot" required>

                <button name="pay" class="pay-btn">
                    Submit for Admin Approval
                </button>
            </form>
        <?php endif; ?>
    </div>
</div>
