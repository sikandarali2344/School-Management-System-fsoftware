<h2>💳 Pay Fees</h2>

<?php
$bank = $pdo->query("SELECT * FROM school_payment_settings WHERE id=1")->fetch();
?>

<p>Bank: <?= $bank['bank_name'] ?></p>
<p>Account #: <?= $bank['account_number'] ?></p>
<p>IBAN: <?= $bank['iban'] ?></p>
<p>Mobile: <?= $bank['mobile_payment'] ?></p>

<div class="alert alert-info">
    Payment karke admin approval ka wait karein
</div>
