<?php
// ================= SECURITY =================
if (!isset($current_user) || $current_user['role'] !== 'admin') {
    echo "<div class='error-message'>Access denied</div>";
    return;
}

/*
EXPECTED TABLE: fee_payments
------------------------------------------------
id
student_id
fee_structure_id
amount_paid
payment_date
payment_method
transaction_id
payment_proof
status (pending|approved|rejected)
created_at
approved_by
approved_at
------------------------------------------------
*/

// ================= APPROVE =================
if (isset($_GET['approve'])) {
    $stmt = $pdo->prepare("
        UPDATE fee_payments 
        SET status='approved',
            approved_by=?,
            approved_at=NOW()
        WHERE id=?
    ");
    $stmt->execute([$current_user['id'], $_GET['approve']]);
}

// ================= REJECT =================
if (isset($_GET['reject'])) {
    $stmt = $pdo->prepare("
        UPDATE fee_payments 
        SET status='rejected'
        WHERE id=?
    ");
    $stmt->execute([$_GET['reject']]);
}

// ================= FETCH PAYMENTS =================
$payments = $pdo->query("
  UPDATE fee_payments fp
JOIN students s ON fp.student_id = s.id
SET fp.class_id = s.class_id
WHERE fp.class_id IS NULL;

")->fetchAll();
?>

<div class="card">
    <div class="card-header">
        <h2>Fee Payments (Admin Approval)</h2>
    </div>

    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th>Student</th>
                    <th>Class</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Transaction ID</th>
                    <th>Proof</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            <?php if($payments): foreach($payments as $p): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($p['student_name']) ?></strong></td>
                    <td><?= $p['class_name'].'-'.$p['section'] ?></td>
                    <td><?= $settings['currency'].number_format($p['amount_paid'],2) ?></td>
                    <td><?= ucfirst($p['payment_method']) ?></td>
                    <td><?= $p['transaction_id'] ?: '—' ?></td>

                    <td>
                        <?php if(!empty($p['payment_proof'])): ?>
                            <a href="uploads/fee_proofs/<?= $p['payment_proof'] ?>" 
                               target="_blank" class="btn btn-info btn-sm">
                                View
                            </a>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>

                    <td>
                        <span class="badge badge-<?=
                            $p['status']=='approved' ? 'success' :
                            ($p['status']=='rejected' ? 'danger' : 'warning')
                        ?>">
                            <?= ucfirst($p['status']) ?>
                        </span>
                    </td>

                    <td>
                        <?php if($p['status']=='pending'): ?>
                            <a href="?page=fees&tab=payments&approve=<?= $p['id'] ?>"
                               class="btn btn-success btn-sm">
                               Approve
                            </a>
                            <a href="?page=fees&tab=payments&reject=<?= $p['id'] ?>"
                               class="btn btn-danger btn-sm">
                               Reject
                            </a>
                        <?php else: ?>
                            —
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; else: ?>
                <tr>
                    <td colspan="8" style="text-align:center;padding:20px">
                        No fee payments found
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
