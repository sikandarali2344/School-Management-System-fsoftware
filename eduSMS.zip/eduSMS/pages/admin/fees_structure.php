<?php
// ================= SECURITY =================
if (!isset($current_user) || $current_user['role'] !== 'admin') {
    echo "<div class='error-message'>Access denied</div>";
    return;
}

// ================= ADD FEE STRUCTURE =================
if (isset($_POST['add_fee_structure'])) {

    $tuition   = $_POST['tuition_fee'];
    $transport = $_POST['transport_fee'] ?? 0;
    $hostel    = $_POST['hostel_fee'] ?? 0;
    $lab       = $_POST['lab_fee'] ?? 0;
    $sports    = $_POST['sports_fee'] ?? 0;
    $misc      = $_POST['misc_fee'] ?? 0;

    $total_fee = $tuition + $transport + $hostel + $lab + $sports + $misc;

    $stmt = $pdo->prepare("
        INSERT INTO fee_structures 
        (class_id, academic_year, tuition_fee, transport_fee, hostel_fee, lab_fee, sports_fee, misc_fee, total_fee, due_date, description)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    ");

    $stmt->execute([
        $_POST['class_id'],
        $_POST['academic_year'],
        $tuition,
        $transport,
        $hostel,
        $lab,
        $sports,
        $misc,
        $total_fee,
        $_POST['due_date'],
        $_POST['description']
    ]);

    echo "<div class='success-message'>Fee structure added successfully</div>";
}

// ================= FETCH DATA =================
$classes = $pdo->query("SELECT * FROM classes WHERE status='active'")->fetchAll();

$fees = $pdo->query("
    SELECT fs.*, c.class_name, c.section
    FROM fee_structures fs
    JOIN classes c ON c.id = fs.class_id
    ORDER BY fs.created_at DESC
")->fetchAll();

$academic_year = date('Y').'-'.(date('Y')+1);
?>

<!-- ================= FEE STRUCTURE LIST ================= -->
<div class="card">
    <div class="card-header">
        <h2>Fee Structure</h2>
        <button class="btn btn-primary" onclick="document.getElementById('feeModal').style.display='block'">
            + Add Fee
        </button>
    </div>

    <table>
        <thead>
            <tr>
                <th>Class</th>
                <th>Academic Year</th>
                <th>Total Fee</th>
                <th>Due Date</th>
            </tr>
        </thead>
        <tbody>
        <?php if($fees): foreach($fees as $f): ?>
            <tr>
                <td><?= $f['class_name'].'-'.$f['section'] ?></td>
                <td><?= $f['academic_year'] ?></td>
                <td><strong><?= $settings['currency'].number_format($f['total_fee'],2) ?></strong></td>
                <td><?= date('d M Y',strtotime($f['due_date'])) ?></td>
            </tr>
        <?php endforeach; else: ?>
            <tr><td colspan="4">No fee structure found</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<!-- ================= MODAL ================= -->
<div id="feeModal" class="modal">
<div class="modal-content">
<h3>Add Fee Structure</h3>

<form method="POST">

<select name="class_id" required>
    <option value="">Select Class</option>
    <?php foreach($classes as $c): ?>
        <option value="<?= $c['id'] ?>">
            <?= $c['class_name'].'-'.$c['section'] ?>
        </option>
    <?php endforeach; ?>
</select>

<input type="text" name="academic_year" value="<?= $academic_year ?>" required>
<input type="number" name="tuition_fee" placeholder="Tuition Fee" required>
<input type="number" name="transport_fee" placeholder="Transport Fee">
<input type="number" name="hostel_fee" placeholder="Hostel Fee">
<input type="number" name="lab_fee" placeholder="Lab Fee">
<input type="number" name="sports_fee" placeholder="Sports Fee">
<input type="number" name="misc_fee" placeholder="Misc Fee">
<input type="date" name="due_date" required>
<textarea name="description" placeholder="Description"></textarea>

<button class="btn btn-success" name="add_fee_structure">Save</button>
<button type="button" class="btn btn-secondary"
        onclick="document.getElementById('feeModal').style.display='none'">
    Cancel
</button>

</form>
</div>
</div>
