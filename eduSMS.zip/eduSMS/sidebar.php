<!-- includes/sidebar.php -->
<nav class="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-graduation-cap"></i> School System</h3>
    </div>
    
    <div class="user-info">
        <div class="user-avatar">
            <i class="fas fa-user"></i>
        </div>
        <div class="user-details">
            <h5><?php echo htmlspecialchars($current_user['name']); ?></h5>
            <small><?php echo ucfirst($current_user['role']); ?></small>
        </div>
    </div>
    
    <ul class="nav-menu">
        <?php foreach ($menu_items as $key => $item): ?>
            <li class="nav-item">
                <a href="?page=<?php echo $key; ?>" 
                   class="nav-link <?php echo ($page == $key) ? 'active' : ''; ?>">
                    <i class="<?php echo $item[1]; ?>"></i>
                    <span><?php echo $item[0]; ?></span>
                    <?php if ($key == 'notifications'): ?>
                        <?php
                        // Get unread count for notification badge
                        require_once '../notifications/notification_controller.php';
                        $controller = new NotificationController();
                        $unread = $controller->getUnreadCount($current_user['id']);
                        if ($unread > 0): ?>
                            <span class="badge bg-danger ms-auto"><?php echo $unread; ?></span>
                        <?php endif; ?>
                    <?php endif; ?>
                </a>
            </li>
        <?php endforeach; ?>
        
        <li class="nav-item">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </li>
    </ul>
</nav>